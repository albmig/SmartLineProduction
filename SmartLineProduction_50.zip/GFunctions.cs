﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SmartLineProduction
{
    class GFunctions
    {
        //public static void Provafunc()
        //{
        //    MessageBox.Show("aaa");
        //}

        public static bool LeggiConfig_SL()
        {
            int pos_x = 0;
            int pos_y = 0;
            int posdiv = 0;
            string config_text = string.Empty;

            // TJ-4120TN_SL
            config_text = Properties.Settings.Default.Settings_Brother_SL;
            posdiv = config_text.IndexOf("|");
            pos_x = Convert.ToInt32(config_text.Substring(0, posdiv));
            pos_y = Convert.ToInt32(config_text.Substring(posdiv + 1, (config_text.Length - posdiv - 1)));
            GVar.Brother_SL_pos_x = pos_x;
            GVar.Brother_SL_pos_y = pos_y;

            return true;
        }

        public static bool LeggiConfig_Antiman()
        {
            int pos_x = 0;
            int pos_y = 0;
            int posdiv = 0;
            string config_text = string.Empty;

            // TJ-4120TN_Antiman
            config_text = Properties.Settings.Default.Settings_Brother_Antiman;
            posdiv = config_text.IndexOf("|");
            pos_x = Convert.ToInt32(config_text.Substring(0, posdiv));
            pos_y = Convert.ToInt32(config_text.Substring(posdiv + 1, (config_text.Length - posdiv - 1)));
            GVar.Brother_Antiman_pos_x = pos_x;
            GVar.Brother_Antiman_pos_y = pos_y;

            return true;
        }

    }
}
