﻿namespace SmartLineProduction
{
    partial class UC_Schede
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Schede));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle49 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle50 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle51 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle52 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle53 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle54 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle55 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle56 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle57 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle58 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle59 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle60 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle61 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle62 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel_Schede = new MetroFramework.Controls.MetroPanel();
            this.Tab_Schede = new MetroFramework.Controls.MetroTabControl();
            this.tab_Kit = new System.Windows.Forms.TabPage();
            this.layout_Kit = new System.Windows.Forms.TableLayoutPanel();
            this.panel_grid_Kit = new MetroFramework.Controls.MetroPanel();
            this.gv_Kit = new MetroFramework.Controls.MetroGrid();
            this.articoloDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descrizioneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descrizioneEstesaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.modelloDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sFArticoliSchedeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.panel_search_kit = new MetroFramework.Controls.MetroPanel();
            this.tb_grid_kit = new MetroFramework.Controls.MetroTextBox();
            this.Kit_layout_pdf = new System.Windows.Forms.TableLayoutPanel();
            this.Kit_pdf_it = new AxAcroPDFLib.AxAcroPDF();
            this.Kit_pdf_en = new AxAcroPDFLib.AxAcroPDF();
            this.panel_des_art_Kit = new MetroFramework.Controls.MetroPanel();
            this.lab_des1_articolo = new MetroFramework.Controls.MetroLabel();
            this.lab_des2_articolo = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.tab_Palmari = new System.Windows.Forms.TabPage();
            this.layout_Palmari = new System.Windows.Forms.TableLayoutPanel();
            this.panel_grid_Palmari = new MetroFramework.Controls.MetroPanel();
            this.gv_Palmari = new MetroFramework.Controls.MetroGrid();
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.tb_grid_palmari = new MetroFramework.Controls.MetroTextBox();
            this.Palmari_layout_pdf = new System.Windows.Forms.TableLayoutPanel();
            this.Palmari_pdf_it = new AxAcroPDFLib.AxAcroPDF();
            this.Palmari_pdf_en = new AxAcroPDFLib.AxAcroPDF();
            this.panel_des_art_Palmari = new MetroFramework.Controls.MetroPanel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.tab_Ricevitori = new System.Windows.Forms.TabPage();
            this.layout_Ricevitori = new System.Windows.Forms.TableLayoutPanel();
            this.panel_grid_Ricevitori = new MetroFramework.Controls.MetroPanel();
            this.gv_Ricevitori = new MetroFramework.Controls.MetroGrid();
            this.metroPanel3 = new MetroFramework.Controls.MetroPanel();
            this.tb_grid_ricevitori = new MetroFramework.Controls.MetroTextBox();
            this.Ricevitori_layout_pdf = new System.Windows.Forms.TableLayoutPanel();
            this.Ricevitori_pdf_it = new AxAcroPDFLib.AxAcroPDF();
            this.Ricevitori_pdf_en = new AxAcroPDFLib.AxAcroPDF();
            this.panel_des_art_Ricevitori = new MetroFramework.Controls.MetroPanel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.tab_Cablaggi = new System.Windows.Forms.TabPage();
            this.layout_Cablaggi = new System.Windows.Forms.TableLayoutPanel();
            this.panel_grid_Cablaggi = new MetroFramework.Controls.MetroPanel();
            this.gv_Cablaggi = new MetroFramework.Controls.MetroGrid();
            this.metroPanel4 = new MetroFramework.Controls.MetroPanel();
            this.tb_grid_cablaggi = new MetroFramework.Controls.MetroTextBox();
            this.Cablaggi_layout_pdf = new System.Windows.Forms.TableLayoutPanel();
            this.Cablaggi_pdf_it = new AxAcroPDFLib.AxAcroPDF();
            this.Cablaggi_pdf_en = new AxAcroPDFLib.AxAcroPDF();
            this.panel_des_art_Cablaggi = new MetroFramework.Controls.MetroPanel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.tab_FW_P = new System.Windows.Forms.TabPage();
            this.layout_FW_P = new System.Windows.Forms.TableLayoutPanel();
            this.panel_grid_FW_P = new MetroFramework.Controls.MetroPanel();
            this.gv_FW_P = new MetroFramework.Controls.MetroGrid();
            this.panel_filter_FW__P = new MetroFramework.Controls.MetroPanel();
            this.radio_FW_P_all = new MetroFramework.Controls.MetroRadioButton();
            this.radio_FW_P_custom = new MetroFramework.Controls.MetroRadioButton();
            this.radio_FW_P_standard = new MetroFramework.Controls.MetroRadioButton();
            this.metroPanel5 = new MetroFramework.Controls.MetroPanel();
            this.tb_grid_FW_P = new MetroFramework.Controls.MetroTextBox();
            this.FW_P_layout_pdf = new System.Windows.Forms.TableLayoutPanel();
            this.FW_P_pdf_it = new AxAcroPDFLib.AxAcroPDF();
            this.FW_P_pdf_en = new AxAcroPDFLib.AxAcroPDF();
            this.panel_des_art_FW_P = new MetroFramework.Controls.MetroPanel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.tab_FW_R = new System.Windows.Forms.TabPage();
            this.layout_FW_R = new System.Windows.Forms.TableLayoutPanel();
            this.panel_grid_FW_R = new MetroFramework.Controls.MetroPanel();
            this.gv_FW_R = new MetroFramework.Controls.MetroGrid();
            this.panel_filter_FW__R = new MetroFramework.Controls.MetroPanel();
            this.radio_FW_R_all = new MetroFramework.Controls.MetroRadioButton();
            this.radio_FW_R_custom = new MetroFramework.Controls.MetroRadioButton();
            this.radio_FW_R_standard = new MetroFramework.Controls.MetroRadioButton();
            this.metroPanel6 = new MetroFramework.Controls.MetroPanel();
            this.tb_grid_FW_R = new MetroFramework.Controls.MetroTextBox();
            this.FW_R_layout_pdf = new System.Windows.Forms.TableLayoutPanel();
            this.FW_R_pdf_it = new AxAcroPDFLib.AxAcroPDF();
            this.FW_R_pdf_en = new AxAcroPDFLib.AxAcroPDF();
            this.panel_des_art_FW_R = new MetroFramework.Controls.MetroPanel();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel16 = new MetroFramework.Controls.MetroLabel();
            this.tab_pack_doc = new System.Windows.Forms.TabPage();
            this.layout_Pack = new System.Windows.Forms.TableLayoutPanel();
            this.panel_grid_pack = new MetroFramework.Controls.MetroPanel();
            this.gv_kit_pack = new MetroFramework.Controls.MetroGrid();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroPanel7 = new MetroFramework.Controls.MetroPanel();
            this.tb_grid_kit_pack = new MetroFramework.Controls.MetroTextBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.btn_do_pack_kit = new MetroFramework.Controls.MetroButton();
            this.gv_pack_explo = new MetroFramework.Controls.MetroGrid();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cb_Doc_EN = new MetroFramework.Controls.MetroCheckBox();
            this.cb_Doc_IT = new MetroFramework.Controls.MetroCheckBox();
            this.panel_pack_kit = new MetroFramework.Controls.MetroPanel();
            this.pack_Kit_pdf = new AxAcroPDFLib.AxAcroPDF();
            this.panel_des_art_Kit_pack = new MetroFramework.Controls.MetroPanel();
            this.metroLabel17 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel18 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel19 = new MetroFramework.Controls.MetroLabel();
            this.layout_orizz_menu = new System.Windows.Forms.TableLayoutPanel();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.sFDistinteBasiSchedeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.famProdBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_ArticoliSchedeTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_ArticoliSchedeTableAdapter();
            this.sF_DistinteBasi_SchedeTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_DistinteBasi_SchedeTableAdapter();
            this.fam_ProdTableAdapter = new SmartLineProduction.ds_SLTableAdapters.Fam_ProdTableAdapter();
            this.sFArticoliToXSWRSchedeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_ArticoliToXSWR_SchedeTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_ArticoliToXSWR_SchedeTableAdapter();
            this.panel_Schede.SuspendLayout();
            this.Tab_Schede.SuspendLayout();
            this.tab_Kit.SuspendLayout();
            this.layout_Kit.SuspendLayout();
            this.panel_grid_Kit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Kit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFArticoliSchedeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            this.panel_search_kit.SuspendLayout();
            this.Kit_layout_pdf.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Kit_pdf_it)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kit_pdf_en)).BeginInit();
            this.panel_des_art_Kit.SuspendLayout();
            this.tab_Palmari.SuspendLayout();
            this.layout_Palmari.SuspendLayout();
            this.panel_grid_Palmari.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Palmari)).BeginInit();
            this.metroPanel2.SuspendLayout();
            this.Palmari_layout_pdf.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Palmari_pdf_it)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Palmari_pdf_en)).BeginInit();
            this.panel_des_art_Palmari.SuspendLayout();
            this.tab_Ricevitori.SuspendLayout();
            this.layout_Ricevitori.SuspendLayout();
            this.panel_grid_Ricevitori.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Ricevitori)).BeginInit();
            this.metroPanel3.SuspendLayout();
            this.Ricevitori_layout_pdf.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Ricevitori_pdf_it)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ricevitori_pdf_en)).BeginInit();
            this.panel_des_art_Ricevitori.SuspendLayout();
            this.tab_Cablaggi.SuspendLayout();
            this.layout_Cablaggi.SuspendLayout();
            this.panel_grid_Cablaggi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Cablaggi)).BeginInit();
            this.metroPanel4.SuspendLayout();
            this.Cablaggi_layout_pdf.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Cablaggi_pdf_it)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cablaggi_pdf_en)).BeginInit();
            this.panel_des_art_Cablaggi.SuspendLayout();
            this.tab_FW_P.SuspendLayout();
            this.layout_FW_P.SuspendLayout();
            this.panel_grid_FW_P.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_FW_P)).BeginInit();
            this.panel_filter_FW__P.SuspendLayout();
            this.metroPanel5.SuspendLayout();
            this.FW_P_layout_pdf.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FW_P_pdf_it)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FW_P_pdf_en)).BeginInit();
            this.panel_des_art_FW_P.SuspendLayout();
            this.tab_FW_R.SuspendLayout();
            this.layout_FW_R.SuspendLayout();
            this.panel_grid_FW_R.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_FW_R)).BeginInit();
            this.panel_filter_FW__R.SuspendLayout();
            this.metroPanel6.SuspendLayout();
            this.FW_R_layout_pdf.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FW_R_pdf_it)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FW_R_pdf_en)).BeginInit();
            this.panel_des_art_FW_R.SuspendLayout();
            this.tab_pack_doc.SuspendLayout();
            this.layout_Pack.SuspendLayout();
            this.panel_grid_pack.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_kit_pack)).BeginInit();
            this.metroPanel7.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_pack_explo)).BeginInit();
            this.metroPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel_pack_kit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pack_Kit_pdf)).BeginInit();
            this.panel_des_art_Kit_pack.SuspendLayout();
            this.layout_orizz_menu.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sFDistinteBasiSchedeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.famProdBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFArticoliToXSWRSchedeBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_Schede
            // 
            this.panel_Schede.Controls.Add(this.Tab_Schede);
            this.panel_Schede.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Schede.HorizontalScrollbarBarColor = true;
            this.panel_Schede.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_Schede.HorizontalScrollbarSize = 10;
            this.panel_Schede.Location = new System.Drawing.Point(20, 55);
            this.panel_Schede.Name = "panel_Schede";
            this.panel_Schede.Size = new System.Drawing.Size(1560, 425);
            this.panel_Schede.TabIndex = 122;
            this.panel_Schede.VerticalScrollbarBarColor = true;
            this.panel_Schede.VerticalScrollbarHighlightOnWheel = false;
            this.panel_Schede.VerticalScrollbarSize = 10;
            // 
            // Tab_Schede
            // 
            this.Tab_Schede.Controls.Add(this.tab_Kit);
            this.Tab_Schede.Controls.Add(this.tab_Palmari);
            this.Tab_Schede.Controls.Add(this.tab_Ricevitori);
            this.Tab_Schede.Controls.Add(this.tab_Cablaggi);
            this.Tab_Schede.Controls.Add(this.tab_FW_P);
            this.Tab_Schede.Controls.Add(this.tab_FW_R);
            this.Tab_Schede.Controls.Add(this.tab_pack_doc);
            this.Tab_Schede.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Tab_Schede.ItemSize = new System.Drawing.Size(150, 34);
            this.Tab_Schede.Location = new System.Drawing.Point(0, 0);
            this.Tab_Schede.Name = "Tab_Schede";
            this.Tab_Schede.SelectedIndex = 6;
            this.Tab_Schede.Size = new System.Drawing.Size(1560, 425);
            this.Tab_Schede.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.Tab_Schede.Style = MetroFramework.MetroColorStyle.Red;
            this.Tab_Schede.TabIndex = 2;
            this.Tab_Schede.UseSelectable = true;
            this.Tab_Schede.UseStyleColors = true;
            // 
            // tab_Kit
            // 
            this.tab_Kit.Controls.Add(this.layout_Kit);
            this.tab_Kit.Location = new System.Drawing.Point(4, 38);
            this.tab_Kit.Name = "tab_Kit";
            this.tab_Kit.Size = new System.Drawing.Size(1552, 383);
            this.tab_Kit.TabIndex = 0;
            this.tab_Kit.Text = "Kit";
            this.tab_Kit.Enter += new System.EventHandler(this.tab_Kit_Enter);
            // 
            // layout_Kit
            // 
            this.layout_Kit.ColumnCount = 2;
            this.layout_Kit.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.layout_Kit.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.layout_Kit.Controls.Add(this.panel_grid_Kit, 0, 0);
            this.layout_Kit.Controls.Add(this.Kit_layout_pdf, 1, 1);
            this.layout_Kit.Controls.Add(this.panel_des_art_Kit, 1, 0);
            this.layout_Kit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Kit.Location = new System.Drawing.Point(0, 0);
            this.layout_Kit.Name = "layout_Kit";
            this.layout_Kit.RowCount = 2;
            this.layout_Kit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.layout_Kit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_Kit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Kit.Size = new System.Drawing.Size(1552, 383);
            this.layout_Kit.TabIndex = 123;
            // 
            // panel_grid_Kit
            // 
            this.panel_grid_Kit.Controls.Add(this.gv_Kit);
            this.panel_grid_Kit.Controls.Add(this.panel_search_kit);
            this.panel_grid_Kit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_grid_Kit.HorizontalScrollbarBarColor = true;
            this.panel_grid_Kit.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_grid_Kit.HorizontalScrollbarSize = 10;
            this.panel_grid_Kit.Location = new System.Drawing.Point(3, 3);
            this.panel_grid_Kit.Name = "panel_grid_Kit";
            this.layout_Kit.SetRowSpan(this.panel_grid_Kit, 2);
            this.panel_grid_Kit.Size = new System.Drawing.Size(144, 377);
            this.panel_grid_Kit.TabIndex = 83;
            this.panel_grid_Kit.VerticalScrollbarBarColor = true;
            this.panel_grid_Kit.VerticalScrollbarHighlightOnWheel = false;
            this.panel_grid_Kit.VerticalScrollbarSize = 10;
            // 
            // gv_Kit
            // 
            this.gv_Kit.AllowUserToAddRows = false;
            this.gv_Kit.AllowUserToDeleteRows = false;
            this.gv_Kit.AllowUserToResizeRows = false;
            dataGridViewCellStyle36.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_Kit.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle36;
            this.gv_Kit.AutoGenerateColumns = false;
            this.gv_Kit.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Kit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Kit.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_Kit.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle37.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle37.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle37.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle37.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Kit.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle37;
            this.gv_Kit.ColumnHeadersHeight = 40;
            this.gv_Kit.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.articoloDataGridViewTextBoxColumn,
            this.descrizioneDataGridViewTextBoxColumn,
            this.descrizioneEstesaDataGridViewTextBoxColumn,
            this.modelloDataGridViewTextBoxColumn});
            this.gv_Kit.DataSource = this.sFArticoliSchedeBindingSource;
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle38.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle38.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle38.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle38.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Kit.DefaultCellStyle = dataGridViewCellStyle38;
            this.gv_Kit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Kit.EnableHeadersVisualStyles = false;
            this.gv_Kit.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Kit.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Kit.Location = new System.Drawing.Point(0, 30);
            this.gv_Kit.MultiSelect = false;
            this.gv_Kit.Name = "gv_Kit";
            this.gv_Kit.ReadOnly = true;
            this.gv_Kit.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle39.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle39.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle39.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle39.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Kit.RowHeadersDefaultCellStyle = dataGridViewCellStyle39;
            this.gv_Kit.RowHeadersVisible = false;
            this.gv_Kit.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Kit.RowTemplate.Height = 30;
            this.gv_Kit.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Kit.Size = new System.Drawing.Size(144, 347);
            this.gv_Kit.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_Kit.TabIndex = 0;
            this.gv_Kit.UseStyleColors = true;
            // 
            // articoloDataGridViewTextBoxColumn
            // 
            this.articoloDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.articoloDataGridViewTextBoxColumn.DataPropertyName = "Articolo";
            this.articoloDataGridViewTextBoxColumn.HeaderText = "Kit";
            this.articoloDataGridViewTextBoxColumn.Name = "articoloDataGridViewTextBoxColumn";
            this.articoloDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // descrizioneDataGridViewTextBoxColumn
            // 
            this.descrizioneDataGridViewTextBoxColumn.DataPropertyName = "Descrizione";
            this.descrizioneDataGridViewTextBoxColumn.HeaderText = "Descrizione";
            this.descrizioneDataGridViewTextBoxColumn.Name = "descrizioneDataGridViewTextBoxColumn";
            this.descrizioneDataGridViewTextBoxColumn.ReadOnly = true;
            this.descrizioneDataGridViewTextBoxColumn.Visible = false;
            // 
            // descrizioneEstesaDataGridViewTextBoxColumn
            // 
            this.descrizioneEstesaDataGridViewTextBoxColumn.DataPropertyName = "DescrizioneEstesa";
            this.descrizioneEstesaDataGridViewTextBoxColumn.HeaderText = "DescrizioneEstesa";
            this.descrizioneEstesaDataGridViewTextBoxColumn.Name = "descrizioneEstesaDataGridViewTextBoxColumn";
            this.descrizioneEstesaDataGridViewTextBoxColumn.ReadOnly = true;
            this.descrizioneEstesaDataGridViewTextBoxColumn.Visible = false;
            // 
            // modelloDataGridViewTextBoxColumn
            // 
            this.modelloDataGridViewTextBoxColumn.DataPropertyName = "Modello";
            this.modelloDataGridViewTextBoxColumn.HeaderText = "Modello";
            this.modelloDataGridViewTextBoxColumn.Name = "modelloDataGridViewTextBoxColumn";
            this.modelloDataGridViewTextBoxColumn.ReadOnly = true;
            this.modelloDataGridViewTextBoxColumn.Visible = false;
            // 
            // sFArticoliSchedeBindingSource
            // 
            this.sFArticoliSchedeBindingSource.DataMember = "SF_ArticoliSchede";
            this.sFArticoliSchedeBindingSource.DataSource = this.ds_SL;
            this.sFArticoliSchedeBindingSource.CurrentChanged += new System.EventHandler(this.sFArticoliSchedeBindingSource_CurrentChanged);
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel_search_kit
            // 
            this.panel_search_kit.BackColor = System.Drawing.Color.Transparent;
            this.panel_search_kit.Controls.Add(this.tb_grid_kit);
            this.panel_search_kit.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_search_kit.HorizontalScrollbarBarColor = true;
            this.panel_search_kit.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_search_kit.HorizontalScrollbarSize = 10;
            this.panel_search_kit.Location = new System.Drawing.Point(0, 0);
            this.panel_search_kit.Name = "panel_search_kit";
            this.panel_search_kit.Size = new System.Drawing.Size(144, 30);
            this.panel_search_kit.TabIndex = 3;
            this.panel_search_kit.UseCustomBackColor = true;
            this.panel_search_kit.VerticalScrollbarBarColor = true;
            this.panel_search_kit.VerticalScrollbarHighlightOnWheel = false;
            this.panel_search_kit.VerticalScrollbarSize = 10;
            // 
            // tb_grid_kit
            // 
            // 
            // 
            // 
            this.tb_grid_kit.CustomButton.Image = null;
            this.tb_grid_kit.CustomButton.Location = new System.Drawing.Point(122, 1);
            this.tb_grid_kit.CustomButton.Name = "";
            this.tb_grid_kit.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_grid_kit.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_grid_kit.CustomButton.TabIndex = 1;
            this.tb_grid_kit.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_grid_kit.CustomButton.UseSelectable = true;
            this.tb_grid_kit.CustomButton.Visible = false;
            this.tb_grid_kit.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_grid_kit.Icon = global::SmartLineProduction.Properties.Resources.Lente;
            this.tb_grid_kit.IconRight = true;
            this.tb_grid_kit.Lines = new string[] {
        "metroTextBox1"};
            this.tb_grid_kit.Location = new System.Drawing.Point(0, 0);
            this.tb_grid_kit.MaxLength = 32767;
            this.tb_grid_kit.Name = "tb_grid_kit";
            this.tb_grid_kit.PasswordChar = '\0';
            this.tb_grid_kit.PromptText = "ricerca";
            this.tb_grid_kit.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_grid_kit.SelectedText = "";
            this.tb_grid_kit.SelectionLength = 0;
            this.tb_grid_kit.SelectionStart = 0;
            this.tb_grid_kit.ShortcutsEnabled = true;
            this.tb_grid_kit.Size = new System.Drawing.Size(144, 23);
            this.tb_grid_kit.TabIndex = 2;
            this.tb_grid_kit.Text = "metroTextBox1";
            this.tb_grid_kit.UseSelectable = true;
            this.tb_grid_kit.WaterMark = "ricerca";
            this.tb_grid_kit.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_grid_kit.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tb_grid_kit.TextChanged += new System.EventHandler(this.tb_grid_kit_TextChanged);
            // 
            // Kit_layout_pdf
            // 
            this.Kit_layout_pdf.ColumnCount = 2;
            this.Kit_layout_pdf.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.Kit_layout_pdf.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.Kit_layout_pdf.Controls.Add(this.Kit_pdf_it, 0, 0);
            this.Kit_layout_pdf.Controls.Add(this.Kit_pdf_en, 1, 0);
            this.Kit_layout_pdf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Kit_layout_pdf.Location = new System.Drawing.Point(153, 53);
            this.Kit_layout_pdf.Name = "Kit_layout_pdf";
            this.Kit_layout_pdf.RowCount = 1;
            this.Kit_layout_pdf.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.Kit_layout_pdf.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 327F));
            this.Kit_layout_pdf.Size = new System.Drawing.Size(1396, 327);
            this.Kit_layout_pdf.TabIndex = 122;
            // 
            // Kit_pdf_it
            // 
            this.Kit_pdf_it.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Kit_pdf_it.Enabled = true;
            this.Kit_pdf_it.Location = new System.Drawing.Point(3, 3);
            this.Kit_pdf_it.Name = "Kit_pdf_it";
            this.Kit_pdf_it.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Kit_pdf_it.OcxState")));
            this.Kit_pdf_it.Size = new System.Drawing.Size(692, 321);
            this.Kit_pdf_it.TabIndex = 0;
            // 
            // Kit_pdf_en
            // 
            this.Kit_pdf_en.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Kit_pdf_en.Enabled = true;
            this.Kit_pdf_en.Location = new System.Drawing.Point(701, 3);
            this.Kit_pdf_en.Name = "Kit_pdf_en";
            this.Kit_pdf_en.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Kit_pdf_en.OcxState")));
            this.Kit_pdf_en.Size = new System.Drawing.Size(692, 321);
            this.Kit_pdf_en.TabIndex = 1;
            // 
            // panel_des_art_Kit
            // 
            this.panel_des_art_Kit.Controls.Add(this.lab_des1_articolo);
            this.panel_des_art_Kit.Controls.Add(this.lab_des2_articolo);
            this.panel_des_art_Kit.Controls.Add(this.metroLabel1);
            this.panel_des_art_Kit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_des_art_Kit.HorizontalScrollbarBarColor = true;
            this.panel_des_art_Kit.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Kit.HorizontalScrollbarSize = 10;
            this.panel_des_art_Kit.Location = new System.Drawing.Point(153, 3);
            this.panel_des_art_Kit.Name = "panel_des_art_Kit";
            this.panel_des_art_Kit.Size = new System.Drawing.Size(1396, 44);
            this.panel_des_art_Kit.TabIndex = 1;
            this.panel_des_art_Kit.VerticalScrollbarBarColor = true;
            this.panel_des_art_Kit.VerticalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Kit.VerticalScrollbarSize = 10;
            // 
            // lab_des1_articolo
            // 
            this.lab_des1_articolo.AutoSize = true;
            this.lab_des1_articolo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFArticoliSchedeBindingSource, "Descrizione", true));
            this.lab_des1_articolo.Location = new System.Drawing.Point(93, 0);
            this.lab_des1_articolo.Name = "lab_des1_articolo";
            this.lab_des1_articolo.Size = new System.Drawing.Size(41, 19);
            this.lab_des1_articolo.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_des1_articolo.TabIndex = 3;
            this.lab_des1_articolo.Text = "Des_1";
            this.lab_des1_articolo.UseStyleColors = true;
            // 
            // lab_des2_articolo
            // 
            this.lab_des2_articolo.AutoSize = true;
            this.lab_des2_articolo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFArticoliSchedeBindingSource, "DescrizioneEstesa", true));
            this.lab_des2_articolo.Location = new System.Drawing.Point(93, 19);
            this.lab_des2_articolo.Name = "lab_des2_articolo";
            this.lab_des2_articolo.Size = new System.Drawing.Size(43, 19);
            this.lab_des2_articolo.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_des2_articolo.TabIndex = 4;
            this.lab_des2_articolo.Text = "Des_2";
            this.lab_des2_articolo.UseStyleColors = true;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(3, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(75, 19);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "Descrizione";
            // 
            // tab_Palmari
            // 
            this.tab_Palmari.Controls.Add(this.layout_Palmari);
            this.tab_Palmari.Location = new System.Drawing.Point(4, 38);
            this.tab_Palmari.Name = "tab_Palmari";
            this.tab_Palmari.Size = new System.Drawing.Size(1552, 383);
            this.tab_Palmari.TabIndex = 1;
            this.tab_Palmari.Text = "Palmari";
            // 
            // layout_Palmari
            // 
            this.layout_Palmari.ColumnCount = 2;
            this.layout_Palmari.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.layout_Palmari.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.layout_Palmari.Controls.Add(this.panel_grid_Palmari, 0, 0);
            this.layout_Palmari.Controls.Add(this.Palmari_layout_pdf, 1, 1);
            this.layout_Palmari.Controls.Add(this.panel_des_art_Palmari, 1, 0);
            this.layout_Palmari.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Palmari.Location = new System.Drawing.Point(0, 0);
            this.layout_Palmari.Name = "layout_Palmari";
            this.layout_Palmari.RowCount = 2;
            this.layout_Palmari.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.layout_Palmari.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_Palmari.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Palmari.Size = new System.Drawing.Size(1552, 383);
            this.layout_Palmari.TabIndex = 124;
            // 
            // panel_grid_Palmari
            // 
            this.panel_grid_Palmari.Controls.Add(this.gv_Palmari);
            this.panel_grid_Palmari.Controls.Add(this.metroPanel2);
            this.panel_grid_Palmari.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_grid_Palmari.HorizontalScrollbarBarColor = true;
            this.panel_grid_Palmari.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_grid_Palmari.HorizontalScrollbarSize = 10;
            this.panel_grid_Palmari.Location = new System.Drawing.Point(3, 3);
            this.panel_grid_Palmari.Name = "panel_grid_Palmari";
            this.layout_Palmari.SetRowSpan(this.panel_grid_Palmari, 2);
            this.panel_grid_Palmari.Size = new System.Drawing.Size(144, 377);
            this.panel_grid_Palmari.TabIndex = 83;
            this.panel_grid_Palmari.VerticalScrollbarBarColor = true;
            this.panel_grid_Palmari.VerticalScrollbarHighlightOnWheel = false;
            this.panel_grid_Palmari.VerticalScrollbarSize = 10;
            // 
            // gv_Palmari
            // 
            this.gv_Palmari.AllowUserToAddRows = false;
            this.gv_Palmari.AllowUserToDeleteRows = false;
            this.gv_Palmari.AllowUserToResizeRows = false;
            dataGridViewCellStyle40.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_Palmari.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle40;
            this.gv_Palmari.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Palmari.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Palmari.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_Palmari.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle41.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle41.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle41.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle41.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle41.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Palmari.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle41;
            this.gv_Palmari.ColumnHeadersHeight = 40;
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle42.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle42.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle42.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle42.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Palmari.DefaultCellStyle = dataGridViewCellStyle42;
            this.gv_Palmari.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Palmari.EnableHeadersVisualStyles = false;
            this.gv_Palmari.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Palmari.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Palmari.Location = new System.Drawing.Point(0, 30);
            this.gv_Palmari.MultiSelect = false;
            this.gv_Palmari.Name = "gv_Palmari";
            this.gv_Palmari.ReadOnly = true;
            this.gv_Palmari.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle43.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle43.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle43.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle43.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle43.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Palmari.RowHeadersDefaultCellStyle = dataGridViewCellStyle43;
            this.gv_Palmari.RowHeadersVisible = false;
            this.gv_Palmari.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Palmari.RowTemplate.Height = 30;
            this.gv_Palmari.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Palmari.Size = new System.Drawing.Size(144, 347);
            this.gv_Palmari.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_Palmari.TabIndex = 0;
            this.gv_Palmari.UseStyleColors = true;
            // 
            // metroPanel2
            // 
            this.metroPanel2.BackColor = System.Drawing.Color.Transparent;
            this.metroPanel2.Controls.Add(this.tb_grid_palmari);
            this.metroPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroPanel2.HorizontalScrollbarBarColor = true;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 10;
            this.metroPanel2.Location = new System.Drawing.Point(0, 0);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(144, 30);
            this.metroPanel2.TabIndex = 3;
            this.metroPanel2.UseCustomBackColor = true;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 10;
            // 
            // tb_grid_palmari
            // 
            // 
            // 
            // 
            this.tb_grid_palmari.CustomButton.Image = null;
            this.tb_grid_palmari.CustomButton.Location = new System.Drawing.Point(122, 1);
            this.tb_grid_palmari.CustomButton.Name = "";
            this.tb_grid_palmari.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_grid_palmari.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_grid_palmari.CustomButton.TabIndex = 1;
            this.tb_grid_palmari.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_grid_palmari.CustomButton.UseSelectable = true;
            this.tb_grid_palmari.CustomButton.Visible = false;
            this.tb_grid_palmari.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_grid_palmari.Icon = global::SmartLineProduction.Properties.Resources.Lente;
            this.tb_grid_palmari.IconRight = true;
            this.tb_grid_palmari.Lines = new string[] {
        "metroTextBox1"};
            this.tb_grid_palmari.Location = new System.Drawing.Point(0, 0);
            this.tb_grid_palmari.MaxLength = 32767;
            this.tb_grid_palmari.Name = "tb_grid_palmari";
            this.tb_grid_palmari.PasswordChar = '\0';
            this.tb_grid_palmari.PromptText = "ricerca";
            this.tb_grid_palmari.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_grid_palmari.SelectedText = "";
            this.tb_grid_palmari.SelectionLength = 0;
            this.tb_grid_palmari.SelectionStart = 0;
            this.tb_grid_palmari.ShortcutsEnabled = true;
            this.tb_grid_palmari.Size = new System.Drawing.Size(144, 23);
            this.tb_grid_palmari.TabIndex = 2;
            this.tb_grid_palmari.Text = "metroTextBox1";
            this.tb_grid_palmari.UseSelectable = true;
            this.tb_grid_palmari.WaterMark = "ricerca";
            this.tb_grid_palmari.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_grid_palmari.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Palmari_layout_pdf
            // 
            this.Palmari_layout_pdf.ColumnCount = 2;
            this.Palmari_layout_pdf.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.Palmari_layout_pdf.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.Palmari_layout_pdf.Controls.Add(this.Palmari_pdf_it, 0, 0);
            this.Palmari_layout_pdf.Controls.Add(this.Palmari_pdf_en, 1, 0);
            this.Palmari_layout_pdf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Palmari_layout_pdf.Location = new System.Drawing.Point(153, 53);
            this.Palmari_layout_pdf.Name = "Palmari_layout_pdf";
            this.Palmari_layout_pdf.RowCount = 1;
            this.Palmari_layout_pdf.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.Palmari_layout_pdf.Size = new System.Drawing.Size(1396, 327);
            this.Palmari_layout_pdf.TabIndex = 84;
            // 
            // Palmari_pdf_it
            // 
            this.Palmari_pdf_it.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Palmari_pdf_it.Enabled = true;
            this.Palmari_pdf_it.Location = new System.Drawing.Point(3, 3);
            this.Palmari_pdf_it.Name = "Palmari_pdf_it";
            this.Palmari_pdf_it.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Palmari_pdf_it.OcxState")));
            this.Palmari_pdf_it.Size = new System.Drawing.Size(692, 321);
            this.Palmari_pdf_it.TabIndex = 0;
            // 
            // Palmari_pdf_en
            // 
            this.Palmari_pdf_en.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Palmari_pdf_en.Enabled = true;
            this.Palmari_pdf_en.Location = new System.Drawing.Point(701, 3);
            this.Palmari_pdf_en.Name = "Palmari_pdf_en";
            this.Palmari_pdf_en.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Palmari_pdf_en.OcxState")));
            this.Palmari_pdf_en.Size = new System.Drawing.Size(692, 321);
            this.Palmari_pdf_en.TabIndex = 1;
            // 
            // panel_des_art_Palmari
            // 
            this.panel_des_art_Palmari.Controls.Add(this.metroLabel2);
            this.panel_des_art_Palmari.Controls.Add(this.metroLabel3);
            this.panel_des_art_Palmari.Controls.Add(this.metroLabel4);
            this.panel_des_art_Palmari.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_des_art_Palmari.HorizontalScrollbarBarColor = true;
            this.panel_des_art_Palmari.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Palmari.HorizontalScrollbarSize = 10;
            this.panel_des_art_Palmari.Location = new System.Drawing.Point(153, 3);
            this.panel_des_art_Palmari.Name = "panel_des_art_Palmari";
            this.panel_des_art_Palmari.Size = new System.Drawing.Size(1396, 44);
            this.panel_des_art_Palmari.TabIndex = 1;
            this.panel_des_art_Palmari.VerticalScrollbarBarColor = true;
            this.panel_des_art_Palmari.VerticalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Palmari.VerticalScrollbarSize = 10;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(93, 0);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(41, 19);
            this.metroLabel2.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel2.TabIndex = 3;
            this.metroLabel2.Text = "Des_1";
            this.metroLabel2.UseStyleColors = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(93, 19);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(43, 19);
            this.metroLabel3.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel3.TabIndex = 4;
            this.metroLabel3.Text = "Des_2";
            this.metroLabel3.UseStyleColors = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(3, 0);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(75, 19);
            this.metroLabel4.TabIndex = 2;
            this.metroLabel4.Text = "Descrizione";
            // 
            // tab_Ricevitori
            // 
            this.tab_Ricevitori.Controls.Add(this.layout_Ricevitori);
            this.tab_Ricevitori.Location = new System.Drawing.Point(4, 38);
            this.tab_Ricevitori.Name = "tab_Ricevitori";
            this.tab_Ricevitori.Size = new System.Drawing.Size(1552, 383);
            this.tab_Ricevitori.TabIndex = 2;
            this.tab_Ricevitori.Text = "Ricevitori";
            // 
            // layout_Ricevitori
            // 
            this.layout_Ricevitori.ColumnCount = 2;
            this.layout_Ricevitori.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.layout_Ricevitori.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.layout_Ricevitori.Controls.Add(this.panel_grid_Ricevitori, 0, 0);
            this.layout_Ricevitori.Controls.Add(this.Ricevitori_layout_pdf, 1, 1);
            this.layout_Ricevitori.Controls.Add(this.panel_des_art_Ricevitori, 1, 0);
            this.layout_Ricevitori.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Ricevitori.Location = new System.Drawing.Point(0, 0);
            this.layout_Ricevitori.Name = "layout_Ricevitori";
            this.layout_Ricevitori.RowCount = 2;
            this.layout_Ricevitori.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.layout_Ricevitori.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_Ricevitori.Size = new System.Drawing.Size(1552, 383);
            this.layout_Ricevitori.TabIndex = 125;
            // 
            // panel_grid_Ricevitori
            // 
            this.panel_grid_Ricevitori.Controls.Add(this.gv_Ricevitori);
            this.panel_grid_Ricevitori.Controls.Add(this.metroPanel3);
            this.panel_grid_Ricevitori.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_grid_Ricevitori.HorizontalScrollbarBarColor = true;
            this.panel_grid_Ricevitori.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_grid_Ricevitori.HorizontalScrollbarSize = 10;
            this.panel_grid_Ricevitori.Location = new System.Drawing.Point(3, 3);
            this.panel_grid_Ricevitori.Name = "panel_grid_Ricevitori";
            this.layout_Ricevitori.SetRowSpan(this.panel_grid_Ricevitori, 2);
            this.panel_grid_Ricevitori.Size = new System.Drawing.Size(144, 377);
            this.panel_grid_Ricevitori.TabIndex = 83;
            this.panel_grid_Ricevitori.VerticalScrollbarBarColor = true;
            this.panel_grid_Ricevitori.VerticalScrollbarHighlightOnWheel = false;
            this.panel_grid_Ricevitori.VerticalScrollbarSize = 10;
            // 
            // gv_Ricevitori
            // 
            this.gv_Ricevitori.AllowUserToAddRows = false;
            this.gv_Ricevitori.AllowUserToDeleteRows = false;
            this.gv_Ricevitori.AllowUserToResizeRows = false;
            dataGridViewCellStyle44.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_Ricevitori.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle44;
            this.gv_Ricevitori.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Ricevitori.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Ricevitori.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_Ricevitori.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle45.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle45.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle45.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle45.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle45.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Ricevitori.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle45;
            this.gv_Ricevitori.ColumnHeadersHeight = 40;
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle46.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle46.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle46.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle46.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle46.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Ricevitori.DefaultCellStyle = dataGridViewCellStyle46;
            this.gv_Ricevitori.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Ricevitori.EnableHeadersVisualStyles = false;
            this.gv_Ricevitori.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Ricevitori.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Ricevitori.Location = new System.Drawing.Point(0, 30);
            this.gv_Ricevitori.MultiSelect = false;
            this.gv_Ricevitori.Name = "gv_Ricevitori";
            this.gv_Ricevitori.ReadOnly = true;
            this.gv_Ricevitori.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle47.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle47.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle47.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Ricevitori.RowHeadersDefaultCellStyle = dataGridViewCellStyle47;
            this.gv_Ricevitori.RowHeadersVisible = false;
            this.gv_Ricevitori.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Ricevitori.RowTemplate.Height = 30;
            this.gv_Ricevitori.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Ricevitori.Size = new System.Drawing.Size(144, 347);
            this.gv_Ricevitori.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_Ricevitori.TabIndex = 0;
            this.gv_Ricevitori.UseStyleColors = true;
            // 
            // metroPanel3
            // 
            this.metroPanel3.BackColor = System.Drawing.Color.Transparent;
            this.metroPanel3.Controls.Add(this.tb_grid_ricevitori);
            this.metroPanel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroPanel3.HorizontalScrollbarBarColor = true;
            this.metroPanel3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel3.HorizontalScrollbarSize = 10;
            this.metroPanel3.Location = new System.Drawing.Point(0, 0);
            this.metroPanel3.Name = "metroPanel3";
            this.metroPanel3.Size = new System.Drawing.Size(144, 30);
            this.metroPanel3.TabIndex = 3;
            this.metroPanel3.UseCustomBackColor = true;
            this.metroPanel3.VerticalScrollbarBarColor = true;
            this.metroPanel3.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel3.VerticalScrollbarSize = 10;
            // 
            // tb_grid_ricevitori
            // 
            // 
            // 
            // 
            this.tb_grid_ricevitori.CustomButton.Image = null;
            this.tb_grid_ricevitori.CustomButton.Location = new System.Drawing.Point(122, 1);
            this.tb_grid_ricevitori.CustomButton.Name = "";
            this.tb_grid_ricevitori.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_grid_ricevitori.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_grid_ricevitori.CustomButton.TabIndex = 1;
            this.tb_grid_ricevitori.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_grid_ricevitori.CustomButton.UseSelectable = true;
            this.tb_grid_ricevitori.CustomButton.Visible = false;
            this.tb_grid_ricevitori.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_grid_ricevitori.Icon = global::SmartLineProduction.Properties.Resources.Lente;
            this.tb_grid_ricevitori.IconRight = true;
            this.tb_grid_ricevitori.Lines = new string[] {
        "metroTextBox1"};
            this.tb_grid_ricevitori.Location = new System.Drawing.Point(0, 0);
            this.tb_grid_ricevitori.MaxLength = 32767;
            this.tb_grid_ricevitori.Name = "tb_grid_ricevitori";
            this.tb_grid_ricevitori.PasswordChar = '\0';
            this.tb_grid_ricevitori.PromptText = "ricerca";
            this.tb_grid_ricevitori.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_grid_ricevitori.SelectedText = "";
            this.tb_grid_ricevitori.SelectionLength = 0;
            this.tb_grid_ricevitori.SelectionStart = 0;
            this.tb_grid_ricevitori.ShortcutsEnabled = true;
            this.tb_grid_ricevitori.Size = new System.Drawing.Size(144, 23);
            this.tb_grid_ricevitori.TabIndex = 2;
            this.tb_grid_ricevitori.Text = "metroTextBox1";
            this.tb_grid_ricevitori.UseSelectable = true;
            this.tb_grid_ricevitori.WaterMark = "ricerca";
            this.tb_grid_ricevitori.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_grid_ricevitori.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Ricevitori_layout_pdf
            // 
            this.Ricevitori_layout_pdf.ColumnCount = 2;
            this.Ricevitori_layout_pdf.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.Ricevitori_layout_pdf.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.Ricevitori_layout_pdf.Controls.Add(this.Ricevitori_pdf_it, 0, 0);
            this.Ricevitori_layout_pdf.Controls.Add(this.Ricevitori_pdf_en, 1, 0);
            this.Ricevitori_layout_pdf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Ricevitori_layout_pdf.Location = new System.Drawing.Point(153, 53);
            this.Ricevitori_layout_pdf.Name = "Ricevitori_layout_pdf";
            this.Ricevitori_layout_pdf.RowCount = 1;
            this.Ricevitori_layout_pdf.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.Ricevitori_layout_pdf.Size = new System.Drawing.Size(1396, 327);
            this.Ricevitori_layout_pdf.TabIndex = 84;
            // 
            // Ricevitori_pdf_it
            // 
            this.Ricevitori_pdf_it.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Ricevitori_pdf_it.Enabled = true;
            this.Ricevitori_pdf_it.Location = new System.Drawing.Point(3, 3);
            this.Ricevitori_pdf_it.Name = "Ricevitori_pdf_it";
            this.Ricevitori_pdf_it.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Ricevitori_pdf_it.OcxState")));
            this.Ricevitori_pdf_it.Size = new System.Drawing.Size(692, 321);
            this.Ricevitori_pdf_it.TabIndex = 1;
            // 
            // Ricevitori_pdf_en
            // 
            this.Ricevitori_pdf_en.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Ricevitori_pdf_en.Enabled = true;
            this.Ricevitori_pdf_en.Location = new System.Drawing.Point(701, 3);
            this.Ricevitori_pdf_en.Name = "Ricevitori_pdf_en";
            this.Ricevitori_pdf_en.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Ricevitori_pdf_en.OcxState")));
            this.Ricevitori_pdf_en.Size = new System.Drawing.Size(692, 321);
            this.Ricevitori_pdf_en.TabIndex = 0;
            // 
            // panel_des_art_Ricevitori
            // 
            this.panel_des_art_Ricevitori.Controls.Add(this.metroLabel5);
            this.panel_des_art_Ricevitori.Controls.Add(this.metroLabel6);
            this.panel_des_art_Ricevitori.Controls.Add(this.metroLabel7);
            this.panel_des_art_Ricevitori.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_des_art_Ricevitori.HorizontalScrollbarBarColor = true;
            this.panel_des_art_Ricevitori.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Ricevitori.HorizontalScrollbarSize = 10;
            this.panel_des_art_Ricevitori.Location = new System.Drawing.Point(153, 3);
            this.panel_des_art_Ricevitori.Name = "panel_des_art_Ricevitori";
            this.panel_des_art_Ricevitori.Size = new System.Drawing.Size(1396, 44);
            this.panel_des_art_Ricevitori.TabIndex = 1;
            this.panel_des_art_Ricevitori.VerticalScrollbarBarColor = true;
            this.panel_des_art_Ricevitori.VerticalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Ricevitori.VerticalScrollbarSize = 10;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(93, 0);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(41, 19);
            this.metroLabel5.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel5.TabIndex = 3;
            this.metroLabel5.Text = "Des_1";
            this.metroLabel5.UseStyleColors = true;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(93, 19);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(43, 19);
            this.metroLabel6.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel6.TabIndex = 4;
            this.metroLabel6.Text = "Des_2";
            this.metroLabel6.UseStyleColors = true;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(3, 0);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(75, 19);
            this.metroLabel7.TabIndex = 2;
            this.metroLabel7.Text = "Descrizione";
            // 
            // tab_Cablaggi
            // 
            this.tab_Cablaggi.Controls.Add(this.layout_Cablaggi);
            this.tab_Cablaggi.Location = new System.Drawing.Point(4, 38);
            this.tab_Cablaggi.Name = "tab_Cablaggi";
            this.tab_Cablaggi.Size = new System.Drawing.Size(1552, 383);
            this.tab_Cablaggi.TabIndex = 3;
            this.tab_Cablaggi.Text = "Cablaggi";
            // 
            // layout_Cablaggi
            // 
            this.layout_Cablaggi.ColumnCount = 2;
            this.layout_Cablaggi.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.layout_Cablaggi.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.layout_Cablaggi.Controls.Add(this.panel_grid_Cablaggi, 0, 0);
            this.layout_Cablaggi.Controls.Add(this.Cablaggi_layout_pdf, 1, 1);
            this.layout_Cablaggi.Controls.Add(this.panel_des_art_Cablaggi, 1, 0);
            this.layout_Cablaggi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Cablaggi.Location = new System.Drawing.Point(0, 0);
            this.layout_Cablaggi.Name = "layout_Cablaggi";
            this.layout_Cablaggi.RowCount = 2;
            this.layout_Cablaggi.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.layout_Cablaggi.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_Cablaggi.Size = new System.Drawing.Size(1552, 383);
            this.layout_Cablaggi.TabIndex = 126;
            // 
            // panel_grid_Cablaggi
            // 
            this.panel_grid_Cablaggi.Controls.Add(this.gv_Cablaggi);
            this.panel_grid_Cablaggi.Controls.Add(this.metroPanel4);
            this.panel_grid_Cablaggi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_grid_Cablaggi.HorizontalScrollbarBarColor = true;
            this.panel_grid_Cablaggi.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_grid_Cablaggi.HorizontalScrollbarSize = 10;
            this.panel_grid_Cablaggi.Location = new System.Drawing.Point(3, 3);
            this.panel_grid_Cablaggi.Name = "panel_grid_Cablaggi";
            this.layout_Cablaggi.SetRowSpan(this.panel_grid_Cablaggi, 2);
            this.panel_grid_Cablaggi.Size = new System.Drawing.Size(144, 377);
            this.panel_grid_Cablaggi.TabIndex = 83;
            this.panel_grid_Cablaggi.VerticalScrollbarBarColor = true;
            this.panel_grid_Cablaggi.VerticalScrollbarHighlightOnWheel = false;
            this.panel_grid_Cablaggi.VerticalScrollbarSize = 10;
            // 
            // gv_Cablaggi
            // 
            this.gv_Cablaggi.AllowUserToAddRows = false;
            this.gv_Cablaggi.AllowUserToDeleteRows = false;
            this.gv_Cablaggi.AllowUserToResizeRows = false;
            dataGridViewCellStyle48.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_Cablaggi.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle48;
            this.gv_Cablaggi.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Cablaggi.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Cablaggi.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_Cablaggi.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle49.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle49.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle49.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle49.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle49.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Cablaggi.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle49;
            this.gv_Cablaggi.ColumnHeadersHeight = 40;
            dataGridViewCellStyle50.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle50.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle50.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle50.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle50.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle50.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Cablaggi.DefaultCellStyle = dataGridViewCellStyle50;
            this.gv_Cablaggi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Cablaggi.EnableHeadersVisualStyles = false;
            this.gv_Cablaggi.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Cablaggi.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Cablaggi.Location = new System.Drawing.Point(0, 30);
            this.gv_Cablaggi.MultiSelect = false;
            this.gv_Cablaggi.Name = "gv_Cablaggi";
            this.gv_Cablaggi.ReadOnly = true;
            this.gv_Cablaggi.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle51.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle51.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle51.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle51.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle51.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Cablaggi.RowHeadersDefaultCellStyle = dataGridViewCellStyle51;
            this.gv_Cablaggi.RowHeadersVisible = false;
            this.gv_Cablaggi.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Cablaggi.RowTemplate.Height = 30;
            this.gv_Cablaggi.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Cablaggi.Size = new System.Drawing.Size(144, 347);
            this.gv_Cablaggi.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_Cablaggi.TabIndex = 0;
            this.gv_Cablaggi.UseStyleColors = true;
            // 
            // metroPanel4
            // 
            this.metroPanel4.BackColor = System.Drawing.Color.Transparent;
            this.metroPanel4.Controls.Add(this.tb_grid_cablaggi);
            this.metroPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroPanel4.HorizontalScrollbarBarColor = true;
            this.metroPanel4.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel4.HorizontalScrollbarSize = 10;
            this.metroPanel4.Location = new System.Drawing.Point(0, 0);
            this.metroPanel4.Name = "metroPanel4";
            this.metroPanel4.Size = new System.Drawing.Size(144, 30);
            this.metroPanel4.TabIndex = 3;
            this.metroPanel4.UseCustomBackColor = true;
            this.metroPanel4.VerticalScrollbarBarColor = true;
            this.metroPanel4.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel4.VerticalScrollbarSize = 10;
            // 
            // tb_grid_cablaggi
            // 
            // 
            // 
            // 
            this.tb_grid_cablaggi.CustomButton.Image = null;
            this.tb_grid_cablaggi.CustomButton.Location = new System.Drawing.Point(122, 1);
            this.tb_grid_cablaggi.CustomButton.Name = "";
            this.tb_grid_cablaggi.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_grid_cablaggi.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_grid_cablaggi.CustomButton.TabIndex = 1;
            this.tb_grid_cablaggi.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_grid_cablaggi.CustomButton.UseSelectable = true;
            this.tb_grid_cablaggi.CustomButton.Visible = false;
            this.tb_grid_cablaggi.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_grid_cablaggi.Icon = global::SmartLineProduction.Properties.Resources.Lente;
            this.tb_grid_cablaggi.IconRight = true;
            this.tb_grid_cablaggi.Lines = new string[] {
        "metroTextBox1"};
            this.tb_grid_cablaggi.Location = new System.Drawing.Point(0, 0);
            this.tb_grid_cablaggi.MaxLength = 32767;
            this.tb_grid_cablaggi.Name = "tb_grid_cablaggi";
            this.tb_grid_cablaggi.PasswordChar = '\0';
            this.tb_grid_cablaggi.PromptText = "ricerca";
            this.tb_grid_cablaggi.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_grid_cablaggi.SelectedText = "";
            this.tb_grid_cablaggi.SelectionLength = 0;
            this.tb_grid_cablaggi.SelectionStart = 0;
            this.tb_grid_cablaggi.ShortcutsEnabled = true;
            this.tb_grid_cablaggi.Size = new System.Drawing.Size(144, 23);
            this.tb_grid_cablaggi.TabIndex = 2;
            this.tb_grid_cablaggi.Text = "metroTextBox1";
            this.tb_grid_cablaggi.UseSelectable = true;
            this.tb_grid_cablaggi.WaterMark = "ricerca";
            this.tb_grid_cablaggi.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_grid_cablaggi.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Cablaggi_layout_pdf
            // 
            this.Cablaggi_layout_pdf.ColumnCount = 2;
            this.Cablaggi_layout_pdf.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.Cablaggi_layout_pdf.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.Cablaggi_layout_pdf.Controls.Add(this.Cablaggi_pdf_it, 0, 0);
            this.Cablaggi_layout_pdf.Controls.Add(this.Cablaggi_pdf_en, 1, 0);
            this.Cablaggi_layout_pdf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Cablaggi_layout_pdf.Location = new System.Drawing.Point(153, 53);
            this.Cablaggi_layout_pdf.Name = "Cablaggi_layout_pdf";
            this.Cablaggi_layout_pdf.RowCount = 1;
            this.Cablaggi_layout_pdf.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.Cablaggi_layout_pdf.Size = new System.Drawing.Size(1396, 327);
            this.Cablaggi_layout_pdf.TabIndex = 84;
            // 
            // Cablaggi_pdf_it
            // 
            this.Cablaggi_pdf_it.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Cablaggi_pdf_it.Enabled = true;
            this.Cablaggi_pdf_it.Location = new System.Drawing.Point(3, 3);
            this.Cablaggi_pdf_it.Name = "Cablaggi_pdf_it";
            this.Cablaggi_pdf_it.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Cablaggi_pdf_it.OcxState")));
            this.Cablaggi_pdf_it.Size = new System.Drawing.Size(692, 321);
            this.Cablaggi_pdf_it.TabIndex = 0;
            // 
            // Cablaggi_pdf_en
            // 
            this.Cablaggi_pdf_en.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Cablaggi_pdf_en.Enabled = true;
            this.Cablaggi_pdf_en.Location = new System.Drawing.Point(701, 3);
            this.Cablaggi_pdf_en.Name = "Cablaggi_pdf_en";
            this.Cablaggi_pdf_en.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Cablaggi_pdf_en.OcxState")));
            this.Cablaggi_pdf_en.Size = new System.Drawing.Size(692, 321);
            this.Cablaggi_pdf_en.TabIndex = 1;
            // 
            // panel_des_art_Cablaggi
            // 
            this.panel_des_art_Cablaggi.Controls.Add(this.metroLabel8);
            this.panel_des_art_Cablaggi.Controls.Add(this.metroLabel9);
            this.panel_des_art_Cablaggi.Controls.Add(this.metroLabel10);
            this.panel_des_art_Cablaggi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_des_art_Cablaggi.HorizontalScrollbarBarColor = true;
            this.panel_des_art_Cablaggi.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Cablaggi.HorizontalScrollbarSize = 10;
            this.panel_des_art_Cablaggi.Location = new System.Drawing.Point(153, 3);
            this.panel_des_art_Cablaggi.Name = "panel_des_art_Cablaggi";
            this.panel_des_art_Cablaggi.Size = new System.Drawing.Size(1396, 44);
            this.panel_des_art_Cablaggi.TabIndex = 1;
            this.panel_des_art_Cablaggi.VerticalScrollbarBarColor = true;
            this.panel_des_art_Cablaggi.VerticalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Cablaggi.VerticalScrollbarSize = 10;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(93, 0);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(41, 19);
            this.metroLabel8.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel8.TabIndex = 3;
            this.metroLabel8.Text = "Des_1";
            this.metroLabel8.UseStyleColors = true;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(93, 19);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(43, 19);
            this.metroLabel9.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel9.TabIndex = 4;
            this.metroLabel9.Text = "Des_2";
            this.metroLabel9.UseStyleColors = true;
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.Location = new System.Drawing.Point(3, 0);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(75, 19);
            this.metroLabel10.TabIndex = 2;
            this.metroLabel10.Text = "Descrizione";
            // 
            // tab_FW_P
            // 
            this.tab_FW_P.Controls.Add(this.layout_FW_P);
            this.tab_FW_P.Location = new System.Drawing.Point(4, 38);
            this.tab_FW_P.Name = "tab_FW_P";
            this.tab_FW_P.Size = new System.Drawing.Size(1552, 383);
            this.tab_FW_P.TabIndex = 4;
            this.tab_FW_P.Text = "Firmware Palmari";
            // 
            // layout_FW_P
            // 
            this.layout_FW_P.ColumnCount = 2;
            this.layout_FW_P.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.layout_FW_P.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.layout_FW_P.Controls.Add(this.panel_grid_FW_P, 0, 0);
            this.layout_FW_P.Controls.Add(this.FW_P_layout_pdf, 1, 1);
            this.layout_FW_P.Controls.Add(this.panel_des_art_FW_P, 1, 0);
            this.layout_FW_P.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_FW_P.Location = new System.Drawing.Point(0, 0);
            this.layout_FW_P.Name = "layout_FW_P";
            this.layout_FW_P.RowCount = 2;
            this.layout_FW_P.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.layout_FW_P.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_FW_P.Size = new System.Drawing.Size(1552, 383);
            this.layout_FW_P.TabIndex = 127;
            // 
            // panel_grid_FW_P
            // 
            this.panel_grid_FW_P.Controls.Add(this.gv_FW_P);
            this.panel_grid_FW_P.Controls.Add(this.panel_filter_FW__P);
            this.panel_grid_FW_P.Controls.Add(this.metroPanel5);
            this.panel_grid_FW_P.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_grid_FW_P.HorizontalScrollbarBarColor = true;
            this.panel_grid_FW_P.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_grid_FW_P.HorizontalScrollbarSize = 10;
            this.panel_grid_FW_P.Location = new System.Drawing.Point(3, 3);
            this.panel_grid_FW_P.Name = "panel_grid_FW_P";
            this.layout_FW_P.SetRowSpan(this.panel_grid_FW_P, 2);
            this.panel_grid_FW_P.Size = new System.Drawing.Size(144, 377);
            this.panel_grid_FW_P.TabIndex = 83;
            this.panel_grid_FW_P.VerticalScrollbarBarColor = true;
            this.panel_grid_FW_P.VerticalScrollbarHighlightOnWheel = false;
            this.panel_grid_FW_P.VerticalScrollbarSize = 10;
            // 
            // gv_FW_P
            // 
            this.gv_FW_P.AllowUserToAddRows = false;
            this.gv_FW_P.AllowUserToDeleteRows = false;
            this.gv_FW_P.AllowUserToResizeRows = false;
            dataGridViewCellStyle52.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_FW_P.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle52;
            this.gv_FW_P.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_FW_P.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_FW_P.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_FW_P.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle53.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle53.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle53.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle53.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle53.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_FW_P.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle53;
            this.gv_FW_P.ColumnHeadersHeight = 40;
            dataGridViewCellStyle54.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle54.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle54.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle54.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle54.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle54.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_FW_P.DefaultCellStyle = dataGridViewCellStyle54;
            this.gv_FW_P.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_FW_P.EnableHeadersVisualStyles = false;
            this.gv_FW_P.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_FW_P.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_FW_P.Location = new System.Drawing.Point(0, 101);
            this.gv_FW_P.MultiSelect = false;
            this.gv_FW_P.Name = "gv_FW_P";
            this.gv_FW_P.ReadOnly = true;
            this.gv_FW_P.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle55.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle55.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle55.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle55.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle55.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle55.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_FW_P.RowHeadersDefaultCellStyle = dataGridViewCellStyle55;
            this.gv_FW_P.RowHeadersVisible = false;
            this.gv_FW_P.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_FW_P.RowTemplate.Height = 30;
            this.gv_FW_P.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_FW_P.Size = new System.Drawing.Size(144, 276);
            this.gv_FW_P.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_FW_P.TabIndex = 0;
            this.gv_FW_P.UseStyleColors = true;
            // 
            // panel_filter_FW__P
            // 
            this.panel_filter_FW__P.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.panel_filter_FW__P.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_filter_FW__P.Controls.Add(this.radio_FW_P_all);
            this.panel_filter_FW__P.Controls.Add(this.radio_FW_P_custom);
            this.panel_filter_FW__P.Controls.Add(this.radio_FW_P_standard);
            this.panel_filter_FW__P.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_filter_FW__P.HorizontalScrollbarBarColor = true;
            this.panel_filter_FW__P.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_filter_FW__P.HorizontalScrollbarSize = 10;
            this.panel_filter_FW__P.Location = new System.Drawing.Point(0, 30);
            this.panel_filter_FW__P.Name = "panel_filter_FW__P";
            this.panel_filter_FW__P.Size = new System.Drawing.Size(144, 71);
            this.panel_filter_FW__P.TabIndex = 4;
            this.panel_filter_FW__P.UseCustomBackColor = true;
            this.panel_filter_FW__P.VerticalScrollbarBarColor = true;
            this.panel_filter_FW__P.VerticalScrollbarHighlightOnWheel = false;
            this.panel_filter_FW__P.VerticalScrollbarSize = 10;
            // 
            // radio_FW_P_all
            // 
            this.radio_FW_P_all.AutoSize = true;
            this.radio_FW_P_all.BackColor = System.Drawing.Color.Transparent;
            this.radio_FW_P_all.Location = new System.Drawing.Point(3, 5);
            this.radio_FW_P_all.Name = "radio_FW_P_all";
            this.radio_FW_P_all.Size = new System.Drawing.Size(73, 15);
            this.radio_FW_P_all.Style = MetroFramework.MetroColorStyle.Red;
            this.radio_FW_P_all.TabIndex = 4;
            this.radio_FW_P_all.Text = "Tutti i FW";
            this.radio_FW_P_all.UseCustomBackColor = true;
            this.radio_FW_P_all.UseSelectable = true;
            this.radio_FW_P_all.UseStyleColors = true;
            // 
            // radio_FW_P_custom
            // 
            this.radio_FW_P_custom.AutoSize = true;
            this.radio_FW_P_custom.BackColor = System.Drawing.Color.Transparent;
            this.radio_FW_P_custom.Location = new System.Drawing.Point(3, 47);
            this.radio_FW_P_custom.Name = "radio_FW_P_custom";
            this.radio_FW_P_custom.Size = new System.Drawing.Size(118, 15);
            this.radio_FW_P_custom.Style = MetroFramework.MetroColorStyle.Red;
            this.radio_FW_P_custom.TabIndex = 3;
            this.radio_FW_P_custom.Text = "FW Personalizzato";
            this.radio_FW_P_custom.UseCustomBackColor = true;
            this.radio_FW_P_custom.UseSelectable = true;
            this.radio_FW_P_custom.UseStyleColors = true;
            // 
            // radio_FW_P_standard
            // 
            this.radio_FW_P_standard.AutoSize = true;
            this.radio_FW_P_standard.BackColor = System.Drawing.Color.Transparent;
            this.radio_FW_P_standard.Location = new System.Drawing.Point(3, 26);
            this.radio_FW_P_standard.Name = "radio_FW_P_standard";
            this.radio_FW_P_standard.Size = new System.Drawing.Size(90, 15);
            this.radio_FW_P_standard.Style = MetroFramework.MetroColorStyle.Red;
            this.radio_FW_P_standard.TabIndex = 2;
            this.radio_FW_P_standard.Text = "FW Standard";
            this.radio_FW_P_standard.UseCustomBackColor = true;
            this.radio_FW_P_standard.UseSelectable = true;
            this.radio_FW_P_standard.UseStyleColors = true;
            // 
            // metroPanel5
            // 
            this.metroPanel5.BackColor = System.Drawing.Color.Transparent;
            this.metroPanel5.Controls.Add(this.tb_grid_FW_P);
            this.metroPanel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroPanel5.HorizontalScrollbarBarColor = true;
            this.metroPanel5.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel5.HorizontalScrollbarSize = 10;
            this.metroPanel5.Location = new System.Drawing.Point(0, 0);
            this.metroPanel5.Name = "metroPanel5";
            this.metroPanel5.Size = new System.Drawing.Size(144, 30);
            this.metroPanel5.TabIndex = 3;
            this.metroPanel5.UseCustomBackColor = true;
            this.metroPanel5.VerticalScrollbarBarColor = true;
            this.metroPanel5.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel5.VerticalScrollbarSize = 10;
            // 
            // tb_grid_FW_P
            // 
            // 
            // 
            // 
            this.tb_grid_FW_P.CustomButton.Image = null;
            this.tb_grid_FW_P.CustomButton.Location = new System.Drawing.Point(122, 1);
            this.tb_grid_FW_P.CustomButton.Name = "";
            this.tb_grid_FW_P.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_grid_FW_P.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_grid_FW_P.CustomButton.TabIndex = 1;
            this.tb_grid_FW_P.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_grid_FW_P.CustomButton.UseSelectable = true;
            this.tb_grid_FW_P.CustomButton.Visible = false;
            this.tb_grid_FW_P.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_grid_FW_P.Icon = global::SmartLineProduction.Properties.Resources.Lente;
            this.tb_grid_FW_P.IconRight = true;
            this.tb_grid_FW_P.Lines = new string[] {
        "metroTextBox1"};
            this.tb_grid_FW_P.Location = new System.Drawing.Point(0, 0);
            this.tb_grid_FW_P.MaxLength = 32767;
            this.tb_grid_FW_P.Name = "tb_grid_FW_P";
            this.tb_grid_FW_P.PasswordChar = '\0';
            this.tb_grid_FW_P.PromptText = "ricerca";
            this.tb_grid_FW_P.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_grid_FW_P.SelectedText = "";
            this.tb_grid_FW_P.SelectionLength = 0;
            this.tb_grid_FW_P.SelectionStart = 0;
            this.tb_grid_FW_P.ShortcutsEnabled = true;
            this.tb_grid_FW_P.Size = new System.Drawing.Size(144, 23);
            this.tb_grid_FW_P.TabIndex = 2;
            this.tb_grid_FW_P.Text = "metroTextBox1";
            this.tb_grid_FW_P.UseSelectable = true;
            this.tb_grid_FW_P.WaterMark = "ricerca";
            this.tb_grid_FW_P.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_grid_FW_P.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // FW_P_layout_pdf
            // 
            this.FW_P_layout_pdf.ColumnCount = 2;
            this.FW_P_layout_pdf.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.FW_P_layout_pdf.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.FW_P_layout_pdf.Controls.Add(this.FW_P_pdf_it, 0, 0);
            this.FW_P_layout_pdf.Controls.Add(this.FW_P_pdf_en, 1, 0);
            this.FW_P_layout_pdf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FW_P_layout_pdf.Location = new System.Drawing.Point(153, 53);
            this.FW_P_layout_pdf.Name = "FW_P_layout_pdf";
            this.FW_P_layout_pdf.RowCount = 1;
            this.FW_P_layout_pdf.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.FW_P_layout_pdf.Size = new System.Drawing.Size(1396, 327);
            this.FW_P_layout_pdf.TabIndex = 84;
            // 
            // FW_P_pdf_it
            // 
            this.FW_P_pdf_it.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FW_P_pdf_it.Enabled = true;
            this.FW_P_pdf_it.Location = new System.Drawing.Point(3, 3);
            this.FW_P_pdf_it.Name = "FW_P_pdf_it";
            this.FW_P_pdf_it.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("FW_P_pdf_it.OcxState")));
            this.FW_P_pdf_it.Size = new System.Drawing.Size(692, 321);
            this.FW_P_pdf_it.TabIndex = 0;
            // 
            // FW_P_pdf_en
            // 
            this.FW_P_pdf_en.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FW_P_pdf_en.Enabled = true;
            this.FW_P_pdf_en.Location = new System.Drawing.Point(701, 3);
            this.FW_P_pdf_en.Name = "FW_P_pdf_en";
            this.FW_P_pdf_en.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("FW_P_pdf_en.OcxState")));
            this.FW_P_pdf_en.Size = new System.Drawing.Size(692, 321);
            this.FW_P_pdf_en.TabIndex = 1;
            // 
            // panel_des_art_FW_P
            // 
            this.panel_des_art_FW_P.Controls.Add(this.metroLabel11);
            this.panel_des_art_FW_P.Controls.Add(this.metroLabel12);
            this.panel_des_art_FW_P.Controls.Add(this.metroLabel13);
            this.panel_des_art_FW_P.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_des_art_FW_P.HorizontalScrollbarBarColor = true;
            this.panel_des_art_FW_P.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_des_art_FW_P.HorizontalScrollbarSize = 10;
            this.panel_des_art_FW_P.Location = new System.Drawing.Point(153, 3);
            this.panel_des_art_FW_P.Name = "panel_des_art_FW_P";
            this.panel_des_art_FW_P.Size = new System.Drawing.Size(1396, 44);
            this.panel_des_art_FW_P.TabIndex = 1;
            this.panel_des_art_FW_P.VerticalScrollbarBarColor = true;
            this.panel_des_art_FW_P.VerticalScrollbarHighlightOnWheel = false;
            this.panel_des_art_FW_P.VerticalScrollbarSize = 10;
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.Location = new System.Drawing.Point(93, 0);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(41, 19);
            this.metroLabel11.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel11.TabIndex = 3;
            this.metroLabel11.Text = "Des_1";
            this.metroLabel11.UseStyleColors = true;
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.Location = new System.Drawing.Point(93, 19);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(43, 19);
            this.metroLabel12.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel12.TabIndex = 4;
            this.metroLabel12.Text = "Des_2";
            this.metroLabel12.UseStyleColors = true;
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.Location = new System.Drawing.Point(3, 0);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(75, 19);
            this.metroLabel13.TabIndex = 2;
            this.metroLabel13.Text = "Descrizione";
            // 
            // tab_FW_R
            // 
            this.tab_FW_R.Controls.Add(this.layout_FW_R);
            this.tab_FW_R.Location = new System.Drawing.Point(4, 38);
            this.tab_FW_R.Name = "tab_FW_R";
            this.tab_FW_R.Size = new System.Drawing.Size(1552, 383);
            this.tab_FW_R.TabIndex = 5;
            this.tab_FW_R.Text = "Firmware Ricevitori";
            // 
            // layout_FW_R
            // 
            this.layout_FW_R.ColumnCount = 2;
            this.layout_FW_R.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.layout_FW_R.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.layout_FW_R.Controls.Add(this.panel_grid_FW_R, 0, 0);
            this.layout_FW_R.Controls.Add(this.FW_R_layout_pdf, 1, 1);
            this.layout_FW_R.Controls.Add(this.panel_des_art_FW_R, 1, 0);
            this.layout_FW_R.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_FW_R.Location = new System.Drawing.Point(0, 0);
            this.layout_FW_R.Name = "layout_FW_R";
            this.layout_FW_R.RowCount = 2;
            this.layout_FW_R.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.layout_FW_R.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_FW_R.Size = new System.Drawing.Size(1552, 383);
            this.layout_FW_R.TabIndex = 128;
            // 
            // panel_grid_FW_R
            // 
            this.panel_grid_FW_R.Controls.Add(this.gv_FW_R);
            this.panel_grid_FW_R.Controls.Add(this.panel_filter_FW__R);
            this.panel_grid_FW_R.Controls.Add(this.metroPanel6);
            this.panel_grid_FW_R.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_grid_FW_R.HorizontalScrollbarBarColor = true;
            this.panel_grid_FW_R.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_grid_FW_R.HorizontalScrollbarSize = 10;
            this.panel_grid_FW_R.Location = new System.Drawing.Point(3, 3);
            this.panel_grid_FW_R.Name = "panel_grid_FW_R";
            this.layout_FW_R.SetRowSpan(this.panel_grid_FW_R, 2);
            this.panel_grid_FW_R.Size = new System.Drawing.Size(144, 377);
            this.panel_grid_FW_R.TabIndex = 83;
            this.panel_grid_FW_R.VerticalScrollbarBarColor = true;
            this.panel_grid_FW_R.VerticalScrollbarHighlightOnWheel = false;
            this.panel_grid_FW_R.VerticalScrollbarSize = 10;
            // 
            // gv_FW_R
            // 
            this.gv_FW_R.AllowUserToAddRows = false;
            this.gv_FW_R.AllowUserToDeleteRows = false;
            this.gv_FW_R.AllowUserToResizeRows = false;
            dataGridViewCellStyle56.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_FW_R.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle56;
            this.gv_FW_R.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_FW_R.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_FW_R.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_FW_R.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle57.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle57.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle57.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle57.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle57.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle57.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_FW_R.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle57;
            this.gv_FW_R.ColumnHeadersHeight = 40;
            dataGridViewCellStyle58.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle58.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle58.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle58.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle58.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle58.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle58.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_FW_R.DefaultCellStyle = dataGridViewCellStyle58;
            this.gv_FW_R.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_FW_R.EnableHeadersVisualStyles = false;
            this.gv_FW_R.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_FW_R.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_FW_R.Location = new System.Drawing.Point(0, 101);
            this.gv_FW_R.MultiSelect = false;
            this.gv_FW_R.Name = "gv_FW_R";
            this.gv_FW_R.ReadOnly = true;
            this.gv_FW_R.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle59.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle59.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle59.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle59.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle59.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle59.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_FW_R.RowHeadersDefaultCellStyle = dataGridViewCellStyle59;
            this.gv_FW_R.RowHeadersVisible = false;
            this.gv_FW_R.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_FW_R.RowTemplate.Height = 30;
            this.gv_FW_R.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_FW_R.Size = new System.Drawing.Size(144, 276);
            this.gv_FW_R.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_FW_R.TabIndex = 0;
            this.gv_FW_R.UseStyleColors = true;
            // 
            // panel_filter_FW__R
            // 
            this.panel_filter_FW__R.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.panel_filter_FW__R.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_filter_FW__R.Controls.Add(this.radio_FW_R_all);
            this.panel_filter_FW__R.Controls.Add(this.radio_FW_R_custom);
            this.panel_filter_FW__R.Controls.Add(this.radio_FW_R_standard);
            this.panel_filter_FW__R.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_filter_FW__R.HorizontalScrollbarBarColor = true;
            this.panel_filter_FW__R.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_filter_FW__R.HorizontalScrollbarSize = 10;
            this.panel_filter_FW__R.Location = new System.Drawing.Point(0, 30);
            this.panel_filter_FW__R.Name = "panel_filter_FW__R";
            this.panel_filter_FW__R.Size = new System.Drawing.Size(144, 71);
            this.panel_filter_FW__R.TabIndex = 5;
            this.panel_filter_FW__R.UseCustomBackColor = true;
            this.panel_filter_FW__R.VerticalScrollbarBarColor = true;
            this.panel_filter_FW__R.VerticalScrollbarHighlightOnWheel = false;
            this.panel_filter_FW__R.VerticalScrollbarSize = 10;
            // 
            // radio_FW_R_all
            // 
            this.radio_FW_R_all.AutoSize = true;
            this.radio_FW_R_all.BackColor = System.Drawing.Color.Transparent;
            this.radio_FW_R_all.Location = new System.Drawing.Point(3, 5);
            this.radio_FW_R_all.Name = "radio_FW_R_all";
            this.radio_FW_R_all.Size = new System.Drawing.Size(73, 15);
            this.radio_FW_R_all.Style = MetroFramework.MetroColorStyle.Red;
            this.radio_FW_R_all.TabIndex = 4;
            this.radio_FW_R_all.Text = "Tutti i FW";
            this.radio_FW_R_all.UseCustomBackColor = true;
            this.radio_FW_R_all.UseSelectable = true;
            this.radio_FW_R_all.UseStyleColors = true;
            // 
            // radio_FW_R_custom
            // 
            this.radio_FW_R_custom.AutoSize = true;
            this.radio_FW_R_custom.BackColor = System.Drawing.Color.Transparent;
            this.radio_FW_R_custom.Location = new System.Drawing.Point(3, 47);
            this.radio_FW_R_custom.Name = "radio_FW_R_custom";
            this.radio_FW_R_custom.Size = new System.Drawing.Size(118, 15);
            this.radio_FW_R_custom.Style = MetroFramework.MetroColorStyle.Red;
            this.radio_FW_R_custom.TabIndex = 3;
            this.radio_FW_R_custom.Text = "FW Personalizzato";
            this.radio_FW_R_custom.UseCustomBackColor = true;
            this.radio_FW_R_custom.UseSelectable = true;
            this.radio_FW_R_custom.UseStyleColors = true;
            // 
            // radio_FW_R_standard
            // 
            this.radio_FW_R_standard.AutoSize = true;
            this.radio_FW_R_standard.BackColor = System.Drawing.Color.Transparent;
            this.radio_FW_R_standard.Location = new System.Drawing.Point(3, 26);
            this.radio_FW_R_standard.Name = "radio_FW_R_standard";
            this.radio_FW_R_standard.Size = new System.Drawing.Size(90, 15);
            this.radio_FW_R_standard.Style = MetroFramework.MetroColorStyle.Red;
            this.radio_FW_R_standard.TabIndex = 2;
            this.radio_FW_R_standard.Text = "FW Standard";
            this.radio_FW_R_standard.UseCustomBackColor = true;
            this.radio_FW_R_standard.UseSelectable = true;
            this.radio_FW_R_standard.UseStyleColors = true;
            // 
            // metroPanel6
            // 
            this.metroPanel6.BackColor = System.Drawing.Color.Transparent;
            this.metroPanel6.Controls.Add(this.tb_grid_FW_R);
            this.metroPanel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroPanel6.HorizontalScrollbarBarColor = true;
            this.metroPanel6.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel6.HorizontalScrollbarSize = 10;
            this.metroPanel6.Location = new System.Drawing.Point(0, 0);
            this.metroPanel6.Name = "metroPanel6";
            this.metroPanel6.Size = new System.Drawing.Size(144, 30);
            this.metroPanel6.TabIndex = 3;
            this.metroPanel6.UseCustomBackColor = true;
            this.metroPanel6.VerticalScrollbarBarColor = true;
            this.metroPanel6.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel6.VerticalScrollbarSize = 10;
            // 
            // tb_grid_FW_R
            // 
            // 
            // 
            // 
            this.tb_grid_FW_R.CustomButton.Image = null;
            this.tb_grid_FW_R.CustomButton.Location = new System.Drawing.Point(122, 1);
            this.tb_grid_FW_R.CustomButton.Name = "";
            this.tb_grid_FW_R.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_grid_FW_R.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_grid_FW_R.CustomButton.TabIndex = 1;
            this.tb_grid_FW_R.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_grid_FW_R.CustomButton.UseSelectable = true;
            this.tb_grid_FW_R.CustomButton.Visible = false;
            this.tb_grid_FW_R.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_grid_FW_R.Icon = global::SmartLineProduction.Properties.Resources.Lente;
            this.tb_grid_FW_R.IconRight = true;
            this.tb_grid_FW_R.Lines = new string[] {
        "metroTextBox1"};
            this.tb_grid_FW_R.Location = new System.Drawing.Point(0, 0);
            this.tb_grid_FW_R.MaxLength = 32767;
            this.tb_grid_FW_R.Name = "tb_grid_FW_R";
            this.tb_grid_FW_R.PasswordChar = '\0';
            this.tb_grid_FW_R.PromptText = "ricerca";
            this.tb_grid_FW_R.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_grid_FW_R.SelectedText = "";
            this.tb_grid_FW_R.SelectionLength = 0;
            this.tb_grid_FW_R.SelectionStart = 0;
            this.tb_grid_FW_R.ShortcutsEnabled = true;
            this.tb_grid_FW_R.Size = new System.Drawing.Size(144, 23);
            this.tb_grid_FW_R.TabIndex = 2;
            this.tb_grid_FW_R.Text = "metroTextBox1";
            this.tb_grid_FW_R.UseSelectable = true;
            this.tb_grid_FW_R.WaterMark = "ricerca";
            this.tb_grid_FW_R.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_grid_FW_R.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // FW_R_layout_pdf
            // 
            this.FW_R_layout_pdf.ColumnCount = 2;
            this.FW_R_layout_pdf.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.FW_R_layout_pdf.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.FW_R_layout_pdf.Controls.Add(this.FW_R_pdf_it, 0, 0);
            this.FW_R_layout_pdf.Controls.Add(this.FW_R_pdf_en, 1, 0);
            this.FW_R_layout_pdf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FW_R_layout_pdf.Location = new System.Drawing.Point(153, 53);
            this.FW_R_layout_pdf.Name = "FW_R_layout_pdf";
            this.FW_R_layout_pdf.RowCount = 1;
            this.FW_R_layout_pdf.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.FW_R_layout_pdf.Size = new System.Drawing.Size(1396, 327);
            this.FW_R_layout_pdf.TabIndex = 84;
            // 
            // FW_R_pdf_it
            // 
            this.FW_R_pdf_it.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FW_R_pdf_it.Enabled = true;
            this.FW_R_pdf_it.Location = new System.Drawing.Point(3, 3);
            this.FW_R_pdf_it.Name = "FW_R_pdf_it";
            this.FW_R_pdf_it.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("FW_R_pdf_it.OcxState")));
            this.FW_R_pdf_it.Size = new System.Drawing.Size(692, 321);
            this.FW_R_pdf_it.TabIndex = 0;
            // 
            // FW_R_pdf_en
            // 
            this.FW_R_pdf_en.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FW_R_pdf_en.Enabled = true;
            this.FW_R_pdf_en.Location = new System.Drawing.Point(701, 3);
            this.FW_R_pdf_en.Name = "FW_R_pdf_en";
            this.FW_R_pdf_en.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("FW_R_pdf_en.OcxState")));
            this.FW_R_pdf_en.Size = new System.Drawing.Size(692, 321);
            this.FW_R_pdf_en.TabIndex = 1;
            // 
            // panel_des_art_FW_R
            // 
            this.panel_des_art_FW_R.Controls.Add(this.metroLabel14);
            this.panel_des_art_FW_R.Controls.Add(this.metroLabel15);
            this.panel_des_art_FW_R.Controls.Add(this.metroLabel16);
            this.panel_des_art_FW_R.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_des_art_FW_R.HorizontalScrollbarBarColor = true;
            this.panel_des_art_FW_R.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_des_art_FW_R.HorizontalScrollbarSize = 10;
            this.panel_des_art_FW_R.Location = new System.Drawing.Point(153, 3);
            this.panel_des_art_FW_R.Name = "panel_des_art_FW_R";
            this.panel_des_art_FW_R.Size = new System.Drawing.Size(1396, 44);
            this.panel_des_art_FW_R.TabIndex = 1;
            this.panel_des_art_FW_R.VerticalScrollbarBarColor = true;
            this.panel_des_art_FW_R.VerticalScrollbarHighlightOnWheel = false;
            this.panel_des_art_FW_R.VerticalScrollbarSize = 10;
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.Location = new System.Drawing.Point(93, 0);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(41, 19);
            this.metroLabel14.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel14.TabIndex = 3;
            this.metroLabel14.Text = "Des_1";
            this.metroLabel14.UseStyleColors = true;
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.Location = new System.Drawing.Point(93, 19);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(43, 19);
            this.metroLabel15.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel15.TabIndex = 4;
            this.metroLabel15.Text = "Des_2";
            this.metroLabel15.UseStyleColors = true;
            // 
            // metroLabel16
            // 
            this.metroLabel16.AutoSize = true;
            this.metroLabel16.Location = new System.Drawing.Point(3, 0);
            this.metroLabel16.Name = "metroLabel16";
            this.metroLabel16.Size = new System.Drawing.Size(75, 19);
            this.metroLabel16.TabIndex = 2;
            this.metroLabel16.Text = "Descrizione";
            // 
            // tab_pack_doc
            // 
            this.tab_pack_doc.Controls.Add(this.layout_Pack);
            this.tab_pack_doc.Location = new System.Drawing.Point(4, 38);
            this.tab_pack_doc.Name = "tab_pack_doc";
            this.tab_pack_doc.Size = new System.Drawing.Size(1552, 383);
            this.tab_pack_doc.TabIndex = 6;
            this.tab_pack_doc.Text = "Raccolta Doc. (Kit)";
            this.tab_pack_doc.Enter += new System.EventHandler(this.tab_pack_doc_Enter);
            // 
            // layout_Pack
            // 
            this.layout_Pack.ColumnCount = 2;
            this.layout_Pack.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.layout_Pack.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.layout_Pack.Controls.Add(this.panel_grid_pack, 0, 0);
            this.layout_Pack.Controls.Add(this.tableLayoutPanel2, 1, 1);
            this.layout_Pack.Controls.Add(this.panel_des_art_Kit_pack, 1, 0);
            this.layout_Pack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Pack.Location = new System.Drawing.Point(0, 0);
            this.layout_Pack.Name = "layout_Pack";
            this.layout_Pack.RowCount = 2;
            this.layout_Pack.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.layout_Pack.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_Pack.Size = new System.Drawing.Size(1552, 383);
            this.layout_Pack.TabIndex = 124;
            // 
            // panel_grid_pack
            // 
            this.panel_grid_pack.Controls.Add(this.gv_kit_pack);
            this.panel_grid_pack.Controls.Add(this.metroPanel7);
            this.panel_grid_pack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_grid_pack.HorizontalScrollbarBarColor = true;
            this.panel_grid_pack.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_grid_pack.HorizontalScrollbarSize = 10;
            this.panel_grid_pack.Location = new System.Drawing.Point(3, 3);
            this.panel_grid_pack.Name = "panel_grid_pack";
            this.layout_Pack.SetRowSpan(this.panel_grid_pack, 2);
            this.panel_grid_pack.Size = new System.Drawing.Size(144, 377);
            this.panel_grid_pack.TabIndex = 123;
            this.panel_grid_pack.VerticalScrollbarBarColor = true;
            this.panel_grid_pack.VerticalScrollbarHighlightOnWheel = false;
            this.panel_grid_pack.VerticalScrollbarSize = 10;
            // 
            // gv_kit_pack
            // 
            this.gv_kit_pack.AllowUserToAddRows = false;
            this.gv_kit_pack.AllowUserToDeleteRows = false;
            this.gv_kit_pack.AllowUserToResizeRows = false;
            dataGridViewCellStyle32.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_kit_pack.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle32;
            this.gv_kit_pack.AutoGenerateColumns = false;
            this.gv_kit_pack.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_kit_pack.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_kit_pack.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_kit_pack.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle33.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle33.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_kit_pack.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle33;
            this.gv_kit_pack.ColumnHeadersHeight = 40;
            this.gv_kit_pack.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.gv_kit_pack.DataSource = this.sFArticoliSchedeBindingSource;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle34.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_kit_pack.DefaultCellStyle = dataGridViewCellStyle34;
            this.gv_kit_pack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_kit_pack.EnableHeadersVisualStyles = false;
            this.gv_kit_pack.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_kit_pack.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_kit_pack.Location = new System.Drawing.Point(0, 30);
            this.gv_kit_pack.MultiSelect = false;
            this.gv_kit_pack.Name = "gv_kit_pack";
            this.gv_kit_pack.ReadOnly = true;
            this.gv_kit_pack.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle35.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_kit_pack.RowHeadersDefaultCellStyle = dataGridViewCellStyle35;
            this.gv_kit_pack.RowHeadersVisible = false;
            this.gv_kit_pack.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_kit_pack.RowTemplate.Height = 30;
            this.gv_kit_pack.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_kit_pack.Size = new System.Drawing.Size(144, 347);
            this.gv_kit_pack.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_kit_pack.TabIndex = 0;
            this.gv_kit_pack.UseStyleColors = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Articolo";
            this.dataGridViewTextBoxColumn1.HeaderText = "Kit";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Descrizione";
            this.dataGridViewTextBoxColumn2.HeaderText = "Descrizione";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Visible = false;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "DescrizioneEstesa";
            this.dataGridViewTextBoxColumn3.HeaderText = "DescrizioneEstesa";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Visible = false;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Modello";
            this.dataGridViewTextBoxColumn4.HeaderText = "Modello";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Visible = false;
            // 
            // metroPanel7
            // 
            this.metroPanel7.BackColor = System.Drawing.Color.Transparent;
            this.metroPanel7.Controls.Add(this.tb_grid_kit_pack);
            this.metroPanel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroPanel7.HorizontalScrollbarBarColor = true;
            this.metroPanel7.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel7.HorizontalScrollbarSize = 10;
            this.metroPanel7.Location = new System.Drawing.Point(0, 0);
            this.metroPanel7.Name = "metroPanel7";
            this.metroPanel7.Size = new System.Drawing.Size(144, 30);
            this.metroPanel7.TabIndex = 3;
            this.metroPanel7.UseCustomBackColor = true;
            this.metroPanel7.VerticalScrollbarBarColor = true;
            this.metroPanel7.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel7.VerticalScrollbarSize = 10;
            // 
            // tb_grid_kit_pack
            // 
            // 
            // 
            // 
            this.tb_grid_kit_pack.CustomButton.Image = null;
            this.tb_grid_kit_pack.CustomButton.Location = new System.Drawing.Point(122, 1);
            this.tb_grid_kit_pack.CustomButton.Name = "";
            this.tb_grid_kit_pack.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_grid_kit_pack.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_grid_kit_pack.CustomButton.TabIndex = 1;
            this.tb_grid_kit_pack.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_grid_kit_pack.CustomButton.UseSelectable = true;
            this.tb_grid_kit_pack.CustomButton.Visible = false;
            this.tb_grid_kit_pack.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_grid_kit_pack.Icon = global::SmartLineProduction.Properties.Resources.Lente;
            this.tb_grid_kit_pack.IconRight = true;
            this.tb_grid_kit_pack.Lines = new string[] {
        "metroTextBox1"};
            this.tb_grid_kit_pack.Location = new System.Drawing.Point(0, 0);
            this.tb_grid_kit_pack.MaxLength = 32767;
            this.tb_grid_kit_pack.Name = "tb_grid_kit_pack";
            this.tb_grid_kit_pack.PasswordChar = '\0';
            this.tb_grid_kit_pack.PromptText = "ricerca";
            this.tb_grid_kit_pack.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_grid_kit_pack.SelectedText = "";
            this.tb_grid_kit_pack.SelectionLength = 0;
            this.tb_grid_kit_pack.SelectionStart = 0;
            this.tb_grid_kit_pack.ShortcutsEnabled = true;
            this.tb_grid_kit_pack.Size = new System.Drawing.Size(144, 23);
            this.tb_grid_kit_pack.TabIndex = 2;
            this.tb_grid_kit_pack.Text = "metroTextBox1";
            this.tb_grid_kit_pack.UseSelectable = true;
            this.tb_grid_kit_pack.WaterMark = "ricerca";
            this.tb_grid_kit_pack.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_grid_kit_pack.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tb_grid_kit_pack.TextChanged += new System.EventHandler(this.tb_grid_kit_pack_TextChanged);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.btn_do_pack_kit, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.gv_pack_explo, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.metroPanel1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel_pack_kit, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(153, 53);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1396, 327);
            this.tableLayoutPanel2.TabIndex = 122;
            // 
            // btn_do_pack_kit
            // 
            this.btn_do_pack_kit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.btn_do_pack_kit.BackColor = System.Drawing.Color.Moccasin;
            this.btn_do_pack_kit.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.btn_do_pack_kit.FontWeight = MetroFramework.MetroButtonWeight.Light;
            this.btn_do_pack_kit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_do_pack_kit.Location = new System.Drawing.Point(199, 299);
            this.btn_do_pack_kit.Name = "btn_do_pack_kit";
            this.btn_do_pack_kit.Size = new System.Drawing.Size(300, 25);
            this.btn_do_pack_kit.TabIndex = 3;
            this.btn_do_pack_kit.Text = "Procedi alla raccolta dei documenti";
            this.btn_do_pack_kit.UseCustomBackColor = true;
            this.btn_do_pack_kit.UseSelectable = true;
            this.btn_do_pack_kit.Click += new System.EventHandler(this.btn_do_pack_kit_Click);
            // 
            // gv_pack_explo
            // 
            this.gv_pack_explo.AllowUserToAddRows = false;
            this.gv_pack_explo.AllowUserToDeleteRows = false;
            this.gv_pack_explo.AllowUserToResizeRows = false;
            this.gv_pack_explo.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_pack_explo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_pack_explo.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_pack_explo.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle60.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle60.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle60.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle60.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle60.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle60.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle60.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_pack_explo.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle60;
            this.gv_pack_explo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle61.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle61.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle61.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle61.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle61.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle61.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle61.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_pack_explo.DefaultCellStyle = dataGridViewCellStyle61;
            this.gv_pack_explo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_pack_explo.EnableHeadersVisualStyles = false;
            this.gv_pack_explo.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_pack_explo.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_pack_explo.Location = new System.Drawing.Point(3, 73);
            this.gv_pack_explo.Name = "gv_pack_explo";
            this.gv_pack_explo.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle62.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle62.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle62.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle62.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle62.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle62.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle62.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_pack_explo.RowHeadersDefaultCellStyle = dataGridViewCellStyle62;
            this.gv_pack_explo.RowHeadersVisible = false;
            this.gv_pack_explo.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_pack_explo.RowTemplate.Height = 40;
            this.gv_pack_explo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_pack_explo.Size = new System.Drawing.Size(692, 220);
            this.gv_pack_explo.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_pack_explo.TabIndex = 2;
            this.gv_pack_explo.UseStyleColors = true;
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.groupBox1);
            this.metroPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(3, 3);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(692, 64);
            this.metroPanel1.TabIndex = 5;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.cb_Doc_EN);
            this.groupBox1.Controls.Add(this.cb_Doc_IT);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(692, 64);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lingua della documentazione";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::SmartLineProduction.Properties.Resources.gb;
            this.pictureBox2.Location = new System.Drawing.Point(196, 40);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(16, 16);
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SmartLineProduction.Properties.Resources.it;
            this.pictureBox1.Location = new System.Drawing.Point(196, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(16, 16);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // cb_Doc_EN
            // 
            this.cb_Doc_EN.AutoSize = true;
            this.cb_Doc_EN.Location = new System.Drawing.Point(6, 40);
            this.cb_Doc_EN.Name = "cb_Doc_EN";
            this.cb_Doc_EN.Size = new System.Drawing.Size(173, 15);
            this.cb_Doc_EN.Style = MetroFramework.MetroColorStyle.Red;
            this.cb_Doc_EN.TabIndex = 4;
            this.cb_Doc_EN.Text = "Documentazione in INGLESE";
            this.cb_Doc_EN.UseSelectable = true;
            this.cb_Doc_EN.UseStyleColors = true;
            this.cb_Doc_EN.Click += new System.EventHandler(this.cb_Doc_EN_Click);
            // 
            // cb_Doc_IT
            // 
            this.cb_Doc_IT.AutoSize = true;
            this.cb_Doc_IT.Location = new System.Drawing.Point(6, 19);
            this.cb_Doc_IT.Name = "cb_Doc_IT";
            this.cb_Doc_IT.Size = new System.Drawing.Size(180, 15);
            this.cb_Doc_IT.Style = MetroFramework.MetroColorStyle.Red;
            this.cb_Doc_IT.TabIndex = 3;
            this.cb_Doc_IT.Text = "Documentazione in ITALIANO";
            this.cb_Doc_IT.UseSelectable = true;
            this.cb_Doc_IT.UseStyleColors = true;
            this.cb_Doc_IT.Click += new System.EventHandler(this.cb_Doc_IT_Click);
            // 
            // panel_pack_kit
            // 
            this.panel_pack_kit.Controls.Add(this.pack_Kit_pdf);
            this.panel_pack_kit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_pack_kit.HorizontalScrollbarBarColor = true;
            this.panel_pack_kit.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_pack_kit.HorizontalScrollbarSize = 10;
            this.panel_pack_kit.Location = new System.Drawing.Point(701, 3);
            this.panel_pack_kit.Name = "panel_pack_kit";
            this.tableLayoutPanel2.SetRowSpan(this.panel_pack_kit, 2);
            this.panel_pack_kit.Size = new System.Drawing.Size(692, 290);
            this.panel_pack_kit.TabIndex = 6;
            this.panel_pack_kit.VerticalScrollbarBarColor = true;
            this.panel_pack_kit.VerticalScrollbarHighlightOnWheel = false;
            this.panel_pack_kit.VerticalScrollbarSize = 10;
            // 
            // pack_Kit_pdf
            // 
            this.pack_Kit_pdf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pack_Kit_pdf.Enabled = true;
            this.pack_Kit_pdf.Location = new System.Drawing.Point(0, 0);
            this.pack_Kit_pdf.Name = "pack_Kit_pdf";
            this.pack_Kit_pdf.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("pack_Kit_pdf.OcxState")));
            this.pack_Kit_pdf.Size = new System.Drawing.Size(692, 290);
            this.pack_Kit_pdf.TabIndex = 2;
            // 
            // panel_des_art_Kit_pack
            // 
            this.panel_des_art_Kit_pack.Controls.Add(this.metroLabel17);
            this.panel_des_art_Kit_pack.Controls.Add(this.metroLabel18);
            this.panel_des_art_Kit_pack.Controls.Add(this.metroLabel19);
            this.panel_des_art_Kit_pack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_des_art_Kit_pack.HorizontalScrollbarBarColor = true;
            this.panel_des_art_Kit_pack.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Kit_pack.HorizontalScrollbarSize = 10;
            this.panel_des_art_Kit_pack.Location = new System.Drawing.Point(153, 3);
            this.panel_des_art_Kit_pack.Name = "panel_des_art_Kit_pack";
            this.panel_des_art_Kit_pack.Size = new System.Drawing.Size(1396, 44);
            this.panel_des_art_Kit_pack.TabIndex = 124;
            this.panel_des_art_Kit_pack.VerticalScrollbarBarColor = true;
            this.panel_des_art_Kit_pack.VerticalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Kit_pack.VerticalScrollbarSize = 10;
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFArticoliSchedeBindingSource, "Descrizione", true));
            this.metroLabel17.Location = new System.Drawing.Point(93, 0);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(18, 19);
            this.metroLabel17.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel17.TabIndex = 3;
            this.metroLabel17.Text = "sf";
            this.metroLabel17.UseStyleColors = true;
            // 
            // metroLabel18
            // 
            this.metroLabel18.AutoSize = true;
            this.metroLabel18.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFArticoliSchedeBindingSource, "DescrizioneEstesa", true));
            this.metroLabel18.Location = new System.Drawing.Point(93, 19);
            this.metroLabel18.Name = "metroLabel18";
            this.metroLabel18.Size = new System.Drawing.Size(43, 19);
            this.metroLabel18.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel18.TabIndex = 4;
            this.metroLabel18.Text = "Des_2";
            this.metroLabel18.UseStyleColors = true;
            // 
            // metroLabel19
            // 
            this.metroLabel19.AutoSize = true;
            this.metroLabel19.Location = new System.Drawing.Point(3, 0);
            this.metroLabel19.Name = "metroLabel19";
            this.metroLabel19.Size = new System.Drawing.Size(75, 19);
            this.metroLabel19.TabIndex = 2;
            this.metroLabel19.Text = "Descrizione";
            // 
            // layout_orizz_menu
            // 
            this.layout_orizz_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.ColumnCount = 10;
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_exit, 10, 0);
            this.layout_orizz_menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_orizz_menu.Location = new System.Drawing.Point(20, 30);
            this.layout_orizz_menu.Name = "layout_orizz_menu";
            this.layout_orizz_menu.RowCount = 1;
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_orizz_menu.Size = new System.Drawing.Size(1560, 25);
            this.layout_orizz_menu.TabIndex = 123;
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Gainsboro;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(1485, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(75, 24);
            this.pan_Menu_exit.TabIndex = 82;
            this.pan_Menu_exit.Text = "menuStrip1";
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            this.menu_sw_exit.Click += new System.EventHandler(this.menu_sw_exit_Click);
            // 
            // sFDistinteBasiSchedeBindingSource
            // 
            this.sFDistinteBasiSchedeBindingSource.DataMember = "SF_DistinteBasi_Schede";
            this.sFDistinteBasiSchedeBindingSource.DataSource = this.ds_SL;
            // 
            // famProdBindingSource
            // 
            this.famProdBindingSource.DataMember = "Fam_Prod";
            this.famProdBindingSource.DataSource = this.ds_SL;
            // 
            // sF_ArticoliSchedeTableAdapter
            // 
            this.sF_ArticoliSchedeTableAdapter.ClearBeforeFill = true;
            // 
            // sF_DistinteBasi_SchedeTableAdapter
            // 
            this.sF_DistinteBasi_SchedeTableAdapter.ClearBeforeFill = true;
            // 
            // fam_ProdTableAdapter
            // 
            this.fam_ProdTableAdapter.ClearBeforeFill = true;
            // 
            // sFArticoliToXSWRSchedeBindingSource
            // 
            this.sFArticoliToXSWRSchedeBindingSource.DataMember = "SF_ArticoliToXSWR_Schede";
            this.sFArticoliToXSWRSchedeBindingSource.DataSource = this.ds_SL;
            // 
            // sF_ArticoliToXSWR_SchedeTableAdapter
            // 
            this.sF_ArticoliToXSWR_SchedeTableAdapter.ClearBeforeFill = true;
            // 
            // UC_Schede
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1600, 500);
            this.ControlBox = false;
            this.Controls.Add(this.panel_Schede);
            this.Controls.Add(this.layout_orizz_menu);
            this.DisplayHeader = false;
            this.Name = "UC_Schede";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UC_Schede_Load);
            this.panel_Schede.ResumeLayout(false);
            this.Tab_Schede.ResumeLayout(false);
            this.tab_Kit.ResumeLayout(false);
            this.layout_Kit.ResumeLayout(false);
            this.panel_grid_Kit.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_Kit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFArticoliSchedeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            this.panel_search_kit.ResumeLayout(false);
            this.Kit_layout_pdf.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Kit_pdf_it)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kit_pdf_en)).EndInit();
            this.panel_des_art_Kit.ResumeLayout(false);
            this.panel_des_art_Kit.PerformLayout();
            this.tab_Palmari.ResumeLayout(false);
            this.layout_Palmari.ResumeLayout(false);
            this.panel_grid_Palmari.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_Palmari)).EndInit();
            this.metroPanel2.ResumeLayout(false);
            this.Palmari_layout_pdf.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Palmari_pdf_it)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Palmari_pdf_en)).EndInit();
            this.panel_des_art_Palmari.ResumeLayout(false);
            this.panel_des_art_Palmari.PerformLayout();
            this.tab_Ricevitori.ResumeLayout(false);
            this.layout_Ricevitori.ResumeLayout(false);
            this.panel_grid_Ricevitori.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_Ricevitori)).EndInit();
            this.metroPanel3.ResumeLayout(false);
            this.Ricevitori_layout_pdf.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Ricevitori_pdf_it)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ricevitori_pdf_en)).EndInit();
            this.panel_des_art_Ricevitori.ResumeLayout(false);
            this.panel_des_art_Ricevitori.PerformLayout();
            this.tab_Cablaggi.ResumeLayout(false);
            this.layout_Cablaggi.ResumeLayout(false);
            this.panel_grid_Cablaggi.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_Cablaggi)).EndInit();
            this.metroPanel4.ResumeLayout(false);
            this.Cablaggi_layout_pdf.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Cablaggi_pdf_it)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cablaggi_pdf_en)).EndInit();
            this.panel_des_art_Cablaggi.ResumeLayout(false);
            this.panel_des_art_Cablaggi.PerformLayout();
            this.tab_FW_P.ResumeLayout(false);
            this.layout_FW_P.ResumeLayout(false);
            this.panel_grid_FW_P.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_FW_P)).EndInit();
            this.panel_filter_FW__P.ResumeLayout(false);
            this.panel_filter_FW__P.PerformLayout();
            this.metroPanel5.ResumeLayout(false);
            this.FW_P_layout_pdf.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.FW_P_pdf_it)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FW_P_pdf_en)).EndInit();
            this.panel_des_art_FW_P.ResumeLayout(false);
            this.panel_des_art_FW_P.PerformLayout();
            this.tab_FW_R.ResumeLayout(false);
            this.layout_FW_R.ResumeLayout(false);
            this.panel_grid_FW_R.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_FW_R)).EndInit();
            this.panel_filter_FW__R.ResumeLayout(false);
            this.panel_filter_FW__R.PerformLayout();
            this.metroPanel6.ResumeLayout(false);
            this.FW_R_layout_pdf.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.FW_R_pdf_it)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FW_R_pdf_en)).EndInit();
            this.panel_des_art_FW_R.ResumeLayout(false);
            this.panel_des_art_FW_R.PerformLayout();
            this.tab_pack_doc.ResumeLayout(false);
            this.layout_Pack.ResumeLayout(false);
            this.panel_grid_pack.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_kit_pack)).EndInit();
            this.metroPanel7.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_pack_explo)).EndInit();
            this.metroPanel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel_pack_kit.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pack_Kit_pdf)).EndInit();
            this.panel_des_art_Kit_pack.ResumeLayout(false);
            this.panel_des_art_Kit_pack.PerformLayout();
            this.layout_orizz_menu.ResumeLayout(false);
            this.layout_orizz_menu.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sFDistinteBasiSchedeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.famProdBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFArticoliToXSWRSchedeBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel panel_Schede;
        private MetroFramework.Controls.MetroTabControl Tab_Schede;
        private System.Windows.Forms.TabPage tab_Kit;
        private System.Windows.Forms.TableLayoutPanel layout_Kit;
        private MetroFramework.Controls.MetroPanel panel_grid_Kit;
        private MetroFramework.Controls.MetroGrid gv_Kit;
        private MetroFramework.Controls.MetroPanel panel_search_kit;
        private MetroFramework.Controls.MetroTextBox tb_grid_kit;
        private System.Windows.Forms.TableLayoutPanel Kit_layout_pdf;
        private AxAcroPDFLib.AxAcroPDF Kit_pdf_it;
        private AxAcroPDFLib.AxAcroPDF Kit_pdf_en;
        private MetroFramework.Controls.MetroPanel panel_des_art_Kit;
        private MetroFramework.Controls.MetroLabel lab_des1_articolo;
        private MetroFramework.Controls.MetroLabel lab_des2_articolo;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.TabPage tab_Palmari;
        private System.Windows.Forms.TableLayoutPanel layout_Palmari;
        private MetroFramework.Controls.MetroPanel panel_grid_Palmari;
        private MetroFramework.Controls.MetroGrid gv_Palmari;
        private MetroFramework.Controls.MetroPanel metroPanel2;
        private MetroFramework.Controls.MetroTextBox tb_grid_palmari;
        private System.Windows.Forms.TableLayoutPanel Palmari_layout_pdf;
        private AxAcroPDFLib.AxAcroPDF Palmari_pdf_it;
        private AxAcroPDFLib.AxAcroPDF Palmari_pdf_en;
        private MetroFramework.Controls.MetroPanel panel_des_art_Palmari;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private System.Windows.Forms.TabPage tab_Ricevitori;
        private System.Windows.Forms.TableLayoutPanel layout_Ricevitori;
        private MetroFramework.Controls.MetroPanel panel_grid_Ricevitori;
        private MetroFramework.Controls.MetroGrid gv_Ricevitori;
        private MetroFramework.Controls.MetroPanel metroPanel3;
        private MetroFramework.Controls.MetroTextBox tb_grid_ricevitori;
        private System.Windows.Forms.TableLayoutPanel Ricevitori_layout_pdf;
        private AxAcroPDFLib.AxAcroPDF Ricevitori_pdf_it;
        private AxAcroPDFLib.AxAcroPDF Ricevitori_pdf_en;
        private MetroFramework.Controls.MetroPanel panel_des_art_Ricevitori;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private System.Windows.Forms.TabPage tab_Cablaggi;
        private System.Windows.Forms.TableLayoutPanel layout_Cablaggi;
        private MetroFramework.Controls.MetroPanel panel_grid_Cablaggi;
        private MetroFramework.Controls.MetroGrid gv_Cablaggi;
        private MetroFramework.Controls.MetroPanel metroPanel4;
        private MetroFramework.Controls.MetroTextBox tb_grid_cablaggi;
        private System.Windows.Forms.TableLayoutPanel Cablaggi_layout_pdf;
        private AxAcroPDFLib.AxAcroPDF Cablaggi_pdf_it;
        private AxAcroPDFLib.AxAcroPDF Cablaggi_pdf_en;
        private MetroFramework.Controls.MetroPanel panel_des_art_Cablaggi;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private System.Windows.Forms.TabPage tab_FW_P;
        private System.Windows.Forms.TableLayoutPanel layout_FW_P;
        private MetroFramework.Controls.MetroPanel panel_grid_FW_P;
        private MetroFramework.Controls.MetroGrid gv_FW_P;
        private MetroFramework.Controls.MetroPanel panel_filter_FW__P;
        private MetroFramework.Controls.MetroRadioButton radio_FW_P_all;
        private MetroFramework.Controls.MetroRadioButton radio_FW_P_custom;
        private MetroFramework.Controls.MetroRadioButton radio_FW_P_standard;
        private MetroFramework.Controls.MetroPanel metroPanel5;
        private MetroFramework.Controls.MetroTextBox tb_grid_FW_P;
        private System.Windows.Forms.TableLayoutPanel FW_P_layout_pdf;
        private AxAcroPDFLib.AxAcroPDF FW_P_pdf_it;
        private AxAcroPDFLib.AxAcroPDF FW_P_pdf_en;
        private MetroFramework.Controls.MetroPanel panel_des_art_FW_P;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private System.Windows.Forms.TabPage tab_FW_R;
        private System.Windows.Forms.TableLayoutPanel layout_FW_R;
        private MetroFramework.Controls.MetroPanel panel_grid_FW_R;
        private MetroFramework.Controls.MetroGrid gv_FW_R;
        private MetroFramework.Controls.MetroPanel panel_filter_FW__R;
        private MetroFramework.Controls.MetroRadioButton radio_FW_R_all;
        private MetroFramework.Controls.MetroRadioButton radio_FW_R_custom;
        private MetroFramework.Controls.MetroRadioButton radio_FW_R_standard;
        private MetroFramework.Controls.MetroPanel metroPanel6;
        private MetroFramework.Controls.MetroTextBox tb_grid_FW_R;
        private System.Windows.Forms.TableLayoutPanel FW_R_layout_pdf;
        private AxAcroPDFLib.AxAcroPDF FW_R_pdf_it;
        private AxAcroPDFLib.AxAcroPDF FW_R_pdf_en;
        private MetroFramework.Controls.MetroPanel panel_des_art_FW_R;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private MetroFramework.Controls.MetroLabel metroLabel16;
        private System.Windows.Forms.TabPage tab_pack_doc;
        private System.Windows.Forms.TableLayoutPanel layout_Pack;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel layout_orizz_menu;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
        private ds_SL ds_SL;
        private System.Windows.Forms.BindingSource sFArticoliSchedeBindingSource;
        private ds_SLTableAdapters.SF_ArticoliSchedeTableAdapter sF_ArticoliSchedeTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descrizioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descrizioneEstesaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn modelloDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroPanel panel_grid_pack;
        private MetroFramework.Controls.MetroGrid gv_kit_pack;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private MetroFramework.Controls.MetroPanel metroPanel7;
        private MetroFramework.Controls.MetroTextBox tb_grid_kit_pack;
        private MetroFramework.Controls.MetroPanel panel_des_art_Kit_pack;
        private MetroFramework.Controls.MetroLabel metroLabel17;
        private MetroFramework.Controls.MetroLabel metroLabel18;
        private MetroFramework.Controls.MetroLabel metroLabel19;
        private MetroFramework.Controls.MetroGrid gv_pack_explo;
        private System.Windows.Forms.BindingSource sFDistinteBasiSchedeBindingSource;
        private ds_SLTableAdapters.SF_DistinteBasi_SchedeTableAdapter sF_DistinteBasi_SchedeTableAdapter;
        private System.Windows.Forms.BindingSource famProdBindingSource;
        private ds_SLTableAdapters.Fam_ProdTableAdapter fam_ProdTableAdapter;
        private MetroFramework.Controls.MetroButton btn_do_pack_kit;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroCheckBox cb_Doc_EN;
        private MetroFramework.Controls.MetroCheckBox cb_Doc_IT;
        private System.Windows.Forms.GroupBox groupBox1;
        private MetroFramework.Controls.MetroPanel panel_pack_kit;
        private AxAcroPDFLib.AxAcroPDF pack_Kit_pdf;
        private System.Windows.Forms.BindingSource sFArticoliToXSWRSchedeBindingSource;
        private ds_SLTableAdapters.SF_ArticoliToXSWR_SchedeTableAdapter sF_ArticoliToXSWR_SchedeTableAdapter;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}
