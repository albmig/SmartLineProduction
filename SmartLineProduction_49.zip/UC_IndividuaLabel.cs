﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using System.Drawing.Printing;

namespace SmartLineProduction
{
    public partial class UC_IndividuaLabel : MetroFramework.Forms.MetroForm
    {
        public static string qr_read_device = "";                               // la lettura "pura" del barcode
        public static string qr_sn = "";                                        // serial number del barcode (non ID Smartline)
        public static string qr_SistematicaSN = "";                             // serial number del barcode (non ID Smartline)
        public static string qr_ID = "";                                        // lettura del barcode, può essere codice articolo (classic) o ID Smartline (smartline)
        public static string qr_device = "";                                    // se smartline, contiene l'articolo estrapolato dall'id - se classic, contiene l'articolo letto
        public static string qr_fw = "";                                        // lettura del barcode
        public static string qr_ClassicSmart = "";                              // C Classic - S Smartline
        public static string qr_LottoFornitore = "";                            // da implementare - lettura del lotto sulla scheda
        public static string qr_Commessa = "";                                  // la commessa selezionata
        public static string NamePrinter = string.Empty;

        public UC_IndividuaLabel()
        {
            InitializeComponent();
        }

        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tbx_ReadLabel_Device_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\t' || e.KeyChar == (char)13)
            {
                e.Handled = true;
                qr_read_device = tbx_ReadLabel_Device.Text;
                AnalizzaQrDevice(qr_read_device);
                but_Reset.Focus();
            }
        }

        private void tbx_ReadLabel_Device_Leave(object sender, EventArgs e)
        {
            qr_read_device = tbx_ReadLabel_Device.Text;
            if (AnalizzaQrDevice(qr_read_device))
            {
                but_Reset.Focus();

                but_Print.Visible = true;
                comboInstalledPrinters.Visible = true;
            }
        }

        private bool AnalizzaQrDevice(string letturabarcode)
        {
            string[] codici = letturabarcode.Split('|');
            int conta = 1;
            foreach (var word in codici)
            {
                switch (conta)
                {
                    case 1: qr_sn = word; conta++; break;
                    case 2: qr_ID = word; conta++; break;
                    case 3: qr_fw = word; conta++; break;
                }
            }

            int lungSN = qr_sn.Length;
            if (lungSN == 16)
            {
                qr_ID = qr_sn; // aggiusto la situazione di confusione che si può creare...
                qr_sn = "";
                qr_ClassicSmart = "S";
                string filtro = "Ser_OfficialSerial = " + "'" + qr_ID + "'";
                DataView dv = ds_Programmazione.SerialNumbers.DefaultView;
                dv.RowFilter = filtro;

                if (dv.Count == 0)
                {
                    MessageBox.Show("Errore grave! Impossibile trovare il numero di serie indicato!");
                    return false;
                }
                foreach (DataRowView rowView in dv)
                {
                    qr_device = rowView["Ser_Device"].ToString();
                    qr_fw = rowView["Ser_SW_Code"].ToString();
                    qr_SistematicaSN = rowView["Ser_SN_Prod"].ToString();
                }
            }
            else
            {
                qr_ClassicSmart = "C";
                qr_device = qr_ID;
            }

            lab_read_SN.Text = qr_sn;
            lab_read_ID.Text = qr_ID;
            lab_read_Device.Text = qr_device;
            lab_read_FW.Text = qr_fw;
            lab_label_SN.Text = qr_SistematicaSN;

            this.Refresh();

            return true;
        }

        private void UC_IndividuaLabel_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SerialNumbers'. È possibile spostarla o rimuoverla se necessario.
            this.serialNumbersTableAdapter.Fill(this.ds_Programmazione.SerialNumbers);

            SettaForm();

            this.WindowState = FormWindowState.Maximized;
            tbx_ReadLabel_Device.Focus();

            FindBrotherPrinters();
        }

        private void SettaForm()
        {
            //this.ActiveControl = tbx_ReadLabel_Device;

            //var myControl = this.ActiveControl.Name;

            if (this.ActiveControl == null)
            {
                tbx_ReadLabel_Device.Focus();
            }
            //metroLabel4.Text = this.ActiveControl.Name;


            lab_read_SN.Text = "";
            lab_read_ID.Text = "";
            lab_read_Device.Text = "";
            lab_read_FW.Text = "";
            lab_label_SN.Text = "";
            tbx_ReadLabel_Device.Text = "";

            but_Print.Visible = false;
            comboInstalledPrinters.Visible = false;

            tbx_ReadLabel_Device.Focus();


        }

        private void but_AttivaProc_Click(object sender, EventArgs e)
        {
            SettaForm();
        }

        private void UC_IndividuaLabel_Shown(object sender, EventArgs e)
        {
            tbx_ReadLabel_Device.Focus();
            //base.OnShown(e);
        }

        private void PrintLabel(string Item)
        {
            //Stampa Etichetta
            if (!Properties.Settings.Default.Use_printer)
            {
                return;
            }

            ////EOS CAB
            ///* Create Object Instance */
            //string tmp_file = @".\SL_label.txt";
            //string text = "";

            ////Etichette gialle
            //text = text + "m m" + "\r";
            //text = text + "J" + "\r";
            //text = text + "H 100" + "\r";
            //text = text + "S l1;0,0,13,16,35" + "\r";

            //text = text + "B 0,0,0,QRCODE,0.25;" + glob_ser_num_write + "\r";
            //text = text + "T 12,2,0,3,pt7,q80; " + glob_codice_fw + "\r";
            //text = text + "T 12,6,0,3,pt7,q80; " + glob_ID_newcode + "\r";
            //text = text + "T 12,10,0,3,pt7,q80; " + glob_ser_num_write + "\r";

            //text = text + "I 7,0,0,1,1,a;LogoSE" + "\r";
            //text = text + "A 1" + "\r";
            //// fine Etichette gialle

            //////Doppia etichetta piccola bianca - Software
            ////text = text + "m m" + "\r";
            ////text = text + "J" + "\r";
            ////text = text + "H 100" + "\r";
            //////text = text + "S l1;0,0,7,9,20,3,2" + "\r";
            ////text = text + "S l1;0,0,7,9,20,23,2" + "\r";
            ////text = text + "B 1,0,0,QRCODE,0.25;" + glob_UNIQUE_ID_NEW + "\r";
            //////text = text + "T 6,2,0,5,pt7,q60; " + db_sw_selezionato + "\r"; //alberto
            //////text = text + "T 12,6,0,3,pt7,q80; " + lab_IDNumber.Text + "\r";
            ////text = text + "T 6,5,0,5,pt7,q60; " + glob_UNIQUE_ID_NEW + "\r";

            //////text = text + "I 7,0,0,1,1,a;LogoSE" + "\r";
            ////text = text + "A 2" + "\r";


            //File.Delete(tmp_file);

            //if (!File.Exists(tmp_file))
            //{
            //    using (var txtFile = File.AppendText(tmp_file))
            //    {
            //        txtFile.WriteLine(text);
            //    }
            //}
            //else if (File.Exists(tmp_file))
            //{
            //    using (var txtFile = File.AppendText(tmp_file))
            //    {
            //        txtFile.WriteLine(text);
            //    }
            //}

            //// create an FTP client
            //string ipprinter = Properties.Settings.Default.IP_printer.ToString();
            //FtpClient client = new FtpClient(ipprinter);
            //client.Credentials = new NetworkCredential("ftpprint", "print");
            //client.Connect();
            //// upload a file and retry 3 times before giving up
            //client.RetryAttempts = 3;
            //client.UploadFile(tmp_file, "/SL_label.txt", FtpRemoteExists.Overwrite, true, FtpVerify.Retry);//alberto
            //client.Disconnect();

            ////File.Delete(tmp_file);
        }

        ////////////////////////////////////
        /// Funzioni per stampa ZPL Zebra //
        ////////////////////////////////////

        private void PrintLabelBrother()
        {
            string command = string.Empty;

            //Apertura porta stampante
            //int a = BROLIB_DLL.openport("Brother TJ-41");
            int a = BROLIB_DLL.openport(NamePrinter);

            command = "SIZE 23.7 mm, 8 mm";
            a = BROLIB_DLL.sendcommand(command);
            command = "DIRECTION 0,0";
            a = BROLIB_DLL.sendcommand(command);
            command = "REFERENCE 1,1";
            a = BROLIB_DLL.sendcommand(command);
            command = "OFFSET 0";
            a = BROLIB_DLL.sendcommand(command);
            command = "SET REWIND OFF";
            a = BROLIB_DLL.sendcommand(command);
            command = "SET PEEL OFF";
            a = BROLIB_DLL.sendcommand(command);
            command = "SET CUTTER OFF";
            a = BROLIB_DLL.sendcommand(command);
            command = "SET PARTIAL_CUTTER OFF";
            a = BROLIB_DLL.sendcommand(command);
            command = "SET TEAR ON";
            a = BROLIB_DLL.sendcommand(command);
            command = "CLS";
            a = BROLIB_DLL.sendcommand(command);

            //            string testo = @"""3869202200000063""";
            string testo = '"' + tbx_ReadLabel_Device.Text + '"';

            command = "QRCODE 168,52,H,10,A,0,X100,J5," + testo + "\r\n";
            a = BROLIB_DLL.sendcommand(command);

            BROLIB_DLL.printlabel("1", "1");
            BROLIB_DLL.closeport();
        }

        private async void but_Print_Click(object sender, EventArgs e)
        {
            PrintLabelBrother();
        }

        private void FindBrotherPrinters()
        {
            String pkInstalledPrinters;
            for (int i = 0; i < PrinterSettings.InstalledPrinters.Count; i++)
            {
                pkInstalledPrinters = PrinterSettings.InstalledPrinters[i];

                string upperprint = pkInstalledPrinters.ToUpper();
                bool contains = upperprint.Contains("BROTHER");
                if (contains) comboInstalledPrinters.Items.Add(pkInstalledPrinters);
            }

            int howmanyprinters = comboInstalledPrinters.Items.Count;
            if (howmanyprinters==0)
            {
                MetroFramework.MetroMessageBox.Show(this, "Warning", "Non esiste una stampante disponibile per l'applicazione su questa postazione!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                comboInstalledPrinters.SelectedIndex = 0;
                NamePrinter = comboInstalledPrinters.SelectedItem.ToString();
            }
        }
    }
}