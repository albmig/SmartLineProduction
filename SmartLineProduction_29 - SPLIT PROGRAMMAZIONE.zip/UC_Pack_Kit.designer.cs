﻿namespace SmartLineProduction
{
    partial class UC_Pack_Kit
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Pack_Kit));
            this.panel_Schede = new MetroFramework.Controls.MetroPanel();
            this.sFArticoliSchedeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.layout_Pack = new System.Windows.Forms.TableLayoutPanel();
            this.panel_grid_pack = new MetroFramework.Controls.MetroPanel();
            this.gv_kit_pack = new MetroFramework.Controls.MetroGrid();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroPanel7 = new MetroFramework.Controls.MetroPanel();
            this.tb_grid_kit_pack = new MetroFramework.Controls.MetroTextBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.btn_do_pack_kit = new MetroFramework.Controls.MetroButton();
            this.gv_pack_explo = new MetroFramework.Controls.MetroGrid();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cb_Doc_EN = new MetroFramework.Controls.MetroCheckBox();
            this.cb_Doc_IT = new MetroFramework.Controls.MetroCheckBox();
            this.panel_pack_kit = new MetroFramework.Controls.MetroPanel();
            this.pack_Kit_pdf = new AxAcroPDFLib.AxAcroPDF();
            this.panel_des_art_Kit_pack = new MetroFramework.Controls.MetroPanel();
            this.metroLabel17 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel18 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel19 = new MetroFramework.Controls.MetroLabel();
            this.sFDistinteBasiSchedeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.famProdBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_ArticoliSchedeTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_ArticoliSchedeTableAdapter();
            this.sF_DistinteBasi_SchedeTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_DistinteBasi_SchedeTableAdapter();
            this.fam_ProdTableAdapter = new SmartLineProduction.ds_SLTableAdapters.Fam_ProdTableAdapter();
            this.sFArticoliToXSWRSchedeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_ArticoliToXSWR_SchedeTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_ArticoliToXSWR_SchedeTableAdapter();
            this.layout_orizz_menu = new System.Windows.Forms.TableLayoutPanel();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.panel_Schede.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sFArticoliSchedeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            this.layout_Pack.SuspendLayout();
            this.panel_grid_pack.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_kit_pack)).BeginInit();
            this.metroPanel7.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_pack_explo)).BeginInit();
            this.metroPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel_pack_kit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pack_Kit_pdf)).BeginInit();
            this.panel_des_art_Kit_pack.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sFDistinteBasiSchedeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.famProdBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFArticoliToXSWRSchedeBindingSource)).BeginInit();
            this.layout_orizz_menu.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_Schede
            // 
            this.panel_Schede.Controls.Add(this.layout_Pack);
            this.panel_Schede.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Schede.HorizontalScrollbarBarColor = true;
            this.panel_Schede.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_Schede.HorizontalScrollbarSize = 10;
            this.panel_Schede.Location = new System.Drawing.Point(20, 55);
            this.panel_Schede.Name = "panel_Schede";
            this.panel_Schede.Size = new System.Drawing.Size(1560, 425);
            this.panel_Schede.TabIndex = 122;
            this.panel_Schede.VerticalScrollbarBarColor = true;
            this.panel_Schede.VerticalScrollbarHighlightOnWheel = false;
            this.panel_Schede.VerticalScrollbarSize = 10;
            // 
            // sFArticoliSchedeBindingSource
            // 
            this.sFArticoliSchedeBindingSource.DataMember = "SF_ArticoliSchede";
            this.sFArticoliSchedeBindingSource.DataSource = this.ds_SL;
            this.sFArticoliSchedeBindingSource.CurrentChanged += new System.EventHandler(this.sFArticoliSchedeBindingSource_CurrentChanged);
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // layout_Pack
            // 
            this.layout_Pack.ColumnCount = 2;
            this.layout_Pack.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.layout_Pack.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.layout_Pack.Controls.Add(this.panel_grid_pack, 0, 0);
            this.layout_Pack.Controls.Add(this.tableLayoutPanel2, 1, 1);
            this.layout_Pack.Controls.Add(this.panel_des_art_Kit_pack, 1, 0);
            this.layout_Pack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Pack.Location = new System.Drawing.Point(0, 0);
            this.layout_Pack.Name = "layout_Pack";
            this.layout_Pack.RowCount = 2;
            this.layout_Pack.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.layout_Pack.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_Pack.Size = new System.Drawing.Size(1560, 425);
            this.layout_Pack.TabIndex = 124;
            // 
            // panel_grid_pack
            // 
            this.panel_grid_pack.Controls.Add(this.gv_kit_pack);
            this.panel_grid_pack.Controls.Add(this.metroPanel7);
            this.panel_grid_pack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_grid_pack.HorizontalScrollbarBarColor = true;
            this.panel_grid_pack.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_grid_pack.HorizontalScrollbarSize = 10;
            this.panel_grid_pack.Location = new System.Drawing.Point(3, 3);
            this.panel_grid_pack.Name = "panel_grid_pack";
            this.layout_Pack.SetRowSpan(this.panel_grid_pack, 2);
            this.panel_grid_pack.Size = new System.Drawing.Size(144, 419);
            this.panel_grid_pack.TabIndex = 123;
            this.panel_grid_pack.VerticalScrollbarBarColor = true;
            this.panel_grid_pack.VerticalScrollbarHighlightOnWheel = false;
            this.panel_grid_pack.VerticalScrollbarSize = 10;
            // 
            // gv_kit_pack
            // 
            this.gv_kit_pack.AllowUserToAddRows = false;
            this.gv_kit_pack.AllowUserToDeleteRows = false;
            this.gv_kit_pack.AllowUserToResizeRows = false;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_kit_pack.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle8;
            this.gv_kit_pack.AutoGenerateColumns = false;
            this.gv_kit_pack.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_kit_pack.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_kit_pack.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_kit_pack.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_kit_pack.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.gv_kit_pack.ColumnHeadersHeight = 40;
            this.gv_kit_pack.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.gv_kit_pack.DataSource = this.sFArticoliSchedeBindingSource;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_kit_pack.DefaultCellStyle = dataGridViewCellStyle10;
            this.gv_kit_pack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_kit_pack.EnableHeadersVisualStyles = false;
            this.gv_kit_pack.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_kit_pack.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_kit_pack.Location = new System.Drawing.Point(0, 30);
            this.gv_kit_pack.MultiSelect = false;
            this.gv_kit_pack.Name = "gv_kit_pack";
            this.gv_kit_pack.ReadOnly = true;
            this.gv_kit_pack.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_kit_pack.RowHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.gv_kit_pack.RowHeadersVisible = false;
            this.gv_kit_pack.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_kit_pack.RowTemplate.Height = 30;
            this.gv_kit_pack.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_kit_pack.Size = new System.Drawing.Size(144, 389);
            this.gv_kit_pack.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_kit_pack.TabIndex = 0;
            this.gv_kit_pack.UseStyleColors = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Articolo";
            this.dataGridViewTextBoxColumn1.HeaderText = "Kit";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Descrizione";
            this.dataGridViewTextBoxColumn2.HeaderText = "Descrizione";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Visible = false;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "DescrizioneEstesa";
            this.dataGridViewTextBoxColumn3.HeaderText = "DescrizioneEstesa";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Visible = false;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Modello";
            this.dataGridViewTextBoxColumn4.HeaderText = "Modello";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Visible = false;
            // 
            // metroPanel7
            // 
            this.metroPanel7.BackColor = System.Drawing.Color.Transparent;
            this.metroPanel7.Controls.Add(this.tb_grid_kit_pack);
            this.metroPanel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroPanel7.HorizontalScrollbarBarColor = true;
            this.metroPanel7.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel7.HorizontalScrollbarSize = 10;
            this.metroPanel7.Location = new System.Drawing.Point(0, 0);
            this.metroPanel7.Name = "metroPanel7";
            this.metroPanel7.Size = new System.Drawing.Size(144, 30);
            this.metroPanel7.TabIndex = 3;
            this.metroPanel7.UseCustomBackColor = true;
            this.metroPanel7.VerticalScrollbarBarColor = true;
            this.metroPanel7.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel7.VerticalScrollbarSize = 10;
            // 
            // tb_grid_kit_pack
            // 
            // 
            // 
            // 
            this.tb_grid_kit_pack.CustomButton.Image = null;
            this.tb_grid_kit_pack.CustomButton.Location = new System.Drawing.Point(122, 1);
            this.tb_grid_kit_pack.CustomButton.Name = "";
            this.tb_grid_kit_pack.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_grid_kit_pack.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_grid_kit_pack.CustomButton.TabIndex = 1;
            this.tb_grid_kit_pack.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_grid_kit_pack.CustomButton.UseSelectable = true;
            this.tb_grid_kit_pack.CustomButton.Visible = false;
            this.tb_grid_kit_pack.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_grid_kit_pack.Icon = global::SmartLineProduction.Properties.Resources.Lente;
            this.tb_grid_kit_pack.IconRight = true;
            this.tb_grid_kit_pack.Lines = new string[] {
        "metroTextBox1"};
            this.tb_grid_kit_pack.Location = new System.Drawing.Point(0, 0);
            this.tb_grid_kit_pack.MaxLength = 32767;
            this.tb_grid_kit_pack.Name = "tb_grid_kit_pack";
            this.tb_grid_kit_pack.PasswordChar = '\0';
            this.tb_grid_kit_pack.PromptText = "ricerca";
            this.tb_grid_kit_pack.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_grid_kit_pack.SelectedText = "";
            this.tb_grid_kit_pack.SelectionLength = 0;
            this.tb_grid_kit_pack.SelectionStart = 0;
            this.tb_grid_kit_pack.ShortcutsEnabled = true;
            this.tb_grid_kit_pack.Size = new System.Drawing.Size(144, 23);
            this.tb_grid_kit_pack.TabIndex = 2;
            this.tb_grid_kit_pack.Text = "metroTextBox1";
            this.tb_grid_kit_pack.UseSelectable = true;
            this.tb_grid_kit_pack.WaterMark = "ricerca";
            this.tb_grid_kit_pack.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_grid_kit_pack.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tb_grid_kit_pack.TextChanged += new System.EventHandler(this.tb_grid_kit_pack_TextChanged);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.btn_do_pack_kit, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.gv_pack_explo, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.metroPanel1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel_pack_kit, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(153, 53);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1404, 369);
            this.tableLayoutPanel2.TabIndex = 122;
            // 
            // btn_do_pack_kit
            // 
            this.btn_do_pack_kit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.btn_do_pack_kit.BackColor = System.Drawing.Color.Moccasin;
            this.btn_do_pack_kit.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.btn_do_pack_kit.FontWeight = MetroFramework.MetroButtonWeight.Light;
            this.btn_do_pack_kit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_do_pack_kit.Location = new System.Drawing.Point(201, 341);
            this.btn_do_pack_kit.Name = "btn_do_pack_kit";
            this.btn_do_pack_kit.Size = new System.Drawing.Size(300, 25);
            this.btn_do_pack_kit.TabIndex = 3;
            this.btn_do_pack_kit.Text = "Procedi alla raccolta dei documenti";
            this.btn_do_pack_kit.UseCustomBackColor = true;
            this.btn_do_pack_kit.UseSelectable = true;
            this.btn_do_pack_kit.Click += new System.EventHandler(this.btn_do_pack_kit_Click);
            // 
            // gv_pack_explo
            // 
            this.gv_pack_explo.AllowUserToAddRows = false;
            this.gv_pack_explo.AllowUserToDeleteRows = false;
            this.gv_pack_explo.AllowUserToResizeRows = false;
            this.gv_pack_explo.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_pack_explo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_pack_explo.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_pack_explo.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_pack_explo.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.gv_pack_explo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_pack_explo.DefaultCellStyle = dataGridViewCellStyle13;
            this.gv_pack_explo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_pack_explo.EnableHeadersVisualStyles = false;
            this.gv_pack_explo.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_pack_explo.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_pack_explo.Location = new System.Drawing.Point(3, 73);
            this.gv_pack_explo.Name = "gv_pack_explo";
            this.gv_pack_explo.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_pack_explo.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.gv_pack_explo.RowHeadersVisible = false;
            this.gv_pack_explo.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_pack_explo.RowTemplate.Height = 40;
            this.gv_pack_explo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_pack_explo.Size = new System.Drawing.Size(696, 262);
            this.gv_pack_explo.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_pack_explo.TabIndex = 2;
            this.gv_pack_explo.UseStyleColors = true;
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.groupBox1);
            this.metroPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(3, 3);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(696, 64);
            this.metroPanel1.TabIndex = 5;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.cb_Doc_EN);
            this.groupBox1.Controls.Add(this.cb_Doc_IT);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(696, 64);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Lingua della documentazione";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::SmartLineProduction.Properties.Resources.gb;
            this.pictureBox2.Location = new System.Drawing.Point(196, 40);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(16, 16);
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SmartLineProduction.Properties.Resources.it;
            this.pictureBox1.Location = new System.Drawing.Point(196, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(16, 16);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // cb_Doc_EN
            // 
            this.cb_Doc_EN.AutoSize = true;
            this.cb_Doc_EN.Location = new System.Drawing.Point(6, 40);
            this.cb_Doc_EN.Name = "cb_Doc_EN";
            this.cb_Doc_EN.Size = new System.Drawing.Size(173, 15);
            this.cb_Doc_EN.Style = MetroFramework.MetroColorStyle.Red;
            this.cb_Doc_EN.TabIndex = 4;
            this.cb_Doc_EN.Text = "Documentazione in INGLESE";
            this.cb_Doc_EN.UseSelectable = true;
            this.cb_Doc_EN.UseStyleColors = true;
            this.cb_Doc_EN.Click += new System.EventHandler(this.cb_Doc_EN_Click);
            // 
            // cb_Doc_IT
            // 
            this.cb_Doc_IT.AutoSize = true;
            this.cb_Doc_IT.Location = new System.Drawing.Point(6, 19);
            this.cb_Doc_IT.Name = "cb_Doc_IT";
            this.cb_Doc_IT.Size = new System.Drawing.Size(180, 15);
            this.cb_Doc_IT.Style = MetroFramework.MetroColorStyle.Red;
            this.cb_Doc_IT.TabIndex = 3;
            this.cb_Doc_IT.Text = "Documentazione in ITALIANO";
            this.cb_Doc_IT.UseSelectable = true;
            this.cb_Doc_IT.UseStyleColors = true;
            this.cb_Doc_IT.Click += new System.EventHandler(this.cb_Doc_IT_Click);
            // 
            // panel_pack_kit
            // 
            this.panel_pack_kit.Controls.Add(this.pack_Kit_pdf);
            this.panel_pack_kit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_pack_kit.HorizontalScrollbarBarColor = true;
            this.panel_pack_kit.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_pack_kit.HorizontalScrollbarSize = 10;
            this.panel_pack_kit.Location = new System.Drawing.Point(705, 3);
            this.panel_pack_kit.Name = "panel_pack_kit";
            this.tableLayoutPanel2.SetRowSpan(this.panel_pack_kit, 2);
            this.panel_pack_kit.Size = new System.Drawing.Size(696, 332);
            this.panel_pack_kit.TabIndex = 6;
            this.panel_pack_kit.VerticalScrollbarBarColor = true;
            this.panel_pack_kit.VerticalScrollbarHighlightOnWheel = false;
            this.panel_pack_kit.VerticalScrollbarSize = 10;
            // 
            // pack_Kit_pdf
            // 
            this.pack_Kit_pdf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pack_Kit_pdf.Enabled = true;
            this.pack_Kit_pdf.Location = new System.Drawing.Point(0, 0);
            this.pack_Kit_pdf.Name = "pack_Kit_pdf";
            this.pack_Kit_pdf.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("pack_Kit_pdf.OcxState")));
            this.pack_Kit_pdf.Size = new System.Drawing.Size(696, 332);
            this.pack_Kit_pdf.TabIndex = 2;
            // 
            // panel_des_art_Kit_pack
            // 
            this.panel_des_art_Kit_pack.Controls.Add(this.metroLabel17);
            this.panel_des_art_Kit_pack.Controls.Add(this.metroLabel18);
            this.panel_des_art_Kit_pack.Controls.Add(this.metroLabel19);
            this.panel_des_art_Kit_pack.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_des_art_Kit_pack.HorizontalScrollbarBarColor = true;
            this.panel_des_art_Kit_pack.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Kit_pack.HorizontalScrollbarSize = 10;
            this.panel_des_art_Kit_pack.Location = new System.Drawing.Point(153, 3);
            this.panel_des_art_Kit_pack.Name = "panel_des_art_Kit_pack";
            this.panel_des_art_Kit_pack.Size = new System.Drawing.Size(1404, 44);
            this.panel_des_art_Kit_pack.TabIndex = 124;
            this.panel_des_art_Kit_pack.VerticalScrollbarBarColor = true;
            this.panel_des_art_Kit_pack.VerticalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Kit_pack.VerticalScrollbarSize = 10;
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFArticoliSchedeBindingSource, "Descrizione", true));
            this.metroLabel17.Location = new System.Drawing.Point(93, 0);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(18, 19);
            this.metroLabel17.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel17.TabIndex = 3;
            this.metroLabel17.Text = "sf";
            this.metroLabel17.UseStyleColors = true;
            // 
            // metroLabel18
            // 
            this.metroLabel18.AutoSize = true;
            this.metroLabel18.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFArticoliSchedeBindingSource, "DescrizioneEstesa", true));
            this.metroLabel18.Location = new System.Drawing.Point(93, 19);
            this.metroLabel18.Name = "metroLabel18";
            this.metroLabel18.Size = new System.Drawing.Size(43, 19);
            this.metroLabel18.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel18.TabIndex = 4;
            this.metroLabel18.Text = "Des_2";
            this.metroLabel18.UseStyleColors = true;
            // 
            // metroLabel19
            // 
            this.metroLabel19.AutoSize = true;
            this.metroLabel19.Location = new System.Drawing.Point(3, 0);
            this.metroLabel19.Name = "metroLabel19";
            this.metroLabel19.Size = new System.Drawing.Size(75, 19);
            this.metroLabel19.TabIndex = 2;
            this.metroLabel19.Text = "Descrizione";
            // 
            // sFDistinteBasiSchedeBindingSource
            // 
            this.sFDistinteBasiSchedeBindingSource.DataMember = "SF_DistinteBasi_Schede";
            this.sFDistinteBasiSchedeBindingSource.DataSource = this.ds_SL;
            // 
            // famProdBindingSource
            // 
            this.famProdBindingSource.DataMember = "Fam_Prod";
            this.famProdBindingSource.DataSource = this.ds_SL;
            // 
            // sF_ArticoliSchedeTableAdapter
            // 
            this.sF_ArticoliSchedeTableAdapter.ClearBeforeFill = true;
            // 
            // sF_DistinteBasi_SchedeTableAdapter
            // 
            this.sF_DistinteBasi_SchedeTableAdapter.ClearBeforeFill = true;
            // 
            // fam_ProdTableAdapter
            // 
            this.fam_ProdTableAdapter.ClearBeforeFill = true;
            // 
            // sFArticoliToXSWRSchedeBindingSource
            // 
            this.sFArticoliToXSWRSchedeBindingSource.DataMember = "SF_ArticoliToXSWR_Schede";
            this.sFArticoliToXSWRSchedeBindingSource.DataSource = this.ds_SL;
            // 
            // sF_ArticoliToXSWR_SchedeTableAdapter
            // 
            this.sF_ArticoliToXSWR_SchedeTableAdapter.ClearBeforeFill = true;
            // 
            // layout_orizz_menu
            // 
            this.layout_orizz_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.ColumnCount = 10;
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_exit, 10, 0);
            this.layout_orizz_menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_orizz_menu.Location = new System.Drawing.Point(20, 30);
            this.layout_orizz_menu.Name = "layout_orizz_menu";
            this.layout_orizz_menu.RowCount = 1;
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_orizz_menu.Size = new System.Drawing.Size(1560, 25);
            this.layout_orizz_menu.TabIndex = 123;
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Gainsboro;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(1485, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(75, 24);
            this.pan_Menu_exit.TabIndex = 82;
            this.pan_Menu_exit.Text = "menuStrip1";
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            this.menu_sw_exit.Click += new System.EventHandler(this.menu_sw_exit_Click);
            // 
            // UC_Pack_Kit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1600, 500);
            this.ControlBox = false;
            this.Controls.Add(this.panel_Schede);
            this.Controls.Add(this.layout_orizz_menu);
            this.DisplayHeader = false;
            this.Name = "UC_Pack_Kit";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UC_Pack_Kit_Load);
            this.panel_Schede.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sFArticoliSchedeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            this.layout_Pack.ResumeLayout(false);
            this.panel_grid_pack.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_kit_pack)).EndInit();
            this.metroPanel7.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_pack_explo)).EndInit();
            this.metroPanel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel_pack_kit.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pack_Kit_pdf)).EndInit();
            this.panel_des_art_Kit_pack.ResumeLayout(false);
            this.panel_des_art_Kit_pack.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sFDistinteBasiSchedeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.famProdBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFArticoliToXSWRSchedeBindingSource)).EndInit();
            this.layout_orizz_menu.ResumeLayout(false);
            this.layout_orizz_menu.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel panel_Schede;
        private System.Windows.Forms.TableLayoutPanel layout_Pack;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private ds_SL ds_SL;
        private System.Windows.Forms.BindingSource sFArticoliSchedeBindingSource;
        private ds_SLTableAdapters.SF_ArticoliSchedeTableAdapter sF_ArticoliSchedeTableAdapter;
        private MetroFramework.Controls.MetroPanel panel_grid_pack;
        private MetroFramework.Controls.MetroGrid gv_kit_pack;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private MetroFramework.Controls.MetroPanel metroPanel7;
        private MetroFramework.Controls.MetroTextBox tb_grid_kit_pack;
        private MetroFramework.Controls.MetroPanel panel_des_art_Kit_pack;
        private MetroFramework.Controls.MetroLabel metroLabel17;
        private MetroFramework.Controls.MetroLabel metroLabel18;
        private MetroFramework.Controls.MetroLabel metroLabel19;
        private MetroFramework.Controls.MetroGrid gv_pack_explo;
        private System.Windows.Forms.BindingSource sFDistinteBasiSchedeBindingSource;
        private ds_SLTableAdapters.SF_DistinteBasi_SchedeTableAdapter sF_DistinteBasi_SchedeTableAdapter;
        private System.Windows.Forms.BindingSource famProdBindingSource;
        private ds_SLTableAdapters.Fam_ProdTableAdapter fam_ProdTableAdapter;
        private MetroFramework.Controls.MetroButton btn_do_pack_kit;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroCheckBox cb_Doc_EN;
        private MetroFramework.Controls.MetroCheckBox cb_Doc_IT;
        private System.Windows.Forms.GroupBox groupBox1;
        private MetroFramework.Controls.MetroPanel panel_pack_kit;
        private AxAcroPDFLib.AxAcroPDF pack_Kit_pdf;
        private System.Windows.Forms.BindingSource sFArticoliToXSWRSchedeBindingSource;
        private ds_SLTableAdapters.SF_ArticoliToXSWR_SchedeTableAdapter sF_ArticoliToXSWR_SchedeTableAdapter;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TableLayoutPanel layout_orizz_menu;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
    }
}
