﻿namespace SmartLineProduction
{


    partial class ds_Prototipi
    {
    }
}
