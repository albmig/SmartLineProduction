﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using Zebra.Sdk.Comm;
using Zebra.Sdk.Printer;
using Zebra.Sdk.Printer.Discovery;


namespace SmartLineProduction
{
    public partial class UC_IndividuaLabel : MetroFramework.Forms.MetroForm
    {
        public static string qr_read_device = "";                               // la lettura "pura" del barcode
        public static string qr_sn = "";                                        // serial number del barcode (non ID Smartline)
        public static string qr_SistematicaSN = "";                             // serial number del barcode (non ID Smartline)
        public static string qr_ID = "";                                        // lettura del barcode, può essere codice articolo (classic) o ID Smartline (smartline)
        public static string qr_device = "";                                    // se smartline, contiene l'articolo estrapolato dall'id - se classic, contiene l'articolo letto
        public static string qr_fw = "";                                        // lettura del barcode
        public static string qr_ClassicSmart = "";                              // C Classic - S Smartline
        public static string qr_LottoFornitore = "";                            // da implementare - lettura del lotto sulla scheda
        public static string qr_Commessa = "";                                  // la commessa selezionata

        public UC_IndividuaLabel()
        {
            InitializeComponent();
        }

        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tbx_ReadLabel_Device_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\t' || e.KeyChar == (char)13)
            {
                e.Handled = true;
                qr_read_device = tbx_ReadLabel_Device.Text;
                AnalizzaQrDevice(qr_read_device);
                but_Reset.Focus();
            }
        }

        private void tbx_ReadLabel_Device_Leave(object sender, EventArgs e)
        {
            qr_read_device = tbx_ReadLabel_Device.Text;
            if (AnalizzaQrDevice(qr_read_device))
            {
                but_Reset.Focus();

                but_Print.Visible = true;
            }
        }

        private bool AnalizzaQrDevice(string letturabarcode)
        {
            string[] codici = letturabarcode.Split('|');
            int conta = 1;
            foreach (var word in codici)
            {
                switch (conta)
                {
                    case 1: qr_sn = word; conta++; break;
                    case 2: qr_ID = word; conta++; break;
                    case 3: qr_fw = word; conta++; break;
                }
            }

            int lungSN = qr_sn.Length;
            if (lungSN == 16)
            {
                qr_ID = qr_sn; // aggiusto la situazione di confusione che si può creare...
                qr_sn = "";
                qr_ClassicSmart = "S";
                string filtro = "Ser_OfficialSerial = " + "'" + qr_ID + "'";
                DataView dv = ds_Programmazione.SerialNumbers.DefaultView;
                dv.RowFilter = filtro;

                if (dv.Count == 0)
                {
                    MessageBox.Show("Errore grave! Impossibile trovare il numero di serie indicato!");
                    return false;
                }
                foreach (DataRowView rowView in dv)
                {
                    qr_device = rowView["Ser_Device"].ToString();
                    qr_fw = rowView["Ser_SW_Code"].ToString();
                    qr_SistematicaSN = rowView["Ser_SN_Prod"].ToString();
                }
            }
            else
            {
                qr_ClassicSmart = "C";
                qr_device = qr_ID;
            }

            lab_read_SN.Text = qr_sn;
            lab_read_ID.Text = qr_ID;
            lab_read_Device.Text = qr_device;
            lab_read_FW.Text = qr_fw;
            lab_label_SN.Text = qr_SistematicaSN;

            this.Refresh();

            return true;
        }

        private void UC_IndividuaLabel_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SerialNumbers'. È possibile spostarla o rimuoverla se necessario.
            this.serialNumbersTableAdapter.Fill(this.ds_Programmazione.SerialNumbers);

            SettaForm();

            this.WindowState = FormWindowState.Maximized;
            tbx_ReadLabel_Device.Focus();
        }

        private void SettaForm()
        {
            //this.ActiveControl = tbx_ReadLabel_Device;

            //var myControl = this.ActiveControl.Name;

            if (this.ActiveControl == null)
            {
                tbx_ReadLabel_Device.Focus();
            }
            //metroLabel4.Text = this.ActiveControl.Name;


            lab_read_SN.Text = "";
            lab_read_ID.Text = "";
            lab_read_Device.Text = "";
            lab_read_FW.Text = "";
            lab_label_SN.Text = "";
            tbx_ReadLabel_Device.Text = "";

            but_Print.Visible = false;

            cb_Correzione.SelectedItem = "0";

            tbx_ReadLabel_Device.Focus();


        }

        private void but_AttivaProc_Click(object sender, EventArgs e)
        {
            SettaForm();
        }

        private void UC_IndividuaLabel_Shown(object sender, EventArgs e)
        {
            tbx_ReadLabel_Device.Focus();
            //base.OnShown(e);
        }

        private void PrintLabel(string Item)
        {
            //Stampa Etichetta
            if (!Properties.Settings.Default.Use_printer)
            {
                return;
            }

            ////EOS CAB
            ///* Create Object Instance */
            //string tmp_file = @".\SL_label.txt";
            //string text = "";

            ////Etichette gialle
            //text = text + "m m" + "\r";
            //text = text + "J" + "\r";
            //text = text + "H 100" + "\r";
            //text = text + "S l1;0,0,13,16,35" + "\r";

            //text = text + "B 0,0,0,QRCODE,0.25;" + glob_ser_num_write + "\r";
            //text = text + "T 12,2,0,3,pt7,q80; " + glob_codice_fw + "\r";
            //text = text + "T 12,6,0,3,pt7,q80; " + glob_ID_newcode + "\r";
            //text = text + "T 12,10,0,3,pt7,q80; " + glob_ser_num_write + "\r";

            //text = text + "I 7,0,0,1,1,a;LogoSE" + "\r";
            //text = text + "A 1" + "\r";
            //// fine Etichette gialle

            //////Doppia etichetta piccola bianca - Software
            ////text = text + "m m" + "\r";
            ////text = text + "J" + "\r";
            ////text = text + "H 100" + "\r";
            //////text = text + "S l1;0,0,7,9,20,3,2" + "\r";
            ////text = text + "S l1;0,0,7,9,20,23,2" + "\r";
            ////text = text + "B 1,0,0,QRCODE,0.25;" + glob_UNIQUE_ID_NEW + "\r";
            //////text = text + "T 6,2,0,5,pt7,q60; " + db_sw_selezionato + "\r"; //alberto
            //////text = text + "T 12,6,0,3,pt7,q80; " + lab_IDNumber.Text + "\r";
            ////text = text + "T 6,5,0,5,pt7,q60; " + glob_UNIQUE_ID_NEW + "\r";

            //////text = text + "I 7,0,0,1,1,a;LogoSE" + "\r";
            ////text = text + "A 2" + "\r";


            //File.Delete(tmp_file);

            //if (!File.Exists(tmp_file))
            //{
            //    using (var txtFile = File.AppendText(tmp_file))
            //    {
            //        txtFile.WriteLine(text);
            //    }
            //}
            //else if (File.Exists(tmp_file))
            //{
            //    using (var txtFile = File.AppendText(tmp_file))
            //    {
            //        txtFile.WriteLine(text);
            //    }
            //}

            //// create an FTP client
            //string ipprinter = Properties.Settings.Default.IP_printer.ToString();
            //FtpClient client = new FtpClient(ipprinter);
            //client.Credentials = new NetworkCredential("ftpprint", "print");
            //client.Connect();
            //// upload a file and retry 3 times before giving up
            //client.RetryAttempts = 3;
            //client.UploadFile(tmp_file, "/SL_label.txt", FtpRemoteExists.Overwrite, true, FtpVerify.Retry);//alberto
            //client.Disconnect();

            ////File.Delete(tmp_file);
        }

        ////////////////////////////////////
        /// Funzioni per stampa ZPL Zebra //
        ////////////////////////////////////
        private async void but_Print_Click(object sender, EventArgs e)
        {
            Connection printerConnection = null;
            try
            {
                printerConnection = GetConnection();
                string ipport = Properties.Settings.Default.IP_printer;
                int port = 9100;

            }
            catch (ConnectionException)
            {
                lab_printer.Text = "Invalid Address and/or Port";
                lab_printer.Refresh();
                await Task.Delay(1000);
                lab_printer.Text = "Not Connected";
                lab_printer.Refresh();
                return;
            }

            await Task.Run(async () =>
            {
                try
                {
                    lab_printer.Text = "Connecting...";
                    lab_printer.Refresh();
                    await Task.Delay(1500);

                    printerConnection.Open();

                    lab_printer.Text = "Connected";
                    lab_printer.Refresh();
                    await Task.Delay(1500);

                    PrinterLanguage printerLanguage = ZebraPrinterFactory.GetInstance(printerConnection).PrinterControlLanguage;

                    lab_printer.Text = "Sending Data...";
                    lab_printer.Refresh();

                    printerConnection.Write(WriteLabel(printerLanguage));
                }
                catch (ConnectionException)
                {
                    lab_printer.Text = "Communications Error";
                    lab_printer.Refresh();
                }
                catch (ZebraPrinterLanguageUnknownException)
                {
                    lab_printer.Text = "Invalid Printer Language";
                    lab_printer.Refresh();
                }
                finally
                {
                    try
                    {
                        await Task.Delay(1000);
                        lab_printer.Text = "Disconnecting...";
                        lab_printer.Refresh();
                        if (printerConnection != null)
                        {
                            printerConnection.Close();
                        }

                        await Task.Delay(1000);
                        lab_printer.Text = "Not Connected";
                        lab_printer.Refresh();
                    }
                    catch (ConnectionException)
                    {
                    }
                    finally
                    {
                    }
                }
            });

        }

        public Connection GetConnection()
        {
            try
            {
                //int port = string.IsNullOrEmpty(viewModel.Port) ? 9100 : int.Parse(viewModel.Port);
                //return new TcpConnection(viewModel.IpAddress, port);

                string ipaddr = Properties.Settings.Default.IP_printer;
                int port = 9100;
                return new TcpConnection(ipaddr, port);
            }
            catch (Exception e)
            {
                throw new ConnectionException(e.Message, e);
            }
        }

        private byte[] GetConfigLabel(PrinterLanguage printerLanguage)
        {
            byte[] configLabel = null;
            if (printerLanguage == PrinterLanguage.ZPL)
            {
                //configLabel = Encoding.UTF8.GetBytes("^XA^FO17,16^GB379,371,8^FS^FT65,255^A0N,135,134^FDTEST^FS^XZ");

                //Modifica del 15.11.2021 - etichetta più performante
                configLabel = Encoding.UTF8.GetBytes("^^XA~TA014~JSN^LT0^MNN^MTT^PON^PMN^LH0,0^JMA^PR2,2~SD30^JUS^LRN^CI0^XZ");
            }
            else if (printerLanguage == PrinterLanguage.CPCL)
            {
                string cpclConfigLabel = "! 0 200 200 406 1\r\n" + "ON-FEED IGNORE\r\n" + "BOX 20 20 380 380 8\r\n" + "T 0 6 137 177 TEST\r\n" + "PRINT\r\n";
                configLabel = Encoding.UTF8.GetBytes(cpclConfigLabel);
            }
            return configLabel;
        }

        private byte[] WriteLabel(PrinterLanguage printerLanguage)
        {
            byte[] configLabel = null;
            if (printerLanguage == PrinterLanguage.ZPL)
            {

                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                int scostamento = 20;
                scostamento = scostamento + Convert.ToInt32(cb_Correzione.Text);
                lab_correzione.Text = scostamento.ToString();
                lab_correzione.Refresh();

                //Versione precedente
                //string ZPL = "^XA";                              //Start of label format
                //ZPL = ZPL + "~TA000";                            //Tear-off Adjust Position
                //ZPL = ZPL + "^LT0";                              //Label Top
                //ZPL = ZPL + "^MTT";                              //Media Type = T -- thermal transfer
                //ZPL = ZPL + "^MMT";                              //
                //ZPL = ZPL + "^MNV";                              //media tracking = V -- continuous media, variable length
                //ZPL = ZPL + "^PR1";                              //Print Rate
                //ZPL = ZPL + "^PW368";                            //Print Width
                //ZPL = ZPL + "^LL0088";                           //Label Length
                //ZPL = ZPL + "^LT" + scostamento.ToString();      //Set start position
                ////ZPL = ZPL + "^FO60,0";                           //Set start position
                //ZPL = ZPL + "^BXN,3,200";                        //Set Bar Code Datamatrix
                ////ZPL = ZPL + "^FD" + "3929202100000097" + "^FS";  //Data Field
                //ZPL = ZPL + "^BY28,28^FT65,0^BXN,2,200,0,0,1,~";
                ////ZPL = ZPL + "^FH\\^FD3929202100000097^FS";
                //ZPL = ZPL + "^FH\\^FD" + tbx_ReadLabel_Device.Text + "^FS";
                ////ZPL = ZPL + "^BY28,28^FT190,0^BXN,2,200,0,0,1,~"; //241
                //ZPL = ZPL + "^BY28,28^FT241,0^BXN,2,200,0,0,1,~"; //241
                ////ZPL = ZPL + "^FH\\^FD1901202100000095^FS";
                //ZPL = ZPL + "^FH\\^FD" + tbx_ReadLabel_Device.Text + "^FS";

                //ZPL = ZPL + "^XZ";                               //End of label format
                //                                                 //ZPL = ZPL + "^POI";                            //Print Orientation
                //                                                 //ZPL = ZPL + "^JMA";                            //Set Dots per Millimeter - A = 24 dots/mm, 12 dots/mm, 8 dots/mm or 6 dots/mm
                //                                                 //ZPL = ZPL + "~SDA25";                          //Set Darkness
                //                                                 //ZPL = ZPL + "^CI9";                            //Change International Font/Encoding
                //                                                 //ZPL = ZPL + "^PQ4";                            //Print copies
                //                                                 //ZPL = ZPL + "^MD";                             //media darkness -- da vedere
                //                                                 //ZPL = ZPL + "^CFE,25";                         //Change Font
                //                                                 //ZPL = ZPL + "^LT-30";                          //Label top position
                //                                                 //ZPL = ZPL + "^LT10";                           //Label top position
                //                                                 //ZPL = ZPL + "^FO00,00^ADN,36,20^FDRRRRRRRRRRRR^FS";

                //NUOVA VERSIONE
                string ZPL = "^XA";                              //Start of label format
                ZPL = ZPL + "^MMT";                              //Media Type = T -- thermal transfer
                ZPL = ZPL + "^PW208";                            //Print Width
                ZPL = ZPL + "^LL0092";                           //Label Length
                ZPL = ZPL + "^LS28";                             //Label Shift
                ZPL = ZPL + "^LT" + scostamento.ToString();      //Set start position
                ZPL = ZPL + "^BXN,3,200";                        //Set Bar Code Datamatrix
                ZPL = ZPL + "^BY28,28^FT65,0^BXN,2,200,0,0,1,~";
                ZPL = ZPL + "^FH\\^FD" + tbx_ReadLabel_Device.Text + "^FS";
                ZPL = ZPL + "^BY28,28^FT241,0^BXN,2,200,0,0,1,~"; //241
                ZPL = ZPL + "^FH\\^FD" + tbx_ReadLabel_Device.Text + "^FS";
                ZPL = ZPL + "^XZ";                               //End of label format

                // send command
                configLabel = Encoding.UTF8.GetBytes(ZPL);
            }
            else if (printerLanguage == PrinterLanguage.CPCL)
            {
                string cpclConfigLabel = "! 0 200 200 406 1\r\n" + "ON-FEED IGNORE\r\n" + "BOX 20 20 380 380 8\r\n" + "T 0 6 137 177 TEST\r\n" + "PRINT\r\n";
                configLabel = Encoding.UTF8.GetBytes(cpclConfigLabel);
            }
            return configLabel;
        }

    }
}