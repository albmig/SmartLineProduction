﻿namespace SmartLineProduction
{


    partial class ds_Ncr
    {
    }
}

namespace SmartLineProduction.ds_NcrTableAdapters {
    
    
    public partial class User_ResponsabileTableAdapter {
    }
}
