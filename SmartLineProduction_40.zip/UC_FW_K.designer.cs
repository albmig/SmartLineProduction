﻿namespace SmartLineProduction
{
    partial class UC_FW_K
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_FW_K));
            this.panel_FW_R = new MetroFramework.Controls.MetroPanel();
            this.gv_FW_K = new MetroFramework.Controls.MetroGrid();
            this.gv_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_TipoDevice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Des1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Des2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Versione = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Revisione = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_IsStandard = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.gv_FW_R_MenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.versioneToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.revisioneToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.aggiungiRevisioneAllelementoSelezionatoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.firmwareBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_Programmazione = new SmartLineProduction.ds_Programmazione();
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.tb_gv_Code = new MetroFramework.Controls.MetroTextBox();
            this.panel_dati = new MetroFramework.Controls.MetroPanel();
            this.tb_gv_Versione = new MetroFramework.Controls.MetroTextBox();
            this.tb_gv_Revisione = new MetroFramework.Controls.MetroTextBox();
            this.cbox_SoftwareStandard = new MetroFramework.Controls.MetroCheckBox();
            this.tb_gv_Des1 = new MetroFramework.Controls.MetroTextBox();
            this.tb_gv_Des2 = new MetroFramework.Controls.MetroTextBox();
            this.gv_Famiglia = new MetroFramework.Controls.MetroGrid();
            this.gv_Famiglia_Check = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.gv_Famiglia_Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Famiglia_Prefix = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Famiglia_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Famiglia_Label = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Famiglia_Tipo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Famiglia_isDevice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Famiglia_Commessa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Famiglia_Len = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Famiglia_Ident = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.famProdBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroLabel22 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel21 = new MetroFramework.Controls.MetroLabel();
            this.layout_dati = new System.Windows.Forms.TableLayoutPanel();
            this.panel_funzionamento = new MetroFramework.Controls.MetroPanel();
            this.rtb_Funzionamento = new System.Windows.Forms.RichTextBox();
            this.metroLabel20 = new MetroFramework.Controls.MetroLabel();
            this.panel_history = new MetroFramework.Controls.MetroPanel();
            this.gv_history = new MetroFramework.Controls.MetroGrid();
            this.history_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.history_Revision = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.history_FromDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel_spacer = new MetroFramework.Controls.MetroPanel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.panel_revisioni = new MetroFramework.Controls.MetroPanel();
            this.rtb_Revisioni = new System.Windows.Forms.RichTextBox();
            this.metroLabel19 = new MetroFramework.Controls.MetroLabel();
            this.pan_Menu_comandi = new System.Windows.Forms.MenuStrip();
            this.menu_sw_new = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_sw_div01 = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_sw_clona = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_sw_div02 = new System.Windows.Forms.ToolStripMenuItem();
            this.creaRevisioneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pan_Menu_salva = new System.Windows.Forms.MenuStrip();
            this.menu_sw_salva = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_sw_div12 = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_sw_annulla = new System.Windows.Forms.ToolStripMenuItem();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.layout_menu = new System.Windows.Forms.TableLayoutPanel();
            this.firmwareTableAdapter = new SmartLineProduction.ds_ProgrammazioneTableAdapters.FirmwareTableAdapter();
            this.fam_ProdTableAdapter = new SmartLineProduction.ds_SLTableAdapters.Fam_ProdTableAdapter();
            this.panel_FW_R.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_FW_K)).BeginInit();
            this.gv_FW_R_MenuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.firmwareBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_Programmazione)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            this.panel_dati.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Famiglia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.famProdBindingSource)).BeginInit();
            this.layout_dati.SuspendLayout();
            this.panel_funzionamento.SuspendLayout();
            this.panel_history.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_history)).BeginInit();
            this.panel_revisioni.SuspendLayout();
            this.pan_Menu_comandi.SuspendLayout();
            this.pan_Menu_salva.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            this.layout_menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_FW_R
            // 
            this.panel_FW_R.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_FW_R.Controls.Add(this.gv_FW_K);
            this.panel_FW_R.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_FW_R.HorizontalScrollbarBarColor = true;
            this.panel_FW_R.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_FW_R.HorizontalScrollbarSize = 10;
            this.panel_FW_R.Location = new System.Drawing.Point(20, 55);
            this.panel_FW_R.Name = "panel_FW_R";
            this.panel_FW_R.Size = new System.Drawing.Size(150, 739);
            this.panel_FW_R.TabIndex = 72;
            this.panel_FW_R.VerticalScrollbarBarColor = true;
            this.panel_FW_R.VerticalScrollbarHighlightOnWheel = false;
            this.panel_FW_R.VerticalScrollbarSize = 10;
            // 
            // gv_FW_K
            // 
            this.gv_FW_K.AccessibleDescription = " ";
            this.gv_FW_K.AllowUserToAddRows = false;
            this.gv_FW_K.AllowUserToDeleteRows = false;
            this.gv_FW_K.AllowUserToOrderColumns = true;
            this.gv_FW_K.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.gv_FW_K.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.gv_FW_K.AutoGenerateColumns = false;
            this.gv_FW_K.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.gv_FW_K.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_FW_K.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_FW_K.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_FW_K.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_FW_K.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gv_FW_K.ColumnHeadersHeight = 40;
            this.gv_FW_K.ColumnHeadersVisible = false;
            this.gv_FW_K.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gv_Code,
            this.gv_TipoDevice,
            this.gv_Des1,
            this.gv_Des2,
            this.gv_Versione,
            this.gv_Revisione,
            this.gv_IsStandard});
            this.gv_FW_K.ContextMenuStrip = this.gv_FW_R_MenuStrip;
            this.gv_FW_K.DataSource = this.firmwareBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_FW_K.DefaultCellStyle = dataGridViewCellStyle3;
            this.gv_FW_K.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_FW_K.EnableHeadersVisualStyles = false;
            this.gv_FW_K.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_FW_K.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_FW_K.Location = new System.Drawing.Point(0, 0);
            this.gv_FW_K.MultiSelect = false;
            this.gv_FW_K.Name = "gv_FW_K";
            this.gv_FW_K.ReadOnly = true;
            this.gv_FW_K.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_FW_K.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.gv_FW_K.RowHeadersVisible = false;
            this.gv_FW_K.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_FW_K.RowTemplate.DividerHeight = 1;
            this.gv_FW_K.RowTemplate.Height = 30;
            this.gv_FW_K.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_FW_K.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_FW_K.Size = new System.Drawing.Size(148, 737);
            this.gv_FW_K.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_FW_K.TabIndex = 2;
            this.gv_FW_K.UseCustomBackColor = true;
            this.gv_FW_K.UseCustomForeColor = true;
            this.gv_FW_K.UseStyleColors = true;
            this.gv_FW_K.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.gv_FW_R_CellPainting);
            // 
            // gv_Code
            // 
            this.gv_Code.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_Code.DataPropertyName = "SW_Code";
            this.gv_Code.HeaderText = "SW_Code";
            this.gv_Code.Name = "gv_Code";
            this.gv_Code.ReadOnly = true;
            // 
            // gv_TipoDevice
            // 
            this.gv_TipoDevice.DataPropertyName = "SW_TipoDevice";
            this.gv_TipoDevice.HeaderText = "SW_TipoDevice";
            this.gv_TipoDevice.Name = "gv_TipoDevice";
            this.gv_TipoDevice.ReadOnly = true;
            this.gv_TipoDevice.Visible = false;
            // 
            // gv_Des1
            // 
            this.gv_Des1.DataPropertyName = "SW_Descrizione";
            this.gv_Des1.HeaderText = "SW_Descrizione";
            this.gv_Des1.Name = "gv_Des1";
            this.gv_Des1.ReadOnly = true;
            this.gv_Des1.Visible = false;
            // 
            // gv_Des2
            // 
            this.gv_Des2.DataPropertyName = "SW_Descrizione_EN";
            this.gv_Des2.HeaderText = "SW_Descrizione_EN";
            this.gv_Des2.Name = "gv_Des2";
            this.gv_Des2.ReadOnly = true;
            this.gv_Des2.Visible = false;
            // 
            // gv_Versione
            // 
            this.gv_Versione.DataPropertyName = "SW_Versione";
            this.gv_Versione.HeaderText = "SW_Versione";
            this.gv_Versione.Name = "gv_Versione";
            this.gv_Versione.ReadOnly = true;
            this.gv_Versione.Visible = false;
            // 
            // gv_Revisione
            // 
            this.gv_Revisione.DataPropertyName = "SW_Revisione";
            this.gv_Revisione.HeaderText = "SW_Revisione";
            this.gv_Revisione.Name = "gv_Revisione";
            this.gv_Revisione.ReadOnly = true;
            this.gv_Revisione.Visible = false;
            // 
            // gv_IsStandard
            // 
            this.gv_IsStandard.DataPropertyName = "SW_Standard";
            this.gv_IsStandard.HeaderText = "SW_Standard";
            this.gv_IsStandard.Name = "gv_IsStandard";
            this.gv_IsStandard.ReadOnly = true;
            this.gv_IsStandard.Visible = false;
            // 
            // gv_FW_R_MenuStrip
            // 
            this.gv_FW_R_MenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.versioneToolStripMenuItem1,
            this.revisioneToolStripMenuItem1});
            this.gv_FW_R_MenuStrip.Name = "gv_FW_R_MenuStrip";
            this.gv_FW_R_MenuStrip.Size = new System.Drawing.Size(125, 48);
            // 
            // versioneToolStripMenuItem1
            // 
            this.versioneToolStripMenuItem1.Name = "versioneToolStripMenuItem1";
            this.versioneToolStripMenuItem1.Size = new System.Drawing.Size(124, 22);
            this.versioneToolStripMenuItem1.Text = "Versione";
            // 
            // revisioneToolStripMenuItem1
            // 
            this.revisioneToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aggiungiRevisioneAllelementoSelezionatoToolStripMenuItem});
            this.revisioneToolStripMenuItem1.Name = "revisioneToolStripMenuItem1";
            this.revisioneToolStripMenuItem1.Size = new System.Drawing.Size(124, 22);
            this.revisioneToolStripMenuItem1.Text = "Revisione";
            // 
            // aggiungiRevisioneAllelementoSelezionatoToolStripMenuItem
            // 
            this.aggiungiRevisioneAllelementoSelezionatoToolStripMenuItem.Name = "aggiungiRevisioneAllelementoSelezionatoToolStripMenuItem";
            this.aggiungiRevisioneAllelementoSelezionatoToolStripMenuItem.Size = new System.Drawing.Size(306, 22);
            this.aggiungiRevisioneAllelementoSelezionatoToolStripMenuItem.Text = "Aggiungi Revisione all\'elemento selezionato";
            this.aggiungiRevisioneAllelementoSelezionatoToolStripMenuItem.Click += new System.EventHandler(this.creaRevisioneToolStripMenuItem_Click);
            // 
            // firmwareBindingSource
            // 
            this.firmwareBindingSource.DataMember = "Firmware";
            this.firmwareBindingSource.DataSource = this.ds_Programmazione;
            this.firmwareBindingSource.Sort = "SW_Code desc";
            this.firmwareBindingSource.CurrentChanged += new System.EventHandler(this.firmwareBindingSource_CurrentChanged);
            // 
            // ds_Programmazione
            // 
            this.ds_Programmazione.DataSetName = "ds_Programmazione";
            this.ds_Programmazione.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(6, 9);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(109, 19);
            this.metroLabel1.TabIndex = 73;
            this.metroLabel1.Text = "Codice Firmware";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(6, 39);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(75, 19);
            this.metroLabel3.TabIndex = 75;
            this.metroLabel3.Text = "Descrizione";
            // 
            // tb_gv_Code
            // 
            // 
            // 
            // 
            this.tb_gv_Code.CustomButton.Image = null;
            this.tb_gv_Code.CustomButton.Location = new System.Drawing.Point(116, 1);
            this.tb_gv_Code.CustomButton.Name = "";
            this.tb_gv_Code.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_gv_Code.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_gv_Code.CustomButton.TabIndex = 1;
            this.tb_gv_Code.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_gv_Code.CustomButton.UseSelectable = true;
            this.tb_gv_Code.CustomButton.Visible = false;
            this.tb_gv_Code.Lines = new string[] {
        " "};
            this.tb_gv_Code.Location = new System.Drawing.Point(152, 9);
            this.tb_gv_Code.MaxLength = 32767;
            this.tb_gv_Code.Name = "tb_gv_Code";
            this.tb_gv_Code.PasswordChar = '\0';
            this.tb_gv_Code.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_gv_Code.SelectedText = "";
            this.tb_gv_Code.SelectionLength = 0;
            this.tb_gv_Code.SelectionStart = 0;
            this.tb_gv_Code.ShortcutsEnabled = true;
            this.tb_gv_Code.Size = new System.Drawing.Size(138, 23);
            this.tb_gv_Code.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_gv_Code.TabIndex = 1;
            this.tb_gv_Code.Text = " ";
            this.tb_gv_Code.UseSelectable = true;
            this.tb_gv_Code.UseStyleColors = true;
            this.tb_gv_Code.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_gv_Code.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // panel_dati
            // 
            this.layout_dati.SetColumnSpan(this.panel_dati, 2);
            this.panel_dati.Controls.Add(this.tb_gv_Code);
            this.panel_dati.Controls.Add(this.tb_gv_Versione);
            this.panel_dati.Controls.Add(this.tb_gv_Revisione);
            this.panel_dati.Controls.Add(this.cbox_SoftwareStandard);
            this.panel_dati.Controls.Add(this.tb_gv_Des1);
            this.panel_dati.Controls.Add(this.tb_gv_Des2);
            this.panel_dati.Controls.Add(this.gv_Famiglia);
            this.panel_dati.Controls.Add(this.metroLabel22);
            this.panel_dati.Controls.Add(this.metroLabel21);
            this.panel_dati.Controls.Add(this.metroLabel3);
            this.panel_dati.Controls.Add(this.metroLabel1);
            this.panel_dati.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_dati.HorizontalScrollbarBarColor = true;
            this.panel_dati.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_dati.HorizontalScrollbarSize = 10;
            this.panel_dati.Location = new System.Drawing.Point(3, 3);
            this.panel_dati.Name = "panel_dati";
            this.panel_dati.Size = new System.Drawing.Size(874, 500);
            this.panel_dati.TabIndex = 77;
            this.panel_dati.VerticalScrollbarBarColor = true;
            this.panel_dati.VerticalScrollbarHighlightOnWheel = false;
            this.panel_dati.VerticalScrollbarSize = 10;
            // 
            // tb_gv_Versione
            // 
            // 
            // 
            // 
            this.tb_gv_Versione.CustomButton.Image = null;
            this.tb_gv_Versione.CustomButton.Location = new System.Drawing.Point(48, 1);
            this.tb_gv_Versione.CustomButton.Name = "";
            this.tb_gv_Versione.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_gv_Versione.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_gv_Versione.CustomButton.TabIndex = 1;
            this.tb_gv_Versione.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_gv_Versione.CustomButton.UseSelectable = true;
            this.tb_gv_Versione.CustomButton.Visible = false;
            this.tb_gv_Versione.Lines = new string[] {
        "metroTextBox1"};
            this.tb_gv_Versione.Location = new System.Drawing.Point(421, 9);
            this.tb_gv_Versione.MaxLength = 32767;
            this.tb_gv_Versione.Name = "tb_gv_Versione";
            this.tb_gv_Versione.PasswordChar = '\0';
            this.tb_gv_Versione.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_gv_Versione.SelectedText = "";
            this.tb_gv_Versione.SelectionLength = 0;
            this.tb_gv_Versione.SelectionStart = 0;
            this.tb_gv_Versione.ShortcutsEnabled = true;
            this.tb_gv_Versione.Size = new System.Drawing.Size(70, 23);
            this.tb_gv_Versione.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_gv_Versione.TabIndex = 2;
            this.tb_gv_Versione.Text = "metroTextBox1";
            this.tb_gv_Versione.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tb_gv_Versione.UseSelectable = true;
            this.tb_gv_Versione.UseStyleColors = true;
            this.tb_gv_Versione.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_gv_Versione.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tb_gv_Versione.Validating += new System.ComponentModel.CancelEventHandler(this.tb_gv_Versione_Validating);
            // 
            // tb_gv_Revisione
            // 
            // 
            // 
            // 
            this.tb_gv_Revisione.CustomButton.Image = null;
            this.tb_gv_Revisione.CustomButton.Location = new System.Drawing.Point(14, 1);
            this.tb_gv_Revisione.CustomButton.Name = "";
            this.tb_gv_Revisione.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_gv_Revisione.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_gv_Revisione.CustomButton.TabIndex = 1;
            this.tb_gv_Revisione.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_gv_Revisione.CustomButton.UseSelectable = true;
            this.tb_gv_Revisione.CustomButton.Visible = false;
            this.tb_gv_Revisione.Lines = new string[] {
        "metroTextBox1"};
            this.tb_gv_Revisione.Location = new System.Drawing.Point(497, 9);
            this.tb_gv_Revisione.MaxLength = 32767;
            this.tb_gv_Revisione.Name = "tb_gv_Revisione";
            this.tb_gv_Revisione.PasswordChar = '\0';
            this.tb_gv_Revisione.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_gv_Revisione.SelectedText = "";
            this.tb_gv_Revisione.SelectionLength = 0;
            this.tb_gv_Revisione.SelectionStart = 0;
            this.tb_gv_Revisione.ShortcutsEnabled = true;
            this.tb_gv_Revisione.Size = new System.Drawing.Size(36, 23);
            this.tb_gv_Revisione.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_gv_Revisione.TabIndex = 3;
            this.tb_gv_Revisione.Text = "metroTextBox1";
            this.tb_gv_Revisione.UseSelectable = true;
            this.tb_gv_Revisione.UseStyleColors = true;
            this.tb_gv_Revisione.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_gv_Revisione.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tb_gv_Revisione.Validating += new System.ComponentModel.CancelEventHandler(this.tb_gv_Revisione_Validating);
            // 
            // cbox_SoftwareStandard
            // 
            this.cbox_SoftwareStandard.AutoSize = true;
            this.cbox_SoftwareStandard.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbox_SoftwareStandard.Location = new System.Drawing.Point(565, 13);
            this.cbox_SoftwareStandard.Name = "cbox_SoftwareStandard";
            this.cbox_SoftwareStandard.Size = new System.Drawing.Size(119, 15);
            this.cbox_SoftwareStandard.Style = MetroFramework.MetroColorStyle.Red;
            this.cbox_SoftwareStandard.TabIndex = 4;
            this.cbox_SoftwareStandard.Text = "Software Standard";
            this.cbox_SoftwareStandard.UseSelectable = true;
            this.cbox_SoftwareStandard.UseStyleColors = true;
            this.cbox_SoftwareStandard.Click += new System.EventHandler(this.cbox_SoftwareStandard_Click);
            // 
            // tb_gv_Des1
            // 
            // 
            // 
            // 
            this.tb_gv_Des1.CustomButton.Image = null;
            this.tb_gv_Des1.CustomButton.Location = new System.Drawing.Point(510, 1);
            this.tb_gv_Des1.CustomButton.Name = "";
            this.tb_gv_Des1.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_gv_Des1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_gv_Des1.CustomButton.TabIndex = 1;
            this.tb_gv_Des1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_gv_Des1.CustomButton.UseSelectable = true;
            this.tb_gv_Des1.CustomButton.Visible = false;
            this.tb_gv_Des1.Lines = new string[] {
        "metroTextBox1"};
            this.tb_gv_Des1.Location = new System.Drawing.Point(152, 39);
            this.tb_gv_Des1.MaxLength = 32767;
            this.tb_gv_Des1.Name = "tb_gv_Des1";
            this.tb_gv_Des1.PasswordChar = '\0';
            this.tb_gv_Des1.PromptText = "Descrizione del firmware";
            this.tb_gv_Des1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_gv_Des1.SelectedText = "";
            this.tb_gv_Des1.SelectionLength = 0;
            this.tb_gv_Des1.SelectionStart = 0;
            this.tb_gv_Des1.ShortcutsEnabled = true;
            this.tb_gv_Des1.Size = new System.Drawing.Size(532, 23);
            this.tb_gv_Des1.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_gv_Des1.TabIndex = 5;
            this.tb_gv_Des1.Text = "metroTextBox1";
            this.tb_gv_Des1.UseSelectable = true;
            this.tb_gv_Des1.UseStyleColors = true;
            this.tb_gv_Des1.WaterMark = "Descrizione del firmware";
            this.tb_gv_Des1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_gv_Des1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // tb_gv_Des2
            // 
            // 
            // 
            // 
            this.tb_gv_Des2.CustomButton.Image = null;
            this.tb_gv_Des2.CustomButton.Location = new System.Drawing.Point(510, 1);
            this.tb_gv_Des2.CustomButton.Name = "";
            this.tb_gv_Des2.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_gv_Des2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_gv_Des2.CustomButton.TabIndex = 1;
            this.tb_gv_Des2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_gv_Des2.CustomButton.UseSelectable = true;
            this.tb_gv_Des2.CustomButton.Visible = false;
            this.tb_gv_Des2.Lines = new string[] {
        "tb_gv_Des2"};
            this.tb_gv_Des2.Location = new System.Drawing.Point(152, 68);
            this.tb_gv_Des2.MaxLength = 32767;
            this.tb_gv_Des2.Name = "tb_gv_Des2";
            this.tb_gv_Des2.PasswordChar = '\0';
            this.tb_gv_Des2.PromptText = "Descrizione del firmware (in inglese)";
            this.tb_gv_Des2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_gv_Des2.SelectedText = "";
            this.tb_gv_Des2.SelectionLength = 0;
            this.tb_gv_Des2.SelectionStart = 0;
            this.tb_gv_Des2.ShortcutsEnabled = true;
            this.tb_gv_Des2.Size = new System.Drawing.Size(532, 23);
            this.tb_gv_Des2.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_gv_Des2.TabIndex = 6;
            this.tb_gv_Des2.Text = "tb_gv_Des2";
            this.tb_gv_Des2.UseSelectable = true;
            this.tb_gv_Des2.UseStyleColors = true;
            this.tb_gv_Des2.WaterMark = "Descrizione del firmware (in inglese)";
            this.tb_gv_Des2.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_gv_Des2.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // gv_Famiglia
            // 
            this.gv_Famiglia.AllowUserToAddRows = false;
            this.gv_Famiglia.AllowUserToDeleteRows = false;
            this.gv_Famiglia.AllowUserToResizeRows = false;
            this.gv_Famiglia.AutoGenerateColumns = false;
            this.gv_Famiglia.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Famiglia.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Famiglia.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_Famiglia.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Famiglia.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.gv_Famiglia.ColumnHeadersHeight = 40;
            this.gv_Famiglia.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gv_Famiglia_Check,
            this.gv_Famiglia_Id,
            this.gv_Famiglia_Prefix,
            this.gv_Famiglia_Name,
            this.gv_Famiglia_Label,
            this.gv_Famiglia_Tipo,
            this.gv_Famiglia_isDevice,
            this.gv_Famiglia_Commessa,
            this.gv_Famiglia_Len,
            this.gv_Famiglia_Ident});
            this.gv_Famiglia.DataSource = this.famProdBindingSource;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Famiglia.DefaultCellStyle = dataGridViewCellStyle9;
            this.gv_Famiglia.EnableHeadersVisualStyles = false;
            this.gv_Famiglia.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Famiglia.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Famiglia.Location = new System.Drawing.Point(697, 38);
            this.gv_Famiglia.MultiSelect = false;
            this.gv_Famiglia.Name = "gv_Famiglia";
            this.gv_Famiglia.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Famiglia.RowHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.gv_Famiglia.RowHeadersVisible = false;
            this.gv_Famiglia.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Famiglia.RowTemplate.Height = 40;
            this.gv_Famiglia.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Famiglia.Size = new System.Drawing.Size(240, 444);
            this.gv_Famiglia.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_Famiglia.TabIndex = 121;
            this.gv_Famiglia.UseCustomBackColor = true;
            this.gv_Famiglia.UseCustomForeColor = true;
            this.gv_Famiglia.UseStyleColors = true;
            // 
            // gv_Famiglia_Check
            // 
            this.gv_Famiglia_Check.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Famiglia_Check.DividerWidth = 1;
            this.gv_Famiglia_Check.HeaderText = "Compatibile";
            this.gv_Famiglia_Check.Name = "gv_Famiglia_Check";
            this.gv_Famiglia_Check.Width = 74;
            // 
            // gv_Famiglia_Id
            // 
            this.gv_Famiglia_Id.DataPropertyName = "Id";
            this.gv_Famiglia_Id.HeaderText = "Id";
            this.gv_Famiglia_Id.Name = "gv_Famiglia_Id";
            this.gv_Famiglia_Id.ReadOnly = true;
            this.gv_Famiglia_Id.Visible = false;
            // 
            // gv_Famiglia_Prefix
            // 
            this.gv_Famiglia_Prefix.DataPropertyName = "Fam_Prefix";
            this.gv_Famiglia_Prefix.HeaderText = "Fam_Prefix";
            this.gv_Famiglia_Prefix.Name = "gv_Famiglia_Prefix";
            this.gv_Famiglia_Prefix.Visible = false;
            // 
            // gv_Famiglia_Name
            // 
            this.gv_Famiglia_Name.DataPropertyName = "Fam_Name";
            this.gv_Famiglia_Name.HeaderText = "Fam_Name";
            this.gv_Famiglia_Name.Name = "gv_Famiglia_Name";
            this.gv_Famiglia_Name.Visible = false;
            // 
            // gv_Famiglia_Label
            // 
            this.gv_Famiglia_Label.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_Famiglia_Label.DataPropertyName = "Fam_Label";
            this.gv_Famiglia_Label.HeaderText = "Famiglia";
            this.gv_Famiglia_Label.Name = "gv_Famiglia_Label";
            this.gv_Famiglia_Label.ReadOnly = true;
            // 
            // gv_Famiglia_Tipo
            // 
            this.gv_Famiglia_Tipo.DataPropertyName = "Fam_Tipo";
            this.gv_Famiglia_Tipo.HeaderText = "Fam_Tipo";
            this.gv_Famiglia_Tipo.Name = "gv_Famiglia_Tipo";
            this.gv_Famiglia_Tipo.Visible = false;
            // 
            // gv_Famiglia_isDevice
            // 
            this.gv_Famiglia_isDevice.DataPropertyName = "Fam_IsDevice";
            this.gv_Famiglia_isDevice.HeaderText = "Fam_IsDevice";
            this.gv_Famiglia_isDevice.Name = "gv_Famiglia_isDevice";
            this.gv_Famiglia_isDevice.Visible = false;
            // 
            // gv_Famiglia_Commessa
            // 
            this.gv_Famiglia_Commessa.DataPropertyName = "Fam_ToCommessa";
            this.gv_Famiglia_Commessa.HeaderText = "Fam_ToCommessa";
            this.gv_Famiglia_Commessa.Name = "gv_Famiglia_Commessa";
            this.gv_Famiglia_Commessa.Visible = false;
            // 
            // gv_Famiglia_Len
            // 
            this.gv_Famiglia_Len.DataPropertyName = "LEN(Fam_Prefix)";
            this.gv_Famiglia_Len.HeaderText = "LEN(Fam_Prefix)";
            this.gv_Famiglia_Len.Name = "gv_Famiglia_Len";
            this.gv_Famiglia_Len.Visible = false;
            // 
            // gv_Famiglia_Ident
            // 
            this.gv_Famiglia_Ident.DataPropertyName = "Fam_ID_Identifier";
            this.gv_Famiglia_Ident.HeaderText = "Fam_ID_Identifier";
            this.gv_Famiglia_Ident.Name = "gv_Famiglia_Ident";
            this.gv_Famiglia_Ident.Visible = false;
            // 
            // famProdBindingSource
            // 
            this.famProdBindingSource.DataMember = "Fam_Prod";
            this.famProdBindingSource.DataSource = this.ds_SL;
            // 
            // metroLabel22
            // 
            this.metroLabel22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.metroLabel22.Location = new System.Drawing.Point(689, 13);
            this.metroLabel22.Name = "metroLabel22";
            this.metroLabel22.Size = new System.Drawing.Size(2, 470);
            this.metroLabel22.TabIndex = 120;
            this.metroLabel22.Text = "metroLabel22";
            this.metroLabel22.UseCustomBackColor = true;
            // 
            // metroLabel21
            // 
            this.metroLabel21.AutoSize = true;
            this.metroLabel21.Location = new System.Drawing.Point(697, 9);
            this.metroLabel21.Name = "metroLabel21";
            this.metroLabel21.Size = new System.Drawing.Size(142, 19);
            this.metroLabel21.TabIndex = 119;
            this.metroLabel21.Text = "Hardware Compatibile";
            // 
            // layout_dati
            // 
            this.layout_dati.ColumnCount = 3;
            this.layout_dati.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.layout_dati.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.layout_dati.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.layout_dati.Controls.Add(this.panel_funzionamento, 1, 1);
            this.layout_dati.Controls.Add(this.panel_dati, 0, 0);
            this.layout_dati.Controls.Add(this.panel_history, 2, 0);
            this.layout_dati.Controls.Add(this.panel_revisioni, 0, 1);
            this.layout_dati.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_dati.Location = new System.Drawing.Point(170, 55);
            this.layout_dati.Name = "layout_dati";
            this.layout_dati.RowCount = 2;
            this.layout_dati.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_dati.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_dati.Size = new System.Drawing.Size(1101, 739);
            this.layout_dati.TabIndex = 78;
            // 
            // panel_funzionamento
            // 
            this.panel_funzionamento.Controls.Add(this.rtb_Funzionamento);
            this.panel_funzionamento.Controls.Add(this.metroLabel20);
            this.panel_funzionamento.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_funzionamento.HorizontalScrollbarBarColor = true;
            this.panel_funzionamento.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_funzionamento.HorizontalScrollbarSize = 10;
            this.panel_funzionamento.Location = new System.Drawing.Point(443, 509);
            this.panel_funzionamento.Name = "panel_funzionamento";
            this.panel_funzionamento.Size = new System.Drawing.Size(434, 228);
            this.panel_funzionamento.TabIndex = 80;
            this.panel_funzionamento.VerticalScrollbarBarColor = true;
            this.panel_funzionamento.VerticalScrollbarHighlightOnWheel = false;
            this.panel_funzionamento.VerticalScrollbarSize = 10;
            // 
            // rtb_Funzionamento
            // 
            this.rtb_Funzionamento.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtb_Funzionamento.Location = new System.Drawing.Point(0, 19);
            this.rtb_Funzionamento.Name = "rtb_Funzionamento";
            this.rtb_Funzionamento.Size = new System.Drawing.Size(434, 209);
            this.rtb_Funzionamento.TabIndex = 0;
            this.rtb_Funzionamento.Text = "";
            // 
            // metroLabel20
            // 
            this.metroLabel20.AutoSize = true;
            this.metroLabel20.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroLabel20.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel20.Location = new System.Drawing.Point(0, 0);
            this.metroLabel20.Name = "metroLabel20";
            this.metroLabel20.Size = new System.Drawing.Size(104, 19);
            this.metroLabel20.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel20.TabIndex = 6;
            this.metroLabel20.Text = "Funzionamento";
            this.metroLabel20.UseStyleColors = true;
            // 
            // panel_history
            // 
            this.panel_history.Controls.Add(this.gv_history);
            this.panel_history.Controls.Add(this.panel_spacer);
            this.panel_history.Controls.Add(this.metroLabel9);
            this.panel_history.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_history.HorizontalScrollbarBarColor = true;
            this.panel_history.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_history.HorizontalScrollbarSize = 10;
            this.panel_history.Location = new System.Drawing.Point(883, 3);
            this.panel_history.Name = "panel_history";
            this.layout_dati.SetRowSpan(this.panel_history, 2);
            this.panel_history.Size = new System.Drawing.Size(215, 734);
            this.panel_history.TabIndex = 78;
            this.panel_history.VerticalScrollbarBarColor = true;
            this.panel_history.VerticalScrollbarHighlightOnWheel = false;
            this.panel_history.VerticalScrollbarSize = 10;
            // 
            // gv_history
            // 
            this.gv_history.AllowUserToAddRows = false;
            this.gv_history.AllowUserToDeleteRows = false;
            this.gv_history.AllowUserToResizeRows = false;
            this.gv_history.AutoGenerateColumns = false;
            this.gv_history.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_history.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_history.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_history.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_history.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.gv_history.ColumnHeadersHeight = 40;
            this.gv_history.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.history_Code,
            this.history_Revision,
            this.history_FromDate});
            this.gv_history.DataSource = this.firmwareBindingSource;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_history.DefaultCellStyle = dataGridViewCellStyle6;
            this.gv_history.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_history.EnableHeadersVisualStyles = false;
            this.gv_history.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_history.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_history.Location = new System.Drawing.Point(0, 38);
            this.gv_history.Name = "gv_history";
            this.gv_history.ReadOnly = true;
            this.gv_history.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_history.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.gv_history.RowHeadersVisible = false;
            this.gv_history.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_history.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_history.Size = new System.Drawing.Size(215, 696);
            this.gv_history.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_history.TabIndex = 4;
            this.gv_history.UseStyleColors = true;
            this.gv_history.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.gv_history_CellPainting);
            // 
            // history_Code
            // 
            this.history_Code.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.history_Code.DataPropertyName = "SW_Code";
            this.history_Code.HeaderText = "SW_Code";
            this.history_Code.Name = "history_Code";
            this.history_Code.ReadOnly = true;
            this.history_Code.Visible = false;
            this.history_Code.Width = 79;
            // 
            // history_Revision
            // 
            this.history_Revision.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.history_Revision.DataPropertyName = "SW_Revisione";
            this.history_Revision.DividerWidth = 1;
            this.history_Revision.HeaderText = "Revisione";
            this.history_Revision.Name = "history_Revision";
            this.history_Revision.ReadOnly = true;
            this.history_Revision.Width = 80;
            // 
            // history_FromDate
            // 
            this.history_FromDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.history_FromDate.DataPropertyName = "SW_Obsolete_ver_from_date";
            this.history_FromDate.HeaderText = "Fino al";
            this.history_FromDate.Name = "history_FromDate";
            this.history_FromDate.ReadOnly = true;
            // 
            // panel_spacer
            // 
            this.panel_spacer.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_spacer.HorizontalScrollbarBarColor = true;
            this.panel_spacer.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_spacer.HorizontalScrollbarSize = 10;
            this.panel_spacer.Location = new System.Drawing.Point(0, 19);
            this.panel_spacer.Name = "panel_spacer";
            this.panel_spacer.Size = new System.Drawing.Size(215, 19);
            this.panel_spacer.TabIndex = 5;
            this.panel_spacer.VerticalScrollbarBarColor = true;
            this.panel_spacer.VerticalScrollbarHighlightOnWheel = false;
            this.panel_spacer.VerticalScrollbarSize = 10;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroLabel9.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel9.Location = new System.Drawing.Point(0, 0);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(125, 19);
            this.metroLabel9.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel9.TabIndex = 3;
            this.metroLabel9.Text = "Versioni precedenti";
            this.metroLabel9.UseStyleColors = true;
            // 
            // panel_revisioni
            // 
            this.panel_revisioni.Controls.Add(this.rtb_Revisioni);
            this.panel_revisioni.Controls.Add(this.metroLabel19);
            this.panel_revisioni.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_revisioni.HorizontalScrollbarBarColor = true;
            this.panel_revisioni.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_revisioni.HorizontalScrollbarSize = 10;
            this.panel_revisioni.Location = new System.Drawing.Point(3, 509);
            this.panel_revisioni.Name = "panel_revisioni";
            this.panel_revisioni.Size = new System.Drawing.Size(434, 228);
            this.panel_revisioni.TabIndex = 79;
            this.panel_revisioni.VerticalScrollbarBarColor = true;
            this.panel_revisioni.VerticalScrollbarHighlightOnWheel = false;
            this.panel_revisioni.VerticalScrollbarSize = 10;
            // 
            // rtb_Revisioni
            // 
            this.rtb_Revisioni.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtb_Revisioni.Location = new System.Drawing.Point(0, 19);
            this.rtb_Revisioni.Name = "rtb_Revisioni";
            this.rtb_Revisioni.Size = new System.Drawing.Size(434, 209);
            this.rtb_Revisioni.TabIndex = 0;
            this.rtb_Revisioni.Text = "";
            // 
            // metroLabel19
            // 
            this.metroLabel19.AutoSize = true;
            this.metroLabel19.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroLabel19.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel19.Location = new System.Drawing.Point(0, 0);
            this.metroLabel19.Name = "metroLabel19";
            this.metroLabel19.Size = new System.Drawing.Size(107, 19);
            this.metroLabel19.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel19.TabIndex = 4;
            this.metroLabel19.Text = "Revision History";
            this.metroLabel19.UseStyleColors = true;
            // 
            // pan_Menu_comandi
            // 
            this.pan_Menu_comandi.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_menu.SetColumnSpan(this.pan_Menu_comandi, 5);
            this.pan_Menu_comandi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_Menu_comandi.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_new,
            this.menu_sw_div01,
            this.menu_sw_clona,
            this.menu_sw_div02,
            this.creaRevisioneToolStripMenuItem});
            this.pan_Menu_comandi.Location = new System.Drawing.Point(0, 0);
            this.pan_Menu_comandi.Name = "pan_Menu_comandi";
            this.pan_Menu_comandi.Size = new System.Drawing.Size(625, 25);
            this.pan_Menu_comandi.TabIndex = 80;
            this.pan_Menu_comandi.Text = "menuStrip1";
            // 
            // menu_sw_new
            // 
            this.menu_sw_new.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_new.Image")));
            this.menu_sw_new.Name = "menu_sw_new";
            this.menu_sw_new.Size = new System.Drawing.Size(117, 21);
            this.menu_sw_new.Text = "Nuova Versione";
            this.menu_sw_new.Click += new System.EventHandler(this.menu_sw_new_Click);
            // 
            // menu_sw_div01
            // 
            this.menu_sw_div01.Enabled = false;
            this.menu_sw_div01.Name = "menu_sw_div01";
            this.menu_sw_div01.Size = new System.Drawing.Size(22, 21);
            this.menu_sw_div01.Text = "|";
            // 
            // menu_sw_clona
            // 
            this.menu_sw_clona.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_clona.Image")));
            this.menu_sw_clona.Name = "menu_sw_clona";
            this.menu_sw_clona.Size = new System.Drawing.Size(290, 21);
            this.menu_sw_clona.Text = "Nuova Versione da elemento selezionato (Clona)";
            this.menu_sw_clona.Click += new System.EventHandler(this.menu_sw_clona_Click);
            // 
            // menu_sw_div02
            // 
            this.menu_sw_div02.Enabled = false;
            this.menu_sw_div02.Name = "menu_sw_div02";
            this.menu_sw_div02.Size = new System.Drawing.Size(22, 21);
            this.menu_sw_div02.Text = "|";
            // 
            // creaRevisioneToolStripMenuItem
            // 
            this.creaRevisioneToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("creaRevisioneToolStripMenuItem.Image")));
            this.creaRevisioneToolStripMenuItem.Name = "creaRevisioneToolStripMenuItem";
            this.creaRevisioneToolStripMenuItem.Size = new System.Drawing.Size(112, 21);
            this.creaRevisioneToolStripMenuItem.Text = "Crea Revisione";
            this.creaRevisioneToolStripMenuItem.Click += new System.EventHandler(this.creaRevisioneToolStripMenuItem_Click);
            // 
            // pan_Menu_salva
            // 
            this.pan_Menu_salva.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pan_Menu_salva.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_menu.SetColumnSpan(this.pan_Menu_salva, 2);
            this.pan_Menu_salva.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_salva.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_salva,
            this.menu_sw_div12,
            this.menu_sw_annulla});
            this.pan_Menu_salva.Location = new System.Drawing.Point(791, 0);
            this.pan_Menu_salva.Name = "pan_Menu_salva";
            this.pan_Menu_salva.Size = new System.Drawing.Size(168, 24);
            this.pan_Menu_salva.TabIndex = 81;
            this.pan_Menu_salva.Text = "menuStrip1";
            // 
            // menu_sw_salva
            // 
            this.menu_sw_salva.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_salva.Image")));
            this.menu_sw_salva.Name = "menu_sw_salva";
            this.menu_sw_salva.Size = new System.Drawing.Size(62, 20);
            this.menu_sw_salva.Text = "Salva";
            this.menu_sw_salva.Click += new System.EventHandler(this.menu_sw_salva_Click);
            // 
            // menu_sw_div12
            // 
            this.menu_sw_div12.Enabled = false;
            this.menu_sw_div12.Name = "menu_sw_div12";
            this.menu_sw_div12.ShowShortcutKeys = false;
            this.menu_sw_div12.Size = new System.Drawing.Size(22, 20);
            this.menu_sw_div12.Text = "|";
            // 
            // menu_sw_annulla
            // 
            this.menu_sw_annulla.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_annulla.Image")));
            this.menu_sw_annulla.Name = "menu_sw_annulla";
            this.menu_sw_annulla.Size = new System.Drawing.Size(76, 20);
            this.menu_sw_annulla.Text = "Annulla";
            this.menu_sw_annulla.Click += new System.EventHandler(this.menu_sw_annulla_Click);
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Gainsboro;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(1176, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(75, 24);
            this.pan_Menu_exit.TabIndex = 82;
            this.pan_Menu_exit.Text = "menuStrip1";
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            this.menu_sw_exit.Click += new System.EventHandler(this.menu_sw_exit_Click);
            // 
            // layout_menu
            // 
            this.layout_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_menu.ColumnCount = 10;
            this.layout_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_menu.Controls.Add(this.pan_Menu_comandi, 0, 0);
            this.layout_menu.Controls.Add(this.pan_Menu_salva, 6, 0);
            this.layout_menu.Controls.Add(this.pan_Menu_exit, 10, 0);
            this.layout_menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_menu.Location = new System.Drawing.Point(20, 30);
            this.layout_menu.Name = "layout_menu";
            this.layout_menu.RowCount = 1;
            this.layout_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_menu.Size = new System.Drawing.Size(1251, 25);
            this.layout_menu.TabIndex = 118;
            // 
            // firmwareTableAdapter
            // 
            this.firmwareTableAdapter.ClearBeforeFill = true;
            // 
            // fam_ProdTableAdapter
            // 
            this.fam_ProdTableAdapter.ClearBeforeFill = true;
            // 
            // UC_FW_K
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1291, 814);
            this.ControlBox = false;
            this.Controls.Add(this.layout_dati);
            this.Controls.Add(this.panel_FW_R);
            this.Controls.Add(this.layout_menu);
            this.DisplayHeader = false;
            this.Name = "UC_FW_K";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Resizable = false;
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.UC_FW_K_FormClosing);
            this.Load += new System.EventHandler(this.UC_FW_K_Load);
            this.panel_FW_R.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_FW_K)).EndInit();
            this.gv_FW_R_MenuStrip.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.firmwareBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_Programmazione)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            this.panel_dati.ResumeLayout(false);
            this.panel_dati.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Famiglia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.famProdBindingSource)).EndInit();
            this.layout_dati.ResumeLayout(false);
            this.panel_funzionamento.ResumeLayout(false);
            this.panel_funzionamento.PerformLayout();
            this.panel_history.ResumeLayout(false);
            this.panel_history.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_history)).EndInit();
            this.panel_revisioni.ResumeLayout(false);
            this.panel_revisioni.PerformLayout();
            this.pan_Menu_comandi.ResumeLayout(false);
            this.pan_Menu_comandi.PerformLayout();
            this.pan_Menu_salva.ResumeLayout(false);
            this.pan_Menu_salva.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            this.layout_menu.ResumeLayout(false);
            this.layout_menu.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private MetroFramework.Controls.MetroPanel panel_FW_R;
        private MetroFramework.Controls.MetroGrid gv_FW_K;
        private ds_SL ds_SL;
        private ds_Programmazione ds_Programmazione;
        private System.Windows.Forms.BindingSource firmwareBindingSource;
        private ds_ProgrammazioneTableAdapters.FirmwareTableAdapter firmwareTableAdapter;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTextBox tb_gv_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_TipoDevice;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Des1;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Des2;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Versione;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Revisione;
        private System.Windows.Forms.DataGridViewCheckBoxColumn gv_IsStandard;
        private MetroFramework.Controls.MetroPanel panel_dati;
        private MetroFramework.Controls.MetroTextBox tb_gv_Des2;
        private MetroFramework.Controls.MetroTextBox tb_gv_Des1;
        private MetroFramework.Controls.MetroTextBox tb_gv_Versione;
        private MetroFramework.Controls.MetroTextBox tb_gv_Revisione;
        private MetroFramework.Controls.MetroCheckBox cbox_SoftwareStandard;
        private System.Windows.Forms.TableLayoutPanel layout_dati;
        private MetroFramework.Controls.MetroPanel panel_history;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroGrid gv_history;
        private MetroFramework.Controls.MetroPanel panel_funzionamento;
        private System.Windows.Forms.RichTextBox rtb_Funzionamento;
        private MetroFramework.Controls.MetroLabel metroLabel20;
        private MetroFramework.Controls.MetroPanel panel_revisioni;
        private System.Windows.Forms.RichTextBox rtb_Revisioni;
        private MetroFramework.Controls.MetroLabel metroLabel19;
        private System.Windows.Forms.ContextMenuStrip gv_FW_R_MenuStrip;
        private System.Windows.Forms.ToolStripMenuItem versioneToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem revisioneToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem aggiungiRevisioneAllelementoSelezionatoToolStripMenuItem;
        private System.Windows.Forms.MenuStrip pan_Menu_comandi;
        private System.Windows.Forms.TableLayoutPanel layout_menu;
        private System.Windows.Forms.MenuStrip pan_Menu_salva;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_salva;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_div12;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_annulla;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_new;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_div01;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_div02;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_clona;
        private System.Windows.Forms.ToolStripMenuItem creaRevisioneToolStripMenuItem;
        private MetroFramework.Controls.MetroLabel metroLabel22;
        private MetroFramework.Controls.MetroLabel metroLabel21;
        private System.Windows.Forms.BindingSource famProdBindingSource;
        private ds_SLTableAdapters.Fam_ProdTableAdapter fam_ProdTableAdapter;
        private MetroFramework.Controls.MetroGrid gv_Famiglia;
        private MetroFramework.Controls.MetroPanel panel_spacer;
        private System.Windows.Forms.DataGridViewTextBoxColumn history_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn history_Revision;
        private System.Windows.Forms.DataGridViewTextBoxColumn history_FromDate;
        private System.Windows.Forms.DataGridViewCheckBoxColumn gv_Famiglia_Check;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Famiglia_Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Famiglia_Prefix;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Famiglia_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Famiglia_Label;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Famiglia_Tipo;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Famiglia_isDevice;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Famiglia_Commessa;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Famiglia_Len;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Famiglia_Ident;
    }
}