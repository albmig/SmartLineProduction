﻿namespace SmartLineProduction
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.metroGrid1 = new MetroFramework.Controls.MetroGrid();
            this.serialNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serialNumberEstDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.flTrasfWebDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataUltModificaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.articoloDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sFSNarsnBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.ds_QuerySN = new SmartLineProduction.ds_QuerySN();
            this.metroGrid2 = new MetroFramework.Controls.MetroGrid();
            this.serialNumberDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.expr1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.desArtDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.desEstArtDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipoMovimentoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.commessaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descrizioneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ragSocCognomeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ragSocNomeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ragSocCompletaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nazioneFiscaleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numBrogliaccioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numRigoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipoFatturaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numFatturaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataFatturaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipoBAMDDTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numBAMDDTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataBAMDDTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sFSNarsnSFSNCicloAttivoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sFSNarsnSFSNQueryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sFSNarsnSFmomamosnBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroGrid3 = new MetroFramework.Controls.MetroGrid();
            this.serialNumberDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.commessaDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.articoloDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataRegistrazioneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.articoloOrdineDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descrizioneDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataDocumentoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numeroOrdineDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataOrdineDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descrizione1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sFSNarsnSFSNCicloAttivoKitBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_SN_arsnTableAdapter = new SmartLineProduction.ds_QuerySNTableAdapters.SF_SN_arsnTableAdapter();
            this.sF_SN_QueryTableAdapter = new SmartLineProduction.ds_QuerySNTableAdapters.SF_SN_QueryTableAdapter();
            this.sF_SN_CicloAttivo_KitTableAdapter = new SmartLineProduction.ds_QuerySNTableAdapters.SF_SN_CicloAttivo_KitTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFSNCicloAttivoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFSNQueryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFmomamosnBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFSNCicloAttivoKitBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // metroGrid1
            // 
            this.metroGrid1.AllowUserToResizeRows = false;
            this.metroGrid1.AutoGenerateColumns = false;
            this.metroGrid1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.metroGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serialNumberDataGridViewTextBoxColumn,
            this.serialNumberEstDataGridViewTextBoxColumn,
            this.flTrasfWebDataGridViewTextBoxColumn,
            this.dataUltModificaDataGridViewTextBoxColumn,
            this.articoloDataGridViewTextBoxColumn});
            this.metroGrid1.DataSource = this.sFSNarsnBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid1.DefaultCellStyle = dataGridViewCellStyle2;
            this.metroGrid1.EnableHeadersVisualStyles = false;
            this.metroGrid1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.Location = new System.Drawing.Point(12, 12);
            this.metroGrid1.Name = "metroGrid1";
            this.metroGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.metroGrid1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid1.Size = new System.Drawing.Size(554, 304);
            this.metroGrid1.TabIndex = 0;
            // 
            // serialNumberDataGridViewTextBoxColumn
            // 
            this.serialNumberDataGridViewTextBoxColumn.DataPropertyName = "SerialNumber";
            this.serialNumberDataGridViewTextBoxColumn.HeaderText = "SerialNumber";
            this.serialNumberDataGridViewTextBoxColumn.Name = "serialNumberDataGridViewTextBoxColumn";
            // 
            // serialNumberEstDataGridViewTextBoxColumn
            // 
            this.serialNumberEstDataGridViewTextBoxColumn.DataPropertyName = "SerialNumberEst";
            this.serialNumberEstDataGridViewTextBoxColumn.HeaderText = "SerialNumberEst";
            this.serialNumberEstDataGridViewTextBoxColumn.Name = "serialNumberEstDataGridViewTextBoxColumn";
            // 
            // flTrasfWebDataGridViewTextBoxColumn
            // 
            this.flTrasfWebDataGridViewTextBoxColumn.DataPropertyName = "FlTrasfWeb";
            this.flTrasfWebDataGridViewTextBoxColumn.HeaderText = "FlTrasfWeb";
            this.flTrasfWebDataGridViewTextBoxColumn.Name = "flTrasfWebDataGridViewTextBoxColumn";
            // 
            // dataUltModificaDataGridViewTextBoxColumn
            // 
            this.dataUltModificaDataGridViewTextBoxColumn.DataPropertyName = "DataUltModifica";
            this.dataUltModificaDataGridViewTextBoxColumn.HeaderText = "DataUltModifica";
            this.dataUltModificaDataGridViewTextBoxColumn.Name = "dataUltModificaDataGridViewTextBoxColumn";
            // 
            // articoloDataGridViewTextBoxColumn
            // 
            this.articoloDataGridViewTextBoxColumn.DataPropertyName = "Articolo";
            this.articoloDataGridViewTextBoxColumn.HeaderText = "Articolo";
            this.articoloDataGridViewTextBoxColumn.Name = "articoloDataGridViewTextBoxColumn";
            this.articoloDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sFSNarsnBindingSource
            // 
            this.sFSNarsnBindingSource.DataMember = "SF_SN_arsn";
            this.sFSNarsnBindingSource.DataSource = this.ds_SL;
            this.sFSNarsnBindingSource.Sort = "SerialNumber asc";
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ds_QuerySN
            // 
            this.ds_QuerySN.DataSetName = "ds_QuerySN";
            this.ds_QuerySN.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // metroGrid2
            // 
            this.metroGrid2.AllowUserToResizeRows = false;
            this.metroGrid2.AutoGenerateColumns = false;
            this.metroGrid2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.metroGrid2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serialNumberDataGridViewTextBoxColumn1,
            this.expr1DataGridViewTextBoxColumn,
            this.desArtDataGridViewTextBoxColumn,
            this.desEstArtDataGridViewTextBoxColumn,
            this.tipoMovimentoDataGridViewTextBoxColumn,
            this.commessaDataGridViewTextBoxColumn,
            this.descrizioneDataGridViewTextBoxColumn,
            this.ragSocCognomeDataGridViewTextBoxColumn,
            this.ragSocNomeDataGridViewTextBoxColumn,
            this.ragSocCompletaDataGridViewTextBoxColumn,
            this.nazioneFiscaleDataGridViewTextBoxColumn,
            this.numBrogliaccioDataGridViewTextBoxColumn,
            this.numRigoDataGridViewTextBoxColumn,
            this.tipoFatturaDataGridViewTextBoxColumn,
            this.numFatturaDataGridViewTextBoxColumn,
            this.dataFatturaDataGridViewTextBoxColumn,
            this.tipoBAMDDTDataGridViewTextBoxColumn,
            this.numBAMDDTDataGridViewTextBoxColumn,
            this.dataBAMDDTDataGridViewTextBoxColumn});
            this.metroGrid2.DataSource = this.sFSNarsnSFSNCicloAttivoBindingSource;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid2.DefaultCellStyle = dataGridViewCellStyle5;
            this.metroGrid2.EnableHeadersVisualStyles = false;
            this.metroGrid2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid2.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid2.Location = new System.Drawing.Point(572, 12);
            this.metroGrid2.Name = "metroGrid2";
            this.metroGrid2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid2.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.metroGrid2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid2.Size = new System.Drawing.Size(574, 144);
            this.metroGrid2.TabIndex = 1;
            // 
            // serialNumberDataGridViewTextBoxColumn1
            // 
            this.serialNumberDataGridViewTextBoxColumn1.DataPropertyName = "SerialNumber";
            this.serialNumberDataGridViewTextBoxColumn1.HeaderText = "SerialNumber";
            this.serialNumberDataGridViewTextBoxColumn1.Name = "serialNumberDataGridViewTextBoxColumn1";
            // 
            // expr1DataGridViewTextBoxColumn
            // 
            this.expr1DataGridViewTextBoxColumn.DataPropertyName = "Expr1";
            this.expr1DataGridViewTextBoxColumn.HeaderText = "Expr1";
            this.expr1DataGridViewTextBoxColumn.Name = "expr1DataGridViewTextBoxColumn";
            this.expr1DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // desArtDataGridViewTextBoxColumn
            // 
            this.desArtDataGridViewTextBoxColumn.DataPropertyName = "DesArt";
            this.desArtDataGridViewTextBoxColumn.HeaderText = "DesArt";
            this.desArtDataGridViewTextBoxColumn.Name = "desArtDataGridViewTextBoxColumn";
            // 
            // desEstArtDataGridViewTextBoxColumn
            // 
            this.desEstArtDataGridViewTextBoxColumn.DataPropertyName = "DesEstArt";
            this.desEstArtDataGridViewTextBoxColumn.HeaderText = "DesEstArt";
            this.desEstArtDataGridViewTextBoxColumn.Name = "desEstArtDataGridViewTextBoxColumn";
            // 
            // tipoMovimentoDataGridViewTextBoxColumn
            // 
            this.tipoMovimentoDataGridViewTextBoxColumn.DataPropertyName = "TipoMovimento";
            this.tipoMovimentoDataGridViewTextBoxColumn.HeaderText = "TipoMovimento";
            this.tipoMovimentoDataGridViewTextBoxColumn.Name = "tipoMovimentoDataGridViewTextBoxColumn";
            // 
            // commessaDataGridViewTextBoxColumn
            // 
            this.commessaDataGridViewTextBoxColumn.DataPropertyName = "Commessa";
            this.commessaDataGridViewTextBoxColumn.HeaderText = "Commessa";
            this.commessaDataGridViewTextBoxColumn.Name = "commessaDataGridViewTextBoxColumn";
            // 
            // descrizioneDataGridViewTextBoxColumn
            // 
            this.descrizioneDataGridViewTextBoxColumn.DataPropertyName = "Descrizione";
            this.descrizioneDataGridViewTextBoxColumn.HeaderText = "Descrizione";
            this.descrizioneDataGridViewTextBoxColumn.Name = "descrizioneDataGridViewTextBoxColumn";
            // 
            // ragSocCognomeDataGridViewTextBoxColumn
            // 
            this.ragSocCognomeDataGridViewTextBoxColumn.DataPropertyName = "RagSocCognome";
            this.ragSocCognomeDataGridViewTextBoxColumn.HeaderText = "RagSocCognome";
            this.ragSocCognomeDataGridViewTextBoxColumn.Name = "ragSocCognomeDataGridViewTextBoxColumn";
            // 
            // ragSocNomeDataGridViewTextBoxColumn
            // 
            this.ragSocNomeDataGridViewTextBoxColumn.DataPropertyName = "RagSocNome";
            this.ragSocNomeDataGridViewTextBoxColumn.HeaderText = "RagSocNome";
            this.ragSocNomeDataGridViewTextBoxColumn.Name = "ragSocNomeDataGridViewTextBoxColumn";
            // 
            // ragSocCompletaDataGridViewTextBoxColumn
            // 
            this.ragSocCompletaDataGridViewTextBoxColumn.DataPropertyName = "RagSocCompleta";
            this.ragSocCompletaDataGridViewTextBoxColumn.HeaderText = "RagSocCompleta";
            this.ragSocCompletaDataGridViewTextBoxColumn.Name = "ragSocCompletaDataGridViewTextBoxColumn";
            // 
            // nazioneFiscaleDataGridViewTextBoxColumn
            // 
            this.nazioneFiscaleDataGridViewTextBoxColumn.DataPropertyName = "NazioneFiscale";
            this.nazioneFiscaleDataGridViewTextBoxColumn.HeaderText = "NazioneFiscale";
            this.nazioneFiscaleDataGridViewTextBoxColumn.Name = "nazioneFiscaleDataGridViewTextBoxColumn";
            // 
            // numBrogliaccioDataGridViewTextBoxColumn
            // 
            this.numBrogliaccioDataGridViewTextBoxColumn.DataPropertyName = "NumBrogliaccio";
            this.numBrogliaccioDataGridViewTextBoxColumn.HeaderText = "NumBrogliaccio";
            this.numBrogliaccioDataGridViewTextBoxColumn.Name = "numBrogliaccioDataGridViewTextBoxColumn";
            // 
            // numRigoDataGridViewTextBoxColumn
            // 
            this.numRigoDataGridViewTextBoxColumn.DataPropertyName = "NumRigo";
            this.numRigoDataGridViewTextBoxColumn.HeaderText = "NumRigo";
            this.numRigoDataGridViewTextBoxColumn.Name = "numRigoDataGridViewTextBoxColumn";
            // 
            // tipoFatturaDataGridViewTextBoxColumn
            // 
            this.tipoFatturaDataGridViewTextBoxColumn.DataPropertyName = "TipoFattura";
            this.tipoFatturaDataGridViewTextBoxColumn.HeaderText = "TipoFattura";
            this.tipoFatturaDataGridViewTextBoxColumn.Name = "tipoFatturaDataGridViewTextBoxColumn";
            // 
            // numFatturaDataGridViewTextBoxColumn
            // 
            this.numFatturaDataGridViewTextBoxColumn.DataPropertyName = "NumFattura";
            this.numFatturaDataGridViewTextBoxColumn.HeaderText = "NumFattura";
            this.numFatturaDataGridViewTextBoxColumn.Name = "numFatturaDataGridViewTextBoxColumn";
            // 
            // dataFatturaDataGridViewTextBoxColumn
            // 
            this.dataFatturaDataGridViewTextBoxColumn.DataPropertyName = "DataFattura";
            this.dataFatturaDataGridViewTextBoxColumn.HeaderText = "DataFattura";
            this.dataFatturaDataGridViewTextBoxColumn.Name = "dataFatturaDataGridViewTextBoxColumn";
            // 
            // tipoBAMDDTDataGridViewTextBoxColumn
            // 
            this.tipoBAMDDTDataGridViewTextBoxColumn.DataPropertyName = "TipoBAMDDT";
            this.tipoBAMDDTDataGridViewTextBoxColumn.HeaderText = "TipoBAMDDT";
            this.tipoBAMDDTDataGridViewTextBoxColumn.Name = "tipoBAMDDTDataGridViewTextBoxColumn";
            // 
            // numBAMDDTDataGridViewTextBoxColumn
            // 
            this.numBAMDDTDataGridViewTextBoxColumn.DataPropertyName = "NumBAMDDT";
            this.numBAMDDTDataGridViewTextBoxColumn.HeaderText = "NumBAMDDT";
            this.numBAMDDTDataGridViewTextBoxColumn.Name = "numBAMDDTDataGridViewTextBoxColumn";
            // 
            // dataBAMDDTDataGridViewTextBoxColumn
            // 
            this.dataBAMDDTDataGridViewTextBoxColumn.DataPropertyName = "DataBAMDDT";
            this.dataBAMDDTDataGridViewTextBoxColumn.HeaderText = "DataBAMDDT";
            this.dataBAMDDTDataGridViewTextBoxColumn.Name = "dataBAMDDTDataGridViewTextBoxColumn";
            // 
            // sFSNarsnSFSNCicloAttivoBindingSource
            // 
            this.sFSNarsnSFSNCicloAttivoBindingSource.DataMember = "SF_SN_arsn_SF_SN_CicloAttivo";
            this.sFSNarsnSFSNCicloAttivoBindingSource.DataSource = this.sFSNarsnBindingSource;
            // 
            // sFSNarsnSFSNQueryBindingSource
            // 
            this.sFSNarsnSFSNQueryBindingSource.DataMember = "SF_SN_arsn_SF_SN_Query";
            this.sFSNarsnSFSNQueryBindingSource.DataSource = this.sFSNarsnBindingSource;
            // 
            // sFSNarsnSFmomamosnBindingSource
            // 
            this.sFSNarsnSFmomamosnBindingSource.DataMember = "SF_SN_arsn_SF_momamosn";
            this.sFSNarsnSFmomamosnBindingSource.DataSource = this.sFSNarsnBindingSource;
            // 
            // metroGrid3
            // 
            this.metroGrid3.AllowUserToResizeRows = false;
            this.metroGrid3.AutoGenerateColumns = false;
            this.metroGrid3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid3.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.metroGrid3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serialNumberDataGridViewTextBoxColumn2,
            this.commessaDataGridViewTextBoxColumn1,
            this.articoloDataGridViewTextBoxColumn1,
            this.dataRegistrazioneDataGridViewTextBoxColumn,
            this.articoloOrdineDataGridViewTextBoxColumn,
            this.descrizioneDataGridViewTextBoxColumn1,
            this.dataDocumentoDataGridViewTextBoxColumn,
            this.numeroOrdineDataGridViewTextBoxColumn,
            this.dataOrdineDataGridViewTextBoxColumn,
            this.descrizione1DataGridViewTextBoxColumn});
            this.metroGrid3.DataSource = this.sFSNarsnSFSNCicloAttivoKitBindingSource;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid3.DefaultCellStyle = dataGridViewCellStyle8;
            this.metroGrid3.EnableHeadersVisualStyles = false;
            this.metroGrid3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid3.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid3.Location = new System.Drawing.Point(572, 172);
            this.metroGrid3.Name = "metroGrid3";
            this.metroGrid3.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid3.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.metroGrid3.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid3.Size = new System.Drawing.Size(574, 144);
            this.metroGrid3.TabIndex = 2;
            // 
            // serialNumberDataGridViewTextBoxColumn2
            // 
            this.serialNumberDataGridViewTextBoxColumn2.DataPropertyName = "SerialNumber";
            this.serialNumberDataGridViewTextBoxColumn2.HeaderText = "SerialNumber";
            this.serialNumberDataGridViewTextBoxColumn2.Name = "serialNumberDataGridViewTextBoxColumn2";
            // 
            // commessaDataGridViewTextBoxColumn1
            // 
            this.commessaDataGridViewTextBoxColumn1.DataPropertyName = "Commessa";
            this.commessaDataGridViewTextBoxColumn1.HeaderText = "Commessa";
            this.commessaDataGridViewTextBoxColumn1.Name = "commessaDataGridViewTextBoxColumn1";
            // 
            // articoloDataGridViewTextBoxColumn1
            // 
            this.articoloDataGridViewTextBoxColumn1.DataPropertyName = "Articolo";
            this.articoloDataGridViewTextBoxColumn1.HeaderText = "Articolo";
            this.articoloDataGridViewTextBoxColumn1.Name = "articoloDataGridViewTextBoxColumn1";
            this.articoloDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataRegistrazioneDataGridViewTextBoxColumn
            // 
            this.dataRegistrazioneDataGridViewTextBoxColumn.DataPropertyName = "DataRegistrazione";
            this.dataRegistrazioneDataGridViewTextBoxColumn.HeaderText = "DataRegistrazione";
            this.dataRegistrazioneDataGridViewTextBoxColumn.Name = "dataRegistrazioneDataGridViewTextBoxColumn";
            // 
            // articoloOrdineDataGridViewTextBoxColumn
            // 
            this.articoloOrdineDataGridViewTextBoxColumn.DataPropertyName = "Articolo_Ordine";
            this.articoloOrdineDataGridViewTextBoxColumn.HeaderText = "Articolo_Ordine";
            this.articoloOrdineDataGridViewTextBoxColumn.Name = "articoloOrdineDataGridViewTextBoxColumn";
            // 
            // descrizioneDataGridViewTextBoxColumn1
            // 
            this.descrizioneDataGridViewTextBoxColumn1.DataPropertyName = "Descrizione";
            this.descrizioneDataGridViewTextBoxColumn1.HeaderText = "Descrizione";
            this.descrizioneDataGridViewTextBoxColumn1.Name = "descrizioneDataGridViewTextBoxColumn1";
            // 
            // dataDocumentoDataGridViewTextBoxColumn
            // 
            this.dataDocumentoDataGridViewTextBoxColumn.DataPropertyName = "DataDocumento";
            this.dataDocumentoDataGridViewTextBoxColumn.HeaderText = "DataDocumento";
            this.dataDocumentoDataGridViewTextBoxColumn.Name = "dataDocumentoDataGridViewTextBoxColumn";
            // 
            // numeroOrdineDataGridViewTextBoxColumn
            // 
            this.numeroOrdineDataGridViewTextBoxColumn.DataPropertyName = "NumeroOrdine";
            this.numeroOrdineDataGridViewTextBoxColumn.HeaderText = "NumeroOrdine";
            this.numeroOrdineDataGridViewTextBoxColumn.Name = "numeroOrdineDataGridViewTextBoxColumn";
            // 
            // dataOrdineDataGridViewTextBoxColumn
            // 
            this.dataOrdineDataGridViewTextBoxColumn.DataPropertyName = "DataOrdine";
            this.dataOrdineDataGridViewTextBoxColumn.HeaderText = "DataOrdine";
            this.dataOrdineDataGridViewTextBoxColumn.Name = "dataOrdineDataGridViewTextBoxColumn";
            // 
            // descrizione1DataGridViewTextBoxColumn
            // 
            this.descrizione1DataGridViewTextBoxColumn.DataPropertyName = "Descrizione1";
            this.descrizione1DataGridViewTextBoxColumn.HeaderText = "Descrizione1";
            this.descrizione1DataGridViewTextBoxColumn.Name = "descrizione1DataGridViewTextBoxColumn";
            // 
            // sFSNarsnSFSNCicloAttivoKitBindingSource
            // 
            this.sFSNarsnSFSNCicloAttivoKitBindingSource.DataMember = "SF_SN_arsn_SF_SN_CicloAttivo_Kit";
            this.sFSNarsnSFSNCicloAttivoKitBindingSource.DataSource = this.sFSNarsnBindingSource;
            // 
            // sF_SN_arsnTableAdapter
            // 
            this.sF_SN_arsnTableAdapter.ClearBeforeFill = true;
            // 
            // sF_SN_QueryTableAdapter
            // 
            this.sF_SN_QueryTableAdapter.ClearBeforeFill = true;
            // 
            // sF_SN_CicloAttivo_KitTableAdapter
            // 
            this.sF_SN_CicloAttivo_KitTableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1187, 615);
            this.Controls.Add(this.metroGrid3);
            this.Controls.Add(this.metroGrid2);
            this.Controls.Add(this.metroGrid1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFSNCicloAttivoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFSNQueryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFmomamosnBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFSNCicloAttivoKitBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroGrid metroGrid1;
        private ds_SL ds_SL;
        private ds_QuerySN ds_QuerySN;
        private System.Windows.Forms.BindingSource sFSNarsnBindingSource;
        private ds_QuerySNTableAdapters.SF_SN_arsnTableAdapter sF_SN_arsnTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn serialNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serialNumberEstDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn flTrasfWebDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataUltModificaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroGrid metroGrid2;
        private System.Windows.Forms.BindingSource sFSNarsnSFSNQueryBindingSource;
        private ds_QuerySNTableAdapters.SF_SN_QueryTableAdapter sF_SN_QueryTableAdapter;
        private System.Windows.Forms.BindingSource sFSNarsnSFmomamosnBindingSource;
        private System.Windows.Forms.BindingSource sFSNarsnSFSNCicloAttivoBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn serialNumberDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn expr1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn desArtDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn desEstArtDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoMovimentoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn commessaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descrizioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ragSocCognomeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ragSocNomeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ragSocCompletaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nazioneFiscaleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numBrogliaccioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numRigoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoFatturaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numFatturaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataFatturaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoBAMDDTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numBAMDDTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataBAMDDTDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroGrid metroGrid3;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoBollaFatturaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeroBollaFatturaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataBollaFatturaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeroBrogliaccioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rigaBrogliaccioDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource sFSNarsnSFSNCicloAttivoKitBindingSource;
        private ds_QuerySNTableAdapters.SF_SN_CicloAttivo_KitTableAdapter sF_SN_CicloAttivo_KitTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn serialNumberDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn commessaDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataRegistrazioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloOrdineDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descrizioneDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataDocumentoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeroOrdineDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataOrdineDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descrizione1DataGridViewTextBoxColumn;
    }
}