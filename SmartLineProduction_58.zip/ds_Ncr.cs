﻿namespace SmartLineProduction
{
}

namespace SmartLineProduction
{
}
namespace SmartLineProduction
{


    public partial class ds_Ncr
    {
    }
}
namespace SmartLineProduction {
    
    
    public partial class ds_Ncr {
    }
}
namespace SmartLineProduction {
    
    
    public partial class ds_Ncr {
    }
}
