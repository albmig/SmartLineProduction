﻿namespace SmartLineProduction
{


    partial class ds_CL_FW_Query
    {
        partial class TE_view_Orders_explodedDataTable
        {
        }
    }
}
