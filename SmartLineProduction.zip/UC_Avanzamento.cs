﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using SmartLineProduction.Properties;

namespace SmartLineProduction
{
    public partial class UC_Avanzamento : MetroFramework.Forms.MetroForm
    {

        public UC_Avanzamento()
        {
            InitializeComponent();
        }

        private void UC_Avanzamento_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_CommesseAperte_CL_SL'. È possibile spostarla o rimuoverla se necessario.
            this.sF_CommesseAperte_CL_SLTableAdapter.Fill(this.ds_SL.SF_CommesseAperte_CL_SL);

            gv_Commesse.Sort(sortDataConsegnaDataGridViewTextBoxColumn, ListSortDirection.Ascending);
        }

        private void gv_Commesse_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            DataGridViewCell cell = this.gv_Commesse.Rows[e.RowIndex].Cells[e.ColumnIndex];
            DataGridViewRow gridRow = gv_Commesse.Rows[e.RowIndex];
            if (gv_Commesse.Columns[e.ColumnIndex].Name == "aOProgrammazioneDataGridViewTextBoxColumn")
            {
                int valore = (int)e.Value;

                cell.ToolTipText = gridRow.Cells["aOProgrammazioneNoteDataGridViewTextBoxColumn"].Value.ToString();
                if ((cell.ToolTipText!="") && (cell.ToolTipText != null))
                {
                    //presenti note
                    if (valore == 0)
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Programma_Enable_nota");
                    }
                    else
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Programma_Disable_nota");
                    }
                }
                else
                {
                    if (valore == 0)
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Programma_Enable");
                    }
                    else
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Programma_Disable");
                    }
                }

            }
        }

        private void gv_Commesse_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            foreach (DataGridViewRow x in gv_Commesse.Rows)
            {
                x.MinimumHeight = 70;
            }
        }
    }
}
