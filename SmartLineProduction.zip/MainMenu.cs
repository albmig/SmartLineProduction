﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;

namespace SmartLineProduction
{
    public partial class MainMenu : MetroFramework.Forms.MetroForm
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void tile_Spedizione_Click(object sender, EventArgs e)
        {
            UC_Spedizione uC_Spedizione = new UC_Spedizione();
            uC_Spedizione.Show();
        }

        private void tile_Avanzamento_Click(object sender, EventArgs e)
        {
            UC_Avanzamento uC_Avanzamento = new UC_Avanzamento();
            uC_Avanzamento.Show();

        }
    }
}
