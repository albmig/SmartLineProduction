﻿namespace SmartLineProduction
{
    partial class UC_Avanzamento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gv_Commesse = new MetroFramework.Controls.MetroGrid();
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.sFCommesseAperteCLSLBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_CommesseAperte_CL_SLTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_CommesseAperte_CL_SLTableAdapter();
            this.entitaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tIPOORDINEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dATAORDINEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nUMEROORDINEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nUMERORIGADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codAnagraficoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sortDataConsegnaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rAGIONESOCIALEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nazioneFiscaleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cOMMESSALONGDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cOMMESSASHORTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aRTICOLODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pREZZOUNITARIODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qTAORDINATADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qTASPEDITADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qTADAEVADEREDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iMPORTODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iMPORTOEVASODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iMPORTODAEVADEREDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.meseConsegnaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomeMeseConsegnaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.annoConsegnaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.commessaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOProgrammazioneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewImageColumn();
            this.aOProgrammazioneNoteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOMontaggioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOMontaggioNoteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOCollaudoConfezionamentoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOCollaudoConfezionamentoNoteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOSpedizioneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOSpedizioneNoteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOVenditaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOVenditaNoteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.distintaBaseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtaprogrammazioneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtamontaggioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtacollaudoconfezionamentoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtavenditaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Commesse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFCommesseAperteCLSLBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // gv_Commesse
            // 
            this.gv_Commesse.AllowUserToAddRows = false;
            this.gv_Commesse.AllowUserToDeleteRows = false;
            this.gv_Commesse.AllowUserToOrderColumns = true;
            this.gv_Commesse.AllowUserToResizeRows = false;
            this.gv_Commesse.AutoGenerateColumns = false;
            this.gv_Commesse.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.gv_Commesse.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Commesse.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Commesse.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Commesse.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gv_Commesse.ColumnHeadersHeight = 40;
            this.gv_Commesse.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.entitaDataGridViewTextBoxColumn,
            this.tIPOORDINEDataGridViewTextBoxColumn,
            this.dATAORDINEDataGridViewTextBoxColumn,
            this.nUMEROORDINEDataGridViewTextBoxColumn,
            this.nUMERORIGADataGridViewTextBoxColumn,
            this.codAnagraficoDataGridViewTextBoxColumn,
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn,
            this.sortDataConsegnaDataGridViewTextBoxColumn,
            this.rAGIONESOCIALEDataGridViewTextBoxColumn,
            this.nazioneFiscaleDataGridViewTextBoxColumn,
            this.cOMMESSALONGDataGridViewTextBoxColumn,
            this.cOMMESSASHORTDataGridViewTextBoxColumn,
            this.aRTICOLODataGridViewTextBoxColumn,
            this.uMDataGridViewTextBoxColumn,
            this.pREZZOUNITARIODataGridViewTextBoxColumn,
            this.qTAORDINATADataGridViewTextBoxColumn,
            this.qTASPEDITADataGridViewTextBoxColumn,
            this.qTADAEVADEREDataGridViewTextBoxColumn,
            this.iMPORTODataGridViewTextBoxColumn,
            this.iMPORTOEVASODataGridViewTextBoxColumn,
            this.iMPORTODAEVADEREDataGridViewTextBoxColumn,
            this.meseConsegnaDataGridViewTextBoxColumn,
            this.nomeMeseConsegnaDataGridViewTextBoxColumn,
            this.annoConsegnaDataGridViewTextBoxColumn,
            this.commessaDataGridViewTextBoxColumn,
            this.aOProgrammazioneDataGridViewTextBoxColumn,
            this.aOProgrammazioneNoteDataGridViewTextBoxColumn,
            this.aOMontaggioDataGridViewTextBoxColumn,
            this.aOMontaggioNoteDataGridViewTextBoxColumn,
            this.aOCollaudoConfezionamentoDataGridViewTextBoxColumn,
            this.aOCollaudoConfezionamentoNoteDataGridViewTextBoxColumn,
            this.aOSpedizioneDataGridViewTextBoxColumn,
            this.aOSpedizioneNoteDataGridViewTextBoxColumn,
            this.aOVenditaDataGridViewTextBoxColumn,
            this.aOVenditaNoteDataGridViewTextBoxColumn,
            this.distintaBaseDataGridViewTextBoxColumn,
            this.qtaprogrammazioneDataGridViewTextBoxColumn,
            this.qtamontaggioDataGridViewTextBoxColumn,
            this.qtacollaudoconfezionamentoDataGridViewTextBoxColumn,
            this.qtavenditaDataGridViewTextBoxColumn});
            this.gv_Commesse.DataSource = this.sFCommesseAperteCLSLBindingSource;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Commesse.DefaultCellStyle = dataGridViewCellStyle9;
            this.gv_Commesse.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Commesse.EnableHeadersVisualStyles = false;
            this.gv_Commesse.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Commesse.GridColor = System.Drawing.Color.White;
            this.gv_Commesse.HighLightPercentage = 0.1F;
            this.gv_Commesse.Location = new System.Drawing.Point(20, 60);
            this.gv_Commesse.MultiSelect = false;
            this.gv_Commesse.Name = "gv_Commesse";
            this.gv_Commesse.ReadOnly = true;
            this.gv_Commesse.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Commesse.RowHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.gv_Commesse.RowHeadersVisible = false;
            this.gv_Commesse.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Commesse.RowTemplate.Height = 60;
            this.gv_Commesse.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Commesse.Size = new System.Drawing.Size(1003, 499);
            this.gv_Commesse.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_Commesse.TabIndex = 0;
            this.gv_Commesse.UseStyleColors = true;
            this.gv_Commesse.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.gv_Commesse_CellFormatting);
            this.gv_Commesse.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.gv_Commesse_CellPainting);
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sFCommesseAperteCLSLBindingSource
            // 
            this.sFCommesseAperteCLSLBindingSource.DataMember = "SF_CommesseAperte_CL_SL";
            this.sFCommesseAperteCLSLBindingSource.DataSource = this.ds_SL;
            // 
            // sF_CommesseAperte_CL_SLTableAdapter
            // 
            this.sF_CommesseAperte_CL_SLTableAdapter.ClearBeforeFill = true;
            // 
            // entitaDataGridViewTextBoxColumn
            // 
            this.entitaDataGridViewTextBoxColumn.DataPropertyName = "Entita";
            this.entitaDataGridViewTextBoxColumn.HeaderText = "Entita";
            this.entitaDataGridViewTextBoxColumn.Name = "entitaDataGridViewTextBoxColumn";
            this.entitaDataGridViewTextBoxColumn.ReadOnly = true;
            this.entitaDataGridViewTextBoxColumn.Visible = false;
            // 
            // tIPOORDINEDataGridViewTextBoxColumn
            // 
            this.tIPOORDINEDataGridViewTextBoxColumn.DataPropertyName = "TIPO_ORDINE";
            this.tIPOORDINEDataGridViewTextBoxColumn.HeaderText = "TIPO_ORDINE";
            this.tIPOORDINEDataGridViewTextBoxColumn.Name = "tIPOORDINEDataGridViewTextBoxColumn";
            this.tIPOORDINEDataGridViewTextBoxColumn.ReadOnly = true;
            this.tIPOORDINEDataGridViewTextBoxColumn.Visible = false;
            // 
            // dATAORDINEDataGridViewTextBoxColumn
            // 
            this.dATAORDINEDataGridViewTextBoxColumn.DataPropertyName = "DATA_ORDINE";
            this.dATAORDINEDataGridViewTextBoxColumn.HeaderText = "DATA_ORDINE";
            this.dATAORDINEDataGridViewTextBoxColumn.Name = "dATAORDINEDataGridViewTextBoxColumn";
            this.dATAORDINEDataGridViewTextBoxColumn.ReadOnly = true;
            this.dATAORDINEDataGridViewTextBoxColumn.Visible = false;
            // 
            // nUMEROORDINEDataGridViewTextBoxColumn
            // 
            this.nUMEROORDINEDataGridViewTextBoxColumn.DataPropertyName = "NUMERO_ORDINE";
            this.nUMEROORDINEDataGridViewTextBoxColumn.HeaderText = "NUMERO_ORDINE";
            this.nUMEROORDINEDataGridViewTextBoxColumn.Name = "nUMEROORDINEDataGridViewTextBoxColumn";
            this.nUMEROORDINEDataGridViewTextBoxColumn.ReadOnly = true;
            this.nUMEROORDINEDataGridViewTextBoxColumn.Visible = false;
            // 
            // nUMERORIGADataGridViewTextBoxColumn
            // 
            this.nUMERORIGADataGridViewTextBoxColumn.DataPropertyName = "NUMERO_RIGA";
            this.nUMERORIGADataGridViewTextBoxColumn.HeaderText = "NUMERO_RIGA";
            this.nUMERORIGADataGridViewTextBoxColumn.Name = "nUMERORIGADataGridViewTextBoxColumn";
            this.nUMERORIGADataGridViewTextBoxColumn.ReadOnly = true;
            this.nUMERORIGADataGridViewTextBoxColumn.Visible = false;
            // 
            // codAnagraficoDataGridViewTextBoxColumn
            // 
            this.codAnagraficoDataGridViewTextBoxColumn.DataPropertyName = "CodAnagrafico";
            this.codAnagraficoDataGridViewTextBoxColumn.HeaderText = "CodAnagrafico";
            this.codAnagraficoDataGridViewTextBoxColumn.Name = "codAnagraficoDataGridViewTextBoxColumn";
            this.codAnagraficoDataGridViewTextBoxColumn.ReadOnly = true;
            this.codAnagraficoDataGridViewTextBoxColumn.Visible = false;
            // 
            // dATACONFERMACONSEGNADataGridViewTextBoxColumn
            // 
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn.DataPropertyName = "DATA_CONFERMA_CONSEGNA";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Format = "d";
            dataGridViewCellStyle2.NullValue = null;
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn.HeaderText = "Data di Consegna (non usare)";
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn.Name = "dATACONFERMACONSEGNADataGridViewTextBoxColumn";
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn.ReadOnly = true;
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn.Visible = false;
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn.Width = 140;
            // 
            // sortDataConsegnaDataGridViewTextBoxColumn
            // 
            this.sortDataConsegnaDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.sortDataConsegnaDataGridViewTextBoxColumn.DataPropertyName = "SortDataConsegna";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.Format = "d";
            dataGridViewCellStyle3.NullValue = null;
            this.sortDataConsegnaDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle3;
            this.sortDataConsegnaDataGridViewTextBoxColumn.HeaderText = "Data di Consegna";
            this.sortDataConsegnaDataGridViewTextBoxColumn.Name = "sortDataConsegnaDataGridViewTextBoxColumn";
            this.sortDataConsegnaDataGridViewTextBoxColumn.ReadOnly = true;
            this.sortDataConsegnaDataGridViewTextBoxColumn.Width = 113;
            // 
            // rAGIONESOCIALEDataGridViewTextBoxColumn
            // 
            this.rAGIONESOCIALEDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.rAGIONESOCIALEDataGridViewTextBoxColumn.DataPropertyName = "RAGIONE_SOCIALE";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.rAGIONESOCIALEDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle4;
            this.rAGIONESOCIALEDataGridViewTextBoxColumn.HeaderText = "Ragione Sociale";
            this.rAGIONESOCIALEDataGridViewTextBoxColumn.Name = "rAGIONESOCIALEDataGridViewTextBoxColumn";
            this.rAGIONESOCIALEDataGridViewTextBoxColumn.ReadOnly = true;
            this.rAGIONESOCIALEDataGridViewTextBoxColumn.Width = 104;
            // 
            // nazioneFiscaleDataGridViewTextBoxColumn
            // 
            this.nazioneFiscaleDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.nazioneFiscaleDataGridViewTextBoxColumn.DataPropertyName = "NazioneFiscale";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.nazioneFiscaleDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle5;
            this.nazioneFiscaleDataGridViewTextBoxColumn.HeaderText = "Nazione";
            this.nazioneFiscaleDataGridViewTextBoxColumn.Name = "nazioneFiscaleDataGridViewTextBoxColumn";
            this.nazioneFiscaleDataGridViewTextBoxColumn.ReadOnly = true;
            this.nazioneFiscaleDataGridViewTextBoxColumn.Width = 73;
            // 
            // cOMMESSALONGDataGridViewTextBoxColumn
            // 
            this.cOMMESSALONGDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.cOMMESSALONGDataGridViewTextBoxColumn.DataPropertyName = "COMMESSALONG";
            this.cOMMESSALONGDataGridViewTextBoxColumn.HeaderText = "Commessa";
            this.cOMMESSALONGDataGridViewTextBoxColumn.Name = "cOMMESSALONGDataGridViewTextBoxColumn";
            this.cOMMESSALONGDataGridViewTextBoxColumn.ReadOnly = true;
            this.cOMMESSALONGDataGridViewTextBoxColumn.Width = 85;
            // 
            // cOMMESSASHORTDataGridViewTextBoxColumn
            // 
            this.cOMMESSASHORTDataGridViewTextBoxColumn.DataPropertyName = "COMMESSASHORT";
            this.cOMMESSASHORTDataGridViewTextBoxColumn.HeaderText = "COMMESSASHORT";
            this.cOMMESSASHORTDataGridViewTextBoxColumn.Name = "cOMMESSASHORTDataGridViewTextBoxColumn";
            this.cOMMESSASHORTDataGridViewTextBoxColumn.ReadOnly = true;
            this.cOMMESSASHORTDataGridViewTextBoxColumn.Visible = false;
            // 
            // aRTICOLODataGridViewTextBoxColumn
            // 
            this.aRTICOLODataGridViewTextBoxColumn.DataPropertyName = "ARTICOLO";
            this.aRTICOLODataGridViewTextBoxColumn.HeaderText = "Articolo";
            this.aRTICOLODataGridViewTextBoxColumn.Name = "aRTICOLODataGridViewTextBoxColumn";
            this.aRTICOLODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // uMDataGridViewTextBoxColumn
            // 
            this.uMDataGridViewTextBoxColumn.DataPropertyName = "UM";
            this.uMDataGridViewTextBoxColumn.HeaderText = "UM";
            this.uMDataGridViewTextBoxColumn.Name = "uMDataGridViewTextBoxColumn";
            this.uMDataGridViewTextBoxColumn.ReadOnly = true;
            this.uMDataGridViewTextBoxColumn.Visible = false;
            // 
            // pREZZOUNITARIODataGridViewTextBoxColumn
            // 
            this.pREZZOUNITARIODataGridViewTextBoxColumn.DataPropertyName = "PREZZO_UNITARIO";
            this.pREZZOUNITARIODataGridViewTextBoxColumn.HeaderText = "PREZZO_UNITARIO";
            this.pREZZOUNITARIODataGridViewTextBoxColumn.Name = "pREZZOUNITARIODataGridViewTextBoxColumn";
            this.pREZZOUNITARIODataGridViewTextBoxColumn.ReadOnly = true;
            this.pREZZOUNITARIODataGridViewTextBoxColumn.Visible = false;
            // 
            // qTAORDINATADataGridViewTextBoxColumn
            // 
            this.qTAORDINATADataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.qTAORDINATADataGridViewTextBoxColumn.DataPropertyName = "QTA_ORDINATA";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.Format = "N0";
            dataGridViewCellStyle6.NullValue = "- - -";
            this.qTAORDINATADataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle6;
            this.qTAORDINATADataGridViewTextBoxColumn.HeaderText = "Q.tà Ordinata";
            this.qTAORDINATADataGridViewTextBoxColumn.Name = "qTAORDINATADataGridViewTextBoxColumn";
            this.qTAORDINATADataGridViewTextBoxColumn.ReadOnly = true;
            this.qTAORDINATADataGridViewTextBoxColumn.Width = 93;
            // 
            // qTASPEDITADataGridViewTextBoxColumn
            // 
            this.qTASPEDITADataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.qTASPEDITADataGridViewTextBoxColumn.DataPropertyName = "QTA_SPEDITA";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Format = "N0";
            dataGridViewCellStyle7.NullValue = "- - -";
            this.qTASPEDITADataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle7;
            this.qTASPEDITADataGridViewTextBoxColumn.HeaderText = "Q.tà Spedita";
            this.qTASPEDITADataGridViewTextBoxColumn.Name = "qTASPEDITADataGridViewTextBoxColumn";
            this.qTASPEDITADataGridViewTextBoxColumn.ReadOnly = true;
            this.qTASPEDITADataGridViewTextBoxColumn.Width = 86;
            // 
            // qTADAEVADEREDataGridViewTextBoxColumn
            // 
            this.qTADAEVADEREDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.qTADAEVADEREDataGridViewTextBoxColumn.DataPropertyName = "QTA_DA_EVADERE";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.Format = "N0";
            dataGridViewCellStyle8.NullValue = "- - -";
            this.qTADAEVADEREDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle8;
            this.qTADAEVADEREDataGridViewTextBoxColumn.HeaderText = "Q.tà inevasa";
            this.qTADAEVADEREDataGridViewTextBoxColumn.Name = "qTADAEVADEREDataGridViewTextBoxColumn";
            this.qTADAEVADEREDataGridViewTextBoxColumn.ReadOnly = true;
            this.qTADAEVADEREDataGridViewTextBoxColumn.Width = 86;
            // 
            // iMPORTODataGridViewTextBoxColumn
            // 
            this.iMPORTODataGridViewTextBoxColumn.DataPropertyName = "IMPORTO";
            this.iMPORTODataGridViewTextBoxColumn.HeaderText = "IMPORTO";
            this.iMPORTODataGridViewTextBoxColumn.Name = "iMPORTODataGridViewTextBoxColumn";
            this.iMPORTODataGridViewTextBoxColumn.ReadOnly = true;
            this.iMPORTODataGridViewTextBoxColumn.Visible = false;
            // 
            // iMPORTOEVASODataGridViewTextBoxColumn
            // 
            this.iMPORTOEVASODataGridViewTextBoxColumn.DataPropertyName = "IMPORTO_EVASO";
            this.iMPORTOEVASODataGridViewTextBoxColumn.HeaderText = "IMPORTO_EVASO";
            this.iMPORTOEVASODataGridViewTextBoxColumn.Name = "iMPORTOEVASODataGridViewTextBoxColumn";
            this.iMPORTOEVASODataGridViewTextBoxColumn.ReadOnly = true;
            this.iMPORTOEVASODataGridViewTextBoxColumn.Visible = false;
            // 
            // iMPORTODAEVADEREDataGridViewTextBoxColumn
            // 
            this.iMPORTODAEVADEREDataGridViewTextBoxColumn.DataPropertyName = "IMPORTO_DA_EVADERE";
            this.iMPORTODAEVADEREDataGridViewTextBoxColumn.HeaderText = "IMPORTO_DA_EVADERE";
            this.iMPORTODAEVADEREDataGridViewTextBoxColumn.Name = "iMPORTODAEVADEREDataGridViewTextBoxColumn";
            this.iMPORTODAEVADEREDataGridViewTextBoxColumn.ReadOnly = true;
            this.iMPORTODAEVADEREDataGridViewTextBoxColumn.Visible = false;
            // 
            // meseConsegnaDataGridViewTextBoxColumn
            // 
            this.meseConsegnaDataGridViewTextBoxColumn.DataPropertyName = "MeseConsegna";
            this.meseConsegnaDataGridViewTextBoxColumn.HeaderText = "MeseConsegna";
            this.meseConsegnaDataGridViewTextBoxColumn.Name = "meseConsegnaDataGridViewTextBoxColumn";
            this.meseConsegnaDataGridViewTextBoxColumn.ReadOnly = true;
            this.meseConsegnaDataGridViewTextBoxColumn.Visible = false;
            // 
            // nomeMeseConsegnaDataGridViewTextBoxColumn
            // 
            this.nomeMeseConsegnaDataGridViewTextBoxColumn.DataPropertyName = "NomeMeseConsegna";
            this.nomeMeseConsegnaDataGridViewTextBoxColumn.HeaderText = "NomeMeseConsegna";
            this.nomeMeseConsegnaDataGridViewTextBoxColumn.Name = "nomeMeseConsegnaDataGridViewTextBoxColumn";
            this.nomeMeseConsegnaDataGridViewTextBoxColumn.ReadOnly = true;
            this.nomeMeseConsegnaDataGridViewTextBoxColumn.Visible = false;
            // 
            // annoConsegnaDataGridViewTextBoxColumn
            // 
            this.annoConsegnaDataGridViewTextBoxColumn.DataPropertyName = "AnnoConsegna";
            this.annoConsegnaDataGridViewTextBoxColumn.HeaderText = "AnnoConsegna";
            this.annoConsegnaDataGridViewTextBoxColumn.Name = "annoConsegnaDataGridViewTextBoxColumn";
            this.annoConsegnaDataGridViewTextBoxColumn.ReadOnly = true;
            this.annoConsegnaDataGridViewTextBoxColumn.Visible = false;
            // 
            // commessaDataGridViewTextBoxColumn
            // 
            this.commessaDataGridViewTextBoxColumn.DataPropertyName = "Commessa";
            this.commessaDataGridViewTextBoxColumn.HeaderText = "Commessa";
            this.commessaDataGridViewTextBoxColumn.Name = "commessaDataGridViewTextBoxColumn";
            this.commessaDataGridViewTextBoxColumn.ReadOnly = true;
            this.commessaDataGridViewTextBoxColumn.Visible = false;
            // 
            // aOProgrammazioneDataGridViewTextBoxColumn
            // 
            this.aOProgrammazioneDataGridViewTextBoxColumn.DataPropertyName = "AO_Programmazione";
            this.aOProgrammazioneDataGridViewTextBoxColumn.HeaderText = "Programmazione";
            this.aOProgrammazioneDataGridViewTextBoxColumn.Name = "aOProgrammazioneDataGridViewTextBoxColumn";
            this.aOProgrammazioneDataGridViewTextBoxColumn.ReadOnly = true;
            this.aOProgrammazioneDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.aOProgrammazioneDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // aOProgrammazioneNoteDataGridViewTextBoxColumn
            // 
            this.aOProgrammazioneNoteDataGridViewTextBoxColumn.DataPropertyName = "AO_Programmazione_Note";
            this.aOProgrammazioneNoteDataGridViewTextBoxColumn.HeaderText = "AO_Programmazione_Note";
            this.aOProgrammazioneNoteDataGridViewTextBoxColumn.Name = "aOProgrammazioneNoteDataGridViewTextBoxColumn";
            this.aOProgrammazioneNoteDataGridViewTextBoxColumn.ReadOnly = true;
            this.aOProgrammazioneNoteDataGridViewTextBoxColumn.Visible = false;
            // 
            // aOMontaggioDataGridViewTextBoxColumn
            // 
            this.aOMontaggioDataGridViewTextBoxColumn.DataPropertyName = "AO_Montaggio";
            this.aOMontaggioDataGridViewTextBoxColumn.HeaderText = "AO_Montaggio";
            this.aOMontaggioDataGridViewTextBoxColumn.Name = "aOMontaggioDataGridViewTextBoxColumn";
            this.aOMontaggioDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // aOMontaggioNoteDataGridViewTextBoxColumn
            // 
            this.aOMontaggioNoteDataGridViewTextBoxColumn.DataPropertyName = "AO_Montaggio_Note";
            this.aOMontaggioNoteDataGridViewTextBoxColumn.HeaderText = "AO_Montaggio_Note";
            this.aOMontaggioNoteDataGridViewTextBoxColumn.Name = "aOMontaggioNoteDataGridViewTextBoxColumn";
            this.aOMontaggioNoteDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // aOCollaudoConfezionamentoDataGridViewTextBoxColumn
            // 
            this.aOCollaudoConfezionamentoDataGridViewTextBoxColumn.DataPropertyName = "AO_CollaudoConfezionamento";
            this.aOCollaudoConfezionamentoDataGridViewTextBoxColumn.HeaderText = "AO_CollaudoConfezionamento";
            this.aOCollaudoConfezionamentoDataGridViewTextBoxColumn.Name = "aOCollaudoConfezionamentoDataGridViewTextBoxColumn";
            this.aOCollaudoConfezionamentoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // aOCollaudoConfezionamentoNoteDataGridViewTextBoxColumn
            // 
            this.aOCollaudoConfezionamentoNoteDataGridViewTextBoxColumn.DataPropertyName = "AO_CollaudoConfezionamento_Note";
            this.aOCollaudoConfezionamentoNoteDataGridViewTextBoxColumn.HeaderText = "AO_CollaudoConfezionamento_Note";
            this.aOCollaudoConfezionamentoNoteDataGridViewTextBoxColumn.Name = "aOCollaudoConfezionamentoNoteDataGridViewTextBoxColumn";
            this.aOCollaudoConfezionamentoNoteDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // aOSpedizioneDataGridViewTextBoxColumn
            // 
            this.aOSpedizioneDataGridViewTextBoxColumn.DataPropertyName = "AO_Spedizione";
            this.aOSpedizioneDataGridViewTextBoxColumn.HeaderText = "AO_Spedizione";
            this.aOSpedizioneDataGridViewTextBoxColumn.Name = "aOSpedizioneDataGridViewTextBoxColumn";
            this.aOSpedizioneDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // aOSpedizioneNoteDataGridViewTextBoxColumn
            // 
            this.aOSpedizioneNoteDataGridViewTextBoxColumn.DataPropertyName = "AO_Spedizione_Note";
            this.aOSpedizioneNoteDataGridViewTextBoxColumn.HeaderText = "AO_Spedizione_Note";
            this.aOSpedizioneNoteDataGridViewTextBoxColumn.Name = "aOSpedizioneNoteDataGridViewTextBoxColumn";
            this.aOSpedizioneNoteDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // aOVenditaDataGridViewTextBoxColumn
            // 
            this.aOVenditaDataGridViewTextBoxColumn.DataPropertyName = "AO_Vendita";
            this.aOVenditaDataGridViewTextBoxColumn.HeaderText = "AO_Vendita";
            this.aOVenditaDataGridViewTextBoxColumn.Name = "aOVenditaDataGridViewTextBoxColumn";
            this.aOVenditaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // aOVenditaNoteDataGridViewTextBoxColumn
            // 
            this.aOVenditaNoteDataGridViewTextBoxColumn.DataPropertyName = "AO_Vendita_Note";
            this.aOVenditaNoteDataGridViewTextBoxColumn.HeaderText = "AO_Vendita_Note";
            this.aOVenditaNoteDataGridViewTextBoxColumn.Name = "aOVenditaNoteDataGridViewTextBoxColumn";
            this.aOVenditaNoteDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // distintaBaseDataGridViewTextBoxColumn
            // 
            this.distintaBaseDataGridViewTextBoxColumn.DataPropertyName = "Distinta_Base";
            this.distintaBaseDataGridViewTextBoxColumn.HeaderText = "Distinta_Base";
            this.distintaBaseDataGridViewTextBoxColumn.Name = "distintaBaseDataGridViewTextBoxColumn";
            this.distintaBaseDataGridViewTextBoxColumn.ReadOnly = true;
            this.distintaBaseDataGridViewTextBoxColumn.Visible = false;
            // 
            // qtaprogrammazioneDataGridViewTextBoxColumn
            // 
            this.qtaprogrammazioneDataGridViewTextBoxColumn.DataPropertyName = "qta_programmazione";
            this.qtaprogrammazioneDataGridViewTextBoxColumn.HeaderText = "qta_programmazione";
            this.qtaprogrammazioneDataGridViewTextBoxColumn.Name = "qtaprogrammazioneDataGridViewTextBoxColumn";
            this.qtaprogrammazioneDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // qtamontaggioDataGridViewTextBoxColumn
            // 
            this.qtamontaggioDataGridViewTextBoxColumn.DataPropertyName = "qta_montaggio";
            this.qtamontaggioDataGridViewTextBoxColumn.HeaderText = "qta_montaggio";
            this.qtamontaggioDataGridViewTextBoxColumn.Name = "qtamontaggioDataGridViewTextBoxColumn";
            this.qtamontaggioDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // qtacollaudoconfezionamentoDataGridViewTextBoxColumn
            // 
            this.qtacollaudoconfezionamentoDataGridViewTextBoxColumn.DataPropertyName = "qta_collaudoconfezionamento";
            this.qtacollaudoconfezionamentoDataGridViewTextBoxColumn.HeaderText = "qta_collaudoconfezionamento";
            this.qtacollaudoconfezionamentoDataGridViewTextBoxColumn.Name = "qtacollaudoconfezionamentoDataGridViewTextBoxColumn";
            this.qtacollaudoconfezionamentoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // qtavenditaDataGridViewTextBoxColumn
            // 
            this.qtavenditaDataGridViewTextBoxColumn.DataPropertyName = "qta_vendita";
            this.qtavenditaDataGridViewTextBoxColumn.HeaderText = "qta_vendita";
            this.qtavenditaDataGridViewTextBoxColumn.Name = "qtavenditaDataGridViewTextBoxColumn";
            this.qtavenditaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // UC_Avanzamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1043, 579);
            this.Controls.Add(this.gv_Commesse);
            this.Name = "UC_Avanzamento";
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "Sistematica - Avanzamento Commesse";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UC_Avanzamento_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gv_Commesse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFCommesseAperteCLSLBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroGrid gv_Commesse;
        private ds_SL ds_SL;
        private System.Windows.Forms.BindingSource sFCommesseAperteCLSLBindingSource;
        private ds_SLTableAdapters.SF_CommesseAperte_CL_SLTableAdapter sF_CommesseAperte_CL_SLTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn entitaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tIPOORDINEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dATAORDINEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nUMEROORDINEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nUMERORIGADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn codAnagraficoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dATACONFERMACONSEGNADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sortDataConsegnaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rAGIONESOCIALEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nazioneFiscaleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cOMMESSALONGDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cOMMESSASHORTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aRTICOLODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn uMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pREZZOUNITARIODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qTAORDINATADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qTASPEDITADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qTADAEVADEREDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iMPORTODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iMPORTOEVASODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iMPORTODAEVADEREDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn meseConsegnaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomeMeseConsegnaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn annoConsegnaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn commessaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewImageColumn aOProgrammazioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOProgrammazioneNoteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOMontaggioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOMontaggioNoteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOCollaudoConfezionamentoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOCollaudoConfezionamentoNoteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOSpedizioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOSpedizioneNoteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOVenditaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOVenditaNoteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn distintaBaseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtaprogrammazioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtamontaggioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtacollaudoconfezionamentoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtavenditaDataGridViewTextBoxColumn;
    }
}