﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using Zebra.Sdk.Comm;
using Zebra.Sdk.Printer;
using Zebra.Sdk.Printer.Discovery;


namespace SmartLineProduction
{
    public partial class UC_PrintLabel_Zebra : MetroFramework.Forms.MetroForm
    {
        public UC_PrintLabel_Zebra()
        {
            InitializeComponent();
        }

        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UC_PrintLabel_Zebra_Load(object sender, EventArgs e)
        {
            SettaForm();

            this.WindowState = FormWindowState.Maximized;
            tbx_PrintString.Focus();
        }

        private void SettaForm()
        {
            if (this.ActiveControl == null)
            {
                tbx_PrintString.Focus();
            }

            tbx_PrintString.Text = "";

            cb_Correzione.SelectedItem = "0";

            tbx_PrintString.Focus();
        }

        private void but_AttivaProc_Click(object sender, EventArgs e)
        {
            SettaForm();
        }

        private void UC_PrintLabel_Zebra_Shown(object sender, EventArgs e)
        {
            tbx_PrintString.Focus();
            //base.OnShown(e);
        }

        ////////////////////////////////////
        /// Funzioni per stampa ZPL Zebra //
        ////////////////////////////////////
        private async void but_Print_Click(object sender, EventArgs e)
        {
            Connection printerConnection = null;
            try
            {
                printerConnection = GetConnection();
                string ipport = Properties.Settings.Default.IP_printer;
                int port = 9100;

            }
            catch (ConnectionException)
            {
                lab_printer.Text = "Invalid Address and/or Port";
                lab_printer.Refresh();
                await Task.Delay(1000);
                lab_printer.Text = "Not Connected";
                lab_printer.Refresh();
                return;
            }

            await Task.Run(async () =>
            {
                try
                {
                    lab_printer.Text = "Connecting...";
                    lab_printer.Refresh();
                    await Task.Delay(1500);

                    printerConnection.Open();

                    lab_printer.Text = "Connected";
                    lab_printer.Refresh();
                    await Task.Delay(1500);

                    //lab_printer.Text = "Determining Printer Language...";
                    //lab_printer.Refresh();
                    //await Task.Delay(1500);

                    PrinterLanguage printerLanguage = ZebraPrinterFactory.GetInstance(printerConnection).PrinterControlLanguage;
                    //lab_printer.Text = "Printer Language " + printerLanguage.ToString();
                    //lab_printer.Refresh();
                    //await Task.Delay(1500);

                    lab_printer.Text = "Sending Data...";
                    lab_printer.Refresh();

                    for (int i = 0; i < 5; i++)
                    {
                        printerConnection.Write(WriteLabel(printerLanguage));
                    }
                }
                catch (ConnectionException)
                {
                    lab_printer.Text = "Communications Error";
                    lab_printer.Refresh();
                }
                catch (ZebraPrinterLanguageUnknownException)
                {
                    lab_printer.Text = "Invalid Printer Language";
                    lab_printer.Refresh();
                }
                finally
                {
                    try
                    {
                        await Task.Delay(1000);
                        lab_printer.Text = "Disconnecting...";
                        lab_printer.Refresh();
                        if (printerConnection != null)
                        {
                            printerConnection.Close();
                        }

                        await Task.Delay(1000);
                        lab_printer.Text = "Not Connected";
                        lab_printer.Refresh();
                    }
                    catch (ConnectionException)
                    {
                    }
                    finally
                    {
                    }
                }
            });

        }

        public Connection GetConnection()
        {
            try
            {
                //int port = string.IsNullOrEmpty(viewModel.Port) ? 9100 : int.Parse(viewModel.Port);
                //return new TcpConnection(viewModel.IpAddress, port);

                string ipaddr = Properties.Settings.Default.IP_printer;
                int port = 9100;
                return new TcpConnection(ipaddr, port);
            }
            catch (Exception e)
            {
                throw new ConnectionException(e.Message, e);
            }
        }

        private byte[] WriteLabel(PrinterLanguage printerLanguage)
        {
            byte[] configLabel = null;
            if (printerLanguage == PrinterLanguage.ZPL)
            {
                //configLabel = Encoding.UTF8.GetBytes("^XA^FO17,16^GB379,371,8^FS^FT65,255^A0N,135,134^FDTEST^FS^XZ");
                //string ZPL = "^XA";                              //Start of label format
                //ZPL = ZPL + "^MMT";                              //Media Type = T -- thermal transfer
                //ZPL = ZPL + "^MNV";                              //media tracking = V -- continuous media, variable length
                ////ZPL = ZPL + "^MD";                             //media darkness -- da vedere
                ////ZPL = ZPL + "^CFE,25";                         //Change Font

                //ZPL = ZPL + "^FO00,00";                          //Set start position
                //ZPL = ZPL + "^LT-60";                            //Label top position

                //ZPL = ZPL + "^BXR,2,200";                        //Set Bar Code Datamatrix
                //ZPL = ZPL + "^FD" + "3929202100000097" + "^FS";  //Data Field

                //ZPL = ZPL + "^XZ";                               //End of label format

                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                int scostamento = 20;
                scostamento = scostamento + Convert.ToInt32(cb_Correzione.Text);
                lab_correzione.Text = scostamento.ToString();
                lab_correzione.Refresh();

                string ZPL = "^XA";                              //Start of label format
                ZPL = ZPL + "~TA000";                            //Tear-off Adjust Position
                ZPL = ZPL + "^LT0";                              //Label Top
                ZPL = ZPL + "^MTT";                              //Media Type = T -- thermal transfer
                ZPL = ZPL + "^MMT";                              //
                ZPL = ZPL + "^MNV";                              //media tracking = V -- continuous media, variable length
                ZPL = ZPL + "^PR1";                              //Print Rate
                //ZPL = ZPL + "^PW368";                            //Print Width
                ZPL = ZPL + "^LL0088";                           //Label Length
                ZPL = ZPL + "^LT" + scostamento.ToString();      //Set start position
                                                                 //ZPL = ZPL + "^FD" + "XSWR00010101X_L" + "^FS";  //Data Field
                                                                 //ZPL = ZPL + "^BY28,28^FT65,0^BXN,2,200,0,0,1,~";
                                                                 //ZPL = ZPL + "^FH\\^FD" + tbx_PrintString.Text + "^FS";
                                                                 //ZPL = ZPL + "^BY28,28^FT190,0^BXN,2,200,0,0,1,~"; //241
                                                                 //ZPL = ZPL + "^FH\\^FD" + tbx_PrintString.Text + "^FS";

                ZPL = ZPL + "^CF0,18";
                ZPL = ZPL + "^FO5,10 ^FD" + tbx_PrintString.Text + "^FS";
                ZPL = ZPL + "^FO190,10 ^FD" + tbx_PrintString.Text + "^FS";

                ZPL = ZPL + "^XZ";                               //End of label format
                                                                 //ZPL = ZPL + "^POI";                            //Print Orientation
                                                                 //ZPL = ZPL + "^JMA";                            //Set Dots per Millimeter - A = 24 dots/mm, 12 dots/mm, 8 dots/mm or 6 dots/mm
                                                                 //ZPL = ZPL + "~SDA25";                          //Set Darkness
                                                                 //ZPL = ZPL + "^CI9";                            //Change International Font/Encoding
                                                                 //ZPL = ZPL + "^PQ4";                            //Print copies
                                                                 //ZPL = ZPL + "^MD";                             //media darkness -- da vedere
                                                                 //ZPL = ZPL + "^CFE,25";                         //Change Font
                                                                 //ZPL = ZPL + "^LT-30";                          //Label top position
                                                                 //ZPL = ZPL + "^LT10";                           //Label top position
                                                                 //ZPL = ZPL + "^FO00,00^ADN,36,20^FDRRRRRRRRRRRR^FS";

                // send command

                configLabel = Encoding.UTF8.GetBytes(ZPL);
            }
            else if (printerLanguage == PrinterLanguage.CPCL)
            {
                string cpclConfigLabel = "! 0 200 200 406 1\r\n" + "ON-FEED IGNORE\r\n" + "BOX 20 20 380 380 8\r\n" + "T 0 6 137 177 TEST\r\n" + "PRINT\r\n";
                configLabel = Encoding.UTF8.GetBytes(cpclConfigLabel);
            }
            return configLabel;
        }

        private void menu_sw_exit_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}