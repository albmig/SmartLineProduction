﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using System.IO;
using Syncfusion.Windows.Forms;
using Syncfusion.Pdf;
using Syncfusion.Pdf.Parsing;
using SmartLineProduction.ds_SLTableAdapters;

namespace SmartLineProduction
{
    public partial class UC_Schede : MetroFramework.Forms.MetroForm
    {
        private string btn_view = "K"; // K-P-R-C-FR-FP
        public UC_Schede()
        {
            InitializeComponent();
        }

        //// LOAD
        private void UC_Schede_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.Fam_Prod'. È possibile spostarla o rimuoverla se necessario.
            this.fam_ProdTableAdapter.FillBy_SchedePack(this.ds_SL.Fam_Prod);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_DistinteBasi_Schede'. È possibile spostarla o rimuoverla se necessario.
            this.sF_DistinteBasi_SchedeTableAdapter.Fill(this.ds_SL.SF_DistinteBasi_Schede);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_ArticoliSchede'. È possibile spostarla o rimuoverla se necessario.
            this.sF_ArticoliSchedeTableAdapter.Fill(this.ds_SL.SF_ArticoliSchede);

            SetView();
        }

        //// BINDINGSOURCE CHANGED
        private void sFArticoliSchedeBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (Tab_Schede.SelectedTab == Tab_Schede.TabPages["tab_Kit"])
            {
                DataRowView drview = (DataRowView)sFArticoliSchedeBindingSource.Current;
                if (drview == null) { return; }

                string articolo = drview["Articolo"].ToString();

                if (articolo.Substring(0, 4) != "XKIT") { return; }

                string path = Properties.Settings.Default.Doc_folder;
                path = path + @"XKIT\";
                string path_it = path + drview["Articolo"].ToString() + @"\IT\" + drview["Articolo"].ToString() + ".pdf";
                string path_en = path + drview["Articolo"].ToString() + @"\EN\" + drview["Articolo"].ToString() + ".pdf";

                if (System.IO.File.Exists(path_it)) { Kit_pdf_it.LoadFile(path_it); } else { Kit_pdf_it.LoadFile(@"Resources\Pdf_notpresent.pdf"); }
                if (System.IO.File.Exists(path_en)) { Kit_pdf_en.LoadFile(path_en); } else { Kit_pdf_en.LoadFile(@"Resources\Pdf_notpresent.pdf"); }
                SetPDFReader();
            }

            if (Tab_Schede.SelectedTab == Tab_Schede.TabPages["tab_Cablaggi"])
            {

                DataRowView drview = (DataRowView)sFArticoliSchedeBindingSource.Current;
                if (drview == null) { return; }

                string articolo = drview["Articolo"].ToString();

                string path = Properties.Settings.Default.Doc_folder;
                path = path + @"XCBL\";

                // Cerca il folder giusto
                string cblstart = articolo + "*";
                string[] dirs = Directory.GetDirectories(path, cblstart, SearchOption.TopDirectoryOnly);

                foreach (string dir in dirs)
                {
                    string path_it = dir + @"\IT\" + drview["Articolo"].ToString() + ".pdf";
                    string path_en = dir + @"\EN\" + drview["Articolo"].ToString() + ".pdf";

                    if (System.IO.File.Exists(path_it)) { Cablaggi_pdf_it.LoadFile(path_it); } else { Cablaggi_pdf_it.LoadFile(@"Resources\Pdf_notpresent.pdf"); }
                    if (System.IO.File.Exists(path_en)) { Cablaggi_pdf_en.LoadFile(path_en); } else { Cablaggi_pdf_en.LoadFile(@"Resources\Pdf_notpresent.pdf"); }
                    SetPDFReader();
                }

                if ((dirs != null) && (!dirs.Any()))
                {
                    Cablaggi_pdf_it.LoadFile(@"Resources\Pdf_notpresent.pdf");
                    Cablaggi_pdf_en.LoadFile(@"Resources\Pdf_notpresent.pdf");
                    SetPDFReader();
                }
            }

            if (Tab_Schede.SelectedTab == Tab_Schede.TabPages["tab_FW_P"])
            {
                DataRowView drview = (DataRowView)sFArticoliSchedeBindingSource.Current;
                if (drview == null) { return; }

                string articolo = drview["Articolo"].ToString();

                string path = Properties.Settings.Default.Doc_folder;
                path = path + @"XSWRP\";

                string path_it = path + drview["Articolo"].ToString() + @"\IT\" + drview["Articolo"].ToString() + ".pdf";
                string path_en = path + drview["Articolo"].ToString() + @"\EN\" + drview["Articolo"].ToString() + ".pdf";

                if (System.IO.File.Exists(path_it)) { FW_P_pdf_it.LoadFile(path_it); } else { FW_P_pdf_it.LoadFile(@"Resources\Pdf_notpresent.pdf"); }
                if (System.IO.File.Exists(path_en)) { FW_P_pdf_en.LoadFile(path_en); } else { FW_P_pdf_en.LoadFile(@"Resources\Pdf_notpresent.pdf"); }
                SetPDFReader();
            }

            if (Tab_Schede.SelectedTab == Tab_Schede.TabPages["tab_FW_R"])
            {
                DataRowView drview = (DataRowView)sFArticoliSchedeBindingSource.Current;
                if (drview == null) { return; }

                string articolo = drview["Articolo"].ToString();

                string path = Properties.Settings.Default.Doc_folder;
                path = path + @"XSWRR\";

                string path_it = path + drview["Articolo"].ToString() + @"\IT\" + drview["Articolo"].ToString() + ".pdf";
                string path_en = path + drview["Articolo"].ToString() + @"\EN\" + drview["Articolo"].ToString() + ".pdf";

                if (System.IO.File.Exists(path_it)) { FW_R_pdf_it.LoadFile(path_it); } else { FW_R_pdf_it.LoadFile(@"Resources\Pdf_notpresent.pdf"); }
                if (System.IO.File.Exists(path_en)) { FW_R_pdf_en.LoadFile(path_en); } else { FW_R_pdf_en.LoadFile(@"Resources\Pdf_notpresent.pdf"); }
                SetPDFReader();
            }
        }

        //// CONTROLS EVENTS
        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tab_Kit_Enter(object sender, EventArgs e)
        {
            this.sF_ArticoliSchedeTableAdapter.FillBy_SchedeProdottoKit(this.ds_SL.SF_ArticoliSchede);
            gv_Kit.Refresh();
        }

        private void tb_grid_kit_TextChanged(object sender, EventArgs e)
        {
            string filtro = string.Format("Articolo LIKE '%{0}%'", tb_grid_kit.Text);
            sFArticoliSchedeBindingSource.Filter = filtro;
            tb_grid_kit.Focus();
        }

        private void tab_Palmari_Enter(object sender, EventArgs e)
        {
            this.sF_ArticoliSchedeTableAdapter.FillBy_SchedeProdottoPalmari(this.ds_SL.SF_ArticoliSchede);
            gv_Palmari.Refresh();
        }

        private void btn_Kit_Click(object sender, EventArgs e)
        {
            btn_view = "K";
        }

        private void btn_Palmari_Click(object sender, EventArgs e)
        {
            btn_view = "P";
        }

        private void btn_Ricevitori_Click(object sender, EventArgs e)
        {
            btn_view = "R";
        }

        private void btn_Cablaggi_Click(object sender, EventArgs e)
        {
            btn_view = "C";
        }

        private void btn_FW_P_Click(object sender, EventArgs e)
        {
            btn_view = "FP";
        }

        private void btn_FW_R_Click(object sender, EventArgs e)
        {
            btn_view = "FR";
        }

        //// OTHER ROUTINES
        private void SetPDFReader()
        {
            Kit_pdf_it.setView("FitV");
            Kit_pdf_en.setView("FitV");
            Palmari_pdf_it.setView("FitV");
            Palmari_pdf_en.setView("FitV");
            Ricevitori_pdf_it.setView("FitV");
            Ricevitori_pdf_en.setView("FitV");
            Cablaggi_pdf_it.setView("FitV");
            Cablaggi_pdf_en.setView("FitV");
            FW_P_pdf_it.setView("FitV");
            FW_P_pdf_en.setView("FitV");
            FW_R_pdf_it.setView("FitV");
            FW_R_pdf_en.setView("FitV");

            Kit_pdf_it.setShowScrollbars(false);
            Kit_pdf_en.setShowScrollbars(false);
            Palmari_pdf_it.setShowScrollbars(false);
            Palmari_pdf_en.setShowScrollbars(false);
            Ricevitori_pdf_it.setShowScrollbars(false);
            Ricevitori_pdf_en.setShowScrollbars(false);
            Cablaggi_pdf_it.setShowScrollbars(false);
            Cablaggi_pdf_en.setShowScrollbars(false);
            FW_P_pdf_it.setShowScrollbars(false);
            FW_P_pdf_en.setShowScrollbars(false);
            FW_R_pdf_it.setShowScrollbars(false);
            FW_R_pdf_en.setShowScrollbars(false);

            Kit_pdf_it.setShowToolbar(false);
            Kit_pdf_en.setShowToolbar(false);
            Palmari_pdf_it.setShowToolbar(false);
            Palmari_pdf_en.setShowToolbar(false);
            Ricevitori_pdf_it.setShowToolbar(false);
            Ricevitori_pdf_en.setShowToolbar(false);
            Cablaggi_pdf_it.setShowToolbar(false);
            Cablaggi_pdf_en.setShowToolbar(false);
            FW_P_pdf_it.setShowToolbar(false);
            FW_P_pdf_en.setShowToolbar(false);
            FW_R_pdf_it.setShowToolbar(false);
            FW_R_pdf_en.setShowToolbar(false);

            Kit_pdf_it.setPageMode("none");
            Kit_pdf_en.setPageMode("none");
            Palmari_pdf_it.setPageMode("none");
            Palmari_pdf_en.setPageMode("none");
            Ricevitori_pdf_it.setPageMode("none");
            Ricevitori_pdf_en.setPageMode("none");
            Cablaggi_pdf_it.setPageMode("none");
            Cablaggi_pdf_en.setPageMode("none");
            FW_P_pdf_it.setPageMode("none");
            FW_P_pdf_en.setPageMode("none");
            FW_R_pdf_it.setPageMode("none");
            FW_R_pdf_en.setPageMode("none");
        }

        private string TrovaPath(string tiporicerca, string codice, string lingua)
        {
            string path = Properties.Settings.Default.Doc_folder;

            if ((tiporicerca=="Kit") && (lingua=="IT"))
            {
                path = path + @"XKIT\";
                string path_it = path + codice + @"\IT\" + codice + ".pdf";
                return path_it;
            }
            if ((tiporicerca == "Kit") && (lingua == "EN"))
            {
                path = path + @"XKIT\";
                string path_en = path + codice + @"\EN\" + codice + ".pdf";
                return path_en;
            }
            if (tiporicerca == "Swr")
            {
                if (codice.StartsWith("XSWRP")) { path = path + @"XSWRP\"; }
                if (codice.StartsWith("XSWRR")) { path = path + @"XSWRR\"; }

                if (lingua == "IT") { string path_it = path + codice + @"\IT\" + codice + ".pdf"; return path_it; }
                if (lingua == "EN") { string path_en = path + codice + @"\EN\" + codice + ".pdf"; return path_en; }
            }

            return null;
        }

        private void SetView()
        {
            tb_grid_kit.Text = "";
            tb_grid_palmari.Text = "";
            tb_grid_ricevitori.Text = "";
            tb_grid_cablaggi.Text = "";
            tb_grid_FW_P.Text = "";
            tb_grid_FW_R.Text = "";
            Tab_Schede.SelectTab("tab_Kit");
            layout_tabbed_pages.Visible = true;

            btn_Kit.BackColor = Color.White;
            btn_Palmari.BackColor = Color.White;
            btn_Ricevitori.BackColor = Color.White;
            btn_Cablaggi.BackColor = Color.White;
            btn_FW_P.BackColor = Color.White;
            btn_FW_R.BackColor = Color.White;
            switch (btn_view)
            {
                case "K":
                    btn_Kit.BackColor = Color.Red;
                    break;
                case "P": break;
                case "R": break;
                case "C": break;
                case "FR": break;
                case "FP": break;
            }
        }

    }
}
