﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using System.IO;
//using Dymo;
using DYMO.Label.Framework;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using Zebra.Sdk.Comm;
using Zebra.Sdk.Printer;
using Zebra.Sdk.Printer.Discovery;

namespace SmartLineProduction
{
    public partial class UC_Programmazione_Progettazione : MetroFramework.Forms.MetroForm
    {
        public string glob_device = "--device EFR32BG13P733F512GM48";
        //public string glob_device = "--device EFR32MG12P332F1024GL125";


        // Lettura impostazioni
        public static string glob_FW_folder = "";
        public static string glob_IP_printer = "";
        public static bool glob_use_printer = false;
        public static string glob_Commander_path = "";

        //Variabili globali utilizzate
        public bool glob_Program_OK = true;
        public string glob_Commessa = "";
        public string glob_Kit = "";
        public string glob_Device = "";
        public string glob_Codice_FW = "";
        public int glob_FW_Key_ID = 0; //Puntatore al firmware
        public int glob_ID_Cli = 0; // Codice Nominativo del cliente
        public string glob_ID_device = "";

        public string glob_ser_num_read = "";
        public string glob_ser_num_write = "";

        //Riposizionamento
        public int glob_selectedrecord = 0;





        //public string glob_codice_kit = "";
        //public string glob_codice_sistema = "";
        //public string glob_codice_fw = "";
        //public string glob_codice_fw_fulltmppath = "";
        public string glob_ID_code = "";
        public string glob_ID_newcode = "";
        public string glob_UNIQUE_ID = "";
        public string glob_Form_ID = "";
        //public string WEB_path_image = @"\\192.168.0.8\ricerca e sviluppo\Documentazione_SL\doc_SL (sinc per web)\";
        public string WEB_path_image = Properties.Settings.Default.Doc_folder;
        //public string glob_ID_cli = "";

        public string glob_Printer_Name = "";
        public string glob_Printer_Tray = "";
        public bool glob_show_evasi = true;

        public string TipoDevice = ""; // P - Palmare / R - Ricevitore

        private ILabel _label;

        public UC_Programmazione_Progettazione()
        {
            InitializeComponent();
        }

        private void UC_Programmazione_Progettazione_Load(object sender, EventArgs e)
        {

            // Abilita zone dello schermo
            ds_Prototipi.dt_Tmp_Fw.Clear();
            ds_Prototipi.dt_Tmp_Programma.Clear();
            AbilitaSchermo();

            LeggiConfig();

            CaricaArchivi();
        }

        /// <summary>
        /// Routines generiche
        /// </summary>
        private void AbilitaSchermo()
        {
            cb_Correzione.SelectedItem = "0";

            TipoDevice = "";

            //Verifica pagina attiva
            menu_commesse_nas.Checked = false;
            menu_commesse_vis.Checked = true;
            grid_prototipi.Refresh();
        }

        private void CaricaArchivi()
        {
            ds_Prototipi.dt_Tmp_Programma.Clear();
            AbilitaSchermo();

            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            // TODO: questa riga di codice carica i dati nella tabella 'ds_Prototipi1.Fam_Prod'. È possibile spostarla o rimuoverla se necessario.
            this.fam_ProdTableAdapter.Fill(this.ds_Prototipi.Fam_Prod);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_Prototipi.FW_Clienti'. È possibile spostarla o rimuoverla se necessario.
            this.fW_ClientiTableAdapter.Fill(this.ds_Prototipi.FW_Clienti);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_Prototipi.Firmware'. È possibile spostarla o rimuoverla se necessario.
            this.firmwareTableAdapter.Fill(this.ds_Prototipi.Firmware);

            // TODO: questa riga di codice carica i dati nella tabella 'ds_Prototipi.SF_LastSerialNumber'. È possibile spostarla o rimuoverla se necessario.
            this.sF_LastSerialNumberTableAdapter.Fill(this.ds_Prototipi.SF_LastSerialNumber);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_Prototipi.SerialNumbers'. È possibile spostarla o rimuoverla se necessario.
            this.serialNumbersTableAdapter.Fill(this.ds_Prototipi.SerialNumbers);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_Prototipi.SF_Progettazione_SL'. È possibile spostarla o rimuoverla se necessario.
            this.sF_Progettazione_SLTableAdapter.Fill(this.ds_Prototipi.SF_Progettazione_SL);

            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.Firmware'. È possibile spostarla o rimuoverla se necessario.
            this.firmwareTableAdapter.Fill(this.ds_Prototipi.Firmware);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SerialNumbers'. È possibile spostarla o rimuoverla se necessario.
            this.serialNumbersTableAdapter.Fill(this.ds_Prototipi.SerialNumbers);


            //// TODO: questa riga di codice carica i dati nella tabella 'ds_Programmazione.SF_LastSerialNumber'. È possibile spostarla o rimuoverla se necessario.
            //this.sF_LastSerialNumberTableAdapter.Fill(this.ds_Prototipi.SF_LastSerialNumber);
            //// TODO: questa riga di codice carica i dati nella tabella 'ds_commander.dt_Firmware'. È possibile spostarla o rimuoverla se necessario.
            //this.firmwareTableAdapter.Fill(this.ds_Prototipi.Firmware);
            //// TODO: questa riga di codice carica i dati nella tabella 'ds_commander1.dt_FW_Clienti'. È possibile spostarla o rimuoverla se necessario.
            //this.fW_ClientiTableAdapter.Fill(this.ds_Prototipi.FW_Clienti);


            SplashDB.Close();
        }

        private void LeggiConfig()
        {
            // Lettura impostazioni
            glob_FW_folder = Properties.Settings.Default.FW_folder;
            glob_IP_printer = Properties.Settings.Default.IP_printer;
            glob_Commander_path = Properties.Settings.Default.Commander_path;
            glob_use_printer = Properties.Settings.Default.Use_printer;

            if (glob_use_printer) { tog_Use_printer.Checked = true; } else {tog_Use_printer.Checked = false; }
            tog_Use_Zebra.Checked = true;
            lab_printer.Text = "";
        }

        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void grid_prototipi_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == grid_prototipi.Columns["grid_prototipi_CommessaDefinizione"].Index)
            {
                //Memorizzo indice riga
                glob_selectedrecord = sFProgettazioneSLBindingSource.Position;

                //Controllo su tipo riga
                DataGridViewRow row = grid_prototipi.Rows[e.RowIndex];
                string Commessa = row.Cells["grid_prototipi_Commessa"].Value.ToString().Trim();
                string Kit = row.Cells["grid_prototipi_ArticoloProgettazione"].Value.ToString().Trim();
                string Item = row.Cells["grid_prototipi_Articolo"].Value.ToString().Trim();

                //Esci se non si programma    
                string tipodevice = Identifica_Tipo_Device(Item);
                if ((tipodevice != "P") && (tipodevice != "R")) return;

                string Fw = "";
                if (row.Cells["grid_prototipi_FW_loading"].Value != null)
                    row.Cells["grid_prototipi_FW_loading"].Value.ToString().Trim();

                if (row.Cells["grid_prototipi_ID"].Value != null)
                    glob_ID_device = row.Cells["grid_prototipi_ID"].Value.ToString().Trim();
                else
                    glob_ID_device = "";

                //Identifica tipo di device
                TipoDevice = Identifica_Tipo_Device(Item);

                if (TipoDevice == "P") // Palmare
                {
                    using (var form = new UC_Prototipo_ID_Palmare(Item))
                    {
                        if (form.ShowDialog() == DialogResult.OK)
                        {
                            glob_Form_ID = form.CodiceID;
                            row.Cells["grid_prototipi_FW_loading"].Value = form.CodiceFW;
                            row.Cells["grid_prototipi_ID"].Value = form.CodiceID;
                            grid_prototipi.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                        }
                        glob_Form_ID = form.CodiceID;
                    }
                }
                else
                {
                    using (var form = new UC_Prototipo_ID_Ricevitore(Item))
                    {
                        if (form.ShowDialog() == DialogResult.OK)
                        {
                            glob_Form_ID = form.CodiceID;
                            row.Cells["grid_prototipi_FW_loading"].Value = form.CodiceFW;
                            row.Cells["grid_prototipi_ID"].Value = form.CodiceID;
                            grid_prototipi.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                        }
                        glob_Form_ID = form.CodiceID;
                    }

                    grid_prototipi.Refresh();
                }
            }

            if (e.ColumnIndex == grid_prototipi.Columns["grid_prototipi_CommessaProgramma"].Index)
            {
                //Controllo su tipo riga
                DataGridViewRow row = grid_prototipi.Rows[e.RowIndex];
                if ((row.Cells["grid_prototipi_FW_loading"].Value == null) || (row.Cells["grid_prototipi_ID"].Value == null))
                {
                    MessageBox.Show("Impossibile proseguire! \nNon è stato definito il firmware oppure l'ID!");
                    return;
                }

                /////////////////////////////////////////
                // Puntatore su tabella FIRMWARE       //
                /////////////////////////////////////////
                DataView dv = new DataView(ds_Prototipi.Firmware);
                string filtro = "SW_Code = " + "'" + row.Cells["grid_prototipi_FW_loading"].Value.ToString() + "'" + " AND SW_Obsolete_ver = false";
                dv.RowFilter = filtro;
                foreach (DataRowView drv in dv)
                {
                    glob_FW_Key_ID = Convert.ToInt32(drv["Id"]);
                }


                /////////////////////////////////////////
                // Riempio le variabili che mi servono //
                /////////////////////////////////////////

                glob_Program_OK = true;
                glob_Commessa = row.Cells["grid_prototipi_Commessa"].Value.ToString().Trim();
                glob_Kit = row.Cells["grid_prototipi_ArticoloProgettazione"].Value.ToString().Trim();
                glob_Device = row.Cells["grid_prototipi_Articolo"].Value.ToString().Trim();
                glob_Codice_FW = row.Cells["grid_prototipi_FW_loading"].Value.ToString().Trim();
                glob_ID_Cli = Convert.ToInt32(row.Cells["grid_prototipi_CodAnagrafico"].Value);
                glob_ID_device = row.Cells["grid_prototipi_ID"].Value.ToString().Trim();
                glob_FW_Key_ID = glob_FW_Key_ID; //trovata nel passaggio precedente

                ds_Prototipi.dt_Tmp_Programma.Clear();
                ds_Prototipi.dt_TMP_Firmware.Clear();

                AggiungiRigaProg(glob_Commessa, glob_Kit, glob_Device, glob_Codice_FW, glob_FW_Key_ID, glob_ID_device);

                ProgrammaChip();
            }
        }

        /////////////////////////////////////////////////////////////////////////////////////////
        // Routine di programmazione
        /////////////////////////////////////////////////////////////////////////////////////////
        private void ProgrammaChip()
        {
            dos_box.Clear();
            ProgrammaSilicon(glob_Commessa, glob_Kit, glob_Device, glob_Codice_FW, glob_FW_Key_ID, glob_ID_device);

            bool endprint = true;
            do
            {
                string correzione = cb_Correzione.Text;
                UC_Reprint_Label uC_Reprint_Label = new UC_Reprint_Label(correzione);
                var result = uC_Reprint_Label.ShowDialog();

                cb_Correzione.SelectedItem = uC_Reprint_Label.Answer;

                if (result == DialogResult.Yes)
                {
                    PrintLabel(glob_ser_num_write);
                    endprint = false;
                }
                else
                {
                    endprint = true;
                }
            } while (!endprint);

            CaricaArchivi();
            RiposizionaGridCommesse();
        }

        private void RiposizionaGridCommesse()
        {
            if (glob_selectedrecord != 0)
            {
                sFProgettazioneSLBindingSource.Position = glob_selectedrecord;
            }
        }

        private bool ProgrammaSilicon(string Commessa, string Kit, string Item, string cod_fw, int fw_key_id, string ID_Hw)
        {
            string nome_fw_full = "";
            string nome_fw_boot = "";
            string nome_fw_conf = "";

            nome_fw_full = glob_FW_folder + @"\" + cod_fw + @"\" + "full_" + cod_fw + ".s37";
            nome_fw_boot = glob_FW_folder + @"\" + cod_fw + @"\" + "boot_" + cod_fw + ".s37";
            nome_fw_conf = glob_FW_folder + @"\" + cod_fw + @"\" + "conf_" + cod_fw + ".s37";

            //Creazione nuovo codice Flash
            glob_ser_num_write = "";
            int LastNumber = TrovaLastProgr(ID_Hw) + 1;
            string strLastNumber = LastNumber.ToString();
            strLastNumber = strLastNumber.PadLeft(8, '0');
            string anno = Convert.ToString(DateTime.Now.Year);
            glob_ser_num_write = ID_Hw + anno + strLastNumber;
            /////////////////////////////////////////////////

            glob_Program_OK = true;
            Program_Board(glob_Commessa, glob_Kit, glob_Device, glob_FW_Key_ID, nome_fw_full, nome_fw_boot, nome_fw_conf, glob_ser_num_write);           //nuovo sistema

            if (glob_Program_OK)
            {
                AggiornaSN(glob_Commessa, glob_Kit, glob_Device, glob_FW_Key_ID, nome_fw_full, ID_Hw, glob_ser_num_read, glob_ser_num_write, glob_ID_Cli);
                AggiornaFwCliente(glob_ID_Cli, glob_Codice_FW);
            }

            return true;
        }

        private int TrovaLastProgr(string ID_Hw)
        {
            int returnLastNumber = 0;
            string anno = Convert.ToString(DateTime.Now.Year);

            sFLastSerialNumberBindingSource.Filter = "Anno = " + "'" + anno + "'";
            if (sFLastSerialNumberBindingSource.Count != 0)
            {
                DataRowView current = (DataRowView)sFLastSerialNumberBindingSource.Current;
                returnLastNumber = Convert.ToInt32(current["LastSerialID"]);
            }
            return returnLastNumber;
        }

        public void Program_Board(string Commessa, string Kit, string Item, int fw_key_id, string nome_fw_full, string nome_fw_boot, string nome_fw_conf, string ID_device)
        {
            //glob_ID_code = ID_Hw;

            dos_box.Clear();

            System.Media.SoundPlayer newplayer = new System.Media.SoundPlayer();
            string newsound = ".\\Windows Notify.wav";
            newplayer.SoundLocation = newsound;
            newplayer.Load();
            newplayer.Play();

            ProcessStartInfo psi = new ProcessStartInfo(@"cmd");
            psi.UseShellExecute = false;
            psi.RedirectStandardOutput = true;
            psi.CreateNoWindow = true;
            psi.RedirectStandardInput = true;
            string text_dos = "";

            //Interrogazione interfaccia
            try
            {
                var proc = Process.Start(psi);

                // Setting "DEBUG MODE"
                proc.StandardInput.WriteLine(Properties.Settings.Default.Commander_path + @"\commander.exe adapter dbgmode OUT");

                // La riga sottostante è da verificare
                proc.StandardInput.WriteLine(Properties.Settings.Default.Commander_path + @"\commander.exe device info " + glob_device);
                proc.StandardInput.WriteLine(Properties.Settings.Default.Commander_path + @"\commander.exe --version");
                proc.StandardInput.WriteLine("exit");

                text_dos = proc.StandardOutput.ReadToEnd();
                dos_box.Text = text_dos + "\n======================================================================" + Environment.NewLine;
                dos_box.Refresh();

                if (text_dos.Contains("ERROR: Cannot connect to J-Link via USB.") ||
                    text_dos.Contains("ERROR: Could not open J-Link connection.") ||
                    text_dos.Contains("ERROR: Could not connect debugger."))
                {
                    MessageBox.Show("Interfaccia non collegata correttamente!");
                    dos_box.Clear();
                    dos_box.Refresh();
                    text_dos = "";
                    glob_Program_OK = false;
                    return;
                }

                dos_box.SelectionStart = dos_box.Text.Length;
                dos_box.ScrollToCaret();
            }
#pragma warning disable CS0168 // La variabile 'ex' è dichiarata, ma non viene mai usata
            catch (Exception ex)
#pragma warning restore CS0168 // La variabile 'ex' è dichiarata, ma non viene mai usata
            {

            }

            // Ricerca delle informazioni

            //Part Number
            if (text_dos.Contains("Part Number    :"))
            {

                for (int i = 0; i <= dos_box.Lines.Length; i++)
                {
                    if (dos_box.Lines[i].Contains("Part Number    :"))
                    {
                        string linea_PN = dos_box.Lines[i].ToString();
                        //lab_PartNumber.Text = linea_PN.Substring(17);
                        break;
                    }
                }
            }

            //Unique ID
            if (text_dos.Contains("Unique ID      :"))
            {

                for (int i = 0; i <= dos_box.Lines.Length; i++)
                {
                    if (dos_box.Lines[i].Contains("Unique ID      :"))
                    {
                        string linea_ID = dos_box.Lines[i].ToString();
                        glob_ser_num_read = linea_ID.Substring(17, 16);

                        //Doppia versione per nome bluetooth
                        if (glob_ser_num_write.Count() == 4)
                        {
                            glob_ser_num_write = ConvertiID(glob_ser_num_read);
                        }
                        else
                        {
                        }
                        break;
                    }
                }
            }

            //Serial Number
            if (text_dos.Contains("Emulator found with SN="))
            {

                for (int i = 0; i <= dos_box.Lines.Length; i++)
                {
                    if (dos_box.Lines[i].Contains("Emulator found with SN="))
                    {
                        string linea_SN = dos_box.Lines[i].ToString();
                        //lab_SN.Text = linea_SN.Substring(23, 9);
                        break;
                    }
                }
            }

            //Cancellazione (Versione con Tommaso)
            try
            {
                var proc = Process.Start(psi);

                string programstring = Properties.Settings.Default.Commander_path + @"\commander.exe device masserase " + glob_device;
                proc.StandardInput.WriteLine(programstring);
                proc.StandardInput.WriteLine("exit");

                text_dos = proc.StandardOutput.ReadToEnd();
                dos_box.Text = dos_box.Text + text_dos + "\n======================================================================" + Environment.NewLine;
                dos_box.Refresh();

                if (text_dos.Contains("ERROR: Cannot connect to J-Link via USB.") ||
                    text_dos.Contains("ERROR: Could not open J-Link connection.") ||
                    text_dos.Contains("ERROR: Could not connect debugger."))
                {
                    MessageBox.Show("Interfaccia non collegata correttamente!");
                    dos_box.Clear();
                    dos_box.Refresh();
                    text_dos = "";
                    glob_Program_OK = false;
                    return;
                }

                dos_box.SelectionStart = dos_box.Text.Length;
                dos_box.ScrollToCaret();
            }
#pragma warning disable CS0168 // La variabile 'ex' è dichiarata, ma non viene mai usata
            catch (Exception ex)
#pragma warning restore CS0168 // La variabile 'ex' è dichiarata, ma non viene mai usata
            {

            }

            //Inserimento firmware (boot_ Versione con Tommaso)
            try
            {
                var proc = Process.Start(psi);

                string programstring = Properties.Settings.Default.Commander_path + @"\commander.exe flash " + '"' + nome_fw_boot + '"' + " --address 0x0 " + glob_device;
                proc.StandardInput.WriteLine(programstring);
                proc.StandardInput.WriteLine("exit");

                text_dos = proc.StandardOutput.ReadToEnd();
                dos_box.Text = dos_box.Text + text_dos + "\n======================================================================" + Environment.NewLine;
                dos_box.Refresh();

                if (text_dos.Contains("ERROR: Cannot connect to J-Link via USB.") ||
                    text_dos.Contains("ERROR: Could not open J-Link connection.") ||
                    text_dos.Contains("ERROR: Unspecified error during flashing.") ||
                    text_dos.Contains("ERROR: Verificiation failed!") ||
                    text_dos.Contains("ERROR: Could not connect debugger."))
                {
                    MessageBox.Show("Interfaccia non collegata correttamente / Errore di programmazione");
                    dos_box.Clear();
                    dos_box.Refresh();
                    text_dos = "";
                    glob_Program_OK = false;
                    return;
                }

                dos_box.SelectionStart = dos_box.Text.Length;
                dos_box.ScrollToCaret();
            }
#pragma warning disable CS0168 // La variabile 'ex' è dichiarata, ma non viene mai usata
            catch (Exception ex)
#pragma warning restore CS0168 // La variabile 'ex' è dichiarata, ma non viene mai usata
            {

            }

            //Verifica (full_ Versione con Eugeniu)
            try
            {
                var proc = Process.Start(psi);

                //string verifyprogramstring = Properties.Settings.Default.Commander_path + @"\commander.exe verify " + glob_codice_fw_fulltmppath + " " + glob_device;
                string verifyprogramstring = Properties.Settings.Default.Commander_path + @"\commander.exe verify " + '"' + nome_fw_boot + '"' + " " + glob_device;
                proc.StandardInput.WriteLine(verifyprogramstring);
                proc.StandardInput.WriteLine("exit");

                text_dos = proc.StandardOutput.ReadToEnd();
                dos_box.Text = dos_box.Text + text_dos + "\n======================================================================" + Environment.NewLine;
                dos_box.Refresh();

                if (text_dos.Contains("ERROR: Cannot connect to J-Link via USB.") ||
                    text_dos.Contains("ERROR: Could not open J-Link connection.") ||
                    text_dos.Contains("ERROR: Unspecified error during flashing.") ||
                    text_dos.Contains("ERROR: Verificiation failed!") ||
                    text_dos.Contains("ERROR: Could not connect debugger."))
                {
                    MessageBox.Show("Interfaccia non collegata correttamente / Errore di programmazione");
                    dos_box.Clear();
                    dos_box.Refresh();
                    text_dos = "";
                    glob_Program_OK = false;
                    return;
                }

                if (text_dos.Contains("DONE"))
                {
                    System.Media.SoundPlayer player = new System.Media.SoundPlayer();
                    string sound = ".\\tada.wav";
                    player.SoundLocation = sound;
                    player.Load();
                    player.Play();
                }
                else
                {
                    System.Media.SoundPlayer player = new System.Media.SoundPlayer();
                    string sound = ".\\Yamaha.wav";
                    player.SoundLocation = sound;
                    player.Load();
                    player.Play();
                    glob_Program_OK = false;
                }

                dos_box.SelectionStart = dos_box.Text.Length;
                dos_box.ScrollToCaret();
            }
#pragma warning disable CS0168 // La variabile 'ex' è dichiarata, ma non viene mai usata
            catch (Exception ex)
#pragma warning restore CS0168 // La variabile 'ex' è dichiarata, ma non viene mai usata
            {

            }

            //Inserimento firmware (boot_ Versione con Tommaso)
            try
            {
                var proc = Process.Start(psi);

                string programstring = Properties.Settings.Default.Commander_path + @"\commander.exe flash " + '"' + nome_fw_conf + '"' + " --address 0x0 " + glob_device;
                proc.StandardInput.WriteLine(programstring);
                proc.StandardInput.WriteLine("exit");

                text_dos = proc.StandardOutput.ReadToEnd();
                dos_box.Text = dos_box.Text + text_dos + "\n======================================================================" + Environment.NewLine;
                dos_box.Refresh();

                if (text_dos.Contains("ERROR: Cannot connect to J-Link via USB.") ||
                    text_dos.Contains("ERROR: Could not open J-Link connection.") ||
                    text_dos.Contains("ERROR: Unspecified error during flashing.") ||
                    text_dos.Contains("ERROR: Verificiation failed!") ||
                    text_dos.Contains("ERROR: Could not connect debugger."))
                {
                    MessageBox.Show("Interfaccia non collegata correttamente / Errore di programmazione");
                    dos_box.Clear();
                    dos_box.Refresh();
                    text_dos = "";
                    glob_Program_OK = false;
                    return;
                }

                dos_box.SelectionStart = dos_box.Text.Length;
                dos_box.ScrollToCaret();
            }
#pragma warning disable CS0168 // La variabile 'ex' è dichiarata, ma non viene mai usata
            catch (Exception ex)
#pragma warning restore CS0168 // La variabile 'ex' è dichiarata, ma non viene mai usata
            {

            }

            //Verifica (full_ Versione con Eugeniu)
            try
            {
                var proc = Process.Start(psi);

                //string verifyprogramstring = Properties.Settings.Default.Commander_path + @"\commander.exe verify " + glob_codice_fw_fulltmppath + " " + glob_device;
                string verifyprogramstring = Properties.Settings.Default.Commander_path + @"\commander.exe verify " + '"' + nome_fw_conf + '"' + " " + glob_device;
                proc.StandardInput.WriteLine(verifyprogramstring);
                proc.StandardInput.WriteLine("exit");

                text_dos = proc.StandardOutput.ReadToEnd();
                dos_box.Text = dos_box.Text + text_dos + "\n======================================================================" + Environment.NewLine;
                dos_box.Refresh();

                if (text_dos.Contains("ERROR: Cannot connect to J-Link via USB.") ||
                    text_dos.Contains("ERROR: Could not open J-Link connection.") ||
                    text_dos.Contains("ERROR: Unspecified error during flashing.") ||
                    text_dos.Contains("ERROR: Verificiation failed!") ||
                    text_dos.Contains("ERROR: Could not connect debugger."))
                {
                    MessageBox.Show("Interfaccia non collegata correttamente / Errore di programmazione");
                    dos_box.Clear();
                    dos_box.Refresh();
                    text_dos = "";
                    glob_Program_OK = false;
                    return;
                }

                if (text_dos.Contains("DONE"))
                {
                    System.Media.SoundPlayer player = new System.Media.SoundPlayer();
                    string sound = ".\\tada.wav";
                    player.SoundLocation = sound;
                    player.Load();
                    player.Play();
                }
                else
                {
                    System.Media.SoundPlayer player = new System.Media.SoundPlayer();
                    string sound = ".\\Yamaha.wav";
                    player.SoundLocation = sound;
                    player.Load();
                    player.Play();
                    glob_Program_OK = false;
                }

                dos_box.SelectionStart = dos_box.Text.Length;
                dos_box.ScrollToCaret();
            }
#pragma warning disable CS0168 // La variabile 'ex' è dichiarata, ma non viene mai usata
            catch (Exception ex)
#pragma warning restore CS0168 // La variabile 'ex' è dichiarata, ma non viene mai usata
            {

            }

            //Scrittura ID - I parte
            try
            {
                string coppia_1 = "";
                string coppia_2 = "";

                coppia_1 = ID_device.Substring(0, 2);
                coppia_2 = ID_device.Substring(2, 2);

                var proc = Process.Start(psi);

                //string verifyprogramstring = Properties.Settings.Default.Path_URL_Commander + @"\commander.exe flash --patch 0x0fe00000:0x0068:2" + " " + device;
                string verifyprogramstring = Properties.Settings.Default.Commander_path + @"\commander.exe flash --patch 0x0fe00000:0x" + coppia_2 + coppia_1 + ":2" + " " + glob_device;

                proc.StandardInput.WriteLine(verifyprogramstring);
                proc.StandardInput.WriteLine("exit");

                text_dos = proc.StandardOutput.ReadToEnd();
                dos_box.Text = dos_box.Text + text_dos + "\n======================================================================" + Environment.NewLine;

                if (text_dos.Contains("ERROR: Cannot connect to J-Link via USB.") ||
                    text_dos.Contains("ERROR: Could not open J-Link connection.") ||
                    text_dos.Contains("ERROR: Unspecified error during flashing.") ||
                    text_dos.Contains("ERROR: Verificiation failed!") ||
                    text_dos.Contains("ERROR: Could not connect debugger."))
                {
                    MessageBox.Show("Interfaccia non collegata correttamente / Errore di programmazione");
                    dos_box.Clear();
                    dos_box.Refresh();
                    text_dos = "";
                    glob_Program_OK = false;
                    return;
                }

                if (text_dos.Contains("DONE"))
                {
                    System.Media.SoundPlayer player = new System.Media.SoundPlayer();
                    string sound = ".\\tada.wav";
                    player.SoundLocation = sound;
                    player.Load();
                    player.Play();
                }
                else
                {
                    System.Media.SoundPlayer player = new System.Media.SoundPlayer();
                    string sound = ".\\Yamaha.wav";
                    player.SoundLocation = sound;
                    player.Load();
                    player.Play();
                    glob_Program_OK = false;
                }

                dos_box.SelectionStart = dos_box.Text.Length;
                dos_box.ScrollToCaret();
            }
#pragma warning disable CS0168 // La variabile 'ex' è dichiarata, ma non viene mai usata
            catch (Exception ex)
#pragma warning restore CS0168 // La variabile 'ex' è dichiarata, ma non viene mai usata
            {

            }

            //Scrittura ID - II  parte
            if (ID_device.Length == 16)
            {
                try
                {
                    string coppia_1 = ID_device.Substring(0, 2);
                    string coppia_2 = ID_device.Substring(2, 2);
                    string coppia_3 = ID_device.Substring(4, 2);
                    string coppia_4 = ID_device.Substring(6, 2);
                    string coppia_5 = ID_device.Substring(8, 2);
                    string coppia_6 = ID_device.Substring(10, 2);
                    string coppia_7 = ID_device.Substring(12, 2);
                    string coppia_8 = ID_device.Substring(14, 2);

                    var proc = Process.Start(psi);

                    string verifyprogramstring = "";
                    if (ID_device.Length == 16)
                    {
                        verifyprogramstring = Properties.Settings.Default.Commander_path + @"\commander.exe flash --patch 0x0FE007F0:0x" + coppia_8 + coppia_7 + coppia_6 + coppia_5 + coppia_4 + coppia_3 + ":6" + " " + glob_device;
                    }
                    proc.StandardInput.WriteLine(verifyprogramstring);
                    proc.StandardInput.WriteLine("exit");

                    text_dos = proc.StandardOutput.ReadToEnd();
                    dos_box.Text = dos_box.Text + text_dos + "\n======================================================================" + Environment.NewLine;

                    if (text_dos.Contains("ERROR: Cannot connect to J-Link via USB.") ||
                        text_dos.Contains("ERROR: Could not open J-Link connection.") ||
                        text_dos.Contains("ERROR: Unspecified error during flashing.") ||
                        text_dos.Contains("ERROR: Verification failed!") ||
                        text_dos.Contains("ERROR: Could not connect debugger."))
                    {
                        MessageBox.Show("Interfaccia non collegata correttamente / Errore di programmazione");
                        dos_box.Clear();
                        dos_box.Refresh();
                        text_dos = "";
                        glob_Program_OK = false;
                        return;
                    }

                    if (text_dos.Contains("DONE"))
                    {
                        System.Media.SoundPlayer player = new System.Media.SoundPlayer();
                        string sound = ".\\tada.wav";
                        player.SoundLocation = sound;
                        player.Load();
                        player.Play();
                    }
                    else
                    {
                        System.Media.SoundPlayer player = new System.Media.SoundPlayer();
                        string sound = ".\\Yamaha.wav";
                        player.SoundLocation = sound;
                        player.Load();
                        player.Play();
                        glob_Program_OK = false;
                    }

                    dos_box.SelectionStart = dos_box.Text.Length;
                    dos_box.ScrollToCaret();
                }
#pragma warning disable CS0168 // La variabile 'ex' è dichiarata, ma non viene mai usata
                catch (Exception ex)
#pragma warning restore CS0168 // La variabile 'ex' è dichiarata, ma non viene mai usata
                {

                }

            }

            if (glob_Program_OK)
            {
                PrintLabel(ID_device);
            }
        }

        private void PrintLabel(string Item)
        {
            //Stampa Etichetta
            if (!Properties.Settings.Default.Use_printer)
            {
                return;
            }

            Print_LabelZebra(glob_ser_num_write);
        }

        private async void Print_LabelZebra(string ID_Hw)
        {
            Connection printerConnection = null;
            try
            {
                printerConnection = GetConnection();
                string ipport = Properties.Settings.Default.IP_printer;
                int port = 9100;

            }
            catch (ConnectionException)
            {
                lab_printer.Text = "Invalid Address and/or Port";
                lab_printer.Refresh();
                await Task.Delay(1000);
                lab_printer.Text = "Not Connected";
                lab_printer.Refresh();
                return;
            }

            await Task.Run(async () =>
            {
                try
                {
                    lab_printer.Text = "Connecting...";
                    lab_printer.Refresh();
                    await Task.Delay(1500);

                    printerConnection.Open();

                    lab_printer.Text = "Connected";
                    lab_printer.Refresh();
                    await Task.Delay(1500);

                    //lab_printer.Text = "Determining Printer Language...";
                    //lab_printer.Refresh();
                    //await Task.Delay(1500);

                    PrinterLanguage printerLanguage = ZebraPrinterFactory.GetInstance(printerConnection).PrinterControlLanguage;
                    //lab_printer.Text = "Printer Language " + printerLanguage.ToString();
                    //lab_printer.Refresh();
                    //await Task.Delay(1500);

                    lab_printer.Text = "Sending Data...";
                    lab_printer.Refresh();

                    //printerConnection.Write(GetConfigLabel(printerLanguage));
                    printerConnection.Write(WriteLabel(printerLanguage));
                }
                catch (ConnectionException)
                {
                    lab_printer.Text = "Communications Error";
                    lab_printer.Refresh();
                }
                catch (ZebraPrinterLanguageUnknownException)
                {
                    lab_printer.Text = "Invalid Printer Language";
                    lab_printer.Refresh();
                }
                finally
                {
                    try
                    {
                        await Task.Delay(1000);
                        lab_printer.Text = "Disconnecting...";
                        lab_printer.Refresh();
                        if (printerConnection != null)
                        {
                            printerConnection.Close();
                        }

                        await Task.Delay(1000);
                        lab_printer.Text = "Not Connected";
                        lab_printer.Refresh();
                    }
                    catch (ConnectionException)
                    {
                    }
                    finally
                    {
                    }
                }
            });

        }

        private byte[] WriteLabel(PrinterLanguage printerLanguage)
        {
            byte[] configLabel = null;
            if (printerLanguage == PrinterLanguage.ZPL)
            {
                //configLabel = Encoding.UTF8.GetBytes("^XA^FO17,16^GB379,371,8^FS^FT65,255^A0N,135,134^FDTEST^FS^XZ");
                //string ZPL = "^XA";                              //Start of label format
                //ZPL = ZPL + "^MMT";                              //Media Type = T -- thermal transfer
                //ZPL = ZPL + "^MNV";                              //media tracking = V -- continuous media, variable length
                ////ZPL = ZPL + "^MD";                             //media darkness -- da vedere
                ////ZPL = ZPL + "^CFE,25";                         //Change Font

                //ZPL = ZPL + "^FO00,00";                          //Set start position
                //ZPL = ZPL + "^LT-60";                            //Label top position

                //ZPL = ZPL + "^BXR,2,200";                        //Set Bar Code Datamatrix
                //ZPL = ZPL + "^FD" + "3929202100000097" + "^FS";  //Data Field

                //ZPL = ZPL + "^XZ";                               //End of label format

                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                int scostamento = 20;
                scostamento = scostamento + Convert.ToInt32(cb_Correzione.Text);

                string ZPL = "^XA";                              //Start of label format
                ZPL = ZPL + "~TA000";                            //Tear-off Adjust Position
                ZPL = ZPL + "^LT0";                              //Label Top
                ZPL = ZPL + "^MTT";                              //Media Type = T -- thermal transfer
                ZPL = ZPL + "^MMT";                              //
                ZPL = ZPL + "^MNV";                              //media tracking = V -- continuous media, variable length
                ZPL = ZPL + "^PR1";                              //Print Rate
                ZPL = ZPL + "^PW368";                            //Print Width
                ZPL = ZPL + "^LL0088";                           //Label Length
                ZPL = ZPL + "^LT" + scostamento.ToString();      //Set start position
                //ZPL = ZPL + "^FO60,0";                           //Set start position
                ZPL = ZPL + "^BXN,3,200";                        //Set Bar Code Datamatrix
                //ZPL = ZPL + "^FD" + "3929202100000097" + "^FS";  //Data Field
                ZPL = ZPL + "^BY28,28^FT65,0^BXN,2,200,0,0,1,~";
                //ZPL = ZPL + "^FH\\^FD3929202100000097^FS";
                ZPL = ZPL + "^FH\\^FD" + glob_ser_num_write + "^FS";
                ZPL = ZPL + "^BY28,28^FT190,0^BXN,2,200,0,0,1,~";
                //ZPL = ZPL + "^FH\\^FD1901202100000095^FS";
                ZPL = ZPL + "^FH\\^FD" + glob_ser_num_write + "^FS";

                ZPL = ZPL + "^XZ";                               //End of label format
                                                                 //ZPL = ZPL + "^POI";                            //Print Orientation
                                                                 //ZPL = ZPL + "^JMA";                            //Set Dots per Millimeter - A = 24 dots/mm, 12 dots/mm, 8 dots/mm or 6 dots/mm
                                                                 //ZPL = ZPL + "~SDA25";                          //Set Darkness
                                                                 //ZPL = ZPL + "^CI9";                            //Change International Font/Encoding
                                                                 //ZPL = ZPL + "^PQ4";                            //Print copies
                                                                 //ZPL = ZPL + "^MD";                             //media darkness -- da vedere
                                                                 //ZPL = ZPL + "^CFE,25";                         //Change Font
                                                                 //ZPL = ZPL + "^LT-30";                          //Label top position
                                                                 //ZPL = ZPL + "^LT10";                           //Label top position
                                                                 //ZPL = ZPL + "^FO00,00^ADN,36,20^FDRRRRRRRRRRRR^FS";

                // send command
                configLabel = Encoding.UTF8.GetBytes(ZPL);
            }
            else if (printerLanguage == PrinterLanguage.CPCL)
            {
                string cpclConfigLabel = "! 0 200 200 406 1\r\n" + "ON-FEED IGNORE\r\n" + "BOX 20 20 380 380 8\r\n" + "T 0 6 137 177 TEST\r\n" + "PRINT\r\n";
                configLabel = Encoding.UTF8.GetBytes(cpclConfigLabel);
            }
            return configLabel;
        }

        private bool AggiungiRigaProg(string Commessa, string Kit, string Item, string cod_fw, int fw_key_id, string ID_Hw)
        {
            DataRow dr = ds_Prototipi.dt_Tmp_Programma.NewRow();
            dr["tmp_prog_commessa"] = Commessa;
            dr["tmp_prog_codart_kit"] = Kit;
            dr["tmp_prog_codart_item"] = Item;
            dr["tmp_prog_codart_fw"] = cod_fw;
            dr["tmp_fw_key_id"] = fw_key_id;
            dr["tmp_ID_Hardware"] = ID_Hw;
            ds_Prototipi.dt_Tmp_Programma.Rows.Add(dr);

            return true;
        }

        public Connection GetConnection()
        {
            try
            {
                //int port = string.IsNullOrEmpty(viewModel.Port) ? 9100 : int.Parse(viewModel.Port);
                //return new TcpConnection(viewModel.IpAddress, port);

                string ipaddr = Properties.Settings.Default.IP_printer;
                int port = 9100;
                return new TcpConnection(ipaddr, port);
            }
            catch (Exception e)
            {
                throw new ConnectionException(e.Message, e);
            }
        }

        private string ConvertiID(string ID)
        {
            string id_write = "";
            id_write = glob_ID_code;
            id_write = id_write + ID.Substring(0, 6) + ID.Substring(10, 6);
            return id_write;
        }

        private void AggiornaSN(string Commessa, string Kit, string Item, int fw_key_id, string nome_fw_full, string ID_Hw, string serial_read, string serial_write, int ID_Cli)
        {
            // Recupero Codice Firmware
            DataRow getRev = ds_Prototipi.Firmware.Rows.Find(fw_key_id);
            string Fw_Rev = getRev["SW_Revisione"].ToString();

            // Verifica se nuovo SN o già esistente
            bool newrecord = false;
            string sel = "Ser_ReadSerial = " + "'" + serial_read + "'";
            DataRow[] result = ds_Prototipi.SerialNumbers.Select(sel);
            if (result.Count() > 0) { newrecord = false; } else { newrecord = true; }

            //Cancello il record prima di scrivere il nuovo
            if (!newrecord)
            {
                foreach (DataRow row in result)
                {
                    row.Delete();
                }
            }

            try
            {
                Validate();
                serialNumbersBindingSource.EndEdit();
                serialNumbersTableAdapter.Update(this.ds_Prototipi.SerialNumbers);
            }
#pragma warning disable CS0168 // La variabile 'ex' è dichiarata, ma non viene mai usata
            catch (System.Exception ex)
#pragma warning restore CS0168 // La variabile 'ex' è dichiarata, ma non viene mai usata
            {
                MessageBox.Show("Table 'SerialNumbers' - Update failed");
            }

            DataRow newrow = ds_Prototipi.SerialNumbers.NewRow();
            newrow["Ser_Device_ID_Code"] = ID_Hw;
            newrow["Ser_OfficialSerial"] = serial_write;
            newrow["Ser_ReadSerial"] = serial_read;
            newrow["Ser_SW_Code"] = glob_Codice_FW;
            newrow["Ser_Spedito"] = false;
            newrow["Ser_DateProduction"] = DateTime.Now;

            newrow["Ser_Commessa"] = Commessa;
            newrow["Ser_Kit"] = Kit;
            newrow["Ser_ID_Cli"] = ID_Cli;
            newrow["Ser_Device"] = Item;

            //riga modificata il 20/05/2021 per programmare i custom ma consentire di vedere anche gli altri firmware
            //newrow["Ser_SW_Std_Type"] = Fw_isStandard;
            newrow["Ser_SW_Std_Type"] = true;
            newrow["Ser_SW_Code_Rev"] = Fw_Rev;

            ds_Prototipi.SerialNumbers.Rows.Add(newrow);

            serialNumbersTableAdapter.Update(newrow);
        }

        private void AggiornaFwCliente(int CodAnaCli, string Fw)
        {
            // Verifica se nuovo SN o già esistente
            bool newrecord = false;
            string sel = "Cod_Nominativo = " + CodAnaCli + " AND SW_Code = '" + Fw + "'";
            DataRow[] result = ds_Prototipi.FW_Clienti.Select(sel);
            if (result.Length > 0)
            { newrecord = false; }
            else
            { newrecord = true; }

            if (newrecord)
            {
                string des_ita = "";
                string des_en = "";
                DataView dv_fw = new DataView(ds_Prototipi.Firmware);
                dv_fw.RowFilter = "SW_Code = " + "'" + Fw + "'";
                if (dv_fw != null)
                {
                    des_ita = dv_fw[0]["SW_Descrizione"].ToString();
                    des_en = dv_fw[0]["SW_Descrizione_EN"].ToString();
                }

                DataRow newrow = ds_Prototipi.FW_Clienti.NewRow();
                newrow["Cod_Nominativo"] = CodAnaCli;
                newrow["SW_Code"] = Fw;
                newrow["SW_Des1"] = des_ita;
                newrow["SW_Des2"] = des_en;

                ds_Prototipi.FW_Clienti.Rows.Add(newrow);

                fW_ClientiTableAdapter.Update(newrow);
            }
        }

        private void aggiornaArchiviToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            CaricaArchivi();

            Cursor.Current = Cursors.Default;
        }

        private void grid_prototipi_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex >= 0)
            { 
                if ((e.ColumnIndex == grid_prototipi.Columns["grid_prototipi_CommessaDefinizione"].Index) /*&& String.IsNullOrEmpty((string)e.FormattedValue)*/)
                {
                    string item = grid_prototipi.Rows[e.RowIndex].Cells["grid_prototipi_Articolo"].FormattedValue.ToString();
                    string tipo_item = Identifica_Tipo_Device(item);
                    if ((tipo_item!= "P") && (tipo_item != "R"))
                    {
                        Rectangle newRect = new Rectangle(e.CellBounds.X + 1, e.CellBounds.Y + 1, e.CellBounds.Width - 4, e.CellBounds.Height - 4);
                        using (Brush gridBrush = new SolidBrush(this.grid_prototipi.GridColor), backColorBrush = new SolidBrush(e.CellStyle.BackColor))
                        {
                            using (Pen gridLinePen = new Pen(gridBrush))
                            {
                                // Erase the cell.
                                e.Graphics.FillRectangle(backColorBrush, e.CellBounds);
                                // Draw the grid lines (only the right and bottom lines;
                                // DataGridView takes care of the others).
                                e.Graphics.DrawLine(gridLinePen, e.CellBounds.Left,
                                e.CellBounds.Bottom - 1, e.CellBounds.Right - 1,
                                e.CellBounds.Bottom - 1);
                                e.Graphics.DrawLine(gridLinePen, e.CellBounds.Right - 1,
                                e.CellBounds.Top, e.CellBounds.Right - 1,
                                e.CellBounds.Bottom);
                                e.Handled = true;
                            }
                        }
                    }
                }
                if ((e.ColumnIndex == grid_prototipi.Columns["grid_prototipi_CommessaProgramma"].Index) /*&& String.IsNullOrEmpty((string)e.FormattedValue)*/)
                {
                    string item = grid_prototipi.Rows[e.RowIndex].Cells["grid_prototipi_Articolo"].FormattedValue.ToString();
                    string tipo_item = Identifica_Tipo_Device(item);
                    if ((tipo_item != "P") && (tipo_item != "R"))
                    {

                        Rectangle newRect = new Rectangle(e.CellBounds.X + 1, e.CellBounds.Y + 1, e.CellBounds.Width - 4, e.CellBounds.Height - 4);
                        using (Brush gridBrush = new SolidBrush(this.grid_prototipi.GridColor), backColorBrush = new SolidBrush(e.CellStyle.BackColor))
                        {
                            using (Pen gridLinePen = new Pen(gridBrush))
                            {
                                // Erase the cell.
                                e.Graphics.FillRectangle(backColorBrush, e.CellBounds);
                                // Draw the grid lines (only the right and bottom lines;
                                // DataGridView takes care of the others).
                                e.Graphics.DrawLine(gridLinePen, e.CellBounds.Left,
                                e.CellBounds.Bottom - 1, e.CellBounds.Right - 1,
                                e.CellBounds.Bottom - 1);
                                e.Graphics.DrawLine(gridLinePen, e.CellBounds.Right - 1,
                                e.CellBounds.Top, e.CellBounds.Right - 1,
                                e.CellBounds.Bottom);
                                e.Handled = true;
                            }
                        }
                    }
                }
            }
        }

        private string Identifica_Tipo_Device(string local_device)
        {
            TipoDevice = "";

            famProdBindingSource.MoveFirst();
            foreach (DataRowView famprodRow in famProdBindingSource)
            {
                // Verifica che ci sia un alias presente
                if (famprodRow["Fam_Alias_Progettazione"].ToString() == "")
                    continue;

                int len_alias = famprodRow["Fam_Alias_Progettazione"].ToString().Length;
                int len_dev = famprodRow["Fam_Prefix"].ToString().Length;

                if ((local_device.Substring(0, len_alias) == famprodRow["Fam_Alias_Progettazione"].ToString()) || (local_device.Substring(0, len_dev) == famprodRow["Fam_Prefix"].ToString()))
                {
                    TipoDevice = famprodRow["Fam_Tipo"].ToString();
                    break;
                }
            }

            return TipoDevice;
        }
    }
}
