﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using System.IO;
using Syncfusion.Windows.Forms;

namespace SmartLineProduction
{
    public partial class UC_SchedeProdotti : MetroFramework.Forms.MetroForm
    {
        public UC_SchedeProdotti()
        {
            InitializeComponent();
        }

        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UC_SchedeProdotti_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_ItemDevice_FW_Des'. È possibile spostarla o rimuoverla se necessario.
            this.sF_ItemDevice_FW_DesTableAdapter.Fill(this.ds_SL.SF_ItemDevice_FW_Des);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_ArticoliSchede'. È possibile spostarla o rimuoverla se necessario.
            this.sF_ArticoliSchedeTableAdapter.Fill(this.ds_SL.SF_ArticoliSchede);

            SetView();
        }

        private void tab_Kit_Enter(object sender, EventArgs e)
        {
            this.sF_ArticoliSchedeTableAdapter.FillBy_Kit(this.ds_SL.SF_ArticoliSchede);
            gv_Kit.Refresh();
        }

        private void sFArticoliSchedeBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (Kit_pdf_it.LoadedDocument != null) { Kit_pdf_it.Unload(); }
            if (Kit_pdf_en.LoadedDocument != null) { Kit_pdf_en.Unload(); }

            DataRowView drview = (DataRowView)sFArticoliSchedeBindingSource.Current;
            if (drview == null) { return; }

            string articolo = drview["Articolo"].ToString();

            if (articolo.Substring(0, 4) != "XKIT") { return; }

            string path = Properties.Settings.Default.Doc_folder;
            path = path + @"XKIT\";
            string path_it = path + drview["Articolo"].ToString() + @"\IT\" + drview["Articolo"].ToString() + ".pdf";
            string path_en = path + drview["Articolo"].ToString() + @"\EN\" + drview["Articolo"].ToString() + ".pdf";

            if (System.IO.File.Exists(path_it)) { Kit_pdf_it.Load(path_it); } else { Kit_pdf_it.Load("Pdf_notpresent.pdf"); }
            if (System.IO.File.Exists(path_en)) { Kit_pdf_en.Load(path_en); } else { Kit_pdf_en.Load("Pdf_notpresent.pdf"); }
        }

        private void SetView()
        {
            tb_grid_kit.Text = "";
            tb_grid_palmari.Text = "";
            tb_grid_ricevitori.Text = "";
        }

        private void tb_grid_kit_TextChanged(object sender, EventArgs e)
        {
            string filtro = string.Format("Articolo LIKE '%{0}%'", tb_grid_kit.Text);
            sFArticoliSchedeBindingSource.Filter = filtro;
            tb_grid_kit.Focus();
        }

        private void sFItemDeviceFWDesBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (Tab_Schede.SelectedTab == Tab_Schede.TabPages["tab_Palmari"])
            {
                if (Palmari_pdf_it.DocumentInformation.FileName != "") { Palmari_pdf_it.Unload(); }
                if (Palmari_pdf_en.DocumentInformation.FileName != "") { Palmari_pdf_en.Unload(); }

                DataRowView drview = (DataRowView)sFItemDeviceFWDesBindingSource.Current;
                if (drview == null) { return; }

                string articolo = drview["Articolo_Device"].ToString();
                string famdevice = drview["FamDevice"].ToString();
                string tipodevice = drview["TipoDevice"].ToString();

                string path = Properties.Settings.Default.Doc_folder;
                path = path + famdevice + @"\";
                string path_it = path + drview["Articolo_Device"].ToString() + @"\IT\" + drview["Articolo_Device"].ToString() + ".pdf";
                string path_en = path + drview["Articolo_Device"].ToString() + @"\EN\" + drview["Articolo_Device"].ToString() + ".pdf";

                if (System.IO.File.Exists(path_it)) { Palmari_pdf_it.Load(path_it); } else { Palmari_pdf_it.Load("Pdf_notpresent.pdf"); }
                if (System.IO.File.Exists(path_en)) { Palmari_pdf_en.Load(path_en); } else { Palmari_pdf_en.Load("Pdf_notpresent.pdf"); }
            }

            if (Tab_Schede.SelectedTab == Tab_Schede.TabPages["tab_Ricevitori"])
            {
                //if (Ricevitori_pdf_it.DocumentInformation.FileName != "") { Ricevitori_pdf_it.Unload(); }
                //if (Ricevitori_pdf_en.DocumentInformation.FileName != "") { Ricevitori_pdf_en.Unload(); }
                Ricevitori_pdf_it.Unload();
                Ricevitori_pdf_en.Unload(); 


                DataRowView drview = (DataRowView)sFItemDeviceFWDesBindingSource.Current;
                if (drview == null) { return; }

                string articolo = drview["Articolo_Device"].ToString();
                string famdevice = drview["FamDevice"].ToString();
                string tipodevice = drview["TipoDevice"].ToString();
                string numfunzioni = drview["NumFunzioni"].ToString();

                string path = Properties.Settings.Default.Doc_folder;
                path = path + famdevice + numfunzioni + @"\";
                string path_it = path + drview["Articolo_Device"].ToString() + @"\IT\" + drview["Articolo_Device"].ToString() + ".pdf";
                string path_en = path + drview["Articolo_Device"].ToString() + @"\EN\" + drview["Articolo_Device"].ToString() + ".pdf";

                if (System.IO.File.Exists(path_it)) { Ricevitori_pdf_it.Load(path_it); } else { Ricevitori_pdf_it.Load("Pdf_notpresent.pdf"); }
                if (System.IO.File.Exists(path_en)) { Ricevitori_pdf_en.Load(path_en); } else { Ricevitori_pdf_en.Load("Pdf_notpresent.pdf"); }
            }

        }

        private void tab_Palmari_Enter(object sender, EventArgs e)
        {
            this.sF_ItemDevice_FW_DesTableAdapter.FillBy_SchedeProdottoPalmari(this.ds_SL.SF_ItemDevice_FW_Des);
            gv_Palmari.Refresh();

        }

        private void tb_grid_palmari_TextChanged(object sender, EventArgs e)
        {
            string filtro = string.Format("Articolo_Device LIKE '%{0}%'", tb_grid_palmari.Text);
            sFItemDeviceFWDesBindingSource.Filter = filtro;
            tb_grid_palmari.Focus();
        }

        private void tab_Ricevitori_Enter(object sender, EventArgs e)
        {
            this.sF_ItemDevice_FW_DesTableAdapter.FillBy_SchedeProdottoRicevitori(this.ds_SL.SF_ItemDevice_FW_Des);
            gv_Ricevitori.Refresh();
        }

        private void tb_grid_ricevitori_TextChanged(object sender, EventArgs e)
        {
            string filtro = string.Format("Articolo_Device LIKE '%{0}%'", tb_grid_ricevitori.Text);
            sFItemDeviceFWDesBindingSource.Filter = filtro;
        }
    }
}
