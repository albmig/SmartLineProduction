﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using SmartLineProduction.Properties;
using System.Data.SqlTypes;
using MetroFramework;
using System.Diagnostics.Contracts;

namespace SmartLineProduction
{
    public partial class UC_FW_R : MetroFramework.Forms.MetroForm
    {
        private string displayform = "V"; // V-View/INV-InsertNewVersion/INR-InsertNewRelease
        public UC_FW_R()
        {
            InitializeComponent();
        }

        private void uscitaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UC_FW_R_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.Fam_Prod'. È possibile spostarla o rimuoverla se necessario.
            this.fam_ProdTableAdapter.Fill(this.ds_SL.Fam_Prod);

            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.Firmware'. È possibile spostarla o rimuoverla se necessario.
            this.firmwareTableAdapter.Fill(this.ds_SL.Firmware);

            GVar.formclosing = false;

            string filtroincorso = "SW_TipoDevice = 'R' and not SW_Obsolete_ver";
            DataView dv_R_incorso = new DataView(ds_SL.Firmware);
            dv_R_incorso.RowFilter = filtroincorso;
            gv_FW_R.DataSource = dv_R_incorso;
            dv_R_incorso.Sort = "SW_Code Asc";

            string filtrofam = "Fam_ID_Identifier <> '' and Fam_Tipo = 'R' and Fam_IsDevice = 1";
            ds_SL.Fam_Prod.DefaultView.RowFilter = filtrofam;
            ds_SL.Fam_Prod.DefaultView.Sort = "Fam_Label Asc";
            gv_Famiglia.DataSource = ds_SL.Fam_Prod.DefaultView;
            gv_Famiglia.Refresh();

            displayform = "V";

            AbilitaForm();
        }

        private void gv_FW_R_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (GVar.formclosing) { return; }

            foreach (DataGridViewRow x in gv_FW_R.Rows)
            {
                x.MinimumHeight = 40;
            }
        }

        private void UC_FW_R_FormClosing(object sender, FormClosingEventArgs e)
        {
            GVar.formclosing = true;
        }

        private void AbilitaForm()
        {
            if (displayform == "V")
            {
                panel_dati.Enabled = false;
                panel_revisioni.Enabled = false;
                panel_funzionamento.Enabled = false;
                panel_FW_R.Enabled = true;
                pan_Menu_comandi.Enabled = true;
                pan_Menu_exit.Enabled = true;
                pan_Menu_salva.Enabled = false;
            }

            if (displayform == "INR")
            {
                panel_dati.Enabled = true;
                panel_revisioni.Enabled = true;
                panel_funzionamento.Enabled = true;
                tb_gv_Code.Enabled = false;
                tb_gv_Versione.Enabled = false;
                int rev = Convert.ToInt32(tb_gv_Revisione.Text);
                int newrev=rev+1;
                tb_gv_Revisione.Text = newrev.ToString();
                cbox_SoftwareStandard.Enabled = false;
                tb_gv_Des1.Enabled = false;
                tb_gv_Des2.Enabled = false;
                panel_freq.Enabled = false;
                tog_Exp.Enabled = false;
                tog_Ple.Enabled = false;
                tog_TstEm.Enabled = false;
                tog_optCan.Enabled = false;
                tog_Prop.Enabled = false;
                tb_gv_TimeOut.Enabled = false;
                tb_gv_ContKeys.Enabled = false;
                tog_SameRow.Enabled = false;
                tog_SP.Enabled = false;
                tb_gv_MaxPair.Enabled = false;
                tog_ShiftPage.Enabled = false;
                tb_gv_OutputN.Enabled = false;
                tb_gv_DigInputN.Enabled = false;
                tb_gv_AnaInputN.Enabled = false;

                string line1 = DateTime.Now.ToString("dd/mm/yyyy HH:mm:ss") + " - Nuova revisione, la precedente era " + rev.ToString() + "\r\n";
                string result = new String('-', 100);
                string line2 = result + "\r\n";

                rtb_Revisioni.Text = line1 + line2 + rtb_Revisioni.Text;

                pan_Menu_comandi.Enabled = false;
                pan_Menu_exit.Enabled = false;
                pan_Menu_salva.Enabled = true;

                panel_FW_R.Enabled = false;
                tb_gv_Revisione.Focus();
            }

            gv_history.DataSource = null;
            gv_history.Refresh();
        }

        private void gv_history_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (GVar.formclosing) { return; }

            foreach (DataGridViewRow x in gv_history.Rows)
            {
                x.MinimumHeight = 40;
            }
        }

        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void creaRevisioneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            displayform = "INR";
            AbilitaForm();
        }

        private void menu_sw_annulla_Click(object sender, EventArgs e)
        {
            displayform = "V";
            AbilitaForm();

            DataGridViewSelectedRowCollection rows = gv_FW_R.SelectedRows;
            CaricaRiga(rows);
        }

        private void CaricaRiga(DataGridViewSelectedRowCollection rows)
        {
            foreach (DataGridViewRow row in rows)
            {
                DataRow myRow = (row.DataBoundItem as DataRowView).Row;

                tb_gv_Code.Text = myRow["SW_Code"].ToString();
                tb_gv_Versione.Text = myRow["SW_Versione"].ToString();
                tb_gv_Revisione.Text = myRow["SW_Revisione"].ToString();

                tb_gv_Des1.Text = myRow["SW_Descrizione"].ToString();
                tb_gv_Des2.Text = myRow["SW_Descrizione_EN"].ToString();
                bool standard = (bool)myRow["SW_Standard"];
                if (standard) { cbox_SoftwareStandard.Checked = true; } else { cbox_SoftwareStandard.Checked = false; }

                cb_868.Checked = false;
                cb_433.Checked = false;
                cb_915.Checked = false;
                cb_filo.Checked = false;
                cb_24.Checked = false;

                switch (myRow["SW_R_Opt_RF"].ToString())
                {
                    case "868": cb_868.Checked = true; break;
                    case "915": cb_915.Checked = true; break;
                    case "433": cb_433.Checked = true; break;
                    case "2.4": cb_24.Checked = true; break;
                    case "filo": cb_filo.Checked = true; break;
                    default: break;
                }
                tog_Exp.Checked = (bool)myRow["SW_R_Opt_Plug_Exp"];
                tog_Ple.Checked = (bool)myRow["SW_R_Opt_Plug_Ple"];
                tog_TstEm.Checked = (bool)myRow["SW_R_Opt_Em_Keyb"];
                tog_optCan.Checked = (bool)myRow["SW_R_Opt_Can"];
                tog_Prop.Checked = (bool)myRow["SW_R_Opt_Prop_Out"];
                tb_gv_TimeOut.Text = (string)myRow["SW_R_Opt_TimeOut"];
                tb_gv_ContKeys.Text = myRow["SW_R_Opt_Cont_Keys"].ToString();
                tog_SameRow.Checked = (bool)myRow["SW_R_Opt_LockSameRow"];
                tog_SP.Checked = (bool)myRow["SW_R_Opt_Use_SP"];
                tb_gv_MaxPair.Text = myRow["SW_R_Opt_MaxPairDevices"].ToString();
                tog_ShiftPage.Checked = (bool)myRow["SW_R_Opt_ShiftPage"];
                tb_gv_OutputN.Text = myRow["SW_R_Opt_Output_No"].ToString();
                tb_gv_DigInputN.Text = myRow["SW_R_Opt_Dig_Input_No"].ToString();
                tb_gv_AnaInputN.Text = myRow["SW_R_Opt_Ana_Input_No"].ToString();
                rtb_Revisioni.Text = myRow["SW_Revisioni"].ToString();
                rtb_Funzionamento.Text = myRow["SW_Funzionamento"].ToString();

                //Crea grid History
                string filtrohistory = "SW_TipoDevice = 'R' and SW_Obsolete_ver and SW_Code = '" + myRow["SW_Code"].ToString() + "'";
                DataView dv_R_history = new DataView(ds_SL.Firmware);
                dv_R_history.RowFilter = filtrohistory;
                gv_history.DataSource = dv_R_history;
                dv_R_history.Sort = "SW_Obsolete_ver_from_date Asc";
                gv_history.Refresh();
                ///////////////////////////////////

                //Crea Grid Famiglia
                string famiglie = myRow["SW_FamProd"].ToString();
                foreach (DataGridViewRow famrow in gv_Famiglia.Rows)
                {
                    string cella = famrow.Cells["gv_Famiglia_Ident"].Value.ToString();
                    if ((cella == "") || (cella == null))
                    {
                        famrow.Cells["gv_Famiglia_Check"].Value = false;
                    }
                    else
                    {
                        char identificatore = Convert.ToChar(famrow.Cells["gv_Famiglia_Ident"].Value);
                        if (famiglie.IndexOf(identificatore) == -1) { famrow.Cells["gv_Famiglia_Check"].Value = false; } else { famrow.Cells["gv_Famiglia_Check"].Value = true; }
                    }
                }

                gv_Famiglia.ClearSelection();
                gv_history.ClearSelection();
            }
        }

        private void gv_FW_R_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewSelectedRowCollection rows = gv_FW_R.SelectedRows;

            CaricaRiga(rows);
        }

        private void menu_sw_salva_Click(object sender, EventArgs e)
        {
            Riga2DB();
        }

        private void Riga2DB()
        {

        }
    }
}
