﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using System.IO;

namespace SmartLineProduction
{
    public partial class UC_SchedeProdotti : MetroFramework.Forms.MetroForm
    {
        public UC_SchedeProdotti()
        {
            InitializeComponent();
        }

        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UC_SchedeProdotti_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_ArticoliSchede'. È possibile spostarla o rimuoverla se necessario.
            this.sF_ArticoliSchedeTableAdapter.Fill(this.ds_SL.SF_ArticoliSchede);
        }

        private void tab_Kit_Enter(object sender, EventArgs e)
        {
            this.sF_ArticoliSchedeTableAdapter.FillBy_Kit(this.ds_SL.SF_ArticoliSchede);
            gv_Kit.Refresh();
        }

        private void sFArticoliSchedeBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            DataRowView drview = (DataRowView)sFArticoliSchedeBindingSource.Current;
            if (drview == null) { return; }

            string articolo = drview["Articolo"].ToString();

            if (articolo.Substring(0, 4) != "XKIT") { return; }

            string path = Properties.Settings.Default.Doc_folder;
            path = path + @"XKIT\";
            string path_it = path + drview["Articolo"].ToString() + @"\IT\" + drview["Articolo"].ToString() + ".pdf";
            string path_en = path + drview["Articolo"].ToString() + @"\EN\" + drview["Articolo"].ToString() + ".pdf";
        }
    }
}
