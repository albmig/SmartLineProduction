﻿namespace SmartLineProduction
{
    partial class UC_Spedizione
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lab_Etichetta = new MetroFramework.Controls.MetroLabel();
            this.tbx_ReadLabel_Device = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.lab_read_FW = new MetroFramework.Controls.MetroLabel();
            this.lab_read_Device = new MetroFramework.Controls.MetroLabel();
            this.lab_read_SN = new MetroFramework.Controls.MetroLabel();
            this.tbx_ReadLabel_Chip = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.Device_Image = new System.Windows.Forms.PictureBox();
            this.labchip_ID = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.labchip_Kit = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.labchip_Cliente = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.serialNumbersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.serialNumbersTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SerialNumbersTableAdapter();
            this.sFAnagraficaClientiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_AnagraficaClientiTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_AnagraficaClientiTableAdapter();
            this.but_Associa = new MetroFramework.Controls.MetroButton();
            this.but_Annulla = new MetroFramework.Controls.MetroButton();
            this.MainMenu = new System.Windows.Forms.MenuStrip();
            this.uscitaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.Device_Image)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.serialNumbersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFAnagraficaClientiBindingSource)).BeginInit();
            this.MainMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // lab_Etichetta
            // 
            this.lab_Etichetta.AutoSize = true;
            this.lab_Etichetta.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_Etichetta.Location = new System.Drawing.Point(333, 56);
            this.lab_Etichetta.Name = "lab_Etichetta";
            this.lab_Etichetta.Size = new System.Drawing.Size(257, 19);
            this.lab_Etichetta.TabIndex = 0;
            this.lab_Etichetta.Text = "Lettura dell\'etichetta presente sul device:";
            // 
            // tbx_ReadLabel_Device
            // 
            // 
            // 
            // 
            this.tbx_ReadLabel_Device.CustomButton.Image = null;
            this.tbx_ReadLabel_Device.CustomButton.Location = new System.Drawing.Point(254, 1);
            this.tbx_ReadLabel_Device.CustomButton.Name = "";
            this.tbx_ReadLabel_Device.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tbx_ReadLabel_Device.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbx_ReadLabel_Device.CustomButton.TabIndex = 1;
            this.tbx_ReadLabel_Device.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbx_ReadLabel_Device.CustomButton.UseSelectable = true;
            this.tbx_ReadLabel_Device.CustomButton.Visible = false;
            this.tbx_ReadLabel_Device.Lines = new string[0];
            this.tbx_ReadLabel_Device.Location = new System.Drawing.Point(333, 108);
            this.tbx_ReadLabel_Device.MaxLength = 32767;
            this.tbx_ReadLabel_Device.Multiline = true;
            this.tbx_ReadLabel_Device.Name = "tbx_ReadLabel_Device";
            this.tbx_ReadLabel_Device.PasswordChar = '\0';
            this.tbx_ReadLabel_Device.PromptText = "Lettura del QR-Code";
            this.tbx_ReadLabel_Device.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbx_ReadLabel_Device.SelectedText = "";
            this.tbx_ReadLabel_Device.SelectionLength = 0;
            this.tbx_ReadLabel_Device.SelectionStart = 0;
            this.tbx_ReadLabel_Device.ShortcutsEnabled = true;
            this.tbx_ReadLabel_Device.Size = new System.Drawing.Size(276, 23);
            this.tbx_ReadLabel_Device.TabIndex = 2;
            this.tbx_ReadLabel_Device.UseSelectable = true;
            this.tbx_ReadLabel_Device.WaterMark = "Lettura del QR-Code";
            this.tbx_ReadLabel_Device.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tbx_ReadLabel_Device.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tbx_ReadLabel_Device.Enter += new System.EventHandler(this.tbx_ReadLabel_Device_Enter);
            this.tbx_ReadLabel_Device.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbx_ReadLabel_Device_KeyPress);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(624, 79);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(107, 19);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "Numero di serie:";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(624, 109);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(50, 19);
            this.metroLabel2.TabIndex = 3;
            this.metroLabel2.Text = "Device:";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(624, 139);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(122, 19);
            this.metroLabel3.TabIndex = 4;
            this.metroLabel3.Text = "Firmware installato:";
            // 
            // lab_read_FW
            // 
            this.lab_read_FW.AutoSize = true;
            this.lab_read_FW.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_read_FW.Location = new System.Drawing.Point(748, 139);
            this.lab_read_FW.Name = "lab_read_FW";
            this.lab_read_FW.Size = new System.Drawing.Size(86, 19);
            this.lab_read_FW.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_read_FW.TabIndex = 7;
            this.lab_read_FW.Text = "lab_read_FW";
            this.lab_read_FW.UseStyleColors = true;
            // 
            // lab_read_Device
            // 
            this.lab_read_Device.AutoSize = true;
            this.lab_read_Device.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_read_Device.Location = new System.Drawing.Point(748, 109);
            this.lab_read_Device.Name = "lab_read_Device";
            this.lab_read_Device.Size = new System.Drawing.Size(106, 19);
            this.lab_read_Device.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_read_Device.TabIndex = 6;
            this.lab_read_Device.Text = "lab_read_Device";
            this.lab_read_Device.UseStyleColors = true;
            // 
            // lab_read_SN
            // 
            this.lab_read_SN.AutoSize = true;
            this.lab_read_SN.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_read_SN.Location = new System.Drawing.Point(748, 79);
            this.lab_read_SN.Name = "lab_read_SN";
            this.lab_read_SN.Size = new System.Drawing.Size(83, 19);
            this.lab_read_SN.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_read_SN.TabIndex = 5;
            this.lab_read_SN.Text = "lab_read_SN";
            this.lab_read_SN.UseStyleColors = true;
            // 
            // tbx_ReadLabel_Chip
            // 
            // 
            // 
            // 
            this.tbx_ReadLabel_Chip.CustomButton.Image = null;
            this.tbx_ReadLabel_Chip.CustomButton.Location = new System.Drawing.Point(254, 1);
            this.tbx_ReadLabel_Chip.CustomButton.Name = "";
            this.tbx_ReadLabel_Chip.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tbx_ReadLabel_Chip.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbx_ReadLabel_Chip.CustomButton.TabIndex = 1;
            this.tbx_ReadLabel_Chip.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbx_ReadLabel_Chip.CustomButton.UseSelectable = true;
            this.tbx_ReadLabel_Chip.CustomButton.Visible = false;
            this.tbx_ReadLabel_Chip.Lines = new string[0];
            this.tbx_ReadLabel_Chip.Location = new System.Drawing.Point(23, 108);
            this.tbx_ReadLabel_Chip.MaxLength = 32767;
            this.tbx_ReadLabel_Chip.Multiline = true;
            this.tbx_ReadLabel_Chip.Name = "tbx_ReadLabel_Chip";
            this.tbx_ReadLabel_Chip.PasswordChar = '\0';
            this.tbx_ReadLabel_Chip.PromptText = "Lettura del QR-Code";
            this.tbx_ReadLabel_Chip.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbx_ReadLabel_Chip.SelectedText = "";
            this.tbx_ReadLabel_Chip.SelectionLength = 0;
            this.tbx_ReadLabel_Chip.SelectionStart = 0;
            this.tbx_ReadLabel_Chip.ShortcutsEnabled = true;
            this.tbx_ReadLabel_Chip.Size = new System.Drawing.Size(276, 23);
            this.tbx_ReadLabel_Chip.TabIndex = 1;
            this.tbx_ReadLabel_Chip.UseSelectable = true;
            this.tbx_ReadLabel_Chip.WaterMark = "Lettura del QR-Code";
            this.tbx_ReadLabel_Chip.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tbx_ReadLabel_Chip.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tbx_ReadLabel_Chip.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbx_ReadLabel_Chip_KeyPress);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(23, 56);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(209, 19);
            this.metroLabel4.TabIndex = 8;
            this.metroLabel4.Text = "Lettura della scheda SMARTLINE:";
            // 
            // Device_Image
            // 
            this.Device_Image.BackColor = System.Drawing.Color.White;
            this.Device_Image.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Device_Image.Location = new System.Drawing.Point(624, 204);
            this.Device_Image.Name = "Device_Image";
            this.Device_Image.Size = new System.Drawing.Size(260, 320);
            this.Device_Image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Device_Image.TabIndex = 41;
            this.Device_Image.TabStop = false;
            // 
            // labchip_ID
            // 
            this.labchip_ID.AutoSize = true;
            this.labchip_ID.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.labchip_ID.Location = new System.Drawing.Point(150, 162);
            this.labchip_ID.Name = "labchip_ID";
            this.labchip_ID.Size = new System.Drawing.Size(72, 19);
            this.labchip_ID.Style = MetroFramework.MetroColorStyle.Red;
            this.labchip_ID.TabIndex = 43;
            this.labchip_ID.Text = "labchip_ID";
            this.labchip_ID.UseStyleColors = true;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(23, 162);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(105, 19);
            this.metroLabel6.TabIndex = 42;
            this.metroLabel6.Text = "Lettura del Chip:";
            // 
            // labchip_Kit
            // 
            this.labchip_Kit.AutoSize = true;
            this.labchip_Kit.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.labchip_Kit.Location = new System.Drawing.Point(150, 191);
            this.labchip_Kit.Name = "labchip_Kit";
            this.labchip_Kit.Size = new System.Drawing.Size(74, 19);
            this.labchip_Kit.Style = MetroFramework.MetroColorStyle.Red;
            this.labchip_Kit.TabIndex = 45;
            this.labchip_Kit.Text = "labchip_Kit";
            this.labchip_Kit.UseStyleColors = true;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(23, 191);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(126, 19);
            this.metroLabel8.TabIndex = 44;
            this.metroLabel8.Text = "Kit di appartenenza:";
            // 
            // labchip_Cliente
            // 
            this.labchip_Cliente.AutoSize = true;
            this.labchip_Cliente.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.labchip_Cliente.Location = new System.Drawing.Point(150, 220);
            this.labchip_Cliente.Name = "labchip_Cliente";
            this.labchip_Cliente.Size = new System.Drawing.Size(100, 19);
            this.labchip_Cliente.Style = MetroFramework.MetroColorStyle.Red;
            this.labchip_Cliente.TabIndex = 47;
            this.labchip_Cliente.Text = "labchip_Cliente";
            this.labchip_Cliente.UseStyleColors = true;
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.Location = new System.Drawing.Point(23, 220);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(52, 19);
            this.metroLabel10.TabIndex = 46;
            this.metroLabel10.Text = "Cliente:";
            // 
            // serialNumbersBindingSource
            // 
            this.serialNumbersBindingSource.DataMember = "SerialNumbers";
            this.serialNumbersBindingSource.DataSource = this.ds_SL;
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // serialNumbersTableAdapter
            // 
            this.serialNumbersTableAdapter.ClearBeforeFill = true;
            // 
            // sFAnagraficaClientiBindingSource
            // 
            this.sFAnagraficaClientiBindingSource.DataMember = "SF_AnagraficaClienti";
            this.sFAnagraficaClientiBindingSource.DataSource = this.ds_SL;
            // 
            // sF_AnagraficaClientiTableAdapter
            // 
            this.sF_AnagraficaClientiTableAdapter.ClearBeforeFill = true;
            // 
            // but_Associa
            // 
            this.but_Associa.Location = new System.Drawing.Point(23, 387);
            this.but_Associa.Name = "but_Associa";
            this.but_Associa.Size = new System.Drawing.Size(276, 23);
            this.but_Associa.Style = MetroFramework.MetroColorStyle.Green;
            this.but_Associa.TabIndex = 48;
            this.but_Associa.Text = "Associa SN - ID";
            this.but_Associa.UseSelectable = true;
            this.but_Associa.UseStyleColors = true;
            // 
            // but_Annulla
            // 
            this.but_Annulla.Location = new System.Drawing.Point(333, 387);
            this.but_Annulla.Name = "but_Annulla";
            this.but_Annulla.Size = new System.Drawing.Size(276, 23);
            this.but_Annulla.Style = MetroFramework.MetroColorStyle.Red;
            this.but_Annulla.TabIndex = 49;
            this.but_Annulla.Text = "Annulla";
            this.but_Annulla.UseSelectable = true;
            this.but_Annulla.UseStyleColors = true;
            this.but_Annulla.Click += new System.EventHandler(this.but_Annulla_Click);
            // 
            // MainMenu
            // 
            this.MainMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.MainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uscitaToolStripMenuItem});
            this.MainMenu.Location = new System.Drawing.Point(20, 30);
            this.MainMenu.Name = "MainMenu";
            this.MainMenu.Size = new System.Drawing.Size(1003, 24);
            this.MainMenu.TabIndex = 72;
            this.MainMenu.Text = "menuStrip1";
            // 
            // uscitaToolStripMenuItem
            // 
            this.uscitaToolStripMenuItem.Name = "uscitaToolStripMenuItem";
            this.uscitaToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.uscitaToolStripMenuItem.Text = "Uscita";
            this.uscitaToolStripMenuItem.Click += new System.EventHandler(this.uscitaToolStripMenuItem_Click);
            // 
            // UC_Spedizione
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1043, 579);
            this.ControlBox = false;
            this.Controls.Add(this.MainMenu);
            this.Controls.Add(this.but_Annulla);
            this.Controls.Add(this.but_Associa);
            this.Controls.Add(this.labchip_Cliente);
            this.Controls.Add(this.metroLabel10);
            this.Controls.Add(this.labchip_Kit);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.labchip_ID);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.Device_Image);
            this.Controls.Add(this.tbx_ReadLabel_Chip);
            this.Controls.Add(this.tbx_ReadLabel_Device);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.lab_read_FW);
            this.Controls.Add(this.lab_read_Device);
            this.Controls.Add(this.lab_read_SN);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.lab_Etichetta);
            this.DisplayHeader = false;
            this.Name = "UC_Spedizione";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Resizable = false;
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "Sistematica - Spedizioni";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UC_Spedizione_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Device_Image)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.serialNumbersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFAnagraficaClientiBindingSource)).EndInit();
            this.MainMenu.ResumeLayout(false);
            this.MainMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel lab_Etichetta;
        private MetroFramework.Controls.MetroTextBox tbx_ReadLabel_Device;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel lab_read_FW;
        private MetroFramework.Controls.MetroLabel lab_read_Device;
        private MetroFramework.Controls.MetroLabel lab_read_SN;
        private MetroFramework.Controls.MetroTextBox tbx_ReadLabel_Chip;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private ds_SL ds_SL;
        private System.Windows.Forms.BindingSource serialNumbersBindingSource;
        private ds_SLTableAdapters.SerialNumbersTableAdapter serialNumbersTableAdapter;
        private System.Windows.Forms.PictureBox Device_Image;
        private MetroFramework.Controls.MetroLabel labchip_ID;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel labchip_Kit;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel labchip_Cliente;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private System.Windows.Forms.BindingSource sFAnagraficaClientiBindingSource;
        private ds_SLTableAdapters.SF_AnagraficaClientiTableAdapter sF_AnagraficaClientiTableAdapter;
        private MetroFramework.Controls.MetroButton but_Associa;
        private MetroFramework.Controls.MetroButton but_Annulla;
        private System.Windows.Forms.MenuStrip MainMenu;
        private System.Windows.Forms.ToolStripMenuItem uscitaToolStripMenuItem;
    }
}