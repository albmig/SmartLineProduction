﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using System.IO;
using Syncfusion.Windows.Forms;
using Syncfusion.Pdf;
using Syncfusion.Pdf.Parsing;
using SmartLineProduction.ds_SLTableAdapters;

namespace SmartLineProduction
{
    public partial class UC_Schede : MetroFramework.Forms.MetroForm
    {
        private string btn_view = "K"; // K-P-R-C-FR-FP
        public UC_Schede()
        {
            InitializeComponent();
        }

        //// LOAD
        private void UC_Schede_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.Fam_Prod'. È possibile spostarla o rimuoverla se necessario.
            this.fam_ProdTableAdapter.FillBy_SchedePack(this.ds_SL.Fam_Prod);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_DistinteBasi_Schede'. È possibile spostarla o rimuoverla se necessario.
            this.sF_DistinteBasi_SchedeTableAdapter.Fill(this.ds_SL.SF_DistinteBasi_Schede);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_ArticoliSchede'. È possibile spostarla o rimuoverla se necessario.
            this.sF_ArticoliSchedeTableAdapter.FillBy_SchedeProdottoKit(this.ds_SL.SF_ArticoliSchede);
            //this.sF_ArticoliSchedeTableAdapter.Fill(this.ds_SL.SF_ArticoliSchede);

            SetView();
        }

        //// BINDINGSOURCE CHANGED
        private void sFArticoliSchedeBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            DataRowView drview = (DataRowView)sFArticoliSchedeBindingSource.Current;
            if (drview == null) { return; }

            string articolo = drview["Articolo"].ToString();
            string famiglia = drview["Famiglia"].ToString();

            //Calcolo del path
            string path = Properties.Settings.Default.Doc_folder;
            string path_it = "";
            string path_en = "";
            switch (btn_view)
            {
                case "K":
                    path = path + @"XKIT\";
                    path_it = path + articolo + @"\IT\" + articolo + ".pdf";
                    path_en = path + articolo + @"\EN\" + articolo + ".pdf";
                    break;
                case "P":
                    path = path + famiglia + @"\";
                    path_it = path + articolo + @"\IT\" + articolo + ".pdf";
                    path_en = path + articolo + @"\EN\" + articolo + ".pdf";
                    break;
                case "R":
                    path = path + famiglia + @"\";
                    path_it = path + articolo + @"\IT\" + articolo + ".pdf";
                    path_en = path + articolo + @"\EN\" + articolo + ".pdf";
                    break;
                case "C":
                    path = path + @"XCBL\";
                    // Cerca il folder giusto
                    string cblstart = articolo + "*";
                    string[] dirs = Directory.GetDirectories(path, cblstart, SearchOption.TopDirectoryOnly);
                    foreach (string dir in dirs)
                    {
                        path = dir + @"\";
                    }
                    path_it = path + @"\IT\" + articolo + ".pdf";
                    path_en = path + @"\EN\" + articolo + ".pdf";
                    break;
                case "FR":
                    path = path + @"XSWRR\";
                    path_it = path + articolo + @"\IT\" + articolo + ".pdf";
                    path_en = path + articolo + @"\EN\" + articolo + ".pdf";
                    break;
                case "FP":
                    path = path + @"XSWRP\";
                    path_it = path + articolo + @"\IT\" + articolo + ".pdf";
                    path_en = path + articolo + @"\EN\" + articolo + ".pdf";
                    break;
            }


            if (System.IO.File.Exists(path_it)) { Schede_pdf_it.LoadFile(path_it); } else { Schede_pdf_it.LoadFile(@"Resources\Pdf_notpresent.pdf"); }
            if (System.IO.File.Exists(path_en)) { Schede_pdf_en.LoadFile(path_en); } else { Schede_pdf_en.LoadFile(@"Resources\Pdf_notpresent.pdf"); }
            SetPDFReader();
        }

        //// CONTROLS EVENTS
        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tab_Kit_Enter(object sender, EventArgs e)
        {
            this.sF_ArticoliSchedeTableAdapter.FillBy_SchedeProdottoKit(this.ds_SL.SF_ArticoliSchede);
            gv_Schede.Refresh();
        }

        private void tb_grid_kit_TextChanged(object sender, EventArgs e)
        {
            string filtro = string.Format("Articolo LIKE '%{0}%'", tb_search.Text);
            sFArticoliSchedeBindingSource.Filter = filtro;
            tb_search.Focus();
        }

        private void btn_Kit_Click(object sender, EventArgs e)
        {
            btn_view = "K";
            this.sF_ArticoliSchedeTableAdapter.FillBy_SchedeProdottoKit(this.ds_SL.SF_ArticoliSchede);
            gv_Schede.Refresh();
        }

        private void btn_Palmari_Click(object sender, EventArgs e)
        {
            btn_view = "P";
            SetView();
        }

        private void btn_Ricevitori_Click(object sender, EventArgs e)
        {
            btn_view = "R";
            SetView();
        }

        private void btn_Cablaggi_Click(object sender, EventArgs e)
        {
            btn_view = "C";
            SetView();
        }

        private void btn_FW_P_Click(object sender, EventArgs e)
        {
            btn_view = "FP";
            SetView();
        }

        private void btn_FW_R_Click(object sender, EventArgs e)
        {
            btn_view = "FR";
            SetView();
        }

        //// OTHER ROUTINES
        private void SetPDFReader()
        {
            Schede_pdf_it.setView("FitV");
            Schede_pdf_en.setView("FitV");

            Schede_pdf_it.setShowScrollbars(false);
            Schede_pdf_en.setShowScrollbars(false);

            Schede_pdf_it.setShowToolbar(false);
            Schede_pdf_en.setShowToolbar(false);

            Schede_pdf_it.setPageMode("none");
            Schede_pdf_en.setPageMode("none");
        }

        private string TrovaPath(string tiporicerca, string codice, string lingua)
        {
            string path = Properties.Settings.Default.Doc_folder;

            if ((tiporicerca=="Kit") && (lingua=="IT"))
            {
                path = path + @"XKIT\";
                string path_it = path + codice + @"\IT\" + codice + ".pdf";
                return path_it;
            }
            if ((tiporicerca == "Kit") && (lingua == "EN"))
            {
                path = path + @"XKIT\";
                string path_en = path + codice + @"\EN\" + codice + ".pdf";
                return path_en;
            }
            if (tiporicerca == "Swr")
            {
                if (codice.StartsWith("XSWRP")) { path = path + @"XSWRP\"; }
                if (codice.StartsWith("XSWRR")) { path = path + @"XSWRR\"; }

                if (lingua == "IT") { string path_it = path + codice + @"\IT\" + codice + ".pdf"; return path_it; }
                if (lingua == "EN") { string path_en = path + codice + @"\EN\" + codice + ".pdf"; return path_en; }
            }

            return null;
        }

        private void SetView()
        {
            btn_Kit.BackColor = Color.White;
            btn_Palmari.BackColor = Color.White;
            btn_Ricevitori.BackColor = Color.White;
            btn_Cablaggi.BackColor = Color.White;
            btn_FW_P.BackColor = Color.White;
            btn_FW_R.BackColor = Color.White;

            switch (btn_view)
            {
                case "K":
                    this.sF_ArticoliSchedeTableAdapter.FillBy_SchedeProdottoKit(this.ds_SL.SF_ArticoliSchede);
                    gv_Schede_Articolo.HeaderText = "Kit";
                    gv_Schede.Refresh();
                    btn_Kit.BackColor = Color.Red;
                    break;
                case "P":
                    this.sF_ArticoliSchedeTableAdapter.FillBy_SchedeProdottoPalmari(this.ds_SL.SF_ArticoliSchede);
                    gv_Schede_Articolo.HeaderText = "Palmare";
                    gv_Schede.Refresh();
                    btn_Palmari.BackColor = Color.Red;
                    break;
                case "R":
                    this.sF_ArticoliSchedeTableAdapter.FillBy_SchedeProdottoRicevitori(this.ds_SL.SF_ArticoliSchede);
                    gv_Schede_Articolo.HeaderText = "Ricevitore";
                    gv_Schede.Refresh();
                    btn_Ricevitori.BackColor = Color.Red;
                    break;
                case "C":
                    this.sF_ArticoliSchedeTableAdapter.FillBy_SchedeProdottoCablaggi(this.ds_SL.SF_ArticoliSchede);
                    gv_Schede_Articolo.HeaderText = "Cablaggio";
                    gv_Schede.Refresh();
                    btn_Cablaggi.BackColor = Color.Red;
                    break;
                case "FR":
                    this.sF_ArticoliSchedeTableAdapter.FillBy_SchedeProdottoFw_R(this.ds_SL.SF_ArticoliSchede);
                    gv_Schede_Articolo.HeaderText = "FW Ricevitore";
                    gv_Schede.Refresh();
                    btn_FW_R.BackColor = Color.Red;
                    break;
                case "FP":
                    this.sF_ArticoliSchedeTableAdapter.FillBy_SchedeProdottoFw_P(this.ds_SL.SF_ArticoliSchede);
                    gv_Schede_Articolo.HeaderText = "FW Palmare";
                    gv_Schede.Refresh();
                    btn_FW_P.BackColor = Color.Red;
                    break;
            }

            tb_search.Text = "";
        }

    }
}
