﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using System.IO;
using Syncfusion.Windows.Forms;
using Syncfusion.Pdf;
using Syncfusion.Pdf.Parsing;
using SmartLineProduction.ds_SLTableAdapters;

namespace SmartLineProduction
{
    public partial class UC_Pack_Kit : MetroFramework.Forms.MetroForm
    {
        public UC_Pack_Kit()
        {
            InitializeComponent();
        }

        //// LOAD
        private void UC_Pack_Kit_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.Fam_Prod'. È possibile spostarla o rimuoverla se necessario.
            this.fam_ProdTableAdapter.FillBy_SchedePack(this.ds_SL.Fam_Prod);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_DistinteBasi_Schede'. È possibile spostarla o rimuoverla se necessario.
            this.sF_DistinteBasi_SchedeTableAdapter.Fill(this.ds_SL.SF_DistinteBasi_Schede);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_ArticoliSchede'. È possibile spostarla o rimuoverla se necessario.
            this.sF_ArticoliSchedeTableAdapter.FillBy_SchedeProdottoKit(this.ds_SL.SF_ArticoliSchede);

            SetView();

            sFArticoliSchedeBindingSource.MoveFirst();
            DataRowView drview = (DataRowView)sFArticoliSchedeBindingSource.Current;
            panel_pack_kit.Visible = false;
            CreaTreeView(drview);
            gv_kit_pack.Refresh();

        }

        //// BINDINGSOURCE CHANGED
        private void sFArticoliSchedeBindingSource_CurrentChanged(object sender, EventArgs e)
        {
                cb_Doc_IT.Checked = true;
                cb_Doc_EN.Checked = false;

                DataRowView drview = (DataRowView)sFArticoliSchedeBindingSource.Current;

                CreaTreeView(drview);
                SetPDFReader();

                panel_pack_kit.Visible = false;
        }

        //// CONTROLS EVENTS
        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tab_pack_doc_Enter(object sender, EventArgs e)
        {
        }

        private void btn_do_pack_kit_Click(object sender, EventArgs e)
        {
            //Get the folder path into DirectoryInfo
            string temppath = @"C:\SEFactoryTemp";
            bool exists = System.IO.Directory.Exists(temppath);
            if (!exists) System.IO.Directory.CreateDirectory(temppath);

            // Delete all files
            System.IO.DirectoryInfo di = new DirectoryInfo(temppath);
            foreach (FileInfo file in di.GetFiles())
            {
                file.Delete();
            }
            foreach (DirectoryInfo dir in di.GetDirectories())
            {
                dir.Delete(true);
            }

            //Download needed files
            Application.UseWaitCursor = true;
            foreach (DataGridViewRow row in gv_pack_explo.Rows)
            {
                if ((bool)row.Cells["Includere"].Value == false) { continue; }

                string nomfile = Path.GetFileName(row.Cells["Path"].Value.ToString());
                string destfile = temppath + @"\" + nomfile;
                System.IO.File.Copy(row.Cells["Path"].Value.ToString(), destfile, true);
            }
            Application.UseWaitCursor = false;


            //DirectoryInfo directoryInfo = new DirectoryInfo(temppath);

            //Get the PDF files in folder path into FileInfo
            //FileInfo[] files = directoryInfo.GetFiles("*.pdf");
            var sorted = Directory.GetFiles(temppath, "*.pdf").Select(fn => new FileInfo(fn)).OrderBy(f => f.Name); ;

            //Create a new PDF document 
            PdfDocument document = new PdfDocument();

            //Set enable memory optimization as true 
            document.EnableMemoryOptimization = true;

            foreach (FileInfo file in sorted)
            {
                //Load the PDF document 
                FileStream fileStream = new FileStream(file.FullName, FileMode.Open);
                PdfLoadedDocument loadedDocument = new PdfLoadedDocument(fileStream);

                //Merge PDF file
                PdfDocumentBase.Merge(document, loadedDocument);

                //Close the existing PDF document 
                loadedDocument.Close(true);
            }

            //Save the PDF document
            string pathout = temppath + @"\" + "MergedPDF.pdf";
            document.Save(pathout);

            //Close the instance of PdfDocument
            document.Close(true);

            pack_Kit_pdf.LoadFile(pathout);
            panel_pack_kit.Visible = true;
        }

        private void cb_Doc_IT_Click(object sender, EventArgs e)
        {
            switch (cb_Doc_IT.CheckState)
            {
                case CheckState.Checked:
                    cb_Doc_EN.Checked = false;
                    break;
                case CheckState.Unchecked:
                    cb_Doc_EN.Checked = true;
                    break;
                case CheckState.Indeterminate:
                    // Code for indeterminate state.  
                    break;
            }
            ConvertiLinguaDoc("IT");
        }

        private void cb_Doc_EN_Click(object sender, EventArgs e)
        {
            switch (cb_Doc_EN.CheckState)
            {
                case CheckState.Checked:
                    cb_Doc_IT.Checked = false;
                    break;
                case CheckState.Unchecked:
                    cb_Doc_IT.Checked = true;
                    break;
                case CheckState.Indeterminate:
                    // Code for indeterminate state.  
                    break;
            }
            ConvertiLinguaDoc("EN");
        }

        private void tb_grid_kit_pack_TextChanged(object sender, EventArgs e)
        {
            string filtro = string.Format("Articolo LIKE '%{0}%'", tb_grid_kit_pack.Text);
            sFArticoliSchedeBindingSource.Filter = filtro;
            tb_grid_kit_pack.Focus();
        }

        //// OTHER ROUTINES
        private void SetPDFReader()
        {
            pack_Kit_pdf.setView("FitV");

            pack_Kit_pdf.setShowScrollbars(false);

            pack_Kit_pdf.setShowToolbar(false);

            pack_Kit_pdf.setPageMode("none");
        }

        private void CreaTreeView(DataRowView drview)
        {
            if (drview == null) { return; }

            DataTable dt_treeview = new DataTable();
            dt_treeview.Columns.Add("Composto", typeof(string));
            dt_treeview.Columns.Add("NomeFile", typeof(string));
            dt_treeview.Columns.Add("Includere", typeof(bool));
            dt_treeview.Columns.Add("XSWRR", typeof(bool));
            dt_treeview.Columns.Add("XSWRP", typeof(bool));
            dt_treeview.Columns.Add("Path", typeof(string));

            dt_treeview.Clear();

            string linguadoc = "";
            if (cb_Doc_IT.Checked) { linguadoc = "IT"; }
            if (cb_Doc_EN.Checked) { linguadoc = "EN"; }
            //Scrivo il padre
            DataRow newrecpadre = dt_treeview.NewRow();
            newrecpadre["Composto"] = drview["Articolo"].ToString();
            newrecpadre["NomeFile"] = drview["Articolo"].ToString();
            newrecpadre["Includere"] = true;
            newrecpadre["Path"] = TrovaPath("Kit", drview["Articolo"].ToString(), linguadoc);

            dt_treeview.Rows.Add(newrecpadre);
            gv_pack_explo.DataSource = dt_treeview;

            string db_filtro = "ArticoloComposto = " + "'" + drview["Articolo"].ToString() + "'";
            sFDistinteBasiSchedeBindingSource.Filter = db_filtro;

            // Primo Ciclo sulla distinta - partiamo con la versione base
            foreach (DataRowView distintarow in sFDistinteBasiSchedeBindingSource)
            {
                string articolo = distintarow["ArticoloComponente"].ToString();
                // Verifico quali siano device    
                string pr_3 = articolo.Substring(0, 3);
                string pr_5 = articolo.Substring(0, 5);
                foreach (DataRowView famrow in famProdBindingSource)
                {
                    if ((famrow["Fam_Prefix"].ToString() == pr_3) || (famrow["Fam_Prefix"].ToString() == pr_5))
                    {
                        string codicefw = this.sF_ArticoliToXSWR_SchedeTableAdapter.Get_CodiceFW(articolo);

                        if (codicefw != null)
                        {
                            DataRow newrec = dt_treeview.NewRow();
                            newrec["Composto"] = articolo;
                            newrec["NomeFile"] = codicefw;
                            newrec["Includere"] = true;
                            if (famrow["Fam_Tipo"].ToString()=="P")
                            {
                                newrec["XSWRP"] = true;
                            }
                            if (famrow["Fam_Tipo"].ToString() == "R")
                            {
                                newrec["XSWRR"] = true;
                            }
                            newrec["Path"] = TrovaPath("Swr", codicefw, linguadoc);
                            dt_treeview.Rows.Add(newrec);
                            gv_pack_explo.DataSource = dt_treeview;
                        }
                    }
                }
            }

            //Secondo Ciclo sulla distinta -sostituisco
            foreach (DataRowView distintarow in sFDistinteBasiSchedeBindingSource)
            {
                string articolo = distintarow["ArticoloComponente"].ToString();
                if ((articolo.Substring(0, 5) == "XSWRR") || (articolo.Substring(0, 5) == "XSWRP"))
                {
                    DataRow newrec = dt_treeview.NewRow();
                    newrec["Composto"] = articolo;
                    newrec["NomeFile"] = distintarow["ArticoloComponente"];
                    newrec["Includere"] = true;
                    newrec["Path"] = TrovaPath("Swr", articolo, linguadoc);

                    dt_treeview.Rows.Add(newrec);
                    gv_pack_explo.DataSource = dt_treeview;

                    string filtro = articolo.Substring(0, 5) + "= 1";
                    DataRow[] result = dt_treeview.Select(filtro);
                    foreach (DataRow row in result)
                    {
                        row["Includere"] = false;
                    }
                }
            }

            gv_pack_explo.Columns["Composto"].HeaderText = "Cod. Composto";
            gv_pack_explo.Columns["NomeFile"].HeaderText = "Nome del file";
            gv_pack_explo.Columns["Includere"].HeaderText = "Includere nella raccolta";
            gv_pack_explo.Columns["XSWRR"].Visible = false;
            gv_pack_explo.Columns["XSWRP"].Visible = false;
            gv_pack_explo.Columns["Path"].Visible = false;

            gv_pack_explo.Columns["Composto"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gv_pack_explo.Columns["NomeFile"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gv_pack_explo.Columns["Includere"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            gv_pack_explo.Columns["Composto"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gv_pack_explo.Columns["NomeFile"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gv_pack_explo.Columns["Includere"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            gv_pack_explo.Columns["Composto"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            gv_pack_explo.Columns["NomeFile"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            gv_pack_explo.Columns["Includere"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            gv_pack_explo.Columns["Path"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            gv_pack_explo.DataSource = dt_treeview;
            gv_pack_explo.Refresh();
        }

        private string TrovaPath(string tiporicerca, string codice, string lingua)
        {
            string path = Properties.Settings.Default.Doc_folder;

            if ((tiporicerca=="Kit") && (lingua=="IT"))
            {
                path = path + @"XKIT\";
                string path_it = path + codice + @"\IT\" + codice + ".pdf";
                return path_it;
            }
            if ((tiporicerca == "Kit") && (lingua == "EN"))
            {
                path = path + @"XKIT\";
                string path_en = path + codice + @"\EN\" + codice + ".pdf";
                return path_en;
            }
            if (tiporicerca == "Swr")
            {
                if (codice.StartsWith("XSWRP")) { path = path + @"XSWRP\"; }
                if (codice.StartsWith("XSWRR")) { path = path + @"XSWRR\"; }

                if (lingua == "IT") { string path_it = path + codice + @"\IT\" + codice + ".pdf"; return path_it; }
                if (lingua == "EN") { string path_en = path + codice + @"\EN\" + codice + ".pdf"; return path_en; }
            }

            return null;
        }

        private void SetView()
        {
            tb_grid_kit_pack.Text = "";
        }

        private void ConvertiLinguaDoc(string lingua)
        {
            foreach (DataGridViewRow row in gv_pack_explo.Rows)
            {
                string path = row.Cells["Path"].Value.ToString();
                string prefit = @"\IT\";
                string prefen = @"\EN\";

                string newpath = "";
                if (lingua =="IT") { newpath = path.Replace(prefen, prefit); }
                if (lingua == "EN") { newpath = path.Replace(prefit, prefen); }
                row.Cells["Path"].Value = newpath;
            }

        }
    }
}
