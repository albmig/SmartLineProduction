namespace SmartLineProduction
{
    partial class UC_ViewConfig
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_Config = new System.Windows.Forms.TableLayoutPanel();
            this.lab_out_01 = new MetroFramework.Controls.MetroLabel();
            this.lab_out_02 = new MetroFramework.Controls.MetroLabel();
            this.lab_out_03 = new MetroFramework.Controls.MetroLabel();
            this.lab_out_04 = new MetroFramework.Controls.MetroLabel();
            this.lab_out_05 = new MetroFramework.Controls.MetroLabel();
            this.lab_out_06 = new MetroFramework.Controls.MetroLabel();
            this.lab_out_07 = new MetroFramework.Controls.MetroLabel();
            this.lab_out_08 = new MetroFramework.Controls.MetroLabel();
            this.lab_out_09 = new MetroFramework.Controls.MetroLabel();
            this.lab_out_10 = new MetroFramework.Controls.MetroLabel();
            this.lab_out_11 = new MetroFramework.Controls.MetroLabel();
            this.lab_out_12 = new MetroFramework.Controls.MetroLabel();
            this.lab_out_13 = new MetroFramework.Controls.MetroLabel();
            this.lab_out_14 = new MetroFramework.Controls.MetroLabel();
            this.lab_out_15 = new MetroFramework.Controls.MetroLabel();
            this.lab_out_16 = new MetroFramework.Controls.MetroLabel();
            this.lab_out_17 = new MetroFramework.Controls.MetroLabel();
            this.lab_out_18 = new MetroFramework.Controls.MetroLabel();
            this.lab_MO_01 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_MO_02 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_MO_03 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_MO_04 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_MO_05 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_MO_06 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_MO_07 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_MO_08 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_MO_09 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_MO_10 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_MO_11 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_MO_12 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_MO_13 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_MO_14 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_MO_15 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_MO_16 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_MO_17 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_MO_18 = new MetroFramework.Controls.MetroCheckBox();
            this.label_NO_Config = new MetroFramework.Controls.MetroLabel();
            this.lab_M_01 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_M_02 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_M_03 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_M_04 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_M_05 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_M_06 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_M_07 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_M_08 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_M_09 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_M_10 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_M_11 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_M_12 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_M_13 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_M_14 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_M_15 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_M_16 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_M_17 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_M_18 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_L_01 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_L_02 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_L_03 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_L_04 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_L_05 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_L_06 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_L_07 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_L_08 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_L_09 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_L_10 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_L_11 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_L_12 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_L_13 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_L_14 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_L_15 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_L_16 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_L_17 = new MetroFramework.Controls.MetroCheckBox();
            this.lab_L_18 = new MetroFramework.Controls.MetroCheckBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.lab_TimeOut = new MetroFramework.Controls.MetroLabel();
            this.lab_Frequency = new MetroFramework.Controls.MetroLabel();
            this.panel_Config.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_Config
            // 
            this.panel_Config.ColumnCount = 4;
            this.panel_Config.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.panel_Config.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.panel_Config.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.panel_Config.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.panel_Config.Controls.Add(this.lab_Frequency, 1, 19);
            this.panel_Config.Controls.Add(this.metroLabel2, 0, 19);
            this.panel_Config.Controls.Add(this.metroLabel1, 0, 18);
            this.panel_Config.Controls.Add(this.lab_out_01, 0, 0);
            this.panel_Config.Controls.Add(this.lab_out_02, 0, 1);
            this.panel_Config.Controls.Add(this.lab_out_03, 0, 2);
            this.panel_Config.Controls.Add(this.lab_out_04, 0, 3);
            this.panel_Config.Controls.Add(this.lab_out_05, 0, 4);
            this.panel_Config.Controls.Add(this.lab_out_06, 0, 5);
            this.panel_Config.Controls.Add(this.lab_out_07, 0, 6);
            this.panel_Config.Controls.Add(this.lab_out_08, 0, 7);
            this.panel_Config.Controls.Add(this.lab_out_09, 0, 8);
            this.panel_Config.Controls.Add(this.lab_out_10, 0, 9);
            this.panel_Config.Controls.Add(this.lab_out_11, 0, 10);
            this.panel_Config.Controls.Add(this.lab_out_12, 0, 11);
            this.panel_Config.Controls.Add(this.lab_out_13, 0, 12);
            this.panel_Config.Controls.Add(this.lab_out_14, 0, 13);
            this.panel_Config.Controls.Add(this.lab_out_15, 0, 14);
            this.panel_Config.Controls.Add(this.lab_out_16, 0, 15);
            this.panel_Config.Controls.Add(this.lab_out_17, 0, 16);
            this.panel_Config.Controls.Add(this.lab_out_18, 0, 17);
            this.panel_Config.Controls.Add(this.lab_MO_01, 1, 0);
            this.panel_Config.Controls.Add(this.lab_MO_02, 1, 1);
            this.panel_Config.Controls.Add(this.lab_MO_03, 1, 2);
            this.panel_Config.Controls.Add(this.lab_MO_04, 1, 3);
            this.panel_Config.Controls.Add(this.lab_MO_05, 1, 4);
            this.panel_Config.Controls.Add(this.lab_MO_06, 1, 5);
            this.panel_Config.Controls.Add(this.lab_MO_07, 1, 6);
            this.panel_Config.Controls.Add(this.lab_MO_08, 1, 7);
            this.panel_Config.Controls.Add(this.lab_MO_09, 1, 8);
            this.panel_Config.Controls.Add(this.lab_MO_10, 1, 9);
            this.panel_Config.Controls.Add(this.lab_MO_11, 1, 10);
            this.panel_Config.Controls.Add(this.lab_MO_12, 1, 11);
            this.panel_Config.Controls.Add(this.lab_MO_13, 1, 12);
            this.panel_Config.Controls.Add(this.lab_MO_14, 1, 13);
            this.panel_Config.Controls.Add(this.lab_MO_15, 1, 14);
            this.panel_Config.Controls.Add(this.lab_MO_16, 1, 15);
            this.panel_Config.Controls.Add(this.lab_MO_17, 1, 16);
            this.panel_Config.Controls.Add(this.lab_MO_18, 1, 17);
            this.panel_Config.Controls.Add(this.label_NO_Config, 0, 20);
            this.panel_Config.Controls.Add(this.lab_M_01, 2, 0);
            this.panel_Config.Controls.Add(this.lab_M_02, 2, 1);
            this.panel_Config.Controls.Add(this.lab_M_03, 2, 2);
            this.panel_Config.Controls.Add(this.lab_M_04, 2, 3);
            this.panel_Config.Controls.Add(this.lab_M_05, 2, 4);
            this.panel_Config.Controls.Add(this.lab_M_06, 2, 5);
            this.panel_Config.Controls.Add(this.lab_M_07, 2, 6);
            this.panel_Config.Controls.Add(this.lab_M_08, 2, 7);
            this.panel_Config.Controls.Add(this.lab_M_09, 2, 8);
            this.panel_Config.Controls.Add(this.lab_M_10, 2, 9);
            this.panel_Config.Controls.Add(this.lab_M_11, 2, 10);
            this.panel_Config.Controls.Add(this.lab_M_12, 2, 11);
            this.panel_Config.Controls.Add(this.lab_M_13, 2, 12);
            this.panel_Config.Controls.Add(this.lab_M_14, 2, 13);
            this.panel_Config.Controls.Add(this.lab_M_15, 2, 14);
            this.panel_Config.Controls.Add(this.lab_M_16, 2, 15);
            this.panel_Config.Controls.Add(this.lab_M_17, 2, 16);
            this.panel_Config.Controls.Add(this.lab_M_18, 2, 17);
            this.panel_Config.Controls.Add(this.lab_L_01, 3, 0);
            this.panel_Config.Controls.Add(this.lab_L_02, 3, 1);
            this.panel_Config.Controls.Add(this.lab_L_03, 3, 2);
            this.panel_Config.Controls.Add(this.lab_L_04, 3, 3);
            this.panel_Config.Controls.Add(this.lab_L_05, 3, 4);
            this.panel_Config.Controls.Add(this.lab_L_06, 3, 5);
            this.panel_Config.Controls.Add(this.lab_L_07, 3, 6);
            this.panel_Config.Controls.Add(this.lab_L_08, 3, 7);
            this.panel_Config.Controls.Add(this.lab_L_09, 3, 8);
            this.panel_Config.Controls.Add(this.lab_L_10, 3, 9);
            this.panel_Config.Controls.Add(this.lab_L_11, 3, 10);
            this.panel_Config.Controls.Add(this.lab_L_12, 3, 11);
            this.panel_Config.Controls.Add(this.lab_L_13, 3, 12);
            this.panel_Config.Controls.Add(this.lab_L_14, 3, 13);
            this.panel_Config.Controls.Add(this.lab_L_15, 3, 14);
            this.panel_Config.Controls.Add(this.lab_L_16, 3, 15);
            this.panel_Config.Controls.Add(this.lab_L_17, 3, 16);
            this.panel_Config.Controls.Add(this.lab_L_18, 3, 17);
            this.panel_Config.Controls.Add(this.lab_TimeOut, 1, 18);
            this.panel_Config.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Config.Location = new System.Drawing.Point(20, 60);
            this.panel_Config.Name = "panel_Config";
            this.panel_Config.RowCount = 21;
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.panel_Config.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.panel_Config.Size = new System.Drawing.Size(460, 520);
            this.panel_Config.TabIndex = 0;
            this.panel_Config.CellPaint += new System.Windows.Forms.TableLayoutCellPaintEventHandler(this.panel_Config_CellPaint);
            // 
            // lab_out_01
            // 
            this.lab_out_01.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_out_01.AutoSize = true;
            this.lab_out_01.BackColor = System.Drawing.Color.Transparent;
            this.lab_out_01.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_out_01.Location = new System.Drawing.Point(3, 3);
            this.lab_out_01.Name = "lab_out_01";
            this.lab_out_01.Size = new System.Drawing.Size(55, 19);
            this.lab_out_01.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_out_01.TabIndex = 0;
            this.lab_out_01.Text = "Out - 1";
            this.lab_out_01.UseStyleColors = true;
            // 
            // lab_out_02
            // 
            this.lab_out_02.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_out_02.AutoSize = true;
            this.lab_out_02.BackColor = System.Drawing.Color.Transparent;
            this.lab_out_02.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_out_02.Location = new System.Drawing.Point(3, 28);
            this.lab_out_02.Name = "lab_out_02";
            this.lab_out_02.Size = new System.Drawing.Size(55, 19);
            this.lab_out_02.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_out_02.TabIndex = 1;
            this.lab_out_02.Text = "Out - 2";
            this.lab_out_02.UseStyleColors = true;
            // 
            // lab_out_03
            // 
            this.lab_out_03.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_out_03.AutoSize = true;
            this.lab_out_03.BackColor = System.Drawing.Color.Transparent;
            this.lab_out_03.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_out_03.Location = new System.Drawing.Point(3, 53);
            this.lab_out_03.Name = "lab_out_03";
            this.lab_out_03.Size = new System.Drawing.Size(55, 19);
            this.lab_out_03.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_out_03.TabIndex = 2;
            this.lab_out_03.Text = "Out - 3";
            this.lab_out_03.UseStyleColors = true;
            // 
            // lab_out_04
            // 
            this.lab_out_04.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_out_04.AutoSize = true;
            this.lab_out_04.BackColor = System.Drawing.Color.Transparent;
            this.lab_out_04.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_out_04.Location = new System.Drawing.Point(3, 78);
            this.lab_out_04.Name = "lab_out_04";
            this.lab_out_04.Size = new System.Drawing.Size(55, 19);
            this.lab_out_04.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_out_04.TabIndex = 3;
            this.lab_out_04.Text = "Out - 4";
            this.lab_out_04.UseStyleColors = true;
            // 
            // lab_out_05
            // 
            this.lab_out_05.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_out_05.AutoSize = true;
            this.lab_out_05.BackColor = System.Drawing.Color.Transparent;
            this.lab_out_05.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_out_05.Location = new System.Drawing.Point(3, 103);
            this.lab_out_05.Name = "lab_out_05";
            this.lab_out_05.Size = new System.Drawing.Size(55, 19);
            this.lab_out_05.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_out_05.TabIndex = 4;
            this.lab_out_05.Text = "Out - 5";
            this.lab_out_05.UseStyleColors = true;
            // 
            // lab_out_06
            // 
            this.lab_out_06.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_out_06.AutoSize = true;
            this.lab_out_06.BackColor = System.Drawing.Color.Transparent;
            this.lab_out_06.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_out_06.Location = new System.Drawing.Point(3, 128);
            this.lab_out_06.Name = "lab_out_06";
            this.lab_out_06.Size = new System.Drawing.Size(55, 19);
            this.lab_out_06.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_out_06.TabIndex = 5;
            this.lab_out_06.Text = "Out - 6";
            this.lab_out_06.UseStyleColors = true;
            // 
            // lab_out_07
            // 
            this.lab_out_07.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_out_07.AutoSize = true;
            this.lab_out_07.BackColor = System.Drawing.Color.Transparent;
            this.lab_out_07.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_out_07.Location = new System.Drawing.Point(3, 153);
            this.lab_out_07.Name = "lab_out_07";
            this.lab_out_07.Size = new System.Drawing.Size(55, 19);
            this.lab_out_07.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_out_07.TabIndex = 6;
            this.lab_out_07.Text = "Out - 7";
            this.lab_out_07.UseStyleColors = true;
            // 
            // lab_out_08
            // 
            this.lab_out_08.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_out_08.AutoSize = true;
            this.lab_out_08.BackColor = System.Drawing.Color.Transparent;
            this.lab_out_08.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_out_08.Location = new System.Drawing.Point(3, 178);
            this.lab_out_08.Name = "lab_out_08";
            this.lab_out_08.Size = new System.Drawing.Size(55, 19);
            this.lab_out_08.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_out_08.TabIndex = 7;
            this.lab_out_08.Text = "Out - 8";
            this.lab_out_08.UseStyleColors = true;
            // 
            // lab_out_09
            // 
            this.lab_out_09.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_out_09.AutoSize = true;
            this.lab_out_09.BackColor = System.Drawing.Color.Transparent;
            this.lab_out_09.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_out_09.Location = new System.Drawing.Point(3, 203);
            this.lab_out_09.Name = "lab_out_09";
            this.lab_out_09.Size = new System.Drawing.Size(55, 19);
            this.lab_out_09.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_out_09.TabIndex = 8;
            this.lab_out_09.Text = "Out - 9";
            this.lab_out_09.UseStyleColors = true;
            // 
            // lab_out_10
            // 
            this.lab_out_10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_out_10.AutoSize = true;
            this.lab_out_10.BackColor = System.Drawing.Color.Transparent;
            this.lab_out_10.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_out_10.Location = new System.Drawing.Point(3, 228);
            this.lab_out_10.Name = "lab_out_10";
            this.lab_out_10.Size = new System.Drawing.Size(63, 19);
            this.lab_out_10.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_out_10.TabIndex = 9;
            this.lab_out_10.Text = "Out - 10";
            this.lab_out_10.UseStyleColors = true;
            // 
            // lab_out_11
            // 
            this.lab_out_11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_out_11.AutoSize = true;
            this.lab_out_11.BackColor = System.Drawing.Color.Transparent;
            this.lab_out_11.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_out_11.Location = new System.Drawing.Point(3, 253);
            this.lab_out_11.Name = "lab_out_11";
            this.lab_out_11.Size = new System.Drawing.Size(63, 19);
            this.lab_out_11.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_out_11.TabIndex = 10;
            this.lab_out_11.Text = "Out - 11";
            this.lab_out_11.UseStyleColors = true;
            // 
            // lab_out_12
            // 
            this.lab_out_12.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_out_12.AutoSize = true;
            this.lab_out_12.BackColor = System.Drawing.Color.Transparent;
            this.lab_out_12.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_out_12.Location = new System.Drawing.Point(3, 278);
            this.lab_out_12.Name = "lab_out_12";
            this.lab_out_12.Size = new System.Drawing.Size(63, 19);
            this.lab_out_12.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_out_12.TabIndex = 11;
            this.lab_out_12.Text = "Out - 12";
            this.lab_out_12.UseStyleColors = true;
            // 
            // lab_out_13
            // 
            this.lab_out_13.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_out_13.AutoSize = true;
            this.lab_out_13.BackColor = System.Drawing.Color.Transparent;
            this.lab_out_13.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_out_13.Location = new System.Drawing.Point(3, 303);
            this.lab_out_13.Name = "lab_out_13";
            this.lab_out_13.Size = new System.Drawing.Size(63, 19);
            this.lab_out_13.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_out_13.TabIndex = 12;
            this.lab_out_13.Text = "Out - 13";
            this.lab_out_13.UseStyleColors = true;
            // 
            // lab_out_14
            // 
            this.lab_out_14.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_out_14.AutoSize = true;
            this.lab_out_14.BackColor = System.Drawing.Color.Transparent;
            this.lab_out_14.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_out_14.Location = new System.Drawing.Point(3, 328);
            this.lab_out_14.Name = "lab_out_14";
            this.lab_out_14.Size = new System.Drawing.Size(63, 19);
            this.lab_out_14.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_out_14.TabIndex = 13;
            this.lab_out_14.Text = "Out - 14";
            this.lab_out_14.UseStyleColors = true;
            // 
            // lab_out_15
            // 
            this.lab_out_15.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_out_15.AutoSize = true;
            this.lab_out_15.BackColor = System.Drawing.Color.Transparent;
            this.lab_out_15.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_out_15.Location = new System.Drawing.Point(3, 353);
            this.lab_out_15.Name = "lab_out_15";
            this.lab_out_15.Size = new System.Drawing.Size(63, 19);
            this.lab_out_15.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_out_15.TabIndex = 14;
            this.lab_out_15.Text = "Out - 15";
            this.lab_out_15.UseStyleColors = true;
            // 
            // lab_out_16
            // 
            this.lab_out_16.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_out_16.AutoSize = true;
            this.lab_out_16.BackColor = System.Drawing.Color.Transparent;
            this.lab_out_16.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_out_16.Location = new System.Drawing.Point(3, 378);
            this.lab_out_16.Name = "lab_out_16";
            this.lab_out_16.Size = new System.Drawing.Size(63, 19);
            this.lab_out_16.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_out_16.TabIndex = 15;
            this.lab_out_16.Text = "Out - 16";
            this.lab_out_16.UseStyleColors = true;
            // 
            // lab_out_17
            // 
            this.lab_out_17.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_out_17.AutoSize = true;
            this.lab_out_17.BackColor = System.Drawing.Color.Transparent;
            this.lab_out_17.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_out_17.Location = new System.Drawing.Point(3, 403);
            this.lab_out_17.Name = "lab_out_17";
            this.lab_out_17.Size = new System.Drawing.Size(63, 19);
            this.lab_out_17.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_out_17.TabIndex = 17;
            this.lab_out_17.Text = "Out - 17";
            this.lab_out_17.UseStyleColors = true;
            // 
            // lab_out_18
            // 
            this.lab_out_18.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_out_18.AutoSize = true;
            this.lab_out_18.BackColor = System.Drawing.Color.Transparent;
            this.lab_out_18.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_out_18.Location = new System.Drawing.Point(3, 428);
            this.lab_out_18.Name = "lab_out_18";
            this.lab_out_18.Size = new System.Drawing.Size(63, 19);
            this.lab_out_18.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_out_18.TabIndex = 16;
            this.lab_out_18.Text = "Out - 18";
            this.lab_out_18.UseStyleColors = true;
            // 
            // lab_MO_01
            // 
            this.lab_MO_01.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_MO_01.AutoSize = true;
            this.lab_MO_01.BackColor = System.Drawing.Color.Transparent;
            this.lab_MO_01.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_MO_01.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_MO_01.Location = new System.Drawing.Point(87, 3);
            this.lab_MO_01.Name = "lab_MO_01";
            this.lab_MO_01.Size = new System.Drawing.Size(117, 19);
            this.lab_MO_01.TabIndex = 18;
            this.lab_MO_01.Text = "Master Output";
            this.lab_MO_01.UseCustomBackColor = true;
            this.lab_MO_01.UseSelectable = true;
            // 
            // lab_MO_02
            // 
            this.lab_MO_02.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_MO_02.AutoSize = true;
            this.lab_MO_02.BackColor = System.Drawing.Color.Transparent;
            this.lab_MO_02.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_MO_02.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_MO_02.Location = new System.Drawing.Point(87, 28);
            this.lab_MO_02.Name = "lab_MO_02";
            this.lab_MO_02.Size = new System.Drawing.Size(117, 19);
            this.lab_MO_02.TabIndex = 19;
            this.lab_MO_02.Text = "Master Output";
            this.lab_MO_02.UseCustomBackColor = true;
            this.lab_MO_02.UseSelectable = true;
            // 
            // lab_MO_03
            // 
            this.lab_MO_03.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_MO_03.AutoSize = true;
            this.lab_MO_03.BackColor = System.Drawing.Color.Transparent;
            this.lab_MO_03.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_MO_03.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_MO_03.Location = new System.Drawing.Point(87, 53);
            this.lab_MO_03.Name = "lab_MO_03";
            this.lab_MO_03.Size = new System.Drawing.Size(117, 19);
            this.lab_MO_03.TabIndex = 20;
            this.lab_MO_03.Text = "Master Output";
            this.lab_MO_03.UseCustomBackColor = true;
            this.lab_MO_03.UseSelectable = true;
            // 
            // lab_MO_04
            // 
            this.lab_MO_04.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_MO_04.AutoSize = true;
            this.lab_MO_04.BackColor = System.Drawing.Color.Transparent;
            this.lab_MO_04.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_MO_04.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_MO_04.Location = new System.Drawing.Point(87, 78);
            this.lab_MO_04.Name = "lab_MO_04";
            this.lab_MO_04.Size = new System.Drawing.Size(117, 19);
            this.lab_MO_04.TabIndex = 21;
            this.lab_MO_04.Text = "Master Output";
            this.lab_MO_04.UseCustomBackColor = true;
            this.lab_MO_04.UseSelectable = true;
            // 
            // lab_MO_05
            // 
            this.lab_MO_05.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_MO_05.AutoSize = true;
            this.lab_MO_05.BackColor = System.Drawing.Color.Transparent;
            this.lab_MO_05.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_MO_05.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_MO_05.Location = new System.Drawing.Point(87, 103);
            this.lab_MO_05.Name = "lab_MO_05";
            this.lab_MO_05.Size = new System.Drawing.Size(117, 19);
            this.lab_MO_05.TabIndex = 22;
            this.lab_MO_05.Text = "Master Output";
            this.lab_MO_05.UseCustomBackColor = true;
            this.lab_MO_05.UseSelectable = true;
            // 
            // lab_MO_06
            // 
            this.lab_MO_06.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_MO_06.AutoSize = true;
            this.lab_MO_06.BackColor = System.Drawing.Color.Transparent;
            this.lab_MO_06.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_MO_06.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_MO_06.Location = new System.Drawing.Point(87, 128);
            this.lab_MO_06.Name = "lab_MO_06";
            this.lab_MO_06.Size = new System.Drawing.Size(117, 19);
            this.lab_MO_06.TabIndex = 23;
            this.lab_MO_06.Text = "Master Output";
            this.lab_MO_06.UseCustomBackColor = true;
            this.lab_MO_06.UseSelectable = true;
            // 
            // lab_MO_07
            // 
            this.lab_MO_07.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_MO_07.AutoSize = true;
            this.lab_MO_07.BackColor = System.Drawing.Color.Transparent;
            this.lab_MO_07.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_MO_07.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_MO_07.Location = new System.Drawing.Point(87, 153);
            this.lab_MO_07.Name = "lab_MO_07";
            this.lab_MO_07.Size = new System.Drawing.Size(117, 19);
            this.lab_MO_07.TabIndex = 24;
            this.lab_MO_07.Text = "Master Output";
            this.lab_MO_07.UseCustomBackColor = true;
            this.lab_MO_07.UseSelectable = true;
            // 
            // lab_MO_08
            // 
            this.lab_MO_08.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_MO_08.AutoSize = true;
            this.lab_MO_08.BackColor = System.Drawing.Color.Transparent;
            this.lab_MO_08.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_MO_08.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_MO_08.Location = new System.Drawing.Point(87, 178);
            this.lab_MO_08.Name = "lab_MO_08";
            this.lab_MO_08.Size = new System.Drawing.Size(117, 19);
            this.lab_MO_08.TabIndex = 25;
            this.lab_MO_08.Text = "Master Output";
            this.lab_MO_08.UseCustomBackColor = true;
            this.lab_MO_08.UseSelectable = true;
            // 
            // lab_MO_09
            // 
            this.lab_MO_09.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_MO_09.AutoSize = true;
            this.lab_MO_09.BackColor = System.Drawing.Color.Transparent;
            this.lab_MO_09.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_MO_09.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_MO_09.Location = new System.Drawing.Point(87, 203);
            this.lab_MO_09.Name = "lab_MO_09";
            this.lab_MO_09.Size = new System.Drawing.Size(117, 19);
            this.lab_MO_09.TabIndex = 26;
            this.lab_MO_09.Text = "Master Output";
            this.lab_MO_09.UseCustomBackColor = true;
            this.lab_MO_09.UseSelectable = true;
            // 
            // lab_MO_10
            // 
            this.lab_MO_10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_MO_10.AutoSize = true;
            this.lab_MO_10.BackColor = System.Drawing.Color.Transparent;
            this.lab_MO_10.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_MO_10.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_MO_10.Location = new System.Drawing.Point(87, 228);
            this.lab_MO_10.Name = "lab_MO_10";
            this.lab_MO_10.Size = new System.Drawing.Size(117, 19);
            this.lab_MO_10.TabIndex = 27;
            this.lab_MO_10.Text = "Master Output";
            this.lab_MO_10.UseCustomBackColor = true;
            this.lab_MO_10.UseSelectable = true;
            // 
            // lab_MO_11
            // 
            this.lab_MO_11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_MO_11.AutoSize = true;
            this.lab_MO_11.BackColor = System.Drawing.Color.Transparent;
            this.lab_MO_11.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_MO_11.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_MO_11.Location = new System.Drawing.Point(87, 253);
            this.lab_MO_11.Name = "lab_MO_11";
            this.lab_MO_11.Size = new System.Drawing.Size(117, 19);
            this.lab_MO_11.TabIndex = 28;
            this.lab_MO_11.Text = "Master Output";
            this.lab_MO_11.UseCustomBackColor = true;
            this.lab_MO_11.UseSelectable = true;
            // 
            // lab_MO_12
            // 
            this.lab_MO_12.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_MO_12.AutoSize = true;
            this.lab_MO_12.BackColor = System.Drawing.Color.Transparent;
            this.lab_MO_12.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_MO_12.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_MO_12.Location = new System.Drawing.Point(87, 278);
            this.lab_MO_12.Name = "lab_MO_12";
            this.lab_MO_12.Size = new System.Drawing.Size(117, 19);
            this.lab_MO_12.TabIndex = 29;
            this.lab_MO_12.Text = "Master Output";
            this.lab_MO_12.UseSelectable = true;
            // 
            // lab_MO_13
            // 
            this.lab_MO_13.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_MO_13.AutoSize = true;
            this.lab_MO_13.BackColor = System.Drawing.Color.Transparent;
            this.lab_MO_13.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_MO_13.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_MO_13.Location = new System.Drawing.Point(87, 303);
            this.lab_MO_13.Name = "lab_MO_13";
            this.lab_MO_13.Size = new System.Drawing.Size(117, 19);
            this.lab_MO_13.TabIndex = 30;
            this.lab_MO_13.Text = "Master Output";
            this.lab_MO_13.UseSelectable = true;
            // 
            // lab_MO_14
            // 
            this.lab_MO_14.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_MO_14.AutoSize = true;
            this.lab_MO_14.BackColor = System.Drawing.Color.Transparent;
            this.lab_MO_14.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_MO_14.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_MO_14.Location = new System.Drawing.Point(87, 328);
            this.lab_MO_14.Name = "lab_MO_14";
            this.lab_MO_14.Size = new System.Drawing.Size(117, 19);
            this.lab_MO_14.TabIndex = 31;
            this.lab_MO_14.Text = "Master Output";
            this.lab_MO_14.UseSelectable = true;
            // 
            // lab_MO_15
            // 
            this.lab_MO_15.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_MO_15.AutoSize = true;
            this.lab_MO_15.BackColor = System.Drawing.Color.Transparent;
            this.lab_MO_15.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_MO_15.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_MO_15.Location = new System.Drawing.Point(87, 353);
            this.lab_MO_15.Name = "lab_MO_15";
            this.lab_MO_15.Size = new System.Drawing.Size(117, 19);
            this.lab_MO_15.TabIndex = 32;
            this.lab_MO_15.Text = "Master Output";
            this.lab_MO_15.UseSelectable = true;
            // 
            // lab_MO_16
            // 
            this.lab_MO_16.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_MO_16.AutoSize = true;
            this.lab_MO_16.BackColor = System.Drawing.Color.Transparent;
            this.lab_MO_16.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_MO_16.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_MO_16.Location = new System.Drawing.Point(87, 378);
            this.lab_MO_16.Name = "lab_MO_16";
            this.lab_MO_16.Size = new System.Drawing.Size(117, 19);
            this.lab_MO_16.TabIndex = 33;
            this.lab_MO_16.Text = "Master Output";
            this.lab_MO_16.UseSelectable = true;
            // 
            // lab_MO_17
            // 
            this.lab_MO_17.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_MO_17.AutoSize = true;
            this.lab_MO_17.BackColor = System.Drawing.Color.Transparent;
            this.lab_MO_17.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_MO_17.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_MO_17.Location = new System.Drawing.Point(87, 403);
            this.lab_MO_17.Name = "lab_MO_17";
            this.lab_MO_17.Size = new System.Drawing.Size(117, 19);
            this.lab_MO_17.TabIndex = 34;
            this.lab_MO_17.Text = "Master Output";
            this.lab_MO_17.UseSelectable = true;
            // 
            // lab_MO_18
            // 
            this.lab_MO_18.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_MO_18.AutoSize = true;
            this.lab_MO_18.BackColor = System.Drawing.Color.Transparent;
            this.lab_MO_18.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_MO_18.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_MO_18.Location = new System.Drawing.Point(87, 428);
            this.lab_MO_18.Name = "lab_MO_18";
            this.lab_MO_18.Size = new System.Drawing.Size(117, 19);
            this.lab_MO_18.TabIndex = 35;
            this.lab_MO_18.Text = "Master Output";
            this.lab_MO_18.UseSelectable = true;
            // 
            // label_NO_Config
            // 
            this.label_NO_Config.AutoSize = true;
            this.panel_Config.SetColumnSpan(this.label_NO_Config, 4);
            this.label_NO_Config.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_NO_Config.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.label_NO_Config.Location = new System.Drawing.Point(3, 500);
            this.label_NO_Config.Name = "label_NO_Config";
            this.label_NO_Config.Size = new System.Drawing.Size(454, 20);
            this.label_NO_Config.Style = MetroFramework.MetroColorStyle.Red;
            this.label_NO_Config.TabIndex = 37;
            this.label_NO_Config.Text = "Stringa di Configurazione - Assente";
            this.label_NO_Config.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_NO_Config.UseStyleColors = true;
            // 
            // lab_M_01
            // 
            this.lab_M_01.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_M_01.AutoSize = true;
            this.lab_M_01.BackColor = System.Drawing.Color.Transparent;
            this.lab_M_01.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_M_01.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_M_01.Location = new System.Drawing.Point(210, 3);
            this.lab_M_01.Name = "lab_M_01";
            this.lab_M_01.Size = new System.Drawing.Size(94, 19);
            this.lab_M_01.TabIndex = 38;
            this.lab_M_01.Text = "Maintained";
            this.lab_M_01.UseCustomBackColor = true;
            this.lab_M_01.UseSelectable = true;
            // 
            // lab_M_02
            // 
            this.lab_M_02.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_M_02.AutoSize = true;
            this.lab_M_02.BackColor = System.Drawing.Color.Transparent;
            this.lab_M_02.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_M_02.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_M_02.Location = new System.Drawing.Point(210, 28);
            this.lab_M_02.Name = "lab_M_02";
            this.lab_M_02.Size = new System.Drawing.Size(94, 19);
            this.lab_M_02.TabIndex = 39;
            this.lab_M_02.Text = "Maintained";
            this.lab_M_02.UseCustomBackColor = true;
            this.lab_M_02.UseSelectable = true;
            // 
            // lab_M_03
            // 
            this.lab_M_03.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_M_03.AutoSize = true;
            this.lab_M_03.BackColor = System.Drawing.Color.Transparent;
            this.lab_M_03.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_M_03.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_M_03.Location = new System.Drawing.Point(210, 53);
            this.lab_M_03.Name = "lab_M_03";
            this.lab_M_03.Size = new System.Drawing.Size(94, 19);
            this.lab_M_03.TabIndex = 40;
            this.lab_M_03.Text = "Maintained";
            this.lab_M_03.UseCustomBackColor = true;
            this.lab_M_03.UseSelectable = true;
            // 
            // lab_M_04
            // 
            this.lab_M_04.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_M_04.AutoSize = true;
            this.lab_M_04.BackColor = System.Drawing.Color.Transparent;
            this.lab_M_04.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_M_04.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_M_04.Location = new System.Drawing.Point(210, 78);
            this.lab_M_04.Name = "lab_M_04";
            this.lab_M_04.Size = new System.Drawing.Size(94, 19);
            this.lab_M_04.TabIndex = 41;
            this.lab_M_04.Text = "Maintained";
            this.lab_M_04.UseCustomBackColor = true;
            this.lab_M_04.UseSelectable = true;
            // 
            // lab_M_05
            // 
            this.lab_M_05.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_M_05.AutoSize = true;
            this.lab_M_05.BackColor = System.Drawing.Color.Transparent;
            this.lab_M_05.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_M_05.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_M_05.Location = new System.Drawing.Point(210, 103);
            this.lab_M_05.Name = "lab_M_05";
            this.lab_M_05.Size = new System.Drawing.Size(94, 19);
            this.lab_M_05.TabIndex = 42;
            this.lab_M_05.Text = "Maintained";
            this.lab_M_05.UseCustomBackColor = true;
            this.lab_M_05.UseSelectable = true;
            // 
            // lab_M_06
            // 
            this.lab_M_06.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_M_06.AutoSize = true;
            this.lab_M_06.BackColor = System.Drawing.Color.Transparent;
            this.lab_M_06.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_M_06.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_M_06.Location = new System.Drawing.Point(210, 128);
            this.lab_M_06.Name = "lab_M_06";
            this.lab_M_06.Size = new System.Drawing.Size(94, 19);
            this.lab_M_06.TabIndex = 43;
            this.lab_M_06.Text = "Maintained";
            this.lab_M_06.UseCustomBackColor = true;
            this.lab_M_06.UseSelectable = true;
            // 
            // lab_M_07
            // 
            this.lab_M_07.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_M_07.AutoSize = true;
            this.lab_M_07.BackColor = System.Drawing.Color.Transparent;
            this.lab_M_07.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_M_07.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_M_07.Location = new System.Drawing.Point(210, 153);
            this.lab_M_07.Name = "lab_M_07";
            this.lab_M_07.Size = new System.Drawing.Size(94, 19);
            this.lab_M_07.TabIndex = 44;
            this.lab_M_07.Text = "Maintained";
            this.lab_M_07.UseCustomBackColor = true;
            this.lab_M_07.UseSelectable = true;
            // 
            // lab_M_08
            // 
            this.lab_M_08.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_M_08.AutoSize = true;
            this.lab_M_08.BackColor = System.Drawing.Color.Transparent;
            this.lab_M_08.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_M_08.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_M_08.Location = new System.Drawing.Point(210, 178);
            this.lab_M_08.Name = "lab_M_08";
            this.lab_M_08.Size = new System.Drawing.Size(94, 19);
            this.lab_M_08.TabIndex = 45;
            this.lab_M_08.Text = "Maintained";
            this.lab_M_08.UseCustomBackColor = true;
            this.lab_M_08.UseSelectable = true;
            // 
            // lab_M_09
            // 
            this.lab_M_09.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_M_09.AutoSize = true;
            this.lab_M_09.BackColor = System.Drawing.Color.Transparent;
            this.lab_M_09.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_M_09.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_M_09.Location = new System.Drawing.Point(210, 203);
            this.lab_M_09.Name = "lab_M_09";
            this.lab_M_09.Size = new System.Drawing.Size(94, 19);
            this.lab_M_09.TabIndex = 46;
            this.lab_M_09.Text = "Maintained";
            this.lab_M_09.UseCustomBackColor = true;
            this.lab_M_09.UseSelectable = true;
            // 
            // lab_M_10
            // 
            this.lab_M_10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_M_10.AutoSize = true;
            this.lab_M_10.BackColor = System.Drawing.Color.Transparent;
            this.lab_M_10.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_M_10.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_M_10.Location = new System.Drawing.Point(210, 228);
            this.lab_M_10.Name = "lab_M_10";
            this.lab_M_10.Size = new System.Drawing.Size(94, 19);
            this.lab_M_10.TabIndex = 47;
            this.lab_M_10.Text = "Maintained";
            this.lab_M_10.UseCustomBackColor = true;
            this.lab_M_10.UseSelectable = true;
            // 
            // lab_M_11
            // 
            this.lab_M_11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_M_11.AutoSize = true;
            this.lab_M_11.BackColor = System.Drawing.Color.Transparent;
            this.lab_M_11.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_M_11.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_M_11.Location = new System.Drawing.Point(210, 253);
            this.lab_M_11.Name = "lab_M_11";
            this.lab_M_11.Size = new System.Drawing.Size(94, 19);
            this.lab_M_11.TabIndex = 48;
            this.lab_M_11.Text = "Maintained";
            this.lab_M_11.UseCustomBackColor = true;
            this.lab_M_11.UseSelectable = true;
            // 
            // lab_M_12
            // 
            this.lab_M_12.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_M_12.AutoSize = true;
            this.lab_M_12.BackColor = System.Drawing.Color.Transparent;
            this.lab_M_12.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_M_12.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_M_12.Location = new System.Drawing.Point(210, 278);
            this.lab_M_12.Name = "lab_M_12";
            this.lab_M_12.Size = new System.Drawing.Size(94, 19);
            this.lab_M_12.TabIndex = 49;
            this.lab_M_12.Text = "Maintained";
            this.lab_M_12.UseCustomBackColor = true;
            this.lab_M_12.UseSelectable = true;
            // 
            // lab_M_13
            // 
            this.lab_M_13.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_M_13.AutoSize = true;
            this.lab_M_13.BackColor = System.Drawing.Color.Transparent;
            this.lab_M_13.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_M_13.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_M_13.Location = new System.Drawing.Point(210, 303);
            this.lab_M_13.Name = "lab_M_13";
            this.lab_M_13.Size = new System.Drawing.Size(94, 19);
            this.lab_M_13.TabIndex = 50;
            this.lab_M_13.Text = "Maintained";
            this.lab_M_13.UseCustomBackColor = true;
            this.lab_M_13.UseSelectable = true;
            // 
            // lab_M_14
            // 
            this.lab_M_14.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_M_14.AutoSize = true;
            this.lab_M_14.BackColor = System.Drawing.Color.Transparent;
            this.lab_M_14.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_M_14.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_M_14.Location = new System.Drawing.Point(210, 328);
            this.lab_M_14.Name = "lab_M_14";
            this.lab_M_14.Size = new System.Drawing.Size(94, 19);
            this.lab_M_14.TabIndex = 51;
            this.lab_M_14.Text = "Maintained";
            this.lab_M_14.UseCustomBackColor = true;
            this.lab_M_14.UseSelectable = true;
            // 
            // lab_M_15
            // 
            this.lab_M_15.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_M_15.AutoSize = true;
            this.lab_M_15.BackColor = System.Drawing.Color.Transparent;
            this.lab_M_15.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_M_15.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_M_15.Location = new System.Drawing.Point(210, 353);
            this.lab_M_15.Name = "lab_M_15";
            this.lab_M_15.Size = new System.Drawing.Size(94, 19);
            this.lab_M_15.TabIndex = 52;
            this.lab_M_15.Text = "Maintained";
            this.lab_M_15.UseCustomBackColor = true;
            this.lab_M_15.UseSelectable = true;
            // 
            // lab_M_16
            // 
            this.lab_M_16.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_M_16.AutoSize = true;
            this.lab_M_16.BackColor = System.Drawing.Color.Transparent;
            this.lab_M_16.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_M_16.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_M_16.Location = new System.Drawing.Point(210, 378);
            this.lab_M_16.Name = "lab_M_16";
            this.lab_M_16.Size = new System.Drawing.Size(94, 19);
            this.lab_M_16.TabIndex = 53;
            this.lab_M_16.Text = "Maintained";
            this.lab_M_16.UseCustomBackColor = true;
            this.lab_M_16.UseSelectable = true;
            // 
            // lab_M_17
            // 
            this.lab_M_17.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_M_17.AutoSize = true;
            this.lab_M_17.BackColor = System.Drawing.Color.Transparent;
            this.lab_M_17.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_M_17.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_M_17.Location = new System.Drawing.Point(210, 403);
            this.lab_M_17.Name = "lab_M_17";
            this.lab_M_17.Size = new System.Drawing.Size(94, 19);
            this.lab_M_17.TabIndex = 54;
            this.lab_M_17.Text = "Maintained";
            this.lab_M_17.UseCustomBackColor = true;
            this.lab_M_17.UseSelectable = true;
            // 
            // lab_M_18
            // 
            this.lab_M_18.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_M_18.AutoSize = true;
            this.lab_M_18.BackColor = System.Drawing.Color.Transparent;
            this.lab_M_18.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_M_18.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_M_18.Location = new System.Drawing.Point(210, 428);
            this.lab_M_18.Name = "lab_M_18";
            this.lab_M_18.Size = new System.Drawing.Size(94, 19);
            this.lab_M_18.TabIndex = 55;
            this.lab_M_18.Text = "Maintained";
            this.lab_M_18.UseCustomBackColor = true;
            this.lab_M_18.UseSelectable = true;
            // 
            // lab_L_01
            // 
            this.lab_L_01.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_L_01.AutoSize = true;
            this.lab_L_01.BackColor = System.Drawing.Color.Transparent;
            this.lab_L_01.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_L_01.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_L_01.Location = new System.Drawing.Point(310, 3);
            this.lab_L_01.Name = "lab_L_01";
            this.lab_L_01.Size = new System.Drawing.Size(73, 19);
            this.lab_L_01.TabIndex = 56;
            this.lab_L_01.Text = "Latched";
            this.lab_L_01.UseCustomBackColor = true;
            this.lab_L_01.UseSelectable = true;
            // 
            // lab_L_02
            // 
            this.lab_L_02.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_L_02.AutoSize = true;
            this.lab_L_02.BackColor = System.Drawing.Color.Transparent;
            this.lab_L_02.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_L_02.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_L_02.Location = new System.Drawing.Point(310, 28);
            this.lab_L_02.Name = "lab_L_02";
            this.lab_L_02.Size = new System.Drawing.Size(73, 19);
            this.lab_L_02.TabIndex = 57;
            this.lab_L_02.Text = "Latched";
            this.lab_L_02.UseCustomBackColor = true;
            this.lab_L_02.UseSelectable = true;
            // 
            // lab_L_03
            // 
            this.lab_L_03.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_L_03.AutoSize = true;
            this.lab_L_03.BackColor = System.Drawing.Color.Transparent;
            this.lab_L_03.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_L_03.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_L_03.Location = new System.Drawing.Point(310, 53);
            this.lab_L_03.Name = "lab_L_03";
            this.lab_L_03.Size = new System.Drawing.Size(73, 19);
            this.lab_L_03.TabIndex = 58;
            this.lab_L_03.Text = "Latched";
            this.lab_L_03.UseCustomBackColor = true;
            this.lab_L_03.UseSelectable = true;
            // 
            // lab_L_04
            // 
            this.lab_L_04.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_L_04.AutoSize = true;
            this.lab_L_04.BackColor = System.Drawing.Color.Transparent;
            this.lab_L_04.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_L_04.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_L_04.Location = new System.Drawing.Point(310, 78);
            this.lab_L_04.Name = "lab_L_04";
            this.lab_L_04.Size = new System.Drawing.Size(73, 19);
            this.lab_L_04.TabIndex = 59;
            this.lab_L_04.Text = "Latched";
            this.lab_L_04.UseCustomBackColor = true;
            this.lab_L_04.UseSelectable = true;
            // 
            // lab_L_05
            // 
            this.lab_L_05.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_L_05.AutoSize = true;
            this.lab_L_05.BackColor = System.Drawing.Color.Transparent;
            this.lab_L_05.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_L_05.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_L_05.Location = new System.Drawing.Point(310, 103);
            this.lab_L_05.Name = "lab_L_05";
            this.lab_L_05.Size = new System.Drawing.Size(73, 19);
            this.lab_L_05.TabIndex = 60;
            this.lab_L_05.Text = "Latched";
            this.lab_L_05.UseCustomBackColor = true;
            this.lab_L_05.UseSelectable = true;
            // 
            // lab_L_06
            // 
            this.lab_L_06.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_L_06.AutoSize = true;
            this.lab_L_06.BackColor = System.Drawing.Color.Transparent;
            this.lab_L_06.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_L_06.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_L_06.Location = new System.Drawing.Point(310, 128);
            this.lab_L_06.Name = "lab_L_06";
            this.lab_L_06.Size = new System.Drawing.Size(73, 19);
            this.lab_L_06.TabIndex = 61;
            this.lab_L_06.Text = "Latched";
            this.lab_L_06.UseCustomBackColor = true;
            this.lab_L_06.UseSelectable = true;
            // 
            // lab_L_07
            // 
            this.lab_L_07.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_L_07.AutoSize = true;
            this.lab_L_07.BackColor = System.Drawing.Color.Transparent;
            this.lab_L_07.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_L_07.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_L_07.Location = new System.Drawing.Point(310, 153);
            this.lab_L_07.Name = "lab_L_07";
            this.lab_L_07.Size = new System.Drawing.Size(73, 19);
            this.lab_L_07.TabIndex = 62;
            this.lab_L_07.Text = "Latched";
            this.lab_L_07.UseCustomBackColor = true;
            this.lab_L_07.UseSelectable = true;
            // 
            // lab_L_08
            // 
            this.lab_L_08.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_L_08.AutoSize = true;
            this.lab_L_08.BackColor = System.Drawing.Color.Transparent;
            this.lab_L_08.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_L_08.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_L_08.Location = new System.Drawing.Point(310, 178);
            this.lab_L_08.Name = "lab_L_08";
            this.lab_L_08.Size = new System.Drawing.Size(73, 19);
            this.lab_L_08.TabIndex = 63;
            this.lab_L_08.Text = "Latched";
            this.lab_L_08.UseCustomBackColor = true;
            this.lab_L_08.UseSelectable = true;
            // 
            // lab_L_09
            // 
            this.lab_L_09.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_L_09.AutoSize = true;
            this.lab_L_09.BackColor = System.Drawing.Color.Transparent;
            this.lab_L_09.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_L_09.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_L_09.Location = new System.Drawing.Point(310, 203);
            this.lab_L_09.Name = "lab_L_09";
            this.lab_L_09.Size = new System.Drawing.Size(73, 19);
            this.lab_L_09.TabIndex = 64;
            this.lab_L_09.Text = "Latched";
            this.lab_L_09.UseCustomBackColor = true;
            this.lab_L_09.UseSelectable = true;
            // 
            // lab_L_10
            // 
            this.lab_L_10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_L_10.AutoSize = true;
            this.lab_L_10.BackColor = System.Drawing.Color.Transparent;
            this.lab_L_10.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_L_10.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_L_10.Location = new System.Drawing.Point(310, 228);
            this.lab_L_10.Name = "lab_L_10";
            this.lab_L_10.Size = new System.Drawing.Size(73, 19);
            this.lab_L_10.TabIndex = 65;
            this.lab_L_10.Text = "Latched";
            this.lab_L_10.UseCustomBackColor = true;
            this.lab_L_10.UseSelectable = true;
            // 
            // lab_L_11
            // 
            this.lab_L_11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_L_11.AutoSize = true;
            this.lab_L_11.BackColor = System.Drawing.Color.Transparent;
            this.lab_L_11.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_L_11.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_L_11.Location = new System.Drawing.Point(310, 253);
            this.lab_L_11.Name = "lab_L_11";
            this.lab_L_11.Size = new System.Drawing.Size(73, 19);
            this.lab_L_11.TabIndex = 66;
            this.lab_L_11.Text = "Latched";
            this.lab_L_11.UseCustomBackColor = true;
            this.lab_L_11.UseSelectable = true;
            // 
            // lab_L_12
            // 
            this.lab_L_12.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_L_12.AutoSize = true;
            this.lab_L_12.BackColor = System.Drawing.Color.Transparent;
            this.lab_L_12.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_L_12.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_L_12.Location = new System.Drawing.Point(310, 278);
            this.lab_L_12.Name = "lab_L_12";
            this.lab_L_12.Size = new System.Drawing.Size(73, 19);
            this.lab_L_12.TabIndex = 67;
            this.lab_L_12.Text = "Latched";
            this.lab_L_12.UseCustomBackColor = true;
            this.lab_L_12.UseSelectable = true;
            // 
            // lab_L_13
            // 
            this.lab_L_13.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_L_13.AutoSize = true;
            this.lab_L_13.BackColor = System.Drawing.Color.Transparent;
            this.lab_L_13.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_L_13.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_L_13.Location = new System.Drawing.Point(310, 303);
            this.lab_L_13.Name = "lab_L_13";
            this.lab_L_13.Size = new System.Drawing.Size(73, 19);
            this.lab_L_13.TabIndex = 68;
            this.lab_L_13.Text = "Latched";
            this.lab_L_13.UseCustomBackColor = true;
            this.lab_L_13.UseSelectable = true;
            // 
            // lab_L_14
            // 
            this.lab_L_14.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_L_14.AutoSize = true;
            this.lab_L_14.BackColor = System.Drawing.Color.Transparent;
            this.lab_L_14.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_L_14.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_L_14.Location = new System.Drawing.Point(310, 328);
            this.lab_L_14.Name = "lab_L_14";
            this.lab_L_14.Size = new System.Drawing.Size(73, 19);
            this.lab_L_14.TabIndex = 69;
            this.lab_L_14.Text = "Latched";
            this.lab_L_14.UseCustomBackColor = true;
            this.lab_L_14.UseSelectable = true;
            // 
            // lab_L_15
            // 
            this.lab_L_15.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_L_15.AutoSize = true;
            this.lab_L_15.BackColor = System.Drawing.Color.Transparent;
            this.lab_L_15.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_L_15.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_L_15.Location = new System.Drawing.Point(310, 353);
            this.lab_L_15.Name = "lab_L_15";
            this.lab_L_15.Size = new System.Drawing.Size(73, 19);
            this.lab_L_15.TabIndex = 70;
            this.lab_L_15.Text = "Latched";
            this.lab_L_15.UseCustomBackColor = true;
            this.lab_L_15.UseSelectable = true;
            // 
            // lab_L_16
            // 
            this.lab_L_16.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_L_16.AutoSize = true;
            this.lab_L_16.BackColor = System.Drawing.Color.Transparent;
            this.lab_L_16.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_L_16.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_L_16.Location = new System.Drawing.Point(310, 378);
            this.lab_L_16.Name = "lab_L_16";
            this.lab_L_16.Size = new System.Drawing.Size(73, 19);
            this.lab_L_16.TabIndex = 71;
            this.lab_L_16.Text = "Latched";
            this.lab_L_16.UseCustomBackColor = true;
            this.lab_L_16.UseSelectable = true;
            // 
            // lab_L_17
            // 
            this.lab_L_17.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_L_17.AutoSize = true;
            this.lab_L_17.BackColor = System.Drawing.Color.Transparent;
            this.lab_L_17.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_L_17.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_L_17.Location = new System.Drawing.Point(310, 403);
            this.lab_L_17.Name = "lab_L_17";
            this.lab_L_17.Size = new System.Drawing.Size(73, 19);
            this.lab_L_17.TabIndex = 72;
            this.lab_L_17.Text = "Latched";
            this.lab_L_17.UseCustomBackColor = true;
            this.lab_L_17.UseSelectable = true;
            // 
            // lab_L_18
            // 
            this.lab_L_18.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_L_18.AutoSize = true;
            this.lab_L_18.BackColor = System.Drawing.Color.Transparent;
            this.lab_L_18.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_L_18.FontSize = MetroFramework.MetroCheckBoxSize.Medium;
            this.lab_L_18.Location = new System.Drawing.Point(310, 428);
            this.lab_L_18.Name = "lab_L_18";
            this.lab_L_18.Size = new System.Drawing.Size(73, 19);
            this.lab_L_18.TabIndex = 73;
            this.lab_L_18.Text = "Latched";
            this.lab_L_18.UseCustomBackColor = true;
            this.lab_L_18.UseSelectable = true;
            // 
            // metroLabel1
            // 
            this.metroLabel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.Location = new System.Drawing.Point(3, 453);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(72, 19);
            this.metroLabel1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel1.TabIndex = 74;
            this.metroLabel1.Text = "Time-Out";
            this.metroLabel1.UseStyleColors = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.Location = new System.Drawing.Point(3, 478);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(78, 19);
            this.metroLabel2.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel2.TabIndex = 75;
            this.metroLabel2.Text = "Frequency";
            this.metroLabel2.UseStyleColors = true;
            // 
            // lab_TimeOut
            // 
            this.lab_TimeOut.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_TimeOut.AutoSize = true;
            this.panel_Config.SetColumnSpan(this.lab_TimeOut, 3);
            this.lab_TimeOut.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_TimeOut.Location = new System.Drawing.Point(87, 453);
            this.lab_TimeOut.Name = "lab_TimeOut";
            this.lab_TimeOut.Size = new System.Drawing.Size(86, 19);
            this.lab_TimeOut.TabIndex = 76;
            this.lab_TimeOut.Text = "lab_TimeOut";
            // 
            // lab_Frequency
            // 
            this.lab_Frequency.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_Frequency.AutoSize = true;
            this.panel_Config.SetColumnSpan(this.lab_Frequency, 3);
            this.lab_Frequency.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_Frequency.Location = new System.Drawing.Point(87, 478);
            this.lab_Frequency.Name = "lab_Frequency";
            this.lab_Frequency.Size = new System.Drawing.Size(96, 19);
            this.lab_Frequency.TabIndex = 77;
            this.lab_Frequency.Text = "lab_Frequency";
            // 
            // UC_ViewConfig
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SmartLineProduction.Properties.Resources.Icona_AV_Programma_Enable;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.BackImage = global::SmartLineProduction.Properties.Resources.Icona_AV_Programma_Enable;
            this.BackLocation = MetroFramework.Forms.BackLocation.BottomLeft;
            this.ClientSize = new System.Drawing.Size(500, 600);
            this.Controls.Add(this.panel_Config);
            this.Name = "UC_ViewConfig";
            this.ShowIcon = false;
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "Visualizza Configurazione";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.UC_ViewConfig_Load);
            this.panel_Config.ResumeLayout(false);
            this.panel_Config.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel panel_Config;
        private MetroFramework.Controls.MetroLabel lab_out_01;
        private MetroFramework.Controls.MetroLabel lab_out_02;
        private MetroFramework.Controls.MetroLabel lab_out_03;
        private MetroFramework.Controls.MetroLabel lab_out_04;
        private MetroFramework.Controls.MetroLabel lab_out_05;
        private MetroFramework.Controls.MetroLabel lab_out_06;
        private MetroFramework.Controls.MetroLabel lab_out_07;
        private MetroFramework.Controls.MetroLabel lab_out_08;
        private MetroFramework.Controls.MetroLabel lab_out_09;
        private MetroFramework.Controls.MetroLabel lab_out_10;
        private MetroFramework.Controls.MetroLabel lab_out_11;
        private MetroFramework.Controls.MetroLabel lab_out_12;
        private MetroFramework.Controls.MetroLabel lab_out_13;
        private MetroFramework.Controls.MetroLabel lab_out_14;
        private MetroFramework.Controls.MetroLabel lab_out_15;
        private MetroFramework.Controls.MetroLabel lab_out_16;
        private MetroFramework.Controls.MetroLabel lab_out_17;
        private MetroFramework.Controls.MetroLabel lab_out_18;
        private MetroFramework.Controls.MetroCheckBox lab_MO_01;
        private MetroFramework.Controls.MetroCheckBox lab_MO_02;
        private MetroFramework.Controls.MetroCheckBox lab_MO_03;
        private MetroFramework.Controls.MetroCheckBox lab_MO_04;
        private MetroFramework.Controls.MetroCheckBox lab_MO_05;
        private MetroFramework.Controls.MetroCheckBox lab_MO_06;
        private MetroFramework.Controls.MetroCheckBox lab_MO_07;
        private MetroFramework.Controls.MetroCheckBox lab_MO_08;
        private MetroFramework.Controls.MetroCheckBox lab_MO_09;
        private MetroFramework.Controls.MetroCheckBox lab_MO_10;
        private MetroFramework.Controls.MetroCheckBox lab_MO_11;
        private MetroFramework.Controls.MetroCheckBox lab_MO_12;
        private MetroFramework.Controls.MetroCheckBox lab_MO_13;
        private MetroFramework.Controls.MetroCheckBox lab_MO_14;
        private MetroFramework.Controls.MetroCheckBox lab_MO_15;
        private MetroFramework.Controls.MetroCheckBox lab_MO_16;
        private MetroFramework.Controls.MetroCheckBox lab_MO_17;
        private MetroFramework.Controls.MetroCheckBox lab_MO_18;
        private MetroFramework.Controls.MetroLabel label_NO_Config;
        private MetroFramework.Controls.MetroCheckBox lab_M_01;
        private MetroFramework.Controls.MetroCheckBox lab_M_02;
        private MetroFramework.Controls.MetroCheckBox lab_M_03;
        private MetroFramework.Controls.MetroCheckBox lab_M_04;
        private MetroFramework.Controls.MetroCheckBox lab_M_05;
        private MetroFramework.Controls.MetroCheckBox lab_M_06;
        private MetroFramework.Controls.MetroCheckBox lab_M_07;
        private MetroFramework.Controls.MetroCheckBox lab_M_08;
        private MetroFramework.Controls.MetroCheckBox lab_M_09;
        private MetroFramework.Controls.MetroCheckBox lab_M_10;
        private MetroFramework.Controls.MetroCheckBox lab_M_11;
        private MetroFramework.Controls.MetroCheckBox lab_M_12;
        private MetroFramework.Controls.MetroCheckBox lab_M_13;
        private MetroFramework.Controls.MetroCheckBox lab_M_14;
        private MetroFramework.Controls.MetroCheckBox lab_M_15;
        private MetroFramework.Controls.MetroCheckBox lab_M_16;
        private MetroFramework.Controls.MetroCheckBox lab_M_17;
        private MetroFramework.Controls.MetroCheckBox lab_M_18;
        private MetroFramework.Controls.MetroCheckBox lab_L_01;
        private MetroFramework.Controls.MetroCheckBox lab_L_02;
        private MetroFramework.Controls.MetroCheckBox lab_L_03;
        private MetroFramework.Controls.MetroCheckBox lab_L_04;
        private MetroFramework.Controls.MetroCheckBox lab_L_05;
        private MetroFramework.Controls.MetroCheckBox lab_L_06;
        private MetroFramework.Controls.MetroCheckBox lab_L_07;
        private MetroFramework.Controls.MetroCheckBox lab_L_08;
        private MetroFramework.Controls.MetroCheckBox lab_L_09;
        private MetroFramework.Controls.MetroCheckBox lab_L_10;
        private MetroFramework.Controls.MetroCheckBox lab_L_11;
        private MetroFramework.Controls.MetroCheckBox lab_L_12;
        private MetroFramework.Controls.MetroCheckBox lab_L_13;
        private MetroFramework.Controls.MetroCheckBox lab_L_14;
        private MetroFramework.Controls.MetroCheckBox lab_L_15;
        private MetroFramework.Controls.MetroCheckBox lab_L_16;
        private MetroFramework.Controls.MetroCheckBox lab_L_17;
        private MetroFramework.Controls.MetroCheckBox lab_L_18;
        private MetroFramework.Controls.MetroLabel lab_Frequency;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel lab_TimeOut;
    }
}