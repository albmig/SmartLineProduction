﻿
namespace SmartLineProduction
{
    partial class Prova
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            this.metroGrid1 = new MetroFramework.Controls.MetroGrid();
            this.ds_SL_History = new SmartLineProduction.ds_SL_History();
            this.sFClientiSerialNumbersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_Clienti_SerialNumbersTableAdapter = new SmartLineProduction.ds_SL_HistoryTableAdapters.SF_Clienti_SerialNumbersTableAdapter();
            this.mastroDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.capocDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sottocDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codAnagraficoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ragSocCognomeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ragSocNomeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ragSocCompletaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.indirizzoFiscaleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroGrid2 = new MetroFramework.Controls.MetroGrid();
            this.sFClientiSerialNumbersSerialNumbersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.serialNumbersTableAdapter = new SmartLineProduction.ds_SL_HistoryTableAdapters.SerialNumbersTableAdapter();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serKitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serIDCliDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serDeviceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serDeviceIDCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serOfficialSerialDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serReadSerialDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serSWCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serSWCodeRevDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serSWStdTypeDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.serSNprodDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serCommessaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serDateProductionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serSpeditoDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.serDataSpeditoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serSubstitionIDReadSerialDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serNoteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroGrid3 = new MetroFramework.Controls.MetroGrid();
            this.serialNumbersFirmwareBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.firmwareTableAdapter = new SmartLineProduction.ds_SL_HistoryTableAdapters.FirmwareTableAdapter();
            this.idDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWTipoDeviceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWDescrizioneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWDescrizioneENDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWVersioneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWRevisioneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWStandardDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWFamProdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWPOptRFDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWPOptUseOledDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPOptUseEmButtDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPOptUseBacklightDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPOptShiftPageDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPOptUseAccelDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPOptUseSPDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPOptUseBuzzerDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPOptUseVibracallDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPOptUseLedTorchDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPPLDDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPOptMaxPairDevicesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWROptRFDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWROptPlugExpDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWROptPlugPleDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWROptEmKeybDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWROptCanDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWROptPropOutDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWROptTimeOutDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWROptContKeysDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWROptLockSameRowDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWROptUseSPDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWROptMaxPairDevicesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWROptShiftPageDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWROptOutputNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWROptDigInputNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWROptAnaInputNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWRevisioniDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWFunzionamentoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWConfigDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWObsoleteverDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWObsoleteverfromdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroGrid4 = new MetroFramework.Controls.MetroGrid();
            this.serialNumbersLastFirmwareBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lastFirmwareTableAdapter = new SmartLineProduction.ds_SL_HistoryTableAdapters.LastFirmwareTableAdapter();
            this.idDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWCodeDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWTipoDeviceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWDescrizioneDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWDescrizioneENDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWVersioneDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWRevisioneDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWStandardDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWFamProdDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWPOptRFDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWPOptUseOledDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPOptUseEmButtDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPOptUseBacklightDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPOptShiftPageDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPOptUseAccelDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPOptUseSPDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPOptUseBuzzerDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPOptUseVibracallDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPOptUseLedTorchDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPPLDDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWPOptMaxPairDevicesDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWROptRFDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWROptPlugExpDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWROptPlugPleDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWROptEmKeybDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWROptCanDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWROptPropOutDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWROptTimeOutDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWROptContKeysDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWROptLockSameRowDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWROptUseSPDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWROptMaxPairDevicesDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWROptShiftPageDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWROptOutputNoDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWROptDigInputNoDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWROptAnaInputNoDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWRevisioniDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWFunzionamentoDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWConfigDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWObsoleteverDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWObsoleteverfromdateDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroGrid5 = new MetroFramework.Controls.MetroGrid();
            this.serialNumbersSerialNumbersObsoleteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.serialNumbers_ObsoleteTableAdapter = new SmartLineProduction.ds_SL_HistoryTableAdapters.SerialNumbers_ObsoleteTableAdapter();
            this.serKitDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serIDCliDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serDeviceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serDeviceIDCodeDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serOfficialSerialDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serReadSerialDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serSWCodeDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serSWCodeRevDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serSWStdTypeDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.serSNprodDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serCommessaDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serDateProductionDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serSpeditoDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.serDataSpeditoDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serSubstitionIDReadSerialDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serNoteDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serObsoleteFromDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroGrid6 = new MetroFramework.Controls.MetroGrid();
            this.serialNumbersBSSNHistoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bS_SN_HistoryTableAdapter = new SmartLineProduction.ds_SL_HistoryTableAdapters.BS_SN_HistoryTableAdapter();
            this.serialnumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.versionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.revisionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.useridDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.deviceidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.createdatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.extrasDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.useremailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL_History)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFClientiSerialNumbersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFClientiSerialNumbersSerialNumbersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.serialNumbersFirmwareBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.serialNumbersLastFirmwareBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.serialNumbersSerialNumbersObsoleteBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.serialNumbersBSSNHistoryBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // metroGrid1
            // 
            this.metroGrid1.AllowUserToResizeRows = false;
            this.metroGrid1.AutoGenerateColumns = false;
            this.metroGrid1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.metroGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mastroDataGridViewTextBoxColumn,
            this.capocDataGridViewTextBoxColumn,
            this.contoDataGridViewTextBoxColumn,
            this.sottocDataGridViewTextBoxColumn,
            this.codAnagraficoDataGridViewTextBoxColumn,
            this.ragSocCognomeDataGridViewTextBoxColumn,
            this.ragSocNomeDataGridViewTextBoxColumn,
            this.ragSocCompletaDataGridViewTextBoxColumn,
            this.indirizzoFiscaleDataGridViewTextBoxColumn});
            this.metroGrid1.DataSource = this.sFClientiSerialNumbersBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid1.DefaultCellStyle = dataGridViewCellStyle2;
            this.metroGrid1.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroGrid1.EnableHeadersVisualStyles = false;
            this.metroGrid1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.Location = new System.Drawing.Point(0, 0);
            this.metroGrid1.Name = "metroGrid1";
            this.metroGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.metroGrid1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid1.Size = new System.Drawing.Size(800, 150);
            this.metroGrid1.TabIndex = 0;
            // 
            // ds_SL_History
            // 
            this.ds_SL_History.DataSetName = "ds_SL_History";
            this.ds_SL_History.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sFClientiSerialNumbersBindingSource
            // 
            this.sFClientiSerialNumbersBindingSource.DataMember = "SF_Clienti_SerialNumbers";
            this.sFClientiSerialNumbersBindingSource.DataSource = this.ds_SL_History;
            this.sFClientiSerialNumbersBindingSource.Sort = "RagSocCognome ASC";
            // 
            // sF_Clienti_SerialNumbersTableAdapter
            // 
            this.sF_Clienti_SerialNumbersTableAdapter.ClearBeforeFill = true;
            // 
            // mastroDataGridViewTextBoxColumn
            // 
            this.mastroDataGridViewTextBoxColumn.DataPropertyName = "Mastro";
            this.mastroDataGridViewTextBoxColumn.HeaderText = "Mastro";
            this.mastroDataGridViewTextBoxColumn.Name = "mastroDataGridViewTextBoxColumn";
            // 
            // capocDataGridViewTextBoxColumn
            // 
            this.capocDataGridViewTextBoxColumn.DataPropertyName = "Capoc";
            this.capocDataGridViewTextBoxColumn.HeaderText = "Capoc";
            this.capocDataGridViewTextBoxColumn.Name = "capocDataGridViewTextBoxColumn";
            // 
            // contoDataGridViewTextBoxColumn
            // 
            this.contoDataGridViewTextBoxColumn.DataPropertyName = "Conto";
            this.contoDataGridViewTextBoxColumn.HeaderText = "Conto";
            this.contoDataGridViewTextBoxColumn.Name = "contoDataGridViewTextBoxColumn";
            // 
            // sottocDataGridViewTextBoxColumn
            // 
            this.sottocDataGridViewTextBoxColumn.DataPropertyName = "Sottoc";
            this.sottocDataGridViewTextBoxColumn.HeaderText = "Sottoc";
            this.sottocDataGridViewTextBoxColumn.Name = "sottocDataGridViewTextBoxColumn";
            // 
            // codAnagraficoDataGridViewTextBoxColumn
            // 
            this.codAnagraficoDataGridViewTextBoxColumn.DataPropertyName = "CodAnagrafico";
            this.codAnagraficoDataGridViewTextBoxColumn.HeaderText = "CodAnagrafico";
            this.codAnagraficoDataGridViewTextBoxColumn.Name = "codAnagraficoDataGridViewTextBoxColumn";
            // 
            // ragSocCognomeDataGridViewTextBoxColumn
            // 
            this.ragSocCognomeDataGridViewTextBoxColumn.DataPropertyName = "RagSocCognome";
            this.ragSocCognomeDataGridViewTextBoxColumn.HeaderText = "RagSocCognome";
            this.ragSocCognomeDataGridViewTextBoxColumn.Name = "ragSocCognomeDataGridViewTextBoxColumn";
            // 
            // ragSocNomeDataGridViewTextBoxColumn
            // 
            this.ragSocNomeDataGridViewTextBoxColumn.DataPropertyName = "RagSocNome";
            this.ragSocNomeDataGridViewTextBoxColumn.HeaderText = "RagSocNome";
            this.ragSocNomeDataGridViewTextBoxColumn.Name = "ragSocNomeDataGridViewTextBoxColumn";
            // 
            // ragSocCompletaDataGridViewTextBoxColumn
            // 
            this.ragSocCompletaDataGridViewTextBoxColumn.DataPropertyName = "RagSocCompleta";
            this.ragSocCompletaDataGridViewTextBoxColumn.HeaderText = "RagSocCompleta";
            this.ragSocCompletaDataGridViewTextBoxColumn.Name = "ragSocCompletaDataGridViewTextBoxColumn";
            // 
            // indirizzoFiscaleDataGridViewTextBoxColumn
            // 
            this.indirizzoFiscaleDataGridViewTextBoxColumn.DataPropertyName = "IndirizzoFiscale";
            this.indirizzoFiscaleDataGridViewTextBoxColumn.HeaderText = "IndirizzoFiscale";
            this.indirizzoFiscaleDataGridViewTextBoxColumn.Name = "indirizzoFiscaleDataGridViewTextBoxColumn";
            // 
            // metroGrid2
            // 
            this.metroGrid2.AllowUserToResizeRows = false;
            this.metroGrid2.AutoGenerateColumns = false;
            this.metroGrid2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(85)))), ((int)(((byte)(85)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.metroGrid2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.serKitDataGridViewTextBoxColumn,
            this.serIDCliDataGridViewTextBoxColumn,
            this.serDeviceDataGridViewTextBoxColumn,
            this.serDeviceIDCodeDataGridViewTextBoxColumn,
            this.serOfficialSerialDataGridViewTextBoxColumn,
            this.serReadSerialDataGridViewTextBoxColumn,
            this.serSWCodeDataGridViewTextBoxColumn,
            this.serSWCodeRevDataGridViewTextBoxColumn,
            this.serSWStdTypeDataGridViewCheckBoxColumn,
            this.serSNprodDataGridViewTextBoxColumn,
            this.serCommessaDataGridViewTextBoxColumn,
            this.serDateProductionDataGridViewTextBoxColumn,
            this.serSpeditoDataGridViewCheckBoxColumn,
            this.serDataSpeditoDataGridViewTextBoxColumn,
            this.serSubstitionIDReadSerialDataGridViewTextBoxColumn,
            this.serNoteDataGridViewTextBoxColumn});
            this.metroGrid2.DataSource = this.sFClientiSerialNumbersSerialNumbersBindingSource;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid2.DefaultCellStyle = dataGridViewCellStyle5;
            this.metroGrid2.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroGrid2.EnableHeadersVisualStyles = false;
            this.metroGrid2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid2.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid2.Location = new System.Drawing.Point(0, 150);
            this.metroGrid2.Name = "metroGrid2";
            this.metroGrid2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(85)))), ((int)(((byte)(85)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid2.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.metroGrid2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid2.Size = new System.Drawing.Size(800, 150);
            this.metroGrid2.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroGrid2.TabIndex = 1;
            // 
            // sFClientiSerialNumbersSerialNumbersBindingSource
            // 
            this.sFClientiSerialNumbersSerialNumbersBindingSource.DataMember = "SF_Clienti_SerialNumbers_SerialNumbers";
            this.sFClientiSerialNumbersSerialNumbersBindingSource.DataSource = this.sFClientiSerialNumbersBindingSource;
            // 
            // serialNumbersTableAdapter
            // 
            this.serialNumbersTableAdapter.ClearBeforeFill = true;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // serKitDataGridViewTextBoxColumn
            // 
            this.serKitDataGridViewTextBoxColumn.DataPropertyName = "Ser_Kit";
            this.serKitDataGridViewTextBoxColumn.HeaderText = "Ser_Kit";
            this.serKitDataGridViewTextBoxColumn.Name = "serKitDataGridViewTextBoxColumn";
            // 
            // serIDCliDataGridViewTextBoxColumn
            // 
            this.serIDCliDataGridViewTextBoxColumn.DataPropertyName = "Ser_ID_Cli";
            this.serIDCliDataGridViewTextBoxColumn.HeaderText = "Ser_ID_Cli";
            this.serIDCliDataGridViewTextBoxColumn.Name = "serIDCliDataGridViewTextBoxColumn";
            // 
            // serDeviceDataGridViewTextBoxColumn
            // 
            this.serDeviceDataGridViewTextBoxColumn.DataPropertyName = "Ser_Device";
            this.serDeviceDataGridViewTextBoxColumn.HeaderText = "Ser_Device";
            this.serDeviceDataGridViewTextBoxColumn.Name = "serDeviceDataGridViewTextBoxColumn";
            // 
            // serDeviceIDCodeDataGridViewTextBoxColumn
            // 
            this.serDeviceIDCodeDataGridViewTextBoxColumn.DataPropertyName = "Ser_Device_ID_Code";
            this.serDeviceIDCodeDataGridViewTextBoxColumn.HeaderText = "Ser_Device_ID_Code";
            this.serDeviceIDCodeDataGridViewTextBoxColumn.Name = "serDeviceIDCodeDataGridViewTextBoxColumn";
            // 
            // serOfficialSerialDataGridViewTextBoxColumn
            // 
            this.serOfficialSerialDataGridViewTextBoxColumn.DataPropertyName = "Ser_OfficialSerial";
            this.serOfficialSerialDataGridViewTextBoxColumn.HeaderText = "Ser_OfficialSerial";
            this.serOfficialSerialDataGridViewTextBoxColumn.Name = "serOfficialSerialDataGridViewTextBoxColumn";
            // 
            // serReadSerialDataGridViewTextBoxColumn
            // 
            this.serReadSerialDataGridViewTextBoxColumn.DataPropertyName = "Ser_ReadSerial";
            this.serReadSerialDataGridViewTextBoxColumn.HeaderText = "Ser_ReadSerial";
            this.serReadSerialDataGridViewTextBoxColumn.Name = "serReadSerialDataGridViewTextBoxColumn";
            // 
            // serSWCodeDataGridViewTextBoxColumn
            // 
            this.serSWCodeDataGridViewTextBoxColumn.DataPropertyName = "Ser_SW_Code";
            this.serSWCodeDataGridViewTextBoxColumn.HeaderText = "Ser_SW_Code";
            this.serSWCodeDataGridViewTextBoxColumn.Name = "serSWCodeDataGridViewTextBoxColumn";
            // 
            // serSWCodeRevDataGridViewTextBoxColumn
            // 
            this.serSWCodeRevDataGridViewTextBoxColumn.DataPropertyName = "Ser_SW_Code_Rev";
            this.serSWCodeRevDataGridViewTextBoxColumn.HeaderText = "Ser_SW_Code_Rev";
            this.serSWCodeRevDataGridViewTextBoxColumn.Name = "serSWCodeRevDataGridViewTextBoxColumn";
            // 
            // serSWStdTypeDataGridViewCheckBoxColumn
            // 
            this.serSWStdTypeDataGridViewCheckBoxColumn.DataPropertyName = "Ser_SW_Std_Type";
            this.serSWStdTypeDataGridViewCheckBoxColumn.HeaderText = "Ser_SW_Std_Type";
            this.serSWStdTypeDataGridViewCheckBoxColumn.Name = "serSWStdTypeDataGridViewCheckBoxColumn";
            // 
            // serSNprodDataGridViewTextBoxColumn
            // 
            this.serSNprodDataGridViewTextBoxColumn.DataPropertyName = "Ser_SN_prod";
            this.serSNprodDataGridViewTextBoxColumn.HeaderText = "Ser_SN_prod";
            this.serSNprodDataGridViewTextBoxColumn.Name = "serSNprodDataGridViewTextBoxColumn";
            // 
            // serCommessaDataGridViewTextBoxColumn
            // 
            this.serCommessaDataGridViewTextBoxColumn.DataPropertyName = "Ser_Commessa";
            this.serCommessaDataGridViewTextBoxColumn.HeaderText = "Ser_Commessa";
            this.serCommessaDataGridViewTextBoxColumn.Name = "serCommessaDataGridViewTextBoxColumn";
            // 
            // serDateProductionDataGridViewTextBoxColumn
            // 
            this.serDateProductionDataGridViewTextBoxColumn.DataPropertyName = "Ser_DateProduction";
            this.serDateProductionDataGridViewTextBoxColumn.HeaderText = "Ser_DateProduction";
            this.serDateProductionDataGridViewTextBoxColumn.Name = "serDateProductionDataGridViewTextBoxColumn";
            // 
            // serSpeditoDataGridViewCheckBoxColumn
            // 
            this.serSpeditoDataGridViewCheckBoxColumn.DataPropertyName = "Ser_Spedito";
            this.serSpeditoDataGridViewCheckBoxColumn.HeaderText = "Ser_Spedito";
            this.serSpeditoDataGridViewCheckBoxColumn.Name = "serSpeditoDataGridViewCheckBoxColumn";
            // 
            // serDataSpeditoDataGridViewTextBoxColumn
            // 
            this.serDataSpeditoDataGridViewTextBoxColumn.DataPropertyName = "Ser_Data_Spedito";
            this.serDataSpeditoDataGridViewTextBoxColumn.HeaderText = "Ser_Data_Spedito";
            this.serDataSpeditoDataGridViewTextBoxColumn.Name = "serDataSpeditoDataGridViewTextBoxColumn";
            // 
            // serSubstitionIDReadSerialDataGridViewTextBoxColumn
            // 
            this.serSubstitionIDReadSerialDataGridViewTextBoxColumn.DataPropertyName = "Ser_Substition_ID_ReadSerial";
            this.serSubstitionIDReadSerialDataGridViewTextBoxColumn.HeaderText = "Ser_Substition_ID_ReadSerial";
            this.serSubstitionIDReadSerialDataGridViewTextBoxColumn.Name = "serSubstitionIDReadSerialDataGridViewTextBoxColumn";
            // 
            // serNoteDataGridViewTextBoxColumn
            // 
            this.serNoteDataGridViewTextBoxColumn.DataPropertyName = "Ser_Note";
            this.serNoteDataGridViewTextBoxColumn.HeaderText = "Ser_Note";
            this.serNoteDataGridViewTextBoxColumn.Name = "serNoteDataGridViewTextBoxColumn";
            // 
            // metroGrid3
            // 
            this.metroGrid3.AllowUserToResizeRows = false;
            this.metroGrid3.AutoGenerateColumns = false;
            this.metroGrid3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid3.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.metroGrid3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn1,
            this.sWCodeDataGridViewTextBoxColumn,
            this.sWTipoDeviceDataGridViewTextBoxColumn,
            this.sWDescrizioneDataGridViewTextBoxColumn,
            this.sWDescrizioneENDataGridViewTextBoxColumn,
            this.sWVersioneDataGridViewTextBoxColumn,
            this.sWRevisioneDataGridViewTextBoxColumn,
            this.sWStandardDataGridViewCheckBoxColumn,
            this.sWFamProdDataGridViewTextBoxColumn,
            this.sWPOptRFDataGridViewTextBoxColumn,
            this.sWPOptUseOledDataGridViewCheckBoxColumn,
            this.sWPOptUseEmButtDataGridViewCheckBoxColumn,
            this.sWPOptUseBacklightDataGridViewCheckBoxColumn,
            this.sWPOptShiftPageDataGridViewCheckBoxColumn,
            this.sWPOptUseAccelDataGridViewCheckBoxColumn,
            this.sWPOptUseSPDataGridViewCheckBoxColumn,
            this.sWPOptUseBuzzerDataGridViewCheckBoxColumn,
            this.sWPOptUseVibracallDataGridViewCheckBoxColumn,
            this.sWPOptUseLedTorchDataGridViewCheckBoxColumn,
            this.sWPPLDDataGridViewCheckBoxColumn,
            this.sWPOptMaxPairDevicesDataGridViewTextBoxColumn,
            this.sWROptRFDataGridViewTextBoxColumn,
            this.sWROptPlugExpDataGridViewCheckBoxColumn,
            this.sWROptPlugPleDataGridViewCheckBoxColumn,
            this.sWROptEmKeybDataGridViewCheckBoxColumn,
            this.sWROptCanDataGridViewCheckBoxColumn,
            this.sWROptPropOutDataGridViewCheckBoxColumn,
            this.sWROptTimeOutDataGridViewTextBoxColumn,
            this.sWROptContKeysDataGridViewTextBoxColumn,
            this.sWROptLockSameRowDataGridViewCheckBoxColumn,
            this.sWROptUseSPDataGridViewCheckBoxColumn,
            this.sWROptMaxPairDevicesDataGridViewTextBoxColumn,
            this.sWROptShiftPageDataGridViewCheckBoxColumn,
            this.sWROptOutputNoDataGridViewTextBoxColumn,
            this.sWROptDigInputNoDataGridViewTextBoxColumn,
            this.sWROptAnaInputNoDataGridViewTextBoxColumn,
            this.sWRevisioniDataGridViewTextBoxColumn,
            this.sWFunzionamentoDataGridViewTextBoxColumn,
            this.sWConfigDataGridViewTextBoxColumn,
            this.sWObsoleteverDataGridViewCheckBoxColumn,
            this.sWObsoleteverfromdateDataGridViewTextBoxColumn});
            this.metroGrid3.DataSource = this.serialNumbersFirmwareBindingSource;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid3.DefaultCellStyle = dataGridViewCellStyle8;
            this.metroGrid3.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroGrid3.EnableHeadersVisualStyles = false;
            this.metroGrid3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid3.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid3.Location = new System.Drawing.Point(0, 300);
            this.metroGrid3.Name = "metroGrid3";
            this.metroGrid3.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid3.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.metroGrid3.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid3.Size = new System.Drawing.Size(800, 150);
            this.metroGrid3.TabIndex = 2;
            // 
            // serialNumbersFirmwareBindingSource
            // 
            this.serialNumbersFirmwareBindingSource.DataMember = "SerialNumbers_Firmware";
            this.serialNumbersFirmwareBindingSource.DataSource = this.sFClientiSerialNumbersSerialNumbersBindingSource;
            // 
            // firmwareTableAdapter
            // 
            this.firmwareTableAdapter.ClearBeforeFill = true;
            // 
            // idDataGridViewTextBoxColumn1
            // 
            this.idDataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn1.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn1.Name = "idDataGridViewTextBoxColumn1";
            this.idDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // sWCodeDataGridViewTextBoxColumn
            // 
            this.sWCodeDataGridViewTextBoxColumn.DataPropertyName = "SW_Code";
            this.sWCodeDataGridViewTextBoxColumn.HeaderText = "SW_Code";
            this.sWCodeDataGridViewTextBoxColumn.Name = "sWCodeDataGridViewTextBoxColumn";
            // 
            // sWTipoDeviceDataGridViewTextBoxColumn
            // 
            this.sWTipoDeviceDataGridViewTextBoxColumn.DataPropertyName = "SW_TipoDevice";
            this.sWTipoDeviceDataGridViewTextBoxColumn.HeaderText = "SW_TipoDevice";
            this.sWTipoDeviceDataGridViewTextBoxColumn.Name = "sWTipoDeviceDataGridViewTextBoxColumn";
            // 
            // sWDescrizioneDataGridViewTextBoxColumn
            // 
            this.sWDescrizioneDataGridViewTextBoxColumn.DataPropertyName = "SW_Descrizione";
            this.sWDescrizioneDataGridViewTextBoxColumn.HeaderText = "SW_Descrizione";
            this.sWDescrizioneDataGridViewTextBoxColumn.Name = "sWDescrizioneDataGridViewTextBoxColumn";
            // 
            // sWDescrizioneENDataGridViewTextBoxColumn
            // 
            this.sWDescrizioneENDataGridViewTextBoxColumn.DataPropertyName = "SW_Descrizione_EN";
            this.sWDescrizioneENDataGridViewTextBoxColumn.HeaderText = "SW_Descrizione_EN";
            this.sWDescrizioneENDataGridViewTextBoxColumn.Name = "sWDescrizioneENDataGridViewTextBoxColumn";
            // 
            // sWVersioneDataGridViewTextBoxColumn
            // 
            this.sWVersioneDataGridViewTextBoxColumn.DataPropertyName = "SW_Versione";
            this.sWVersioneDataGridViewTextBoxColumn.HeaderText = "SW_Versione";
            this.sWVersioneDataGridViewTextBoxColumn.Name = "sWVersioneDataGridViewTextBoxColumn";
            // 
            // sWRevisioneDataGridViewTextBoxColumn
            // 
            this.sWRevisioneDataGridViewTextBoxColumn.DataPropertyName = "SW_Revisione";
            this.sWRevisioneDataGridViewTextBoxColumn.HeaderText = "SW_Revisione";
            this.sWRevisioneDataGridViewTextBoxColumn.Name = "sWRevisioneDataGridViewTextBoxColumn";
            // 
            // sWStandardDataGridViewCheckBoxColumn
            // 
            this.sWStandardDataGridViewCheckBoxColumn.DataPropertyName = "SW_Standard";
            this.sWStandardDataGridViewCheckBoxColumn.HeaderText = "SW_Standard";
            this.sWStandardDataGridViewCheckBoxColumn.Name = "sWStandardDataGridViewCheckBoxColumn";
            // 
            // sWFamProdDataGridViewTextBoxColumn
            // 
            this.sWFamProdDataGridViewTextBoxColumn.DataPropertyName = "SW_FamProd";
            this.sWFamProdDataGridViewTextBoxColumn.HeaderText = "SW_FamProd";
            this.sWFamProdDataGridViewTextBoxColumn.Name = "sWFamProdDataGridViewTextBoxColumn";
            // 
            // sWPOptRFDataGridViewTextBoxColumn
            // 
            this.sWPOptRFDataGridViewTextBoxColumn.DataPropertyName = "SW_P_Opt_RF";
            this.sWPOptRFDataGridViewTextBoxColumn.HeaderText = "SW_P_Opt_RF";
            this.sWPOptRFDataGridViewTextBoxColumn.Name = "sWPOptRFDataGridViewTextBoxColumn";
            // 
            // sWPOptUseOledDataGridViewCheckBoxColumn
            // 
            this.sWPOptUseOledDataGridViewCheckBoxColumn.DataPropertyName = "SW_P_Opt_Use_Oled";
            this.sWPOptUseOledDataGridViewCheckBoxColumn.HeaderText = "SW_P_Opt_Use_Oled";
            this.sWPOptUseOledDataGridViewCheckBoxColumn.Name = "sWPOptUseOledDataGridViewCheckBoxColumn";
            // 
            // sWPOptUseEmButtDataGridViewCheckBoxColumn
            // 
            this.sWPOptUseEmButtDataGridViewCheckBoxColumn.DataPropertyName = "SW_P_Opt_Use_EmButt";
            this.sWPOptUseEmButtDataGridViewCheckBoxColumn.HeaderText = "SW_P_Opt_Use_EmButt";
            this.sWPOptUseEmButtDataGridViewCheckBoxColumn.Name = "sWPOptUseEmButtDataGridViewCheckBoxColumn";
            // 
            // sWPOptUseBacklightDataGridViewCheckBoxColumn
            // 
            this.sWPOptUseBacklightDataGridViewCheckBoxColumn.DataPropertyName = "SW_P_Opt_Use_Backlight";
            this.sWPOptUseBacklightDataGridViewCheckBoxColumn.HeaderText = "SW_P_Opt_Use_Backlight";
            this.sWPOptUseBacklightDataGridViewCheckBoxColumn.Name = "sWPOptUseBacklightDataGridViewCheckBoxColumn";
            // 
            // sWPOptShiftPageDataGridViewCheckBoxColumn
            // 
            this.sWPOptShiftPageDataGridViewCheckBoxColumn.DataPropertyName = "SW_P_Opt_ShiftPage";
            this.sWPOptShiftPageDataGridViewCheckBoxColumn.HeaderText = "SW_P_Opt_ShiftPage";
            this.sWPOptShiftPageDataGridViewCheckBoxColumn.Name = "sWPOptShiftPageDataGridViewCheckBoxColumn";
            // 
            // sWPOptUseAccelDataGridViewCheckBoxColumn
            // 
            this.sWPOptUseAccelDataGridViewCheckBoxColumn.DataPropertyName = "SW_P_Opt_Use_Accel";
            this.sWPOptUseAccelDataGridViewCheckBoxColumn.HeaderText = "SW_P_Opt_Use_Accel";
            this.sWPOptUseAccelDataGridViewCheckBoxColumn.Name = "sWPOptUseAccelDataGridViewCheckBoxColumn";
            // 
            // sWPOptUseSPDataGridViewCheckBoxColumn
            // 
            this.sWPOptUseSPDataGridViewCheckBoxColumn.DataPropertyName = "SW_P_Opt_Use_SP";
            this.sWPOptUseSPDataGridViewCheckBoxColumn.HeaderText = "SW_P_Opt_Use_SP";
            this.sWPOptUseSPDataGridViewCheckBoxColumn.Name = "sWPOptUseSPDataGridViewCheckBoxColumn";
            // 
            // sWPOptUseBuzzerDataGridViewCheckBoxColumn
            // 
            this.sWPOptUseBuzzerDataGridViewCheckBoxColumn.DataPropertyName = "SW_P_Opt_Use_Buzzer";
            this.sWPOptUseBuzzerDataGridViewCheckBoxColumn.HeaderText = "SW_P_Opt_Use_Buzzer";
            this.sWPOptUseBuzzerDataGridViewCheckBoxColumn.Name = "sWPOptUseBuzzerDataGridViewCheckBoxColumn";
            // 
            // sWPOptUseVibracallDataGridViewCheckBoxColumn
            // 
            this.sWPOptUseVibracallDataGridViewCheckBoxColumn.DataPropertyName = "SW_P_Opt_Use_Vibracall";
            this.sWPOptUseVibracallDataGridViewCheckBoxColumn.HeaderText = "SW_P_Opt_Use_Vibracall";
            this.sWPOptUseVibracallDataGridViewCheckBoxColumn.Name = "sWPOptUseVibracallDataGridViewCheckBoxColumn";
            // 
            // sWPOptUseLedTorchDataGridViewCheckBoxColumn
            // 
            this.sWPOptUseLedTorchDataGridViewCheckBoxColumn.DataPropertyName = "SW_P_Opt_Use_LedTorch";
            this.sWPOptUseLedTorchDataGridViewCheckBoxColumn.HeaderText = "SW_P_Opt_Use_LedTorch";
            this.sWPOptUseLedTorchDataGridViewCheckBoxColumn.Name = "sWPOptUseLedTorchDataGridViewCheckBoxColumn";
            // 
            // sWPPLDDataGridViewCheckBoxColumn
            // 
            this.sWPPLDDataGridViewCheckBoxColumn.DataPropertyName = "SW_P_PLD";
            this.sWPPLDDataGridViewCheckBoxColumn.HeaderText = "SW_P_PLD";
            this.sWPPLDDataGridViewCheckBoxColumn.Name = "sWPPLDDataGridViewCheckBoxColumn";
            // 
            // sWPOptMaxPairDevicesDataGridViewTextBoxColumn
            // 
            this.sWPOptMaxPairDevicesDataGridViewTextBoxColumn.DataPropertyName = "SW_P_Opt_MaxPairDevices";
            this.sWPOptMaxPairDevicesDataGridViewTextBoxColumn.HeaderText = "SW_P_Opt_MaxPairDevices";
            this.sWPOptMaxPairDevicesDataGridViewTextBoxColumn.Name = "sWPOptMaxPairDevicesDataGridViewTextBoxColumn";
            // 
            // sWROptRFDataGridViewTextBoxColumn
            // 
            this.sWROptRFDataGridViewTextBoxColumn.DataPropertyName = "SW_R_Opt_RF";
            this.sWROptRFDataGridViewTextBoxColumn.HeaderText = "SW_R_Opt_RF";
            this.sWROptRFDataGridViewTextBoxColumn.Name = "sWROptRFDataGridViewTextBoxColumn";
            // 
            // sWROptPlugExpDataGridViewCheckBoxColumn
            // 
            this.sWROptPlugExpDataGridViewCheckBoxColumn.DataPropertyName = "SW_R_Opt_Plug_Exp";
            this.sWROptPlugExpDataGridViewCheckBoxColumn.HeaderText = "SW_R_Opt_Plug_Exp";
            this.sWROptPlugExpDataGridViewCheckBoxColumn.Name = "sWROptPlugExpDataGridViewCheckBoxColumn";
            // 
            // sWROptPlugPleDataGridViewCheckBoxColumn
            // 
            this.sWROptPlugPleDataGridViewCheckBoxColumn.DataPropertyName = "SW_R_Opt_Plug_Ple";
            this.sWROptPlugPleDataGridViewCheckBoxColumn.HeaderText = "SW_R_Opt_Plug_Ple";
            this.sWROptPlugPleDataGridViewCheckBoxColumn.Name = "sWROptPlugPleDataGridViewCheckBoxColumn";
            // 
            // sWROptEmKeybDataGridViewCheckBoxColumn
            // 
            this.sWROptEmKeybDataGridViewCheckBoxColumn.DataPropertyName = "SW_R_Opt_Em_Keyb";
            this.sWROptEmKeybDataGridViewCheckBoxColumn.HeaderText = "SW_R_Opt_Em_Keyb";
            this.sWROptEmKeybDataGridViewCheckBoxColumn.Name = "sWROptEmKeybDataGridViewCheckBoxColumn";
            // 
            // sWROptCanDataGridViewCheckBoxColumn
            // 
            this.sWROptCanDataGridViewCheckBoxColumn.DataPropertyName = "SW_R_Opt_Can";
            this.sWROptCanDataGridViewCheckBoxColumn.HeaderText = "SW_R_Opt_Can";
            this.sWROptCanDataGridViewCheckBoxColumn.Name = "sWROptCanDataGridViewCheckBoxColumn";
            // 
            // sWROptPropOutDataGridViewCheckBoxColumn
            // 
            this.sWROptPropOutDataGridViewCheckBoxColumn.DataPropertyName = "SW_R_Opt_Prop_Out";
            this.sWROptPropOutDataGridViewCheckBoxColumn.HeaderText = "SW_R_Opt_Prop_Out";
            this.sWROptPropOutDataGridViewCheckBoxColumn.Name = "sWROptPropOutDataGridViewCheckBoxColumn";
            // 
            // sWROptTimeOutDataGridViewTextBoxColumn
            // 
            this.sWROptTimeOutDataGridViewTextBoxColumn.DataPropertyName = "SW_R_Opt_TimeOut";
            this.sWROptTimeOutDataGridViewTextBoxColumn.HeaderText = "SW_R_Opt_TimeOut";
            this.sWROptTimeOutDataGridViewTextBoxColumn.Name = "sWROptTimeOutDataGridViewTextBoxColumn";
            // 
            // sWROptContKeysDataGridViewTextBoxColumn
            // 
            this.sWROptContKeysDataGridViewTextBoxColumn.DataPropertyName = "SW_R_Opt_Cont_Keys";
            this.sWROptContKeysDataGridViewTextBoxColumn.HeaderText = "SW_R_Opt_Cont_Keys";
            this.sWROptContKeysDataGridViewTextBoxColumn.Name = "sWROptContKeysDataGridViewTextBoxColumn";
            // 
            // sWROptLockSameRowDataGridViewCheckBoxColumn
            // 
            this.sWROptLockSameRowDataGridViewCheckBoxColumn.DataPropertyName = "SW_R_Opt_LockSameRow";
            this.sWROptLockSameRowDataGridViewCheckBoxColumn.HeaderText = "SW_R_Opt_LockSameRow";
            this.sWROptLockSameRowDataGridViewCheckBoxColumn.Name = "sWROptLockSameRowDataGridViewCheckBoxColumn";
            // 
            // sWROptUseSPDataGridViewCheckBoxColumn
            // 
            this.sWROptUseSPDataGridViewCheckBoxColumn.DataPropertyName = "SW_R_Opt_Use_SP";
            this.sWROptUseSPDataGridViewCheckBoxColumn.HeaderText = "SW_R_Opt_Use_SP";
            this.sWROptUseSPDataGridViewCheckBoxColumn.Name = "sWROptUseSPDataGridViewCheckBoxColumn";
            // 
            // sWROptMaxPairDevicesDataGridViewTextBoxColumn
            // 
            this.sWROptMaxPairDevicesDataGridViewTextBoxColumn.DataPropertyName = "SW_R_Opt_MaxPairDevices";
            this.sWROptMaxPairDevicesDataGridViewTextBoxColumn.HeaderText = "SW_R_Opt_MaxPairDevices";
            this.sWROptMaxPairDevicesDataGridViewTextBoxColumn.Name = "sWROptMaxPairDevicesDataGridViewTextBoxColumn";
            // 
            // sWROptShiftPageDataGridViewCheckBoxColumn
            // 
            this.sWROptShiftPageDataGridViewCheckBoxColumn.DataPropertyName = "SW_R_Opt_ShiftPage";
            this.sWROptShiftPageDataGridViewCheckBoxColumn.HeaderText = "SW_R_Opt_ShiftPage";
            this.sWROptShiftPageDataGridViewCheckBoxColumn.Name = "sWROptShiftPageDataGridViewCheckBoxColumn";
            // 
            // sWROptOutputNoDataGridViewTextBoxColumn
            // 
            this.sWROptOutputNoDataGridViewTextBoxColumn.DataPropertyName = "SW_R_Opt_Output_No";
            this.sWROptOutputNoDataGridViewTextBoxColumn.HeaderText = "SW_R_Opt_Output_No";
            this.sWROptOutputNoDataGridViewTextBoxColumn.Name = "sWROptOutputNoDataGridViewTextBoxColumn";
            // 
            // sWROptDigInputNoDataGridViewTextBoxColumn
            // 
            this.sWROptDigInputNoDataGridViewTextBoxColumn.DataPropertyName = "SW_R_Opt_Dig_Input_No";
            this.sWROptDigInputNoDataGridViewTextBoxColumn.HeaderText = "SW_R_Opt_Dig_Input_No";
            this.sWROptDigInputNoDataGridViewTextBoxColumn.Name = "sWROptDigInputNoDataGridViewTextBoxColumn";
            // 
            // sWROptAnaInputNoDataGridViewTextBoxColumn
            // 
            this.sWROptAnaInputNoDataGridViewTextBoxColumn.DataPropertyName = "SW_R_Opt_Ana_Input_No";
            this.sWROptAnaInputNoDataGridViewTextBoxColumn.HeaderText = "SW_R_Opt_Ana_Input_No";
            this.sWROptAnaInputNoDataGridViewTextBoxColumn.Name = "sWROptAnaInputNoDataGridViewTextBoxColumn";
            // 
            // sWRevisioniDataGridViewTextBoxColumn
            // 
            this.sWRevisioniDataGridViewTextBoxColumn.DataPropertyName = "SW_Revisioni";
            this.sWRevisioniDataGridViewTextBoxColumn.HeaderText = "SW_Revisioni";
            this.sWRevisioniDataGridViewTextBoxColumn.Name = "sWRevisioniDataGridViewTextBoxColumn";
            // 
            // sWFunzionamentoDataGridViewTextBoxColumn
            // 
            this.sWFunzionamentoDataGridViewTextBoxColumn.DataPropertyName = "SW_Funzionamento";
            this.sWFunzionamentoDataGridViewTextBoxColumn.HeaderText = "SW_Funzionamento";
            this.sWFunzionamentoDataGridViewTextBoxColumn.Name = "sWFunzionamentoDataGridViewTextBoxColumn";
            // 
            // sWConfigDataGridViewTextBoxColumn
            // 
            this.sWConfigDataGridViewTextBoxColumn.DataPropertyName = "SW_Config";
            this.sWConfigDataGridViewTextBoxColumn.HeaderText = "SW_Config";
            this.sWConfigDataGridViewTextBoxColumn.Name = "sWConfigDataGridViewTextBoxColumn";
            // 
            // sWObsoleteverDataGridViewCheckBoxColumn
            // 
            this.sWObsoleteverDataGridViewCheckBoxColumn.DataPropertyName = "SW_Obsolete_ver";
            this.sWObsoleteverDataGridViewCheckBoxColumn.HeaderText = "SW_Obsolete_ver";
            this.sWObsoleteverDataGridViewCheckBoxColumn.Name = "sWObsoleteverDataGridViewCheckBoxColumn";
            // 
            // sWObsoleteverfromdateDataGridViewTextBoxColumn
            // 
            this.sWObsoleteverfromdateDataGridViewTextBoxColumn.DataPropertyName = "SW_Obsolete_ver_from_date";
            this.sWObsoleteverfromdateDataGridViewTextBoxColumn.HeaderText = "SW_Obsolete_ver_from_date";
            this.sWObsoleteverfromdateDataGridViewTextBoxColumn.Name = "sWObsoleteverfromdateDataGridViewTextBoxColumn";
            // 
            // metroGrid4
            // 
            this.metroGrid4.AllowUserToResizeRows = false;
            this.metroGrid4.AutoGenerateColumns = false;
            this.metroGrid4.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid4.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid4.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.metroGrid4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn2,
            this.sWCodeDataGridViewTextBoxColumn1,
            this.sWTipoDeviceDataGridViewTextBoxColumn1,
            this.sWDescrizioneDataGridViewTextBoxColumn1,
            this.sWDescrizioneENDataGridViewTextBoxColumn1,
            this.sWVersioneDataGridViewTextBoxColumn1,
            this.sWRevisioneDataGridViewTextBoxColumn1,
            this.sWStandardDataGridViewCheckBoxColumn1,
            this.sWFamProdDataGridViewTextBoxColumn1,
            this.sWPOptRFDataGridViewTextBoxColumn1,
            this.sWPOptUseOledDataGridViewCheckBoxColumn1,
            this.sWPOptUseEmButtDataGridViewCheckBoxColumn1,
            this.sWPOptUseBacklightDataGridViewCheckBoxColumn1,
            this.sWPOptShiftPageDataGridViewCheckBoxColumn1,
            this.sWPOptUseAccelDataGridViewCheckBoxColumn1,
            this.sWPOptUseSPDataGridViewCheckBoxColumn1,
            this.sWPOptUseBuzzerDataGridViewCheckBoxColumn1,
            this.sWPOptUseVibracallDataGridViewCheckBoxColumn1,
            this.sWPOptUseLedTorchDataGridViewCheckBoxColumn1,
            this.sWPPLDDataGridViewCheckBoxColumn1,
            this.sWPOptMaxPairDevicesDataGridViewTextBoxColumn1,
            this.sWROptRFDataGridViewTextBoxColumn1,
            this.sWROptPlugExpDataGridViewCheckBoxColumn1,
            this.sWROptPlugPleDataGridViewCheckBoxColumn1,
            this.sWROptEmKeybDataGridViewCheckBoxColumn1,
            this.sWROptCanDataGridViewCheckBoxColumn1,
            this.sWROptPropOutDataGridViewCheckBoxColumn1,
            this.sWROptTimeOutDataGridViewTextBoxColumn1,
            this.sWROptContKeysDataGridViewTextBoxColumn1,
            this.sWROptLockSameRowDataGridViewCheckBoxColumn1,
            this.sWROptUseSPDataGridViewCheckBoxColumn1,
            this.sWROptMaxPairDevicesDataGridViewTextBoxColumn1,
            this.sWROptShiftPageDataGridViewCheckBoxColumn1,
            this.sWROptOutputNoDataGridViewTextBoxColumn1,
            this.sWROptDigInputNoDataGridViewTextBoxColumn1,
            this.sWROptAnaInputNoDataGridViewTextBoxColumn1,
            this.sWRevisioniDataGridViewTextBoxColumn1,
            this.sWFunzionamentoDataGridViewTextBoxColumn1,
            this.sWConfigDataGridViewTextBoxColumn1,
            this.sWObsoleteverDataGridViewCheckBoxColumn1,
            this.sWObsoleteverfromdateDataGridViewTextBoxColumn1});
            this.metroGrid4.DataSource = this.serialNumbersLastFirmwareBindingSource;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid4.DefaultCellStyle = dataGridViewCellStyle11;
            this.metroGrid4.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroGrid4.EnableHeadersVisualStyles = false;
            this.metroGrid4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid4.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid4.Location = new System.Drawing.Point(0, 450);
            this.metroGrid4.Name = "metroGrid4";
            this.metroGrid4.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid4.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.metroGrid4.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid4.Size = new System.Drawing.Size(800, 150);
            this.metroGrid4.TabIndex = 3;
            // 
            // serialNumbersLastFirmwareBindingSource
            // 
            this.serialNumbersLastFirmwareBindingSource.DataMember = "SerialNumbers_LastFirmware";
            this.serialNumbersLastFirmwareBindingSource.DataSource = this.sFClientiSerialNumbersSerialNumbersBindingSource;
            // 
            // lastFirmwareTableAdapter
            // 
            this.lastFirmwareTableAdapter.ClearBeforeFill = true;
            // 
            // idDataGridViewTextBoxColumn2
            // 
            this.idDataGridViewTextBoxColumn2.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn2.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn2.Name = "idDataGridViewTextBoxColumn2";
            this.idDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // sWCodeDataGridViewTextBoxColumn1
            // 
            this.sWCodeDataGridViewTextBoxColumn1.DataPropertyName = "SW_Code";
            this.sWCodeDataGridViewTextBoxColumn1.HeaderText = "SW_Code";
            this.sWCodeDataGridViewTextBoxColumn1.Name = "sWCodeDataGridViewTextBoxColumn1";
            // 
            // sWTipoDeviceDataGridViewTextBoxColumn1
            // 
            this.sWTipoDeviceDataGridViewTextBoxColumn1.DataPropertyName = "SW_TipoDevice";
            this.sWTipoDeviceDataGridViewTextBoxColumn1.HeaderText = "SW_TipoDevice";
            this.sWTipoDeviceDataGridViewTextBoxColumn1.Name = "sWTipoDeviceDataGridViewTextBoxColumn1";
            // 
            // sWDescrizioneDataGridViewTextBoxColumn1
            // 
            this.sWDescrizioneDataGridViewTextBoxColumn1.DataPropertyName = "SW_Descrizione";
            this.sWDescrizioneDataGridViewTextBoxColumn1.HeaderText = "SW_Descrizione";
            this.sWDescrizioneDataGridViewTextBoxColumn1.Name = "sWDescrizioneDataGridViewTextBoxColumn1";
            // 
            // sWDescrizioneENDataGridViewTextBoxColumn1
            // 
            this.sWDescrizioneENDataGridViewTextBoxColumn1.DataPropertyName = "SW_Descrizione_EN";
            this.sWDescrizioneENDataGridViewTextBoxColumn1.HeaderText = "SW_Descrizione_EN";
            this.sWDescrizioneENDataGridViewTextBoxColumn1.Name = "sWDescrizioneENDataGridViewTextBoxColumn1";
            // 
            // sWVersioneDataGridViewTextBoxColumn1
            // 
            this.sWVersioneDataGridViewTextBoxColumn1.DataPropertyName = "SW_Versione";
            this.sWVersioneDataGridViewTextBoxColumn1.HeaderText = "SW_Versione";
            this.sWVersioneDataGridViewTextBoxColumn1.Name = "sWVersioneDataGridViewTextBoxColumn1";
            // 
            // sWRevisioneDataGridViewTextBoxColumn1
            // 
            this.sWRevisioneDataGridViewTextBoxColumn1.DataPropertyName = "SW_Revisione";
            this.sWRevisioneDataGridViewTextBoxColumn1.HeaderText = "SW_Revisione";
            this.sWRevisioneDataGridViewTextBoxColumn1.Name = "sWRevisioneDataGridViewTextBoxColumn1";
            // 
            // sWStandardDataGridViewCheckBoxColumn1
            // 
            this.sWStandardDataGridViewCheckBoxColumn1.DataPropertyName = "SW_Standard";
            this.sWStandardDataGridViewCheckBoxColumn1.HeaderText = "SW_Standard";
            this.sWStandardDataGridViewCheckBoxColumn1.Name = "sWStandardDataGridViewCheckBoxColumn1";
            // 
            // sWFamProdDataGridViewTextBoxColumn1
            // 
            this.sWFamProdDataGridViewTextBoxColumn1.DataPropertyName = "SW_FamProd";
            this.sWFamProdDataGridViewTextBoxColumn1.HeaderText = "SW_FamProd";
            this.sWFamProdDataGridViewTextBoxColumn1.Name = "sWFamProdDataGridViewTextBoxColumn1";
            // 
            // sWPOptRFDataGridViewTextBoxColumn1
            // 
            this.sWPOptRFDataGridViewTextBoxColumn1.DataPropertyName = "SW_P_Opt_RF";
            this.sWPOptRFDataGridViewTextBoxColumn1.HeaderText = "SW_P_Opt_RF";
            this.sWPOptRFDataGridViewTextBoxColumn1.Name = "sWPOptRFDataGridViewTextBoxColumn1";
            // 
            // sWPOptUseOledDataGridViewCheckBoxColumn1
            // 
            this.sWPOptUseOledDataGridViewCheckBoxColumn1.DataPropertyName = "SW_P_Opt_Use_Oled";
            this.sWPOptUseOledDataGridViewCheckBoxColumn1.HeaderText = "SW_P_Opt_Use_Oled";
            this.sWPOptUseOledDataGridViewCheckBoxColumn1.Name = "sWPOptUseOledDataGridViewCheckBoxColumn1";
            // 
            // sWPOptUseEmButtDataGridViewCheckBoxColumn1
            // 
            this.sWPOptUseEmButtDataGridViewCheckBoxColumn1.DataPropertyName = "SW_P_Opt_Use_EmButt";
            this.sWPOptUseEmButtDataGridViewCheckBoxColumn1.HeaderText = "SW_P_Opt_Use_EmButt";
            this.sWPOptUseEmButtDataGridViewCheckBoxColumn1.Name = "sWPOptUseEmButtDataGridViewCheckBoxColumn1";
            // 
            // sWPOptUseBacklightDataGridViewCheckBoxColumn1
            // 
            this.sWPOptUseBacklightDataGridViewCheckBoxColumn1.DataPropertyName = "SW_P_Opt_Use_Backlight";
            this.sWPOptUseBacklightDataGridViewCheckBoxColumn1.HeaderText = "SW_P_Opt_Use_Backlight";
            this.sWPOptUseBacklightDataGridViewCheckBoxColumn1.Name = "sWPOptUseBacklightDataGridViewCheckBoxColumn1";
            // 
            // sWPOptShiftPageDataGridViewCheckBoxColumn1
            // 
            this.sWPOptShiftPageDataGridViewCheckBoxColumn1.DataPropertyName = "SW_P_Opt_ShiftPage";
            this.sWPOptShiftPageDataGridViewCheckBoxColumn1.HeaderText = "SW_P_Opt_ShiftPage";
            this.sWPOptShiftPageDataGridViewCheckBoxColumn1.Name = "sWPOptShiftPageDataGridViewCheckBoxColumn1";
            // 
            // sWPOptUseAccelDataGridViewCheckBoxColumn1
            // 
            this.sWPOptUseAccelDataGridViewCheckBoxColumn1.DataPropertyName = "SW_P_Opt_Use_Accel";
            this.sWPOptUseAccelDataGridViewCheckBoxColumn1.HeaderText = "SW_P_Opt_Use_Accel";
            this.sWPOptUseAccelDataGridViewCheckBoxColumn1.Name = "sWPOptUseAccelDataGridViewCheckBoxColumn1";
            // 
            // sWPOptUseSPDataGridViewCheckBoxColumn1
            // 
            this.sWPOptUseSPDataGridViewCheckBoxColumn1.DataPropertyName = "SW_P_Opt_Use_SP";
            this.sWPOptUseSPDataGridViewCheckBoxColumn1.HeaderText = "SW_P_Opt_Use_SP";
            this.sWPOptUseSPDataGridViewCheckBoxColumn1.Name = "sWPOptUseSPDataGridViewCheckBoxColumn1";
            // 
            // sWPOptUseBuzzerDataGridViewCheckBoxColumn1
            // 
            this.sWPOptUseBuzzerDataGridViewCheckBoxColumn1.DataPropertyName = "SW_P_Opt_Use_Buzzer";
            this.sWPOptUseBuzzerDataGridViewCheckBoxColumn1.HeaderText = "SW_P_Opt_Use_Buzzer";
            this.sWPOptUseBuzzerDataGridViewCheckBoxColumn1.Name = "sWPOptUseBuzzerDataGridViewCheckBoxColumn1";
            // 
            // sWPOptUseVibracallDataGridViewCheckBoxColumn1
            // 
            this.sWPOptUseVibracallDataGridViewCheckBoxColumn1.DataPropertyName = "SW_P_Opt_Use_Vibracall";
            this.sWPOptUseVibracallDataGridViewCheckBoxColumn1.HeaderText = "SW_P_Opt_Use_Vibracall";
            this.sWPOptUseVibracallDataGridViewCheckBoxColumn1.Name = "sWPOptUseVibracallDataGridViewCheckBoxColumn1";
            // 
            // sWPOptUseLedTorchDataGridViewCheckBoxColumn1
            // 
            this.sWPOptUseLedTorchDataGridViewCheckBoxColumn1.DataPropertyName = "SW_P_Opt_Use_LedTorch";
            this.sWPOptUseLedTorchDataGridViewCheckBoxColumn1.HeaderText = "SW_P_Opt_Use_LedTorch";
            this.sWPOptUseLedTorchDataGridViewCheckBoxColumn1.Name = "sWPOptUseLedTorchDataGridViewCheckBoxColumn1";
            // 
            // sWPPLDDataGridViewCheckBoxColumn1
            // 
            this.sWPPLDDataGridViewCheckBoxColumn1.DataPropertyName = "SW_P_PLD";
            this.sWPPLDDataGridViewCheckBoxColumn1.HeaderText = "SW_P_PLD";
            this.sWPPLDDataGridViewCheckBoxColumn1.Name = "sWPPLDDataGridViewCheckBoxColumn1";
            // 
            // sWPOptMaxPairDevicesDataGridViewTextBoxColumn1
            // 
            this.sWPOptMaxPairDevicesDataGridViewTextBoxColumn1.DataPropertyName = "SW_P_Opt_MaxPairDevices";
            this.sWPOptMaxPairDevicesDataGridViewTextBoxColumn1.HeaderText = "SW_P_Opt_MaxPairDevices";
            this.sWPOptMaxPairDevicesDataGridViewTextBoxColumn1.Name = "sWPOptMaxPairDevicesDataGridViewTextBoxColumn1";
            // 
            // sWROptRFDataGridViewTextBoxColumn1
            // 
            this.sWROptRFDataGridViewTextBoxColumn1.DataPropertyName = "SW_R_Opt_RF";
            this.sWROptRFDataGridViewTextBoxColumn1.HeaderText = "SW_R_Opt_RF";
            this.sWROptRFDataGridViewTextBoxColumn1.Name = "sWROptRFDataGridViewTextBoxColumn1";
            // 
            // sWROptPlugExpDataGridViewCheckBoxColumn1
            // 
            this.sWROptPlugExpDataGridViewCheckBoxColumn1.DataPropertyName = "SW_R_Opt_Plug_Exp";
            this.sWROptPlugExpDataGridViewCheckBoxColumn1.HeaderText = "SW_R_Opt_Plug_Exp";
            this.sWROptPlugExpDataGridViewCheckBoxColumn1.Name = "sWROptPlugExpDataGridViewCheckBoxColumn1";
            // 
            // sWROptPlugPleDataGridViewCheckBoxColumn1
            // 
            this.sWROptPlugPleDataGridViewCheckBoxColumn1.DataPropertyName = "SW_R_Opt_Plug_Ple";
            this.sWROptPlugPleDataGridViewCheckBoxColumn1.HeaderText = "SW_R_Opt_Plug_Ple";
            this.sWROptPlugPleDataGridViewCheckBoxColumn1.Name = "sWROptPlugPleDataGridViewCheckBoxColumn1";
            // 
            // sWROptEmKeybDataGridViewCheckBoxColumn1
            // 
            this.sWROptEmKeybDataGridViewCheckBoxColumn1.DataPropertyName = "SW_R_Opt_Em_Keyb";
            this.sWROptEmKeybDataGridViewCheckBoxColumn1.HeaderText = "SW_R_Opt_Em_Keyb";
            this.sWROptEmKeybDataGridViewCheckBoxColumn1.Name = "sWROptEmKeybDataGridViewCheckBoxColumn1";
            // 
            // sWROptCanDataGridViewCheckBoxColumn1
            // 
            this.sWROptCanDataGridViewCheckBoxColumn1.DataPropertyName = "SW_R_Opt_Can";
            this.sWROptCanDataGridViewCheckBoxColumn1.HeaderText = "SW_R_Opt_Can";
            this.sWROptCanDataGridViewCheckBoxColumn1.Name = "sWROptCanDataGridViewCheckBoxColumn1";
            // 
            // sWROptPropOutDataGridViewCheckBoxColumn1
            // 
            this.sWROptPropOutDataGridViewCheckBoxColumn1.DataPropertyName = "SW_R_Opt_Prop_Out";
            this.sWROptPropOutDataGridViewCheckBoxColumn1.HeaderText = "SW_R_Opt_Prop_Out";
            this.sWROptPropOutDataGridViewCheckBoxColumn1.Name = "sWROptPropOutDataGridViewCheckBoxColumn1";
            // 
            // sWROptTimeOutDataGridViewTextBoxColumn1
            // 
            this.sWROptTimeOutDataGridViewTextBoxColumn1.DataPropertyName = "SW_R_Opt_TimeOut";
            this.sWROptTimeOutDataGridViewTextBoxColumn1.HeaderText = "SW_R_Opt_TimeOut";
            this.sWROptTimeOutDataGridViewTextBoxColumn1.Name = "sWROptTimeOutDataGridViewTextBoxColumn1";
            // 
            // sWROptContKeysDataGridViewTextBoxColumn1
            // 
            this.sWROptContKeysDataGridViewTextBoxColumn1.DataPropertyName = "SW_R_Opt_Cont_Keys";
            this.sWROptContKeysDataGridViewTextBoxColumn1.HeaderText = "SW_R_Opt_Cont_Keys";
            this.sWROptContKeysDataGridViewTextBoxColumn1.Name = "sWROptContKeysDataGridViewTextBoxColumn1";
            // 
            // sWROptLockSameRowDataGridViewCheckBoxColumn1
            // 
            this.sWROptLockSameRowDataGridViewCheckBoxColumn1.DataPropertyName = "SW_R_Opt_LockSameRow";
            this.sWROptLockSameRowDataGridViewCheckBoxColumn1.HeaderText = "SW_R_Opt_LockSameRow";
            this.sWROptLockSameRowDataGridViewCheckBoxColumn1.Name = "sWROptLockSameRowDataGridViewCheckBoxColumn1";
            // 
            // sWROptUseSPDataGridViewCheckBoxColumn1
            // 
            this.sWROptUseSPDataGridViewCheckBoxColumn1.DataPropertyName = "SW_R_Opt_Use_SP";
            this.sWROptUseSPDataGridViewCheckBoxColumn1.HeaderText = "SW_R_Opt_Use_SP";
            this.sWROptUseSPDataGridViewCheckBoxColumn1.Name = "sWROptUseSPDataGridViewCheckBoxColumn1";
            // 
            // sWROptMaxPairDevicesDataGridViewTextBoxColumn1
            // 
            this.sWROptMaxPairDevicesDataGridViewTextBoxColumn1.DataPropertyName = "SW_R_Opt_MaxPairDevices";
            this.sWROptMaxPairDevicesDataGridViewTextBoxColumn1.HeaderText = "SW_R_Opt_MaxPairDevices";
            this.sWROptMaxPairDevicesDataGridViewTextBoxColumn1.Name = "sWROptMaxPairDevicesDataGridViewTextBoxColumn1";
            // 
            // sWROptShiftPageDataGridViewCheckBoxColumn1
            // 
            this.sWROptShiftPageDataGridViewCheckBoxColumn1.DataPropertyName = "SW_R_Opt_ShiftPage";
            this.sWROptShiftPageDataGridViewCheckBoxColumn1.HeaderText = "SW_R_Opt_ShiftPage";
            this.sWROptShiftPageDataGridViewCheckBoxColumn1.Name = "sWROptShiftPageDataGridViewCheckBoxColumn1";
            // 
            // sWROptOutputNoDataGridViewTextBoxColumn1
            // 
            this.sWROptOutputNoDataGridViewTextBoxColumn1.DataPropertyName = "SW_R_Opt_Output_No";
            this.sWROptOutputNoDataGridViewTextBoxColumn1.HeaderText = "SW_R_Opt_Output_No";
            this.sWROptOutputNoDataGridViewTextBoxColumn1.Name = "sWROptOutputNoDataGridViewTextBoxColumn1";
            // 
            // sWROptDigInputNoDataGridViewTextBoxColumn1
            // 
            this.sWROptDigInputNoDataGridViewTextBoxColumn1.DataPropertyName = "SW_R_Opt_Dig_Input_No";
            this.sWROptDigInputNoDataGridViewTextBoxColumn1.HeaderText = "SW_R_Opt_Dig_Input_No";
            this.sWROptDigInputNoDataGridViewTextBoxColumn1.Name = "sWROptDigInputNoDataGridViewTextBoxColumn1";
            // 
            // sWROptAnaInputNoDataGridViewTextBoxColumn1
            // 
            this.sWROptAnaInputNoDataGridViewTextBoxColumn1.DataPropertyName = "SW_R_Opt_Ana_Input_No";
            this.sWROptAnaInputNoDataGridViewTextBoxColumn1.HeaderText = "SW_R_Opt_Ana_Input_No";
            this.sWROptAnaInputNoDataGridViewTextBoxColumn1.Name = "sWROptAnaInputNoDataGridViewTextBoxColumn1";
            // 
            // sWRevisioniDataGridViewTextBoxColumn1
            // 
            this.sWRevisioniDataGridViewTextBoxColumn1.DataPropertyName = "SW_Revisioni";
            this.sWRevisioniDataGridViewTextBoxColumn1.HeaderText = "SW_Revisioni";
            this.sWRevisioniDataGridViewTextBoxColumn1.Name = "sWRevisioniDataGridViewTextBoxColumn1";
            // 
            // sWFunzionamentoDataGridViewTextBoxColumn1
            // 
            this.sWFunzionamentoDataGridViewTextBoxColumn1.DataPropertyName = "SW_Funzionamento";
            this.sWFunzionamentoDataGridViewTextBoxColumn1.HeaderText = "SW_Funzionamento";
            this.sWFunzionamentoDataGridViewTextBoxColumn1.Name = "sWFunzionamentoDataGridViewTextBoxColumn1";
            // 
            // sWConfigDataGridViewTextBoxColumn1
            // 
            this.sWConfigDataGridViewTextBoxColumn1.DataPropertyName = "SW_Config";
            this.sWConfigDataGridViewTextBoxColumn1.HeaderText = "SW_Config";
            this.sWConfigDataGridViewTextBoxColumn1.Name = "sWConfigDataGridViewTextBoxColumn1";
            // 
            // sWObsoleteverDataGridViewCheckBoxColumn1
            // 
            this.sWObsoleteverDataGridViewCheckBoxColumn1.DataPropertyName = "SW_Obsolete_ver";
            this.sWObsoleteverDataGridViewCheckBoxColumn1.HeaderText = "SW_Obsolete_ver";
            this.sWObsoleteverDataGridViewCheckBoxColumn1.Name = "sWObsoleteverDataGridViewCheckBoxColumn1";
            // 
            // sWObsoleteverfromdateDataGridViewTextBoxColumn1
            // 
            this.sWObsoleteverfromdateDataGridViewTextBoxColumn1.DataPropertyName = "SW_Obsolete_ver_from_date";
            this.sWObsoleteverfromdateDataGridViewTextBoxColumn1.HeaderText = "SW_Obsolete_ver_from_date";
            this.sWObsoleteverfromdateDataGridViewTextBoxColumn1.Name = "sWObsoleteverfromdateDataGridViewTextBoxColumn1";
            // 
            // metroGrid5
            // 
            this.metroGrid5.AllowUserToResizeRows = false;
            this.metroGrid5.AutoGenerateColumns = false;
            this.metroGrid5.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid5.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid5.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid5.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.metroGrid5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serKitDataGridViewTextBoxColumn1,
            this.serIDCliDataGridViewTextBoxColumn1,
            this.serDeviceDataGridViewTextBoxColumn1,
            this.serDeviceIDCodeDataGridViewTextBoxColumn1,
            this.serOfficialSerialDataGridViewTextBoxColumn1,
            this.serReadSerialDataGridViewTextBoxColumn1,
            this.serSWCodeDataGridViewTextBoxColumn1,
            this.serSWCodeRevDataGridViewTextBoxColumn1,
            this.serSWStdTypeDataGridViewCheckBoxColumn1,
            this.serSNprodDataGridViewTextBoxColumn1,
            this.serCommessaDataGridViewTextBoxColumn1,
            this.serDateProductionDataGridViewTextBoxColumn1,
            this.serSpeditoDataGridViewCheckBoxColumn1,
            this.serDataSpeditoDataGridViewTextBoxColumn1,
            this.serSubstitionIDReadSerialDataGridViewTextBoxColumn1,
            this.serNoteDataGridViewTextBoxColumn1,
            this.serObsoleteFromDateDataGridViewTextBoxColumn});
            this.metroGrid5.DataSource = this.serialNumbersSerialNumbersObsoleteBindingSource;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid5.DefaultCellStyle = dataGridViewCellStyle14;
            this.metroGrid5.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroGrid5.EnableHeadersVisualStyles = false;
            this.metroGrid5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid5.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid5.Location = new System.Drawing.Point(0, 600);
            this.metroGrid5.Name = "metroGrid5";
            this.metroGrid5.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid5.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.metroGrid5.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid5.Size = new System.Drawing.Size(800, 150);
            this.metroGrid5.TabIndex = 4;
            // 
            // serialNumbersSerialNumbersObsoleteBindingSource
            // 
            this.serialNumbersSerialNumbersObsoleteBindingSource.DataMember = "SerialNumbers_SerialNumbers_Obsolete";
            this.serialNumbersSerialNumbersObsoleteBindingSource.DataSource = this.sFClientiSerialNumbersSerialNumbersBindingSource;
            // 
            // serialNumbers_ObsoleteTableAdapter
            // 
            this.serialNumbers_ObsoleteTableAdapter.ClearBeforeFill = true;
            // 
            // serKitDataGridViewTextBoxColumn1
            // 
            this.serKitDataGridViewTextBoxColumn1.DataPropertyName = "Ser_Kit";
            this.serKitDataGridViewTextBoxColumn1.HeaderText = "Ser_Kit";
            this.serKitDataGridViewTextBoxColumn1.Name = "serKitDataGridViewTextBoxColumn1";
            // 
            // serIDCliDataGridViewTextBoxColumn1
            // 
            this.serIDCliDataGridViewTextBoxColumn1.DataPropertyName = "Ser_ID_Cli";
            this.serIDCliDataGridViewTextBoxColumn1.HeaderText = "Ser_ID_Cli";
            this.serIDCliDataGridViewTextBoxColumn1.Name = "serIDCliDataGridViewTextBoxColumn1";
            // 
            // serDeviceDataGridViewTextBoxColumn1
            // 
            this.serDeviceDataGridViewTextBoxColumn1.DataPropertyName = "Ser_Device";
            this.serDeviceDataGridViewTextBoxColumn1.HeaderText = "Ser_Device";
            this.serDeviceDataGridViewTextBoxColumn1.Name = "serDeviceDataGridViewTextBoxColumn1";
            // 
            // serDeviceIDCodeDataGridViewTextBoxColumn1
            // 
            this.serDeviceIDCodeDataGridViewTextBoxColumn1.DataPropertyName = "Ser_Device_ID_Code";
            this.serDeviceIDCodeDataGridViewTextBoxColumn1.HeaderText = "Ser_Device_ID_Code";
            this.serDeviceIDCodeDataGridViewTextBoxColumn1.Name = "serDeviceIDCodeDataGridViewTextBoxColumn1";
            // 
            // serOfficialSerialDataGridViewTextBoxColumn1
            // 
            this.serOfficialSerialDataGridViewTextBoxColumn1.DataPropertyName = "Ser_OfficialSerial";
            this.serOfficialSerialDataGridViewTextBoxColumn1.HeaderText = "Ser_OfficialSerial";
            this.serOfficialSerialDataGridViewTextBoxColumn1.Name = "serOfficialSerialDataGridViewTextBoxColumn1";
            // 
            // serReadSerialDataGridViewTextBoxColumn1
            // 
            this.serReadSerialDataGridViewTextBoxColumn1.DataPropertyName = "Ser_ReadSerial";
            this.serReadSerialDataGridViewTextBoxColumn1.HeaderText = "Ser_ReadSerial";
            this.serReadSerialDataGridViewTextBoxColumn1.Name = "serReadSerialDataGridViewTextBoxColumn1";
            // 
            // serSWCodeDataGridViewTextBoxColumn1
            // 
            this.serSWCodeDataGridViewTextBoxColumn1.DataPropertyName = "Ser_SW_Code";
            this.serSWCodeDataGridViewTextBoxColumn1.HeaderText = "Ser_SW_Code";
            this.serSWCodeDataGridViewTextBoxColumn1.Name = "serSWCodeDataGridViewTextBoxColumn1";
            // 
            // serSWCodeRevDataGridViewTextBoxColumn1
            // 
            this.serSWCodeRevDataGridViewTextBoxColumn1.DataPropertyName = "Ser_SW_Code_Rev";
            this.serSWCodeRevDataGridViewTextBoxColumn1.HeaderText = "Ser_SW_Code_Rev";
            this.serSWCodeRevDataGridViewTextBoxColumn1.Name = "serSWCodeRevDataGridViewTextBoxColumn1";
            // 
            // serSWStdTypeDataGridViewCheckBoxColumn1
            // 
            this.serSWStdTypeDataGridViewCheckBoxColumn1.DataPropertyName = "Ser_SW_Std_Type";
            this.serSWStdTypeDataGridViewCheckBoxColumn1.HeaderText = "Ser_SW_Std_Type";
            this.serSWStdTypeDataGridViewCheckBoxColumn1.Name = "serSWStdTypeDataGridViewCheckBoxColumn1";
            // 
            // serSNprodDataGridViewTextBoxColumn1
            // 
            this.serSNprodDataGridViewTextBoxColumn1.DataPropertyName = "Ser_SN_prod";
            this.serSNprodDataGridViewTextBoxColumn1.HeaderText = "Ser_SN_prod";
            this.serSNprodDataGridViewTextBoxColumn1.Name = "serSNprodDataGridViewTextBoxColumn1";
            // 
            // serCommessaDataGridViewTextBoxColumn1
            // 
            this.serCommessaDataGridViewTextBoxColumn1.DataPropertyName = "Ser_Commessa";
            this.serCommessaDataGridViewTextBoxColumn1.HeaderText = "Ser_Commessa";
            this.serCommessaDataGridViewTextBoxColumn1.Name = "serCommessaDataGridViewTextBoxColumn1";
            // 
            // serDateProductionDataGridViewTextBoxColumn1
            // 
            this.serDateProductionDataGridViewTextBoxColumn1.DataPropertyName = "Ser_DateProduction";
            this.serDateProductionDataGridViewTextBoxColumn1.HeaderText = "Ser_DateProduction";
            this.serDateProductionDataGridViewTextBoxColumn1.Name = "serDateProductionDataGridViewTextBoxColumn1";
            // 
            // serSpeditoDataGridViewCheckBoxColumn1
            // 
            this.serSpeditoDataGridViewCheckBoxColumn1.DataPropertyName = "Ser_Spedito";
            this.serSpeditoDataGridViewCheckBoxColumn1.HeaderText = "Ser_Spedito";
            this.serSpeditoDataGridViewCheckBoxColumn1.Name = "serSpeditoDataGridViewCheckBoxColumn1";
            // 
            // serDataSpeditoDataGridViewTextBoxColumn1
            // 
            this.serDataSpeditoDataGridViewTextBoxColumn1.DataPropertyName = "Ser_Data_Spedito";
            this.serDataSpeditoDataGridViewTextBoxColumn1.HeaderText = "Ser_Data_Spedito";
            this.serDataSpeditoDataGridViewTextBoxColumn1.Name = "serDataSpeditoDataGridViewTextBoxColumn1";
            // 
            // serSubstitionIDReadSerialDataGridViewTextBoxColumn1
            // 
            this.serSubstitionIDReadSerialDataGridViewTextBoxColumn1.DataPropertyName = "Ser_Substition_ID_ReadSerial";
            this.serSubstitionIDReadSerialDataGridViewTextBoxColumn1.HeaderText = "Ser_Substition_ID_ReadSerial";
            this.serSubstitionIDReadSerialDataGridViewTextBoxColumn1.Name = "serSubstitionIDReadSerialDataGridViewTextBoxColumn1";
            // 
            // serNoteDataGridViewTextBoxColumn1
            // 
            this.serNoteDataGridViewTextBoxColumn1.DataPropertyName = "Ser_Note";
            this.serNoteDataGridViewTextBoxColumn1.HeaderText = "Ser_Note";
            this.serNoteDataGridViewTextBoxColumn1.Name = "serNoteDataGridViewTextBoxColumn1";
            // 
            // serObsoleteFromDateDataGridViewTextBoxColumn
            // 
            this.serObsoleteFromDateDataGridViewTextBoxColumn.DataPropertyName = "Ser_ObsoleteFromDate";
            this.serObsoleteFromDateDataGridViewTextBoxColumn.HeaderText = "Ser_ObsoleteFromDate";
            this.serObsoleteFromDateDataGridViewTextBoxColumn.Name = "serObsoleteFromDateDataGridViewTextBoxColumn";
            // 
            // metroGrid6
            // 
            this.metroGrid6.AllowUserToResizeRows = false;
            this.metroGrid6.AutoGenerateColumns = false;
            this.metroGrid6.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid6.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid6.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid6.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.metroGrid6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serialnumberDataGridViewTextBoxColumn,
            this.versionDataGridViewTextBoxColumn,
            this.revisionDataGridViewTextBoxColumn,
            this.useridDataGridViewTextBoxColumn,
            this.deviceidDataGridViewTextBoxColumn,
            this.createdatDataGridViewTextBoxColumn,
            this.typeDataGridViewTextBoxColumn,
            this.extrasDataGridViewTextBoxColumn,
            this.useremailDataGridViewTextBoxColumn,
            this.customernameDataGridViewTextBoxColumn});
            this.metroGrid6.DataSource = this.serialNumbersBSSNHistoryBindingSource;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid6.DefaultCellStyle = dataGridViewCellStyle17;
            this.metroGrid6.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroGrid6.EnableHeadersVisualStyles = false;
            this.metroGrid6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid6.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid6.Location = new System.Drawing.Point(0, 750);
            this.metroGrid6.Name = "metroGrid6";
            this.metroGrid6.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid6.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.metroGrid6.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid6.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid6.Size = new System.Drawing.Size(800, 150);
            this.metroGrid6.TabIndex = 5;
            // 
            // serialNumbersBSSNHistoryBindingSource
            // 
            this.serialNumbersBSSNHistoryBindingSource.DataMember = "SerialNumbers_BS_SN_History";
            this.serialNumbersBSSNHistoryBindingSource.DataSource = this.sFClientiSerialNumbersSerialNumbersBindingSource;
            // 
            // bS_SN_HistoryTableAdapter
            // 
            this.bS_SN_HistoryTableAdapter.ClearBeforeFill = true;
            // 
            // serialnumberDataGridViewTextBoxColumn
            // 
            this.serialnumberDataGridViewTextBoxColumn.DataPropertyName = "serialnumber";
            this.serialnumberDataGridViewTextBoxColumn.HeaderText = "serialnumber";
            this.serialnumberDataGridViewTextBoxColumn.Name = "serialnumberDataGridViewTextBoxColumn";
            // 
            // versionDataGridViewTextBoxColumn
            // 
            this.versionDataGridViewTextBoxColumn.DataPropertyName = "version";
            this.versionDataGridViewTextBoxColumn.HeaderText = "version";
            this.versionDataGridViewTextBoxColumn.Name = "versionDataGridViewTextBoxColumn";
            // 
            // revisionDataGridViewTextBoxColumn
            // 
            this.revisionDataGridViewTextBoxColumn.DataPropertyName = "revision";
            this.revisionDataGridViewTextBoxColumn.HeaderText = "revision";
            this.revisionDataGridViewTextBoxColumn.Name = "revisionDataGridViewTextBoxColumn";
            // 
            // useridDataGridViewTextBoxColumn
            // 
            this.useridDataGridViewTextBoxColumn.DataPropertyName = "user_id";
            this.useridDataGridViewTextBoxColumn.HeaderText = "user_id";
            this.useridDataGridViewTextBoxColumn.Name = "useridDataGridViewTextBoxColumn";
            // 
            // deviceidDataGridViewTextBoxColumn
            // 
            this.deviceidDataGridViewTextBoxColumn.DataPropertyName = "device_id";
            this.deviceidDataGridViewTextBoxColumn.HeaderText = "device_id";
            this.deviceidDataGridViewTextBoxColumn.Name = "deviceidDataGridViewTextBoxColumn";
            // 
            // createdatDataGridViewTextBoxColumn
            // 
            this.createdatDataGridViewTextBoxColumn.DataPropertyName = "created_at";
            this.createdatDataGridViewTextBoxColumn.HeaderText = "created_at";
            this.createdatDataGridViewTextBoxColumn.Name = "createdatDataGridViewTextBoxColumn";
            // 
            // typeDataGridViewTextBoxColumn
            // 
            this.typeDataGridViewTextBoxColumn.DataPropertyName = "type";
            this.typeDataGridViewTextBoxColumn.HeaderText = "type";
            this.typeDataGridViewTextBoxColumn.Name = "typeDataGridViewTextBoxColumn";
            // 
            // extrasDataGridViewTextBoxColumn
            // 
            this.extrasDataGridViewTextBoxColumn.DataPropertyName = "extras";
            this.extrasDataGridViewTextBoxColumn.HeaderText = "extras";
            this.extrasDataGridViewTextBoxColumn.Name = "extrasDataGridViewTextBoxColumn";
            // 
            // useremailDataGridViewTextBoxColumn
            // 
            this.useremailDataGridViewTextBoxColumn.DataPropertyName = "user_email";
            this.useremailDataGridViewTextBoxColumn.HeaderText = "user_email";
            this.useremailDataGridViewTextBoxColumn.Name = "useremailDataGridViewTextBoxColumn";
            // 
            // customernameDataGridViewTextBoxColumn
            // 
            this.customernameDataGridViewTextBoxColumn.DataPropertyName = "customer_name";
            this.customernameDataGridViewTextBoxColumn.HeaderText = "customer_name";
            this.customernameDataGridViewTextBoxColumn.Name = "customernameDataGridViewTextBoxColumn";
            // 
            // Prova
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 839);
            this.ControlBox = false;
            this.Controls.Add(this.metroGrid6);
            this.Controls.Add(this.metroGrid5);
            this.Controls.Add(this.metroGrid4);
            this.Controls.Add(this.metroGrid3);
            this.Controls.Add(this.metroGrid2);
            this.Controls.Add(this.metroGrid1);
            this.Name = "Prova";
            this.Text = "Prova";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Prova_Load);
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL_History)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFClientiSerialNumbersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFClientiSerialNumbersSerialNumbersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.serialNumbersFirmwareBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.serialNumbersLastFirmwareBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.serialNumbersSerialNumbersObsoleteBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.serialNumbersBSSNHistoryBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroGrid metroGrid1;
        private ds_SL_History ds_SL_History;
        private System.Windows.Forms.BindingSource sFClientiSerialNumbersBindingSource;
        private ds_SL_HistoryTableAdapters.SF_Clienti_SerialNumbersTableAdapter sF_Clienti_SerialNumbersTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn mastroDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn capocDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sottocDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn codAnagraficoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ragSocCognomeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ragSocNomeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ragSocCompletaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn indirizzoFiscaleDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroGrid metroGrid2;
        private System.Windows.Forms.BindingSource sFClientiSerialNumbersSerialNumbersBindingSource;
        private ds_SL_HistoryTableAdapters.SerialNumbersTableAdapter serialNumbersTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serKitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serIDCliDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serDeviceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serDeviceIDCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serOfficialSerialDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serReadSerialDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serSWCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serSWCodeRevDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn serSWStdTypeDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serSNprodDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serCommessaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serDateProductionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn serSpeditoDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serDataSpeditoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serSubstitionIDReadSerialDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serNoteDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroGrid metroGrid3;
        private System.Windows.Forms.BindingSource serialNumbersFirmwareBindingSource;
        private ds_SL_HistoryTableAdapters.FirmwareTableAdapter firmwareTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWTipoDeviceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWDescrizioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWDescrizioneENDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWVersioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWRevisioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWStandardDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWFamProdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWPOptRFDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPOptUseOledDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPOptUseEmButtDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPOptUseBacklightDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPOptShiftPageDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPOptUseAccelDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPOptUseSPDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPOptUseBuzzerDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPOptUseVibracallDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPOptUseLedTorchDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPPLDDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWPOptMaxPairDevicesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWROptRFDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWROptPlugExpDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWROptPlugPleDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWROptEmKeybDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWROptCanDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWROptPropOutDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWROptTimeOutDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWROptContKeysDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWROptLockSameRowDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWROptUseSPDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWROptMaxPairDevicesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWROptShiftPageDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWROptOutputNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWROptDigInputNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWROptAnaInputNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWRevisioniDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWFunzionamentoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWConfigDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWObsoleteverDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWObsoleteverfromdateDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroGrid metroGrid4;
        private System.Windows.Forms.BindingSource serialNumbersLastFirmwareBindingSource;
        private ds_SL_HistoryTableAdapters.LastFirmwareTableAdapter lastFirmwareTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWCodeDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWTipoDeviceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWDescrizioneDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWDescrizioneENDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWVersioneDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWRevisioneDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWStandardDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWFamProdDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWPOptRFDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPOptUseOledDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPOptUseEmButtDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPOptUseBacklightDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPOptShiftPageDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPOptUseAccelDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPOptUseSPDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPOptUseBuzzerDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPOptUseVibracallDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPOptUseLedTorchDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWPPLDDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWPOptMaxPairDevicesDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWROptRFDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWROptPlugExpDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWROptPlugPleDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWROptEmKeybDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWROptCanDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWROptPropOutDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWROptTimeOutDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWROptContKeysDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWROptLockSameRowDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWROptUseSPDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWROptMaxPairDevicesDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWROptShiftPageDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWROptOutputNoDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWROptDigInputNoDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWROptAnaInputNoDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWRevisioniDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWFunzionamentoDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWConfigDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWObsoleteverDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWObsoleteverfromdateDataGridViewTextBoxColumn1;
        private MetroFramework.Controls.MetroGrid metroGrid5;
        private System.Windows.Forms.BindingSource serialNumbersSerialNumbersObsoleteBindingSource;
        private ds_SL_HistoryTableAdapters.SerialNumbers_ObsoleteTableAdapter serialNumbers_ObsoleteTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn serKitDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serIDCliDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serDeviceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serDeviceIDCodeDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serOfficialSerialDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serReadSerialDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serSWCodeDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serSWCodeRevDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn serSWStdTypeDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serSNprodDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serCommessaDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serDateProductionDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn serSpeditoDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serDataSpeditoDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serSubstitionIDReadSerialDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serNoteDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serObsoleteFromDateDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroGrid metroGrid6;
        private System.Windows.Forms.BindingSource serialNumbersBSSNHistoryBindingSource;
        private ds_SL_HistoryTableAdapters.BS_SN_HistoryTableAdapter bS_SN_HistoryTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn serialnumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn versionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn revisionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn useridDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn deviceidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn createdatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn extrasDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn useremailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customernameDataGridViewTextBoxColumn;
    }
}