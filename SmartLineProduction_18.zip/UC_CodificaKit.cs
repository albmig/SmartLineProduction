﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using System.Web.UI.Design;

namespace SmartLineProduction
{
    public partial class UC_CodificaKit : MetroFramework.Forms.MetroForm
    {
        string code_prefix = "XKIT";
        string code_cli = "";
        string code_variante = "";
        string code_prog = "";
        string code_combohw = "";
        string code_cablvar = "";
        string code_fam = "";
        string code_freq = "";
        string code_suffix = "_L";
        string code_KIT = "";

        public UC_CodificaKit()
        {
            InitializeComponent();
        }

        /// Control Events
        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UC_CodificaKit_Load(object sender, EventArgs e)
        {
            SetView();
            CreaCodice();

            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL1.Tab_Combokit'. È possibile spostarla o rimuoverla se necessario.
            this.tab_CombokitTableAdapter.FillBy_Tab_COMBOKIT(this.ds_SL.Tab_Combokit);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL1.Tab_Freq'. È possibile spostarla o rimuoverla se necessario.
            this.tab_FreqTableAdapter.FillBy_Tab_FREQ(this.ds_SL.Tab_Freq);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL1.Tab_Fam'. È possibile spostarla o rimuoverla se necessario.
            this.tab_FamTableAdapter.FillBy_Tab_FAM(this.ds_SL.Tab_Fam);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL1.Tab_Cbl'. È possibile spostarla o rimuoverla se necessario.
            this.tab_CblTableAdapter.FillBy_Tab_CBL(this.ds_SL.Tab_Cbl);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.Tab_Combohw'. È possibile spostarla o rimuoverla se necessario.
            this.tab_CombohwTableAdapter.FillBy_Tab_COMBOHW(this.ds_SL.Tab_Combohw);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.Tab_Var'. È possibile spostarla o rimuoverla se necessario.
            this.tab_VarTableAdapter.FillBy_Tab_VAR(this.ds_SL.Tab_Var);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_ArticoliSchede'. È possibile spostarla o rimuoverla se necessario.
            //this.sF_ArticoliSchedeTableAdapter.FillBy_SchedeProdottoKit(this.ds_SL.SF_ArticoliSchede);

        }

        private void tabVarBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            DataRowView drview = (DataRowView)tabVarBindingSource.Current;
            if (drview != null)
            {
                code_variante = drview["Tab_Valore"].ToString();
                lab_var.Text = code_variante;
                CreaCodice();
            }
        }

        private void tabCombohwBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            DataRowView drview = (DataRowView)tabCombohwBindingSource.Current;
            if (drview != null)
            {
                code_combohw = drview["Tab_Valore"].ToString();
                lab_combohw.Text = code_combohw;
                CreaCodice();
            }
        }

        private void tabCblBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            DataRowView drview = (DataRowView)tabCblBindingSource.Current;
            if (drview != null)
            {
                code_cablvar = drview["Tab_Valore"].ToString();
                lab_cbl.Text = code_cablvar;
                CreaCodice();
            }
        }

        private void tabFamBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            DataRowView drview = (DataRowView)tabFamBindingSource.Current;
            if (drview != null)
            {
                code_fam = drview["Tab_Valore"].ToString();
                lab_fam.Text = code_fam;
                CreaCodice();
            }
        }

        private void tabFreqBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            DataRowView drview = (DataRowView)tabFreqBindingSource.Current;
            if (drview != null)
            {
                code_freq = drview["Tab_Valore"].ToString();
                lab_freq.Text = code_freq;
                CreaCodice();
            }
        }

        /// Routines
        private void SetView()
        {
            code_prefix = "XKIT";
            code_cli = "__";
            code_variante = "_";
            code_prog = "__";
            code_combohw = "_";
            code_cablvar = "_";
            code_fam = "_";
            code_freq = "_";
            code_suffix = "_L";
            code_KIT = "";

            tb_CodiceKit.Text = "XKIT";
        }

        private void CreaCodice()
        {
            code_KIT = code_prefix + code_cli + code_variante + code_prog + code_combohw + code_cablvar + code_fam + code_freq + code_suffix;
            tb_CodiceKit.Text = code_KIT;
            tb_CodiceKit.Refresh();
            FiltraKit();
        }

        private void FiltraKit()
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_ArticoliSchede'. È possibile spostarla o rimuoverla se necessario.
            this.sF_ArticoliSchedeTableAdapter.FillBy_CodificaKit(this.ds_SL.SF_ArticoliSchede, code_KIT);

            gv_Schede.Refresh();
        }

        private void tabCombokitBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            DataRowView drview = (DataRowView)tabCombokitBindingSource.Current;
            if (drview != null)
            {
                code_prog = drview["Tab_Valore"].ToString();
                lab_prog.Text = code_prog;
                CreaCodice();
            }

        }
    }
}
