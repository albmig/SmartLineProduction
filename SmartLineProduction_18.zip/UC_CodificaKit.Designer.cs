﻿namespace SmartLineProduction
{
    partial class UC_CodificaKit
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_CodificaKit));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.layout_orizz_menu = new System.Windows.Forms.TableLayoutPanel();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel_grid_Schede = new MetroFramework.Controls.MetroPanel();
            this.gv_Schede = new MetroFramework.Controls.MetroGrid();
            this.sFArticoliSchedeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.panel_scelta = new MetroFramework.Controls.MetroPanel();
            this.lab_prog = new MetroFramework.Controls.MetroLabel();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.tabCombokitBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.lab_freq = new MetroFramework.Controls.MetroLabel();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.tabFreqBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.lab_fam = new MetroFramework.Controls.MetroLabel();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.tabFamBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.lab_cbl = new MetroFramework.Controls.MetroLabel();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.tabCblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.lab_combohw = new MetroFramework.Controls.MetroLabel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.tabCombohwBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.lab_var = new MetroFramework.Controls.MetroLabel();
            this.cb_var = new System.Windows.Forms.ComboBox();
            this.tabVarBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.panel_code = new MetroFramework.Controls.MetroPanel();
            this.tb_CodiceKit = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.tab_VarTableAdapter = new SmartLineProduction.ds_SLTableAdapters.Tab_VarTableAdapter();
            this.sF_ArticoliSchedeTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_ArticoliSchedeTableAdapter();
            this.tab_CombohwTableAdapter = new SmartLineProduction.ds_SLTableAdapters.Tab_CombohwTableAdapter();
            this.tab_CblTableAdapter = new SmartLineProduction.ds_SLTableAdapters.Tab_CblTableAdapter();
            this.tab_FamTableAdapter = new SmartLineProduction.ds_SLTableAdapters.Tab_FamTableAdapter();
            this.tab_FreqTableAdapter = new SmartLineProduction.ds_SLTableAdapters.Tab_FreqTableAdapter();
            this.tab_CombokitTableAdapter = new SmartLineProduction.ds_SLTableAdapters.Tab_CombokitTableAdapter();
            this.articoloDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descrizioneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descrizioneEstesaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.modelloDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prefix3DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prefix5DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.famigliaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.layout_orizz_menu.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel_grid_Schede.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Schede)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFArticoliSchedeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            this.panel_scelta.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabCombokitBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabFreqBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabFamBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabCblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabCombohwBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabVarBindingSource)).BeginInit();
            this.panel_code.SuspendLayout();
            this.SuspendLayout();
            // 
            // layout_orizz_menu
            // 
            this.layout_orizz_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.ColumnCount = 10;
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_exit, 10, 0);
            this.layout_orizz_menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_orizz_menu.Location = new System.Drawing.Point(20, 30);
            this.layout_orizz_menu.Name = "layout_orizz_menu";
            this.layout_orizz_menu.RowCount = 1;
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_orizz_menu.Size = new System.Drawing.Size(960, 25);
            this.layout_orizz_menu.TabIndex = 124;
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Gainsboro;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(885, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(75, 24);
            this.pan_Menu_exit.TabIndex = 82;
            this.pan_Menu_exit.Text = "menuStrip1";
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            this.menu_sw_exit.Click += new System.EventHandler(this.menu_sw_exit_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.panel_grid_Schede, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel_scelta, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel_code, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(20, 55);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(960, 425);
            this.tableLayoutPanel1.TabIndex = 125;
            // 
            // panel_grid_Schede
            // 
            this.panel_grid_Schede.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tableLayoutPanel1.SetColumnSpan(this.panel_grid_Schede, 2);
            this.panel_grid_Schede.Controls.Add(this.gv_Schede);
            this.panel_grid_Schede.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_grid_Schede.HorizontalScrollbarBarColor = true;
            this.panel_grid_Schede.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_grid_Schede.HorizontalScrollbarSize = 10;
            this.panel_grid_Schede.Location = new System.Drawing.Point(3, 247);
            this.panel_grid_Schede.Name = "panel_grid_Schede";
            this.tableLayoutPanel1.SetRowSpan(this.panel_grid_Schede, 2);
            this.panel_grid_Schede.Size = new System.Drawing.Size(413, 175);
            this.panel_grid_Schede.TabIndex = 84;
            this.panel_grid_Schede.VerticalScrollbarBarColor = true;
            this.panel_grid_Schede.VerticalScrollbarHighlightOnWheel = false;
            this.panel_grid_Schede.VerticalScrollbarSize = 10;
            // 
            // gv_Schede
            // 
            this.gv_Schede.AllowUserToAddRows = false;
            this.gv_Schede.AllowUserToDeleteRows = false;
            this.gv_Schede.AllowUserToResizeRows = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_Schede.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.gv_Schede.AutoGenerateColumns = false;
            this.gv_Schede.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Schede.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Schede.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_Schede.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Schede.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.gv_Schede.ColumnHeadersHeight = 40;
            this.gv_Schede.ColumnHeadersVisible = false;
            this.gv_Schede.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.articoloDataGridViewTextBoxColumn,
            this.descrizioneDataGridViewTextBoxColumn,
            this.descrizioneEstesaDataGridViewTextBoxColumn,
            this.modelloDataGridViewTextBoxColumn,
            this.prefix3DataGridViewTextBoxColumn,
            this.prefix5DataGridViewTextBoxColumn,
            this.famigliaDataGridViewTextBoxColumn});
            this.gv_Schede.DataSource = this.sFArticoliSchedeBindingSource;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Schede.DefaultCellStyle = dataGridViewCellStyle7;
            this.gv_Schede.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Schede.EnableHeadersVisualStyles = false;
            this.gv_Schede.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Schede.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Schede.Location = new System.Drawing.Point(0, 0);
            this.gv_Schede.MultiSelect = false;
            this.gv_Schede.Name = "gv_Schede";
            this.gv_Schede.ReadOnly = true;
            this.gv_Schede.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Schede.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.gv_Schede.RowHeadersVisible = false;
            this.gv_Schede.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Schede.RowTemplate.Height = 30;
            this.gv_Schede.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Schede.Size = new System.Drawing.Size(411, 173);
            this.gv_Schede.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_Schede.TabIndex = 0;
            this.gv_Schede.UseStyleColors = true;
            // 
            // sFArticoliSchedeBindingSource
            // 
            this.sFArticoliSchedeBindingSource.DataMember = "SF_ArticoliSchede";
            this.sFArticoliSchedeBindingSource.DataSource = this.ds_SL;
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel_scelta
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.panel_scelta, 2);
            this.panel_scelta.Controls.Add(this.lab_prog);
            this.panel_scelta.Controls.Add(this.comboBox5);
            this.panel_scelta.Controls.Add(this.metroLabel4);
            this.panel_scelta.Controls.Add(this.lab_freq);
            this.panel_scelta.Controls.Add(this.comboBox4);
            this.panel_scelta.Controls.Add(this.metroLabel8);
            this.panel_scelta.Controls.Add(this.lab_fam);
            this.panel_scelta.Controls.Add(this.comboBox3);
            this.panel_scelta.Controls.Add(this.metroLabel7);
            this.panel_scelta.Controls.Add(this.lab_cbl);
            this.panel_scelta.Controls.Add(this.comboBox2);
            this.panel_scelta.Controls.Add(this.metroLabel6);
            this.panel_scelta.Controls.Add(this.lab_combohw);
            this.panel_scelta.Controls.Add(this.comboBox1);
            this.panel_scelta.Controls.Add(this.metroLabel5);
            this.panel_scelta.Controls.Add(this.lab_var);
            this.panel_scelta.Controls.Add(this.cb_var);
            this.panel_scelta.Controls.Add(this.metroLabel3);
            this.panel_scelta.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_scelta.HorizontalScrollbarBarColor = true;
            this.panel_scelta.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_scelta.HorizontalScrollbarSize = 10;
            this.panel_scelta.Location = new System.Drawing.Point(3, 3);
            this.panel_scelta.Name = "panel_scelta";
            this.panel_scelta.Size = new System.Drawing.Size(413, 200);
            this.panel_scelta.TabIndex = 0;
            this.panel_scelta.VerticalScrollbarBarColor = true;
            this.panel_scelta.VerticalScrollbarHighlightOnWheel = false;
            this.panel_scelta.VerticalScrollbarSize = 10;
            // 
            // lab_prog
            // 
            this.lab_prog.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_prog.Location = new System.Drawing.Point(148, 30);
            this.lab_prog.Name = "lab_prog";
            this.lab_prog.Size = new System.Drawing.Size(41, 19);
            this.lab_prog.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_prog.TabIndex = 95;
            this.lab_prog.Text = "metroLabel1";
            this.lab_prog.UseStyleColors = true;
            // 
            // comboBox5
            // 
            this.comboBox5.DataSource = this.tabCombokitBindingSource;
            this.comboBox5.DisplayMember = "Tab_Des";
            this.comboBox5.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(192, 30);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(360, 21);
            this.comboBox5.TabIndex = 1;
            // 
            // tabCombokitBindingSource
            // 
            this.tabCombokitBindingSource.DataMember = "Tab_Combokit";
            this.tabCombokitBindingSource.DataSource = this.ds_SL;
            this.tabCombokitBindingSource.CurrentChanged += new System.EventHandler(this.tabCombokitBindingSource_CurrentChanged);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(0, 30);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(80, 19);
            this.metroLabel4.TabIndex = 93;
            this.metroLabel4.Text = "Progressivo:";
            // 
            // lab_freq
            // 
            this.lab_freq.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_freq.Location = new System.Drawing.Point(148, 138);
            this.lab_freq.Name = "lab_freq";
            this.lab_freq.Size = new System.Drawing.Size(41, 19);
            this.lab_freq.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_freq.TabIndex = 92;
            this.lab_freq.Text = "lab_freq";
            this.lab_freq.UseStyleColors = true;
            // 
            // comboBox4
            // 
            this.comboBox4.DataSource = this.tabFreqBindingSource;
            this.comboBox4.DisplayMember = "Tab_Des";
            this.comboBox4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(192, 138);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(360, 21);
            this.comboBox4.TabIndex = 5;
            // 
            // tabFreqBindingSource
            // 
            this.tabFreqBindingSource.DataMember = "Tab_Freq";
            this.tabFreqBindingSource.DataSource = this.ds_SL;
            this.tabFreqBindingSource.Sort = "Tab_Des ASC";
            this.tabFreqBindingSource.CurrentChanged += new System.EventHandler(this.tabFreqBindingSource_CurrentChanged);
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(0, 138);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(73, 19);
            this.metroLabel8.TabIndex = 90;
            this.metroLabel8.Text = "Frequenza:";
            // 
            // lab_fam
            // 
            this.lab_fam.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_fam.Location = new System.Drawing.Point(148, 111);
            this.lab_fam.Name = "lab_fam";
            this.lab_fam.Size = new System.Drawing.Size(41, 19);
            this.lab_fam.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_fam.TabIndex = 89;
            this.lab_fam.Text = "lab_fam";
            this.lab_fam.UseStyleColors = true;
            // 
            // comboBox3
            // 
            this.comboBox3.DataSource = this.tabFamBindingSource;
            this.comboBox3.DisplayMember = "Tab_Des";
            this.comboBox3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(192, 111);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(360, 21);
            this.comboBox3.TabIndex = 4;
            // 
            // tabFamBindingSource
            // 
            this.tabFamBindingSource.DataMember = "Tab_Fam";
            this.tabFamBindingSource.DataSource = this.ds_SL;
            this.tabFamBindingSource.Sort = "Tab_Des ASC";
            this.tabFamBindingSource.CurrentChanged += new System.EventHandler(this.tabFamBindingSource_CurrentChanged);
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(0, 111);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(61, 19);
            this.metroLabel7.TabIndex = 87;
            this.metroLabel7.Text = "Famiglia:";
            // 
            // lab_cbl
            // 
            this.lab_cbl.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_cbl.Location = new System.Drawing.Point(148, 84);
            this.lab_cbl.Name = "lab_cbl";
            this.lab_cbl.Size = new System.Drawing.Size(41, 19);
            this.lab_cbl.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_cbl.TabIndex = 86;
            this.lab_cbl.Text = "metroLabel4";
            this.lab_cbl.UseStyleColors = true;
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.tabCblBindingSource;
            this.comboBox2.DisplayMember = "Tab_Des";
            this.comboBox2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(192, 84);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(360, 21);
            this.comboBox2.TabIndex = 3;
            // 
            // tabCblBindingSource
            // 
            this.tabCblBindingSource.DataMember = "Tab_Cbl";
            this.tabCblBindingSource.DataSource = this.ds_SL;
            this.tabCblBindingSource.Sort = "Tab_Des ASC";
            this.tabCblBindingSource.CurrentChanged += new System.EventHandler(this.tabCblBindingSource_CurrentChanged);
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(0, 84);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(146, 19);
            this.metroLabel6.TabIndex = 84;
            this.metroLabel6.Text = "Cablaggio/Var. Custom:";
            // 
            // lab_combohw
            // 
            this.lab_combohw.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_combohw.Location = new System.Drawing.Point(148, 57);
            this.lab_combohw.Name = "lab_combohw";
            this.lab_combohw.Size = new System.Drawing.Size(41, 19);
            this.lab_combohw.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_combohw.TabIndex = 83;
            this.lab_combohw.Text = "lab_combohw";
            this.lab_combohw.UseStyleColors = true;
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.tabCombohwBindingSource;
            this.comboBox1.DisplayMember = "Tab_Des";
            this.comboBox1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(192, 57);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(360, 21);
            this.comboBox1.TabIndex = 2;
            // 
            // tabCombohwBindingSource
            // 
            this.tabCombohwBindingSource.DataMember = "Tab_Combohw";
            this.tabCombohwBindingSource.DataSource = this.ds_SL;
            this.tabCombohwBindingSource.Sort = "Tab_Des ASC";
            this.tabCombohwBindingSource.CurrentChanged += new System.EventHandler(this.tabCombohwBindingSource_CurrentChanged);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(0, 57);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(83, 19);
            this.metroLabel5.TabIndex = 81;
            this.metroLabel5.Text = "Combo HW:";
            // 
            // lab_var
            // 
            this.lab_var.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_var.Location = new System.Drawing.Point(148, 3);
            this.lab_var.Name = "lab_var";
            this.lab_var.Size = new System.Drawing.Size(41, 19);
            this.lab_var.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_var.TabIndex = 80;
            this.lab_var.Text = "lab_var";
            this.lab_var.UseStyleColors = true;
            // 
            // cb_var
            // 
            this.cb_var.DataSource = this.tabVarBindingSource;
            this.cb_var.DisplayMember = "Tab_Des";
            this.cb_var.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_var.FormattingEnabled = true;
            this.cb_var.Location = new System.Drawing.Point(192, 3);
            this.cb_var.Name = "cb_var";
            this.cb_var.Size = new System.Drawing.Size(360, 21);
            this.cb_var.TabIndex = 0;
            // 
            // tabVarBindingSource
            // 
            this.tabVarBindingSource.DataMember = "Tab_Var";
            this.tabVarBindingSource.DataSource = this.ds_SL;
            this.tabVarBindingSource.CurrentChanged += new System.EventHandler(this.tabVarBindingSource_CurrentChanged);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(0, 3);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(58, 19);
            this.metroLabel3.TabIndex = 78;
            this.metroLabel3.Text = "Variante:";
            // 
            // panel_code
            // 
            this.panel_code.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel1.SetColumnSpan(this.panel_code, 2);
            this.panel_code.Controls.Add(this.tb_CodiceKit);
            this.panel_code.Controls.Add(this.metroLabel2);
            this.panel_code.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_code.HorizontalScrollbarBarColor = true;
            this.panel_code.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_code.HorizontalScrollbarSize = 10;
            this.panel_code.Location = new System.Drawing.Point(3, 209);
            this.panel_code.Name = "panel_code";
            this.panel_code.Size = new System.Drawing.Size(413, 32);
            this.panel_code.TabIndex = 1;
            this.panel_code.VerticalScrollbarBarColor = true;
            this.panel_code.VerticalScrollbarHighlightOnWheel = false;
            this.panel_code.VerticalScrollbarSize = 10;
            // 
            // tb_CodiceKit
            // 
            this.tb_CodiceKit.BackColor = System.Drawing.Color.LightYellow;
            // 
            // 
            // 
            this.tb_CodiceKit.CustomButton.Image = null;
            this.tb_CodiceKit.CustomButton.Location = new System.Drawing.Point(126, 1);
            this.tb_CodiceKit.CustomButton.Name = "";
            this.tb_CodiceKit.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_CodiceKit.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_CodiceKit.CustomButton.TabIndex = 1;
            this.tb_CodiceKit.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_CodiceKit.CustomButton.UseSelectable = true;
            this.tb_CodiceKit.CustomButton.Visible = false;
            this.tb_CodiceKit.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.tb_CodiceKit.ForeColor = System.Drawing.Color.Maroon;
            this.tb_CodiceKit.Lines = new string[] {
        "metroTextBox1"};
            this.tb_CodiceKit.Location = new System.Drawing.Point(192, 5);
            this.tb_CodiceKit.MaxLength = 32767;
            this.tb_CodiceKit.Name = "tb_CodiceKit";
            this.tb_CodiceKit.PasswordChar = '\0';
            this.tb_CodiceKit.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_CodiceKit.SelectedText = "";
            this.tb_CodiceKit.SelectionLength = 0;
            this.tb_CodiceKit.SelectionStart = 0;
            this.tb_CodiceKit.ShortcutsEnabled = true;
            this.tb_CodiceKit.Size = new System.Drawing.Size(148, 23);
            this.tb_CodiceKit.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_CodiceKit.TabIndex = 76;
            this.tb_CodiceKit.Text = "metroTextBox1";
            this.tb_CodiceKit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tb_CodiceKit.UseCustomBackColor = true;
            this.tb_CodiceKit.UseSelectable = true;
            this.tb_CodiceKit.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_CodiceKit.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.BackColor = System.Drawing.Color.Transparent;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Location = new System.Drawing.Point(113, 8);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(73, 19);
            this.metroLabel2.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel2.TabIndex = 75;
            this.metroLabel2.Text = "Codice Kit:";
            this.metroLabel2.UseCustomBackColor = true;
            this.metroLabel2.UseCustomForeColor = true;
            this.metroLabel2.UseStyleColors = true;
            // 
            // tab_VarTableAdapter
            // 
            this.tab_VarTableAdapter.ClearBeforeFill = true;
            // 
            // sF_ArticoliSchedeTableAdapter
            // 
            this.sF_ArticoliSchedeTableAdapter.ClearBeforeFill = true;
            // 
            // tab_CombohwTableAdapter
            // 
            this.tab_CombohwTableAdapter.ClearBeforeFill = true;
            // 
            // tab_CblTableAdapter
            // 
            this.tab_CblTableAdapter.ClearBeforeFill = true;
            // 
            // tab_FamTableAdapter
            // 
            this.tab_FamTableAdapter.ClearBeforeFill = true;
            // 
            // tab_FreqTableAdapter
            // 
            this.tab_FreqTableAdapter.ClearBeforeFill = true;
            // 
            // tab_CombokitTableAdapter
            // 
            this.tab_CombokitTableAdapter.ClearBeforeFill = true;
            // 
            // articoloDataGridViewTextBoxColumn
            // 
            this.articoloDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.articoloDataGridViewTextBoxColumn.DataPropertyName = "Articolo";
            this.articoloDataGridViewTextBoxColumn.HeaderText = "Kit";
            this.articoloDataGridViewTextBoxColumn.Name = "articoloDataGridViewTextBoxColumn";
            this.articoloDataGridViewTextBoxColumn.ReadOnly = true;
            this.articoloDataGridViewTextBoxColumn.Width = 5;
            // 
            // descrizioneDataGridViewTextBoxColumn
            // 
            this.descrizioneDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.descrizioneDataGridViewTextBoxColumn.DataPropertyName = "Descrizione";
            this.descrizioneDataGridViewTextBoxColumn.HeaderText = "Descrizione";
            this.descrizioneDataGridViewTextBoxColumn.Name = "descrizioneDataGridViewTextBoxColumn";
            this.descrizioneDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // descrizioneEstesaDataGridViewTextBoxColumn
            // 
            this.descrizioneEstesaDataGridViewTextBoxColumn.DataPropertyName = "DescrizioneEstesa";
            this.descrizioneEstesaDataGridViewTextBoxColumn.HeaderText = "DescrizioneEstesa";
            this.descrizioneEstesaDataGridViewTextBoxColumn.Name = "descrizioneEstesaDataGridViewTextBoxColumn";
            this.descrizioneEstesaDataGridViewTextBoxColumn.ReadOnly = true;
            this.descrizioneEstesaDataGridViewTextBoxColumn.Visible = false;
            // 
            // modelloDataGridViewTextBoxColumn
            // 
            this.modelloDataGridViewTextBoxColumn.DataPropertyName = "Modello";
            this.modelloDataGridViewTextBoxColumn.HeaderText = "Modello";
            this.modelloDataGridViewTextBoxColumn.Name = "modelloDataGridViewTextBoxColumn";
            this.modelloDataGridViewTextBoxColumn.ReadOnly = true;
            this.modelloDataGridViewTextBoxColumn.Visible = false;
            // 
            // prefix3DataGridViewTextBoxColumn
            // 
            this.prefix3DataGridViewTextBoxColumn.DataPropertyName = "Prefix_3";
            this.prefix3DataGridViewTextBoxColumn.HeaderText = "Prefix_3";
            this.prefix3DataGridViewTextBoxColumn.Name = "prefix3DataGridViewTextBoxColumn";
            this.prefix3DataGridViewTextBoxColumn.ReadOnly = true;
            this.prefix3DataGridViewTextBoxColumn.Visible = false;
            // 
            // prefix5DataGridViewTextBoxColumn
            // 
            this.prefix5DataGridViewTextBoxColumn.DataPropertyName = "Prefix_5";
            this.prefix5DataGridViewTextBoxColumn.HeaderText = "Prefix_5";
            this.prefix5DataGridViewTextBoxColumn.Name = "prefix5DataGridViewTextBoxColumn";
            this.prefix5DataGridViewTextBoxColumn.ReadOnly = true;
            this.prefix5DataGridViewTextBoxColumn.Visible = false;
            // 
            // famigliaDataGridViewTextBoxColumn
            // 
            this.famigliaDataGridViewTextBoxColumn.DataPropertyName = "Famiglia";
            this.famigliaDataGridViewTextBoxColumn.HeaderText = "Famiglia";
            this.famigliaDataGridViewTextBoxColumn.Name = "famigliaDataGridViewTextBoxColumn";
            this.famigliaDataGridViewTextBoxColumn.ReadOnly = true;
            this.famigliaDataGridViewTextBoxColumn.Visible = false;
            // 
            // UC_CodificaKit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 500);
            this.ControlBox = false;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.layout_orizz_menu);
            this.DisplayHeader = false;
            this.Name = "UC_CodificaKit";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UC_CodificaKit_Load);
            this.layout_orizz_menu.ResumeLayout(false);
            this.layout_orizz_menu.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel_grid_Schede.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_Schede)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFArticoliSchedeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            this.panel_scelta.ResumeLayout(false);
            this.panel_scelta.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabCombokitBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabFreqBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabFamBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabCblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabCombohwBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabVarBindingSource)).EndInit();
            this.panel_code.ResumeLayout(false);
            this.panel_code.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel layout_orizz_menu;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private MetroFramework.Controls.MetroPanel panel_scelta;
        private MetroFramework.Controls.MetroPanel panel_code;
        private MetroFramework.Controls.MetroTextBox tb_CodiceKit;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private ds_SL ds_SL;
        private MetroFramework.Controls.MetroLabel lab_var;
        private System.Windows.Forms.ComboBox cb_var;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private System.Windows.Forms.BindingSource tabVarBindingSource;
        private ds_SLTableAdapters.Tab_VarTableAdapter tab_VarTableAdapter;
        private MetroFramework.Controls.MetroPanel panel_grid_Schede;
        private MetroFramework.Controls.MetroGrid gv_Schede;
        private System.Windows.Forms.BindingSource sFArticoliSchedeBindingSource;
        private ds_SLTableAdapters.SF_ArticoliSchedeTableAdapter sF_ArticoliSchedeTableAdapter;
        private MetroFramework.Controls.MetroLabel lab_combohw;
        private System.Windows.Forms.ComboBox comboBox1;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private System.Windows.Forms.BindingSource tabCombohwBindingSource;
        private ds_SLTableAdapters.Tab_CombohwTableAdapter tab_CombohwTableAdapter;
        private MetroFramework.Controls.MetroLabel lab_cbl;
        private System.Windows.Forms.ComboBox comboBox2;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private System.Windows.Forms.BindingSource tabCblBindingSource;
        private ds_SLTableAdapters.Tab_CblTableAdapter tab_CblTableAdapter;
        private MetroFramework.Controls.MetroLabel lab_fam;
        private System.Windows.Forms.ComboBox comboBox3;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private System.Windows.Forms.BindingSource tabFamBindingSource;
        private ds_SLTableAdapters.Tab_FamTableAdapter tab_FamTableAdapter;
        private MetroFramework.Controls.MetroLabel lab_freq;
        private System.Windows.Forms.ComboBox comboBox4;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private System.Windows.Forms.BindingSource tabFreqBindingSource;
        private ds_SLTableAdapters.Tab_FreqTableAdapter tab_FreqTableAdapter;
        private MetroFramework.Controls.MetroLabel lab_prog;
        private System.Windows.Forms.ComboBox comboBox5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private System.Windows.Forms.BindingSource tabCombokitBindingSource;
        private ds_SLTableAdapters.Tab_CombokitTableAdapter tab_CombokitTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descrizioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descrizioneEstesaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn modelloDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prefix3DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prefix5DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn famigliaDataGridViewTextBoxColumn;
    }
}
