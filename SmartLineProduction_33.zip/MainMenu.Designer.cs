﻿namespace SmartLineProduction
{
    partial class MainMenu
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenu));
            this.layout_Menu = new System.Windows.Forms.TableLayoutPanel();
            this.layout_orizz_menu = new System.Windows.Forms.TableLayoutPanel();
            this.MainMenuStrip = new System.Windows.Forms.MenuStrip();
            this.spedizioneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fasiDiAvanzamentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.programmazioneSmartLineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.programmaDaCommessaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.riprogrammazionePlugClonazioneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spedizioneToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.individuazioneEtichetteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.raccoltaDatasheetPerCommessaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aaaaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestioneDelFirmwareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classicLineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.smartLineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fWPalmariToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fWRicevitoriToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fWPikToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.codificaKitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.areaCommercialeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.schedeProdottiToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.configuratoreUsciteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.areaMagazzinoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.analisiDisponibilitàDiMagazzinoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.areaSmartLineùToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prodottiAttivatiToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.areaAmministrativaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.analisiCostiDelVendutoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.qualitàToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classificazioneDocumentiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tracciaiblitàDeiNumeriDiSerieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.progettiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lavorazioneProgettiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.lab_resources_path = new MetroFramework.Controls.MetroLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.miniToolStrip = new System.Windows.Forms.MenuStrip();
            this.tracciaturaProdottiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.layout_Menu.SuspendLayout();
            this.layout_orizz_menu.SuspendLayout();
            this.MainMenuStrip.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // layout_Menu
            // 
            this.layout_Menu.AutoScroll = true;
            this.layout_Menu.AutoSize = true;
            this.layout_Menu.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.layout_Menu.ColumnCount = 16;
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.Controls.Add(this.layout_orizz_menu, 0, 0);
            this.layout_Menu.Controls.Add(this.metroPanel1, 0, 1);
            this.layout_Menu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Menu.Location = new System.Drawing.Point(20, 60);
            this.layout_Menu.Name = "layout_Menu";
            this.layout_Menu.RowCount = 2;
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_Menu.Size = new System.Drawing.Size(760, 370);
            this.layout_Menu.TabIndex = 1;
            // 
            // layout_orizz_menu
            // 
            this.layout_orizz_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.ColumnCount = 10;
            this.layout_Menu.SetColumnSpan(this.layout_orizz_menu, 20);
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.Controls.Add(this.MainMenuStrip, 0, 0);
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_exit, 10, 0);
            this.layout_orizz_menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_orizz_menu.Location = new System.Drawing.Point(3, 3);
            this.layout_orizz_menu.Name = "layout_orizz_menu";
            this.layout_orizz_menu.RowCount = 1;
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_orizz_menu.Size = new System.Drawing.Size(754, 25);
            this.layout_orizz_menu.TabIndex = 119;
            // 
            // MainMenuStrip
            // 
            this.MainMenuStrip.BackColor = System.Drawing.Color.Transparent;
            this.layout_orizz_menu.SetColumnSpan(this.MainMenuStrip, 9);
            this.MainMenuStrip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.spedizioneToolStripMenuItem,
            this.gestioneDelFirmwareToolStripMenuItem,
            this.reportToolStripMenuItem,
            this.qualitàToolStripMenuItem,
            this.progettiToolStripMenuItem});
            this.MainMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.MainMenuStrip.Name = "MainMenuStrip";
            this.MainMenuStrip.Size = new System.Drawing.Size(675, 25);
            this.MainMenuStrip.TabIndex = 83;
            this.MainMenuStrip.Text = "menuStrip1";
            // 
            // spedizioneToolStripMenuItem
            // 
            this.spedizioneToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fasiDiAvanzamentoToolStripMenuItem,
            this.programmazioneSmartLineToolStripMenuItem,
            this.spedizioneToolStripMenuItem1,
            this.individuazioneEtichetteToolStripMenuItem,
            this.raccoltaDatasheetPerCommessaToolStripMenuItem,
            this.aaaaToolStripMenuItem});
            this.spedizioneToolStripMenuItem.Name = "spedizioneToolStripMenuItem";
            this.spedizioneToolStripMenuItem.Size = new System.Drawing.Size(115, 21);
            this.spedizioneToolStripMenuItem.Text = "Fasi di lavorazione";
            // 
            // fasiDiAvanzamentoToolStripMenuItem
            // 
            this.fasiDiAvanzamentoToolStripMenuItem.Name = "fasiDiAvanzamentoToolStripMenuItem";
            this.fasiDiAvanzamentoToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.fasiDiAvanzamentoToolStripMenuItem.Text = "Fasi di avanzamento";
            this.fasiDiAvanzamentoToolStripMenuItem.Click += new System.EventHandler(this.fasiDiAvanzamentoToolStripMenuItem_Click);
            // 
            // programmazioneSmartLineToolStripMenuItem
            // 
            this.programmazioneSmartLineToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.programmaDaCommessaToolStripMenuItem,
            this.riprogrammazionePlugClonazioneToolStripMenuItem});
            this.programmazioneSmartLineToolStripMenuItem.Name = "programmazioneSmartLineToolStripMenuItem";
            this.programmazioneSmartLineToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.programmazioneSmartLineToolStripMenuItem.Text = "--- Programmazione SmartLine ---";
            // 
            // programmaDaCommessaToolStripMenuItem
            // 
            this.programmaDaCommessaToolStripMenuItem.Name = "programmaDaCommessaToolStripMenuItem";
            this.programmaDaCommessaToolStripMenuItem.Size = new System.Drawing.Size(295, 22);
            this.programmaDaCommessaToolStripMenuItem.Text = "Programmazione - Commessa";
            this.programmaDaCommessaToolStripMenuItem.Click += new System.EventHandler(this.programmaDaCommessaToolStripMenuItem_Click);
            // 
            // riprogrammazionePlugClonazioneToolStripMenuItem
            // 
            this.riprogrammazionePlugClonazioneToolStripMenuItem.Name = "riprogrammazionePlugClonazioneToolStripMenuItem";
            this.riprogrammazionePlugClonazioneToolStripMenuItem.Size = new System.Drawing.Size(295, 22);
            this.riprogrammazionePlugClonazioneToolStripMenuItem.Text = "Programmazione - Clonazione Plug Radio";
            this.riprogrammazionePlugClonazioneToolStripMenuItem.Click += new System.EventHandler(this.riprogrammazionePlugClonazioneToolStripMenuItem_Click);
            // 
            // spedizioneToolStripMenuItem1
            // 
            this.spedizioneToolStripMenuItem1.Name = "spedizioneToolStripMenuItem1";
            this.spedizioneToolStripMenuItem1.Size = new System.Drawing.Size(281, 22);
            this.spedizioneToolStripMenuItem1.Text = "Check-out Collaudo/Confezionamento";
            this.spedizioneToolStripMenuItem1.Click += new System.EventHandler(this.spedizioneToolStripMenuItem1_Click);
            // 
            // individuazioneEtichetteToolStripMenuItem
            // 
            this.individuazioneEtichetteToolStripMenuItem.Name = "individuazioneEtichetteToolStripMenuItem";
            this.individuazioneEtichetteToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.individuazioneEtichetteToolStripMenuItem.Text = "Individuazione Etichette";
            this.individuazioneEtichetteToolStripMenuItem.Click += new System.EventHandler(this.individuazioneEtichetteToolStripMenuItem_Click);
            // 
            // raccoltaDatasheetPerCommessaToolStripMenuItem
            // 
            this.raccoltaDatasheetPerCommessaToolStripMenuItem.Name = "raccoltaDatasheetPerCommessaToolStripMenuItem";
            this.raccoltaDatasheetPerCommessaToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.raccoltaDatasheetPerCommessaToolStripMenuItem.Text = "Raccolta Datasheet per commessa";
            this.raccoltaDatasheetPerCommessaToolStripMenuItem.Click += new System.EventHandler(this.raccoltaDatasheetPerCommessaToolStripMenuItem_Click);
            // 
            // aaaaToolStripMenuItem
            // 
            this.aaaaToolStripMenuItem.Name = "aaaaToolStripMenuItem";
            this.aaaaToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.aaaaToolStripMenuItem.Text = "aaaa";
            this.aaaaToolStripMenuItem.Visible = false;
            this.aaaaToolStripMenuItem.Click += new System.EventHandler(this.aaaaToolStripMenuItem_Click);
            // 
            // gestioneDelFirmwareToolStripMenuItem
            // 
            this.gestioneDelFirmwareToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.classicLineToolStripMenuItem,
            this.smartLineToolStripMenuItem});
            this.gestioneDelFirmwareToolStripMenuItem.Name = "gestioneDelFirmwareToolStripMenuItem";
            this.gestioneDelFirmwareToolStripMenuItem.Size = new System.Drawing.Size(136, 21);
            this.gestioneDelFirmwareToolStripMenuItem.Text = "Gestione del Firmware";
            // 
            // classicLineToolStripMenuItem
            // 
            this.classicLineToolStripMenuItem.Name = "classicLineToolStripMenuItem";
            this.classicLineToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.classicLineToolStripMenuItem.Text = "- Classic Line -";
            // 
            // smartLineToolStripMenuItem
            // 
            this.smartLineToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fWPalmariToolStripMenuItem1,
            this.fWRicevitoriToolStripMenuItem1,
            this.fWPikToolStripMenuItem1});
            this.smartLineToolStripMenuItem.Name = "smartLineToolStripMenuItem";
            this.smartLineToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.smartLineToolStripMenuItem.Text = "- Smart Line -";
            // 
            // fWPalmariToolStripMenuItem1
            // 
            this.fWPalmariToolStripMenuItem1.Name = "fWPalmariToolStripMenuItem1";
            this.fWPalmariToolStripMenuItem1.Size = new System.Drawing.Size(143, 22);
            this.fWPalmariToolStripMenuItem1.Text = "FW Palmari";
            this.fWPalmariToolStripMenuItem1.Click += new System.EventHandler(this.fWPalmariToolStripMenuItem1_Click);
            // 
            // fWRicevitoriToolStripMenuItem1
            // 
            this.fWRicevitoriToolStripMenuItem1.Name = "fWRicevitoriToolStripMenuItem1";
            this.fWRicevitoriToolStripMenuItem1.Size = new System.Drawing.Size(143, 22);
            this.fWRicevitoriToolStripMenuItem1.Text = "FW Ricevitori";
            this.fWRicevitoriToolStripMenuItem1.Click += new System.EventHandler(this.fWRicevitoriToolStripMenuItem1_Click);
            // 
            // fWPikToolStripMenuItem1
            // 
            this.fWPikToolStripMenuItem1.Name = "fWPikToolStripMenuItem1";
            this.fWPikToolStripMenuItem1.Size = new System.Drawing.Size(143, 22);
            this.fWPikToolStripMenuItem1.Text = "FW PiK";
            this.fWPikToolStripMenuItem1.Visible = false;
            this.fWPikToolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.codificaKitToolStripMenuItem,
            this.toolStripSeparator2,
            this.areaCommercialeToolStripMenuItem,
            this.areaMagazzinoToolStripMenuItem,
            this.areaSmartLineùToolStripMenuItem,
            this.toolStripSeparator1,
            this.areaAmministrativaToolStripMenuItem});
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(100, 21);
            this.reportToolStripMenuItem.Text = "Report - Analisi";
            // 
            // codificaKitToolStripMenuItem
            // 
            this.codificaKitToolStripMenuItem.Name = "codificaKitToolStripMenuItem";
            this.codificaKitToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.codificaKitToolStripMenuItem.Text = "Ricerca / Richiesta di codifica Kit";
            this.codificaKitToolStripMenuItem.Click += new System.EventHandler(this.codificaKitToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(242, 6);
            // 
            // areaCommercialeToolStripMenuItem
            // 
            this.areaCommercialeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.schedeProdottiToolStripMenuItem1,
            this.configuratoreUsciteToolStripMenuItem});
            this.areaCommercialeToolStripMenuItem.Name = "areaCommercialeToolStripMenuItem";
            this.areaCommercialeToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.areaCommercialeToolStripMenuItem.Text = "Area Commerciale";
            // 
            // schedeProdottiToolStripMenuItem1
            // 
            this.schedeProdottiToolStripMenuItem1.Name = "schedeProdottiToolStripMenuItem1";
            this.schedeProdottiToolStripMenuItem1.Size = new System.Drawing.Size(183, 22);
            this.schedeProdottiToolStripMenuItem1.Text = "Schede Prodotti";
            this.schedeProdottiToolStripMenuItem1.Click += new System.EventHandler(this.schedeProdottiToolStripMenuItem1_Click);
            // 
            // configuratoreUsciteToolStripMenuItem
            // 
            this.configuratoreUsciteToolStripMenuItem.Name = "configuratoreUsciteToolStripMenuItem";
            this.configuratoreUsciteToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.configuratoreUsciteToolStripMenuItem.Text = "Configuratore Uscite";
            this.configuratoreUsciteToolStripMenuItem.Click += new System.EventHandler(this.configuratoreUsciteToolStripMenuItem_Click);
            // 
            // areaMagazzinoToolStripMenuItem
            // 
            this.areaMagazzinoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.analisiDisponibilitàDiMagazzinoToolStripMenuItem});
            this.areaMagazzinoToolStripMenuItem.Name = "areaMagazzinoToolStripMenuItem";
            this.areaMagazzinoToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.areaMagazzinoToolStripMenuItem.Text = "Area Magazzino";
            // 
            // analisiDisponibilitàDiMagazzinoToolStripMenuItem
            // 
            this.analisiDisponibilitàDiMagazzinoToolStripMenuItem.Name = "analisiDisponibilitàDiMagazzinoToolStripMenuItem";
            this.analisiDisponibilitàDiMagazzinoToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
            this.analisiDisponibilitàDiMagazzinoToolStripMenuItem.Text = "Analisi disponibilità di magazzino";
            this.analisiDisponibilitàDiMagazzinoToolStripMenuItem.Click += new System.EventHandler(this.analisiDisponibilitàDiMagazzinoToolStripMenuItem_Click);
            // 
            // areaSmartLineùToolStripMenuItem
            // 
            this.areaSmartLineùToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.prodottiAttivatiToolStripMenuItem1,
            this.tracciaturaProdottiToolStripMenuItem});
            this.areaSmartLineùToolStripMenuItem.Name = "areaSmartLineùToolStripMenuItem";
            this.areaSmartLineùToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.areaSmartLineùToolStripMenuItem.Text = "Area SmartLine";
            // 
            // prodottiAttivatiToolStripMenuItem1
            // 
            this.prodottiAttivatiToolStripMenuItem1.Name = "prodottiAttivatiToolStripMenuItem1";
            this.prodottiAttivatiToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.prodottiAttivatiToolStripMenuItem1.Text = "Prodotti attivati";
            this.prodottiAttivatiToolStripMenuItem1.Click += new System.EventHandler(this.prodottiAttivatiToolStripMenuItem1_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(242, 6);
            // 
            // areaAmministrativaToolStripMenuItem
            // 
            this.areaAmministrativaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.analisiCostiDelVendutoToolStripMenuItem});
            this.areaAmministrativaToolStripMenuItem.Name = "areaAmministrativaToolStripMenuItem";
            this.areaAmministrativaToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.areaAmministrativaToolStripMenuItem.Text = "Area Amministrativa";
            // 
            // analisiCostiDelVendutoToolStripMenuItem
            // 
            this.analisiCostiDelVendutoToolStripMenuItem.Name = "analisiCostiDelVendutoToolStripMenuItem";
            this.analisiCostiDelVendutoToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.analisiCostiDelVendutoToolStripMenuItem.Text = "Analisi Costi del Venduto";
            this.analisiCostiDelVendutoToolStripMenuItem.Click += new System.EventHandler(this.analisiCostiDelVendutoToolStripMenuItem_Click);
            // 
            // qualitàToolStripMenuItem
            // 
            this.qualitàToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.classificazioneDocumentiToolStripMenuItem,
            this.toolStripSeparator3,
            this.tracciaiblitàDeiNumeriDiSerieToolStripMenuItem});
            this.qualitàToolStripMenuItem.Name = "qualitàToolStripMenuItem";
            this.qualitàToolStripMenuItem.Size = new System.Drawing.Size(57, 21);
            this.qualitàToolStripMenuItem.Text = "Qualità";
            // 
            // classificazioneDocumentiToolStripMenuItem
            // 
            this.classificazioneDocumentiToolStripMenuItem.Name = "classificazioneDocumentiToolStripMenuItem";
            this.classificazioneDocumentiToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.classificazioneDocumentiToolStripMenuItem.Text = "Classificazione Documenti";
            this.classificazioneDocumentiToolStripMenuItem.Click += new System.EventHandler(this.classificazioneDocumentiToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(236, 6);
            // 
            // tracciaiblitàDeiNumeriDiSerieToolStripMenuItem
            // 
            this.tracciaiblitàDeiNumeriDiSerieToolStripMenuItem.Name = "tracciaiblitàDeiNumeriDiSerieToolStripMenuItem";
            this.tracciaiblitàDeiNumeriDiSerieToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.tracciaiblitàDeiNumeriDiSerieToolStripMenuItem.Text = "Tracciabilità dei Numeri di Serie";
            this.tracciaiblitàDeiNumeriDiSerieToolStripMenuItem.Click += new System.EventHandler(this.tracciaiblitàDeiNumeriDiSerieToolStripMenuItem_Click);
            // 
            // progettiToolStripMenuItem
            // 
            this.progettiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lavorazioneProgettiToolStripMenuItem});
            this.progettiToolStripMenuItem.Name = "progettiToolStripMenuItem";
            this.progettiToolStripMenuItem.Size = new System.Drawing.Size(88, 21);
            this.progettiToolStripMenuItem.Text = "Area Progetti";
            this.progettiToolStripMenuItem.Visible = false;
            // 
            // lavorazioneProgettiToolStripMenuItem
            // 
            this.lavorazioneProgettiToolStripMenuItem.Name = "lavorazioneProgettiToolStripMenuItem";
            this.lavorazioneProgettiToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.lavorazioneProgettiToolStripMenuItem.Text = "Lavorazione Progetti";
            this.lavorazioneProgettiToolStripMenuItem.Click += new System.EventHandler(this.lavorazioneProgettiToolStripMenuItem_Click);
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Transparent;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(679, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(75, 24);
            this.pan_Menu_exit.TabIndex = 82;
            this.pan_Menu_exit.Text = "menuStrip1";
            this.pan_Menu_exit.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.pan_Menu_exit_ItemClicked);
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            this.menu_sw_exit.Click += new System.EventHandler(this.menu_sw_exit_Click);
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroPanel1.BackgroundImage")));
            this.metroPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.layout_Menu.SetColumnSpan(this.metroPanel1, 16);
            this.metroPanel1.Controls.Add(this.lab_resources_path);
            this.metroPanel1.Controls.Add(this.pictureBox1);
            this.metroPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(3, 34);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(754, 333);
            this.metroPanel1.TabIndex = 120;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // lab_resources_path
            // 
            this.lab_resources_path.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lab_resources_path.AutoSize = true;
            this.lab_resources_path.BackColor = System.Drawing.Color.Transparent;
            this.lab_resources_path.ForeColor = System.Drawing.Color.White;
            this.lab_resources_path.Location = new System.Drawing.Point(3, 314);
            this.lab_resources_path.Name = "lab_resources_path";
            this.lab_resources_path.Size = new System.Drawing.Size(81, 19);
            this.lab_resources_path.TabIndex = 3;
            this.lab_resources_path.Text = "metroLabel1";
            this.lab_resources_path.UseCustomBackColor = true;
            this.lab_resources_path.UseCustomForeColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(300, 99);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(150, 150);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // miniToolStrip
            // 
            this.miniToolStrip.AccessibleName = "Selezione nuovo elemento";
            this.miniToolStrip.AccessibleRole = System.Windows.Forms.AccessibleRole.ComboBox;
            this.miniToolStrip.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.miniToolStrip.AutoSize = false;
            this.miniToolStrip.BackColor = System.Drawing.Color.Gainsboro;
            this.miniToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.miniToolStrip.Location = new System.Drawing.Point(0, 0);
            this.miniToolStrip.Name = "miniToolStrip";
            this.miniToolStrip.Size = new System.Drawing.Size(75, 24);
            this.miniToolStrip.TabIndex = 82;
            // 
            // tracciaturaProdottiToolStripMenuItem
            // 
            this.tracciaturaProdottiToolStripMenuItem.Name = "tracciaturaProdottiToolStripMenuItem";
            this.tracciaturaProdottiToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.tracciaturaProdottiToolStripMenuItem.Text = "Tracciatura prodotti";
            this.tracciaturaProdottiToolStripMenuItem.Click += new System.EventHandler(this.tracciaturaProdottiToolStripMenuItem_Click);
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.layout_Menu);
            this.IsMdiContainer = true;
            this.Name = "MainMenu";
            this.ShowIcon = false;
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "Sistematica - Factory";
            this.TransparencyKey = System.Drawing.Color.Empty;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainMenu_Load);
            this.MdiChildActivate += new System.EventHandler(this.MainMenu_MdiChildActivate);
            this.layout_Menu.ResumeLayout(false);
            this.layout_orizz_menu.ResumeLayout(false);
            this.layout_orizz_menu.PerformLayout();
            this.MainMenuStrip.ResumeLayout(false);
            this.MainMenuStrip.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel layout_Menu;
        private System.Windows.Forms.TableLayoutPanel layout_orizz_menu;
        private System.Windows.Forms.MenuStrip MainMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem spedizioneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fasiDiAvanzamentoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spedizioneToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem gestioneDelFirmwareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
        private System.Windows.Forms.MenuStrip miniToolStrip;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem codificaKitToolStripMenuItem;
        private MetroFramework.Controls.MetroLabel lab_resources_path;
        private System.Windows.Forms.ToolStripMenuItem classicLineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem smartLineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fWPalmariToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem fWRicevitoriToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem raccoltaDatasheetPerCommessaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aaaaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem qualitàToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem classificazioneDocumentiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem areaMagazzinoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem areaCommercialeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem areaSmartLineùToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prodottiAttivatiToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem schedeProdottiToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem analisiDisponibilitàDiMagazzinoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configuratoreUsciteToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem areaAmministrativaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem analisiCostiDelVendutoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem progettiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lavorazioneProgettiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fWPikToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem individuazioneEtichetteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem programmazioneSmartLineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem programmaDaCommessaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem riprogrammazionePlugClonazioneToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem tracciaiblitàDeiNumeriDiSerieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tracciaturaProdottiToolStripMenuItem;
    }
}

