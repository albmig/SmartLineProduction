﻿namespace SmartLineProduction
{
}

namespace SmartLineProduction
{
}
namespace SmartLineProduction
{


    public partial class ds_Ncr
    {
    }
}
