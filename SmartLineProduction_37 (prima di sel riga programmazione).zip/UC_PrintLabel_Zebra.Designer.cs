﻿namespace SmartLineProduction
{
    partial class UC_PrintLabel_Zebra
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_PrintLabel_Zebra));
            this.layout_orizz_menu = new System.Windows.Forms.TableLayoutPanel();
            this.panel_SN = new MetroFramework.Controls.MetroPanel();
            this.lab_correzione = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.cb_Correzione = new System.Windows.Forms.ComboBox();
            this.lab_printer = new MetroFramework.Controls.MetroLabel();
            this.but_Print = new MetroFramework.Controls.MetroButton();
            this.lab_Etichetta = new MetroFramework.Controls.MetroLabel();
            this.tbx_PrintString = new MetroFramework.Controls.MetroTextBox();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.layout_orizz_menu.SuspendLayout();
            this.panel_SN.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            this.SuspendLayout();
            // 
            // layout_orizz_menu
            // 
            this.layout_orizz_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.ColumnCount = 10;
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_exit, 10, 0);
            this.layout_orizz_menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_orizz_menu.Location = new System.Drawing.Point(20, 30);
            this.layout_orizz_menu.Name = "layout_orizz_menu";
            this.layout_orizz_menu.RowCount = 1;
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_orizz_menu.Size = new System.Drawing.Size(839, 25);
            this.layout_orizz_menu.TabIndex = 120;
            // 
            // panel_SN
            // 
            this.panel_SN.Controls.Add(this.lab_correzione);
            this.panel_SN.Controls.Add(this.metroLabel4);
            this.panel_SN.Controls.Add(this.cb_Correzione);
            this.panel_SN.Controls.Add(this.lab_printer);
            this.panel_SN.Controls.Add(this.but_Print);
            this.panel_SN.Controls.Add(this.lab_Etichetta);
            this.panel_SN.Controls.Add(this.tbx_PrintString);
            this.panel_SN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_SN.HorizontalScrollbarBarColor = true;
            this.panel_SN.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_SN.HorizontalScrollbarSize = 10;
            this.panel_SN.Location = new System.Drawing.Point(20, 55);
            this.panel_SN.Name = "panel_SN";
            this.panel_SN.Size = new System.Drawing.Size(839, 351);
            this.panel_SN.TabIndex = 0;
            this.panel_SN.VerticalScrollbarBarColor = true;
            this.panel_SN.VerticalScrollbarHighlightOnWheel = false;
            this.panel_SN.VerticalScrollbarSize = 10;
            // 
            // lab_correzione
            // 
            this.lab_correzione.AutoSize = true;
            this.lab_correzione.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_correzione.Location = new System.Drawing.Point(285, 112);
            this.lab_correzione.Name = "lab_correzione";
            this.lab_correzione.Size = new System.Drawing.Size(86, 19);
            this.lab_correzione.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_correzione.TabIndex = 16;
            this.lab_correzione.Text = "metroLabel5";
            this.lab_correzione.UseStyleColors = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(3, 90);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(135, 19);
            this.metroLabel4.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel4.TabIndex = 15;
            this.metroLabel4.Text = "Correzione in altezza";
            this.metroLabel4.UseStyleColors = true;
            // 
            // cb_Correzione
            // 
            this.cb_Correzione.FormattingEnabled = true;
            this.cb_Correzione.Items.AddRange(new object[] {
            "-50",
            "-45",
            "-40",
            "-35",
            "-30",
            "-25",
            "-20",
            "-15",
            "-10",
            "-5",
            "0",
            "5",
            "10",
            "15",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50"});
            this.cb_Correzione.Location = new System.Drawing.Point(3, 112);
            this.cb_Correzione.Name = "cb_Correzione";
            this.cb_Correzione.Size = new System.Drawing.Size(276, 21);
            this.cb_Correzione.TabIndex = 14;
            // 
            // lab_printer
            // 
            this.lab_printer.AutoSize = true;
            this.lab_printer.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_printer.Location = new System.Drawing.Point(285, 139);
            this.lab_printer.Name = "lab_printer";
            this.lab_printer.Size = new System.Drawing.Size(74, 19);
            this.lab_printer.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_printer.TabIndex = 13;
            this.lab_printer.Text = "lab_printer";
            this.lab_printer.UseStyleColors = true;
            // 
            // but_Print
            // 
            this.but_Print.BackColor = System.Drawing.Color.White;
            this.but_Print.Location = new System.Drawing.Point(3, 139);
            this.but_Print.Name = "but_Print";
            this.but_Print.Size = new System.Drawing.Size(276, 23);
            this.but_Print.Style = MetroFramework.MetroColorStyle.Red;
            this.but_Print.TabIndex = 12;
            this.but_Print.Text = "Stampa Etichetta";
            this.but_Print.UseSelectable = true;
            this.but_Print.UseStyleColors = true;
            this.but_Print.Click += new System.EventHandler(this.but_Print_Click);
            // 
            // lab_Etichetta
            // 
            this.lab_Etichetta.AutoSize = true;
            this.lab_Etichetta.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_Etichetta.Location = new System.Drawing.Point(3, 3);
            this.lab_Etichetta.Name = "lab_Etichetta";
            this.lab_Etichetta.Size = new System.Drawing.Size(158, 19);
            this.lab_Etichetta.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_Etichetta.TabIndex = 0;
            this.lab_Etichetta.Text = "Contenuto da stampare:";
            this.lab_Etichetta.UseStyleColors = true;
            // 
            // tbx_PrintString
            // 
            // 
            // 
            // 
            this.tbx_PrintString.CustomButton.Image = null;
            this.tbx_PrintString.CustomButton.Location = new System.Drawing.Point(254, 1);
            this.tbx_PrintString.CustomButton.Name = "";
            this.tbx_PrintString.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tbx_PrintString.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbx_PrintString.CustomButton.TabIndex = 1;
            this.tbx_PrintString.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbx_PrintString.CustomButton.UseSelectable = true;
            this.tbx_PrintString.CustomButton.Visible = false;
            this.tbx_PrintString.Lines = new string[0];
            this.tbx_PrintString.Location = new System.Drawing.Point(3, 25);
            this.tbx_PrintString.MaxLength = 32767;
            this.tbx_PrintString.Multiline = true;
            this.tbx_PrintString.Name = "tbx_PrintString";
            this.tbx_PrintString.PasswordChar = '\0';
            this.tbx_PrintString.PromptText = "Dato da stampare";
            this.tbx_PrintString.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbx_PrintString.SelectedText = "";
            this.tbx_PrintString.SelectionLength = 0;
            this.tbx_PrintString.SelectionStart = 0;
            this.tbx_PrintString.ShortcutsEnabled = true;
            this.tbx_PrintString.Size = new System.Drawing.Size(276, 23);
            this.tbx_PrintString.TabIndex = 0;
            this.tbx_PrintString.UseSelectable = true;
            this.tbx_PrintString.WaterMark = "Dato da stampare";
            this.tbx_PrintString.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tbx_PrintString.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Gainsboro;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(747, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(92, 24);
            this.pan_Menu_exit.TabIndex = 83;
            this.pan_Menu_exit.Text = "menuStrip1";
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            this.menu_sw_exit.Click += new System.EventHandler(this.menu_sw_exit_Click_1);
            // 
            // UC_PrintLabel_Zebra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(879, 426);
            this.ControlBox = false;
            this.Controls.Add(this.panel_SN);
            this.Controls.Add(this.layout_orizz_menu);
            this.DisplayHeader = false;
            this.Name = "UC_PrintLabel_Zebra";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UC_PrintLabel_Zebra_Load);
            this.Shown += new System.EventHandler(this.UC_PrintLabel_Zebra_Shown);
            this.layout_orizz_menu.ResumeLayout(false);
            this.layout_orizz_menu.PerformLayout();
            this.panel_SN.ResumeLayout(false);
            this.panel_SN.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel layout_orizz_menu;
        private MetroFramework.Controls.MetroPanel panel_SN;
        private MetroFramework.Controls.MetroLabel lab_Etichetta;
        private MetroFramework.Controls.MetroTextBox tbx_PrintString;
        private MetroFramework.Controls.MetroButton but_Print;
        private MetroFramework.Controls.MetroLabel lab_printer;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private System.Windows.Forms.ComboBox cb_Correzione;
        private MetroFramework.Controls.MetroLabel lab_correzione;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
    }
}
