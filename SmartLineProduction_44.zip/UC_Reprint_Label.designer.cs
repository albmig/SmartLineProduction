﻿namespace SmartLineProduction
{
    partial class UC_Reprint_Label
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.but_abort_UC_Reprint_Label = new MetroFramework.Controls.MetroButton();
            this.but_close_UC_Reprint_Label = new MetroFramework.Controls.MetroButton();
            this.cb_Correzione = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(20, 80);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(78, 19);
            this.metroLabel1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel1.TabIndex = 17;
            this.metroLabel1.Text = "Correzione:";
            this.metroLabel1.UseCustomBackColor = true;
            this.metroLabel1.UseStyleColors = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.but_abort_UC_Reprint_Label, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.but_close_UC_Reprint_Label, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(20, 139);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(360, 21);
            this.tableLayoutPanel1.TabIndex = 39;
            // 
            // but_abort_UC_Reprint_Label
            // 
            this.but_abort_UC_Reprint_Label.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.but_abort_UC_Reprint_Label.DialogResult = System.Windows.Forms.DialogResult.No;
            this.but_abort_UC_Reprint_Label.Location = new System.Drawing.Point(185, 3);
            this.but_abort_UC_Reprint_Label.Name = "but_abort_UC_Reprint_Label";
            this.but_abort_UC_Reprint_Label.Size = new System.Drawing.Size(170, 15);
            this.but_abort_UC_Reprint_Label.TabIndex = 39;
            this.but_abort_UC_Reprint_Label.Text = "Annulla";
            this.but_abort_UC_Reprint_Label.UseSelectable = true;
            this.but_abort_UC_Reprint_Label.Click += new System.EventHandler(this.but_abort_UC_Reprint_Label_Click);
            // 
            // but_close_UC_Reprint_Label
            // 
            this.but_close_UC_Reprint_Label.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.but_close_UC_Reprint_Label.DialogResult = System.Windows.Forms.DialogResult.Yes;
            this.but_close_UC_Reprint_Label.Location = new System.Drawing.Point(5, 3);
            this.but_close_UC_Reprint_Label.Name = "but_close_UC_Reprint_Label";
            this.but_close_UC_Reprint_Label.Size = new System.Drawing.Size(170, 15);
            this.but_close_UC_Reprint_Label.TabIndex = 3;
            this.but_close_UC_Reprint_Label.Text = "Ristampa";
            this.but_close_UC_Reprint_Label.UseSelectable = true;
            this.but_close_UC_Reprint_Label.Click += new System.EventHandler(this.but_close_UC_Reprint_Label_Click);
            // 
            // cb_Correzione
            // 
            this.cb_Correzione.FormattingEnabled = true;
            this.cb_Correzione.Items.AddRange(new object[] {
            "-50",
            "-45",
            "-40",
            "-35",
            "-30",
            "-25",
            "-20",
            "-15",
            "-10",
            "-5",
            "0",
            "5",
            "10",
            "15",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50"});
            this.cb_Correzione.Location = new System.Drawing.Point(112, 80);
            this.cb_Correzione.Name = "cb_Correzione";
            this.cb_Correzione.Size = new System.Drawing.Size(151, 21);
            this.cb_Correzione.TabIndex = 40;
            // 
            // UC_Reprint_Label
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = MetroFramework.Forms.MetroFormBorderStyle.FixedSingle;
            this.ClientSize = new System.Drawing.Size(400, 180);
            this.ControlBox = false;
            this.Controls.Add(this.cb_Correzione);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.metroLabel1);
            this.Name = "UC_Reprint_Label";
            this.Resizable = false;
            this.ShowIcon = false;
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "Ristampa etichetta";
            this.TopMost = true;
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private MetroFramework.Controls.MetroButton but_abort_UC_Reprint_Label;
        private MetroFramework.Controls.MetroButton but_close_UC_Reprint_Label;
        private System.Windows.Forms.ComboBox cb_Correzione;
    }
}