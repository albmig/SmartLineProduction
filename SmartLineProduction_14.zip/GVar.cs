﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Windows.Forms;

namespace SmartLineProduction
{
    public static class GVar
    {
        public static bool CloseSplash = false;
        public static bool formclosing = false;

        public static string gl_commessa = "";
        public static string gl_ragsoc = "";
        public static string gl_articolo = "";
        public static string gl_note = "";
        public static int gl_qtaevadere = 0;

        public static string gl_tipofiltro_FW_P = "";
        public static string gl_tipofiltro_FW_R = "";

    }
}
