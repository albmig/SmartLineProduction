﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace SmartLineProduction
{
    public partial class UC_Spedizione : MetroFramework.Forms.MetroForm
    {

        public static string qr_read_device = "";
        public static string qr_read_chip = "";
        public static string qr_sn = "";
        public static string qr_device = "";
        public static string qr_fw = "";
        public static string qr_chip = "";
        //public string WEB_path_image = @"\\192.168.0.8\ricerca e sviluppo\Documentazione_SL\doc_SL (sinc per web)\";
        public string WEB_path_image = Properties.Settings.Default.Doc_folder;


        public UC_Spedizione()
        {
            InitializeComponent();
        }

        private void UC_Spedizione_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_AnagraficaClienti'. È possibile spostarla o rimuoverla se necessario.
            this.sF_AnagraficaClientiTableAdapter.Fill(this.ds_SL.SF_AnagraficaClienti);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SerialNumbers'. È possibile spostarla o rimuoverla se necessario.
            this.serialNumbersTableAdapter.Fill(this.ds_SL.SerialNumbers);
            PulisciForm();
        }

        private void PulisciForm()
        {
            tbx_ReadLabel_Chip.Text = "";
            tbx_ReadLabel_Device.Text = "";

            lab_read_SN.Text = "";
            lab_read_Device.Text = "";
            lab_read_FW.Text = "";
            ID_Device_Image.Image = null;
            Serial_Device_Image.Image = null;

            labchip_ID.Text = "";
            labchip_Kit.Text = "";
            labchip_Device.Text = "";
            labchip_Cliente.Text = "";

            but_Associa.Visible = false;
            but_Annulla.Visible = false;
        }

        private void AnalizzaQrDevice()
        {
            string[] codici = qr_read_device.Split('|');
            int conta = 1;
            foreach (var word in codici)
            {
                switch (conta)
                {
                    case 1: qr_sn = word; conta++; break;
                    case 2: qr_device = word; conta++; break;
                    case 3: qr_fw = word; conta++; break;
                }
            }

            lab_read_SN.Text = qr_sn;
            lab_read_Device.Text = qr_device;
            lab_read_FW.Text = qr_fw;
            this.Refresh();
        }

        private void tbx_ReadLabel_Device_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\t' || e.KeyChar == (char)13)
            {
                e.Handled = true;
                qr_read_device = tbx_ReadLabel_Device.Text;
                qr_chip = tbx_ReadLabel_Chip.Text;
                AnalizzaQrDevice();

                if (lab_read_Device.Text != labchip_Device.Text)
                {
                    MessageBox.Show("Incongruenza sulle letture. Device diversi!");
                    PulisciForm();
                    return;
                }

                //CaricaImmagine
                string famdevice = labchip_Device.Text.Substring(0, 3);
                if (famdevice == "XSB")
                {
                    famdevice = labchip_Device.Text.Substring(0, 5);
                }

                //Carica immagine scheda
                string path = WEB_path_image + famdevice + @"\" + labchip_Device.Text + @"\" + labchip_Device.Text + "_Full.png";

                if (!File.Exists(path))
                {
                    MessageBox.Show("Immagine non presente");
                    Serial_Device_Image.Image = null;
                }
                else
                {
                    Serial_Device_Image.Image = Image.FromFile(path);
                }

                but_Associa.Visible = true;
                but_Associa.Focus();

                but_Annulla.Visible = true;
            }
        }

        private void tbx_ReadLabel_Chip_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\t' || e.KeyChar == (char)13)
            {
                e.Handled = true;
                qr_read_chip = tbx_ReadLabel_Chip.Text;
                // Lettura del SerialNumber
                this.serialNumbersTableAdapter.FillBy_Spedizioni_OfficialSerial(this.ds_SL.SerialNumbers, qr_read_chip);
                if (ds_SL.SerialNumbers.Count == 0)
                {
                    MessageBox.Show("ID non codificato!");
                    tbx_ReadLabel_Chip.Text = "";
                }
                else
                {
                    foreach (DataRow ser_row in ds_SL.SerialNumbers)
                    {
                        labchip_Device.Text = ser_row["Ser_Device"].ToString();
                        labchip_ID.Text = ser_row["Ser_ReadSerial"].ToString();
                        labchip_Kit.Text = ser_row["Ser_Kit"].ToString();

                        string clifiltro = "CODICE_NOMINATIVO = " + "'" + ser_row["Ser_ID_Cli"] + "'";
                        DataView dvcli = ds_SL.SF_AnagraficaClienti.DefaultView;
                        dvcli.RowFilter = clifiltro;
                        foreach (DataRowView drvcli in dvcli)
                        {
                            labchip_Cliente.Text = drvcli["RAGIONESOCIALE"].ToString();
                        }

                        if (ser_row["Ser_SN_prod"].ToString() != "")
                        {
                            DateTime datasped = (DateTime)ser_row["Ser_Data_Spedito"];
                            string data = datasped.ToString("dd.MM.yyyy");
                            string message = "Il numero di serie è già stato associato. \nSpedito in data " + data + ".\nContinuare?";
                            const string caption = "Articolo già spedito!";
                            var result = MessageBox.Show(message, caption,
                                                         MessageBoxButtons.YesNo,
                                                         MessageBoxIcon.Question);

                            // If the no button was pressed ...
                            if (result == DialogResult.No)
                            {
                                PulisciForm();
                                return;
                            }
                        }

                        //CaricaImmagine
                        string famdevice = ser_row["Ser_Device"].ToString().Substring(0, 3);
                        if (famdevice == "XSB")
                        {
                            famdevice = ser_row["Ser_Device"].ToString().Substring(0, 5);
                        }

                        //Carica immagine scheda
                        string path = WEB_path_image + famdevice + @"\" + ser_row["Ser_Device"].ToString() + @"\" + ser_row["Ser_Device"].ToString() + "_Full.png";

                        if (!File.Exists(path))
                        {
                            MessageBox.Show("Immagine non presente");
                            ID_Device_Image.Image = null;
                        }
                        else
                        {
                            ID_Device_Image.Image = Image.FromFile(path);
                        }
                    }
                }

                tbx_ReadLabel_Device.Focus();
            }
        }

        private void VisualizzaDati()
        {
            labchip_ID.Text = qr_device;

            //Trova Device
            string filtro = "Ser_OfficialSerial = " + "'" + qr_device + "'";
            DataView dv = ds_SL.SerialNumbers.DefaultView;
            dv.RowFilter = filtro;
            foreach (DataRowView rowView in dv)
            {
                DataRow rowSN = rowView.Row;

                labchip_Kit.Text = rowView["Ser_Kit"].ToString();

                string clifiltro = "CODICE_NOMINATIVO = " + "'" + rowSN["Ser_ID_Cli"] + "'";
                DataView dvcli = ds_SL.SF_AnagraficaClienti.DefaultView;
                dvcli.RowFilter = clifiltro;
                foreach (DataRowView drvcli in dvcli)
                {
                    labchip_Cliente.Text = drvcli["RAGIONESOCIALE"].ToString();
                }

            }


            but_Associa.Visible = true;
            but_Associa.Focus();

            but_Annulla.Visible = true;
        }

        private void tbx_ReadLabel_Device_Enter(object sender, EventArgs e)
        {
            if (tbx_ReadLabel_Chip.Text.Length != 16)
            {
                MessageBox.Show("Codice chip non corretto!");
                tbx_ReadLabel_Chip.Text = "";
                tbx_ReadLabel_Chip.Focus();
            }
        }

        private void but_Annulla_Click(object sender, EventArgs e)
        {
            PulisciForm();
        }

        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tbx_ReadLabel_Chip_TextChanged(object sender, EventArgs e)
        {
            labchip_ID.Text = "";
            labchip_Kit.Text = "";
            labchip_Cliente.Text = "";
        }

        private void tbx_ReadLabel_Device_Leave(object sender, EventArgs e)
        {
            if (tbx_ReadLabel_Device.Text == "") { tbx_ReadLabel_Device.Focus(); }
        }

        private void tbx_ReadLabel_Chip_Leave(object sender, EventArgs e)
        {
            if (tbx_ReadLabel_Chip.Text == "") { tbx_ReadLabel_Chip.Focus(); }
        }
    }
}
