﻿namespace SmartLineProduction
{
    partial class UC_Spedizione
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Spedizione));
            this.lab_Etichetta = new MetroFramework.Controls.MetroLabel();
            this.tbx_ReadLabel_Device = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.lab_read_FW = new MetroFramework.Controls.MetroLabel();
            this.lab_read_Device = new MetroFramework.Controls.MetroLabel();
            this.lab_read_SN = new MetroFramework.Controls.MetroLabel();
            this.tbx_ReadLabel_Chip = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.ID_Device_Image = new System.Windows.Forms.PictureBox();
            this.labchip_ID = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.labchip_Kit = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.labchip_Cliente = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.but_Associa = new MetroFramework.Controls.MetroButton();
            this.but_Annulla = new MetroFramework.Controls.MetroButton();
            this.layout_orizz_menu = new System.Windows.Forms.TableLayoutPanel();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.serialNumbersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.serialNumbersTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SerialNumbersTableAdapter();
            this.sFAnagraficaClientiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_AnagraficaClientiTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_AnagraficaClientiTableAdapter();
            this.layout_spedizioni = new System.Windows.Forms.TableLayoutPanel();
            this.panel_ID = new MetroFramework.Controls.MetroPanel();
            this.panel_SN = new MetroFramework.Controls.MetroPanel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.labchip_Device = new MetroFramework.Controls.MetroLabel();
            this.Serial_Device_Image = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)(this.ID_Device_Image)).BeginInit();
            this.layout_orizz_menu.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.serialNumbersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFAnagraficaClientiBindingSource)).BeginInit();
            this.layout_spedizioni.SuspendLayout();
            this.panel_ID.SuspendLayout();
            this.panel_SN.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Serial_Device_Image)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lab_Etichetta
            // 
            this.lab_Etichetta.AutoSize = true;
            this.lab_Etichetta.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_Etichetta.Location = new System.Drawing.Point(0, 0);
            this.lab_Etichetta.Name = "lab_Etichetta";
            this.lab_Etichetta.Size = new System.Drawing.Size(257, 19);
            this.lab_Etichetta.TabIndex = 0;
            this.lab_Etichetta.Text = "Lettura dell\'etichetta presente sul device:";
            // 
            // tbx_ReadLabel_Device
            // 
            // 
            // 
            // 
            this.tbx_ReadLabel_Device.CustomButton.Image = null;
            this.tbx_ReadLabel_Device.CustomButton.Location = new System.Drawing.Point(254, 1);
            this.tbx_ReadLabel_Device.CustomButton.Name = "";
            this.tbx_ReadLabel_Device.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tbx_ReadLabel_Device.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbx_ReadLabel_Device.CustomButton.TabIndex = 1;
            this.tbx_ReadLabel_Device.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbx_ReadLabel_Device.CustomButton.UseSelectable = true;
            this.tbx_ReadLabel_Device.CustomButton.Visible = false;
            this.tbx_ReadLabel_Device.Lines = new string[0];
            this.tbx_ReadLabel_Device.Location = new System.Drawing.Point(0, 22);
            this.tbx_ReadLabel_Device.MaxLength = 32767;
            this.tbx_ReadLabel_Device.Multiline = true;
            this.tbx_ReadLabel_Device.Name = "tbx_ReadLabel_Device";
            this.tbx_ReadLabel_Device.PasswordChar = '\0';
            this.tbx_ReadLabel_Device.PromptText = "Lettura del QR-Code";
            this.tbx_ReadLabel_Device.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbx_ReadLabel_Device.SelectedText = "";
            this.tbx_ReadLabel_Device.SelectionLength = 0;
            this.tbx_ReadLabel_Device.SelectionStart = 0;
            this.tbx_ReadLabel_Device.ShortcutsEnabled = true;
            this.tbx_ReadLabel_Device.Size = new System.Drawing.Size(276, 23);
            this.tbx_ReadLabel_Device.TabIndex = 2;
            this.tbx_ReadLabel_Device.UseSelectable = true;
            this.tbx_ReadLabel_Device.WaterMark = "Lettura del QR-Code";
            this.tbx_ReadLabel_Device.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tbx_ReadLabel_Device.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tbx_ReadLabel_Device.Enter += new System.EventHandler(this.tbx_ReadLabel_Device_Enter);
            this.tbx_ReadLabel_Device.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbx_ReadLabel_Device_KeyPress);
            this.tbx_ReadLabel_Device.Leave += new System.EventHandler(this.tbx_ReadLabel_Device_Leave);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(0, 70);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(107, 19);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "Numero di serie:";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(0, 130);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(50, 19);
            this.metroLabel2.TabIndex = 3;
            this.metroLabel2.Text = "Device:";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(0, 160);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(122, 19);
            this.metroLabel3.TabIndex = 4;
            this.metroLabel3.Text = "Firmware installato:";
            // 
            // lab_read_FW
            // 
            this.lab_read_FW.AutoSize = true;
            this.lab_read_FW.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_read_FW.Location = new System.Drawing.Point(130, 160);
            this.lab_read_FW.Name = "lab_read_FW";
            this.lab_read_FW.Size = new System.Drawing.Size(86, 19);
            this.lab_read_FW.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_read_FW.TabIndex = 7;
            this.lab_read_FW.Text = "lab_read_FW";
            this.lab_read_FW.UseStyleColors = true;
            // 
            // lab_read_Device
            // 
            this.lab_read_Device.AutoSize = true;
            this.lab_read_Device.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_read_Device.Location = new System.Drawing.Point(130, 130);
            this.lab_read_Device.Name = "lab_read_Device";
            this.lab_read_Device.Size = new System.Drawing.Size(106, 19);
            this.lab_read_Device.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_read_Device.TabIndex = 6;
            this.lab_read_Device.Text = "lab_read_Device";
            this.lab_read_Device.UseStyleColors = true;
            // 
            // lab_read_SN
            // 
            this.lab_read_SN.AutoSize = true;
            this.lab_read_SN.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_read_SN.Location = new System.Drawing.Point(130, 70);
            this.lab_read_SN.Name = "lab_read_SN";
            this.lab_read_SN.Size = new System.Drawing.Size(83, 19);
            this.lab_read_SN.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_read_SN.TabIndex = 5;
            this.lab_read_SN.Text = "lab_read_SN";
            this.lab_read_SN.UseStyleColors = true;
            // 
            // tbx_ReadLabel_Chip
            // 
            // 
            // 
            // 
            this.tbx_ReadLabel_Chip.CustomButton.Image = null;
            this.tbx_ReadLabel_Chip.CustomButton.Location = new System.Drawing.Point(254, 1);
            this.tbx_ReadLabel_Chip.CustomButton.Name = "";
            this.tbx_ReadLabel_Chip.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tbx_ReadLabel_Chip.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbx_ReadLabel_Chip.CustomButton.TabIndex = 1;
            this.tbx_ReadLabel_Chip.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbx_ReadLabel_Chip.CustomButton.UseSelectable = true;
            this.tbx_ReadLabel_Chip.CustomButton.Visible = false;
            this.tbx_ReadLabel_Chip.Lines = new string[0];
            this.tbx_ReadLabel_Chip.Location = new System.Drawing.Point(0, 22);
            this.tbx_ReadLabel_Chip.MaxLength = 32767;
            this.tbx_ReadLabel_Chip.Multiline = true;
            this.tbx_ReadLabel_Chip.Name = "tbx_ReadLabel_Chip";
            this.tbx_ReadLabel_Chip.PasswordChar = '\0';
            this.tbx_ReadLabel_Chip.PromptText = "Lettura del QR-Code";
            this.tbx_ReadLabel_Chip.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbx_ReadLabel_Chip.SelectedText = "";
            this.tbx_ReadLabel_Chip.SelectionLength = 0;
            this.tbx_ReadLabel_Chip.SelectionStart = 0;
            this.tbx_ReadLabel_Chip.ShortcutsEnabled = true;
            this.tbx_ReadLabel_Chip.Size = new System.Drawing.Size(276, 23);
            this.tbx_ReadLabel_Chip.TabIndex = 1;
            this.tbx_ReadLabel_Chip.UseSelectable = true;
            this.tbx_ReadLabel_Chip.WaterMark = "Lettura del QR-Code";
            this.tbx_ReadLabel_Chip.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tbx_ReadLabel_Chip.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tbx_ReadLabel_Chip.TextChanged += new System.EventHandler(this.tbx_ReadLabel_Chip_TextChanged);
            this.tbx_ReadLabel_Chip.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbx_ReadLabel_Chip_KeyPress);
            this.tbx_ReadLabel_Chip.Leave += new System.EventHandler(this.tbx_ReadLabel_Chip_Leave);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(0, 0);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(209, 19);
            this.metroLabel4.TabIndex = 8;
            this.metroLabel4.Text = "Lettura della scheda SMARTLINE:";
            // 
            // ID_Device_Image
            // 
            this.ID_Device_Image.BackColor = System.Drawing.Color.White;
            this.ID_Device_Image.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ID_Device_Image.Location = new System.Drawing.Point(3, 209);
            this.ID_Device_Image.Name = "ID_Device_Image";
            this.ID_Device_Image.Size = new System.Drawing.Size(244, 320);
            this.ID_Device_Image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ID_Device_Image.TabIndex = 41;
            this.ID_Device_Image.TabStop = false;
            // 
            // labchip_ID
            // 
            this.labchip_ID.AutoSize = true;
            this.labchip_ID.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.labchip_ID.Location = new System.Drawing.Point(130, 70);
            this.labchip_ID.Name = "labchip_ID";
            this.labchip_ID.Size = new System.Drawing.Size(72, 19);
            this.labchip_ID.Style = MetroFramework.MetroColorStyle.Red;
            this.labchip_ID.TabIndex = 43;
            this.labchip_ID.Text = "labchip_ID";
            this.labchip_ID.UseStyleColors = true;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(0, 70);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(105, 19);
            this.metroLabel6.TabIndex = 42;
            this.metroLabel6.Text = "Lettura del Chip:";
            // 
            // labchip_Kit
            // 
            this.labchip_Kit.AutoSize = true;
            this.labchip_Kit.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.labchip_Kit.Location = new System.Drawing.Point(130, 100);
            this.labchip_Kit.Name = "labchip_Kit";
            this.labchip_Kit.Size = new System.Drawing.Size(74, 19);
            this.labchip_Kit.Style = MetroFramework.MetroColorStyle.Red;
            this.labchip_Kit.TabIndex = 45;
            this.labchip_Kit.Text = "labchip_Kit";
            this.labchip_Kit.UseStyleColors = true;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(0, 100);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(126, 19);
            this.metroLabel8.TabIndex = 44;
            this.metroLabel8.Text = "Kit di appartenenza:";
            // 
            // labchip_Cliente
            // 
            this.labchip_Cliente.AutoSize = true;
            this.labchip_Cliente.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.labchip_Cliente.Location = new System.Drawing.Point(130, 160);
            this.labchip_Cliente.Name = "labchip_Cliente";
            this.labchip_Cliente.Size = new System.Drawing.Size(100, 19);
            this.labchip_Cliente.Style = MetroFramework.MetroColorStyle.Red;
            this.labchip_Cliente.TabIndex = 47;
            this.labchip_Cliente.Text = "labchip_Cliente";
            this.labchip_Cliente.UseStyleColors = true;
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.Location = new System.Drawing.Point(0, 160);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(52, 19);
            this.metroLabel10.TabIndex = 46;
            this.metroLabel10.Text = "Cliente:";
            // 
            // but_Associa
            // 
            this.but_Associa.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.but_Associa.Location = new System.Drawing.Point(3, 38);
            this.but_Associa.Name = "but_Associa";
            this.but_Associa.Size = new System.Drawing.Size(276, 23);
            this.but_Associa.Style = MetroFramework.MetroColorStyle.Green;
            this.but_Associa.TabIndex = 48;
            this.but_Associa.Text = "Associa SN - ID";
            this.but_Associa.UseSelectable = true;
            this.but_Associa.UseStyleColors = true;
            // 
            // but_Annulla
            // 
            this.but_Annulla.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.but_Annulla.Location = new System.Drawing.Point(3, 138);
            this.but_Annulla.Name = "but_Annulla";
            this.but_Annulla.Size = new System.Drawing.Size(276, 23);
            this.but_Annulla.Style = MetroFramework.MetroColorStyle.Red;
            this.but_Annulla.TabIndex = 49;
            this.but_Annulla.Text = "Annulla";
            this.but_Annulla.UseSelectable = true;
            this.but_Annulla.UseStyleColors = true;
            this.but_Annulla.Click += new System.EventHandler(this.but_Annulla_Click);
            // 
            // layout_orizz_menu
            // 
            this.layout_orizz_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.ColumnCount = 10;
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_exit, 10, 0);
            this.layout_orizz_menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_orizz_menu.Location = new System.Drawing.Point(20, 30);
            this.layout_orizz_menu.Name = "layout_orizz_menu";
            this.layout_orizz_menu.RowCount = 1;
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_orizz_menu.Size = new System.Drawing.Size(1003, 25);
            this.layout_orizz_menu.TabIndex = 121;
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Gainsboro;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(928, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(75, 24);
            this.pan_Menu_exit.TabIndex = 82;
            this.pan_Menu_exit.Text = "menuStrip1";
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            this.menu_sw_exit.Click += new System.EventHandler(this.menu_sw_exit_Click);
            // 
            // serialNumbersBindingSource
            // 
            this.serialNumbersBindingSource.DataMember = "SerialNumbers";
            this.serialNumbersBindingSource.DataSource = this.ds_SL;
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // serialNumbersTableAdapter
            // 
            this.serialNumbersTableAdapter.ClearBeforeFill = true;
            // 
            // sFAnagraficaClientiBindingSource
            // 
            this.sFAnagraficaClientiBindingSource.DataMember = "SF_AnagraficaClienti";
            this.sFAnagraficaClientiBindingSource.DataSource = this.ds_SL;
            // 
            // sF_AnagraficaClientiTableAdapter
            // 
            this.sF_AnagraficaClientiTableAdapter.ClearBeforeFill = true;
            // 
            // layout_spedizioni
            // 
            this.layout_spedizioni.ColumnCount = 4;
            this.layout_spedizioni.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.layout_spedizioni.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.layout_spedizioni.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.layout_spedizioni.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.layout_spedizioni.Controls.Add(this.panel_ID, 0, 0);
            this.layout_spedizioni.Controls.Add(this.panel_SN, 1, 0);
            this.layout_spedizioni.Controls.Add(this.ID_Device_Image, 0, 1);
            this.layout_spedizioni.Controls.Add(this.Serial_Device_Image, 1, 1);
            this.layout_spedizioni.Controls.Add(this.tableLayoutPanel1, 2, 0);
            this.layout_spedizioni.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_spedizioni.Location = new System.Drawing.Point(20, 55);
            this.layout_spedizioni.Name = "layout_spedizioni";
            this.layout_spedizioni.RowCount = 2;
            this.layout_spedizioni.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_spedizioni.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_spedizioni.Size = new System.Drawing.Size(1003, 544);
            this.layout_spedizioni.TabIndex = 122;
            // 
            // panel_ID
            // 
            this.panel_ID.Controls.Add(this.labchip_Device);
            this.panel_ID.Controls.Add(this.metroLabel5);
            this.panel_ID.Controls.Add(this.metroLabel4);
            this.panel_ID.Controls.Add(this.tbx_ReadLabel_Chip);
            this.panel_ID.Controls.Add(this.metroLabel6);
            this.panel_ID.Controls.Add(this.labchip_Cliente);
            this.panel_ID.Controls.Add(this.labchip_ID);
            this.panel_ID.Controls.Add(this.metroLabel10);
            this.panel_ID.Controls.Add(this.metroLabel8);
            this.panel_ID.Controls.Add(this.labchip_Kit);
            this.panel_ID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_ID.HorizontalScrollbarBarColor = true;
            this.panel_ID.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_ID.HorizontalScrollbarSize = 10;
            this.panel_ID.Location = new System.Drawing.Point(3, 3);
            this.panel_ID.Name = "panel_ID";
            this.panel_ID.Size = new System.Drawing.Size(244, 200);
            this.panel_ID.TabIndex = 123;
            this.panel_ID.VerticalScrollbarBarColor = true;
            this.panel_ID.VerticalScrollbarHighlightOnWheel = false;
            this.panel_ID.VerticalScrollbarSize = 10;
            // 
            // panel_SN
            // 
            this.panel_SN.Controls.Add(this.metroLabel1);
            this.panel_SN.Controls.Add(this.metroLabel2);
            this.panel_SN.Controls.Add(this.lab_read_FW);
            this.panel_SN.Controls.Add(this.metroLabel3);
            this.panel_SN.Controls.Add(this.lab_read_Device);
            this.panel_SN.Controls.Add(this.lab_read_SN);
            this.panel_SN.Controls.Add(this.lab_Etichetta);
            this.panel_SN.Controls.Add(this.tbx_ReadLabel_Device);
            this.panel_SN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_SN.HorizontalScrollbarBarColor = true;
            this.panel_SN.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_SN.HorizontalScrollbarSize = 10;
            this.panel_SN.Location = new System.Drawing.Point(253, 3);
            this.panel_SN.Name = "panel_SN";
            this.panel_SN.Size = new System.Drawing.Size(244, 200);
            this.panel_SN.TabIndex = 123;
            this.panel_SN.VerticalScrollbarBarColor = true;
            this.panel_SN.VerticalScrollbarHighlightOnWheel = false;
            this.panel_SN.VerticalScrollbarSize = 10;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(0, 130);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(50, 19);
            this.metroLabel5.TabIndex = 48;
            this.metroLabel5.Text = "Device:";
            // 
            // labchip_Device
            // 
            this.labchip_Device.AutoSize = true;
            this.labchip_Device.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.labchip_Device.Location = new System.Drawing.Point(130, 130);
            this.labchip_Device.Name = "labchip_Device";
            this.labchip_Device.Size = new System.Drawing.Size(98, 19);
            this.labchip_Device.Style = MetroFramework.MetroColorStyle.Red;
            this.labchip_Device.TabIndex = 49;
            this.labchip_Device.Text = "labchip_Device";
            this.labchip_Device.UseStyleColors = true;
            // 
            // Serial_Device_Image
            // 
            this.Serial_Device_Image.BackColor = System.Drawing.Color.White;
            this.Serial_Device_Image.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Serial_Device_Image.Location = new System.Drawing.Point(253, 209);
            this.Serial_Device_Image.Name = "Serial_Device_Image";
            this.Serial_Device_Image.Size = new System.Drawing.Size(244, 320);
            this.Serial_Device_Image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Serial_Device_Image.TabIndex = 124;
            this.Serial_Device_Image.TabStop = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.but_Associa, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.but_Annulla, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(503, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(244, 200);
            this.tableLayoutPanel1.TabIndex = 125;
            // 
            // UC_Spedizione
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1043, 649);
            this.ControlBox = false;
            this.Controls.Add(this.layout_spedizioni);
            this.Controls.Add(this.layout_orizz_menu);
            this.DisplayHeader = false;
            this.Name = "UC_Spedizione";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Resizable = false;
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UC_Spedizione_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ID_Device_Image)).EndInit();
            this.layout_orizz_menu.ResumeLayout(false);
            this.layout_orizz_menu.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.serialNumbersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFAnagraficaClientiBindingSource)).EndInit();
            this.layout_spedizioni.ResumeLayout(false);
            this.panel_ID.ResumeLayout(false);
            this.panel_ID.PerformLayout();
            this.panel_SN.ResumeLayout(false);
            this.panel_SN.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Serial_Device_Image)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroLabel lab_Etichetta;
        private MetroFramework.Controls.MetroTextBox tbx_ReadLabel_Device;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel lab_read_FW;
        private MetroFramework.Controls.MetroLabel lab_read_Device;
        private MetroFramework.Controls.MetroLabel lab_read_SN;
        private MetroFramework.Controls.MetroTextBox tbx_ReadLabel_Chip;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private ds_SL ds_SL;
        private System.Windows.Forms.BindingSource serialNumbersBindingSource;
        private ds_SLTableAdapters.SerialNumbersTableAdapter serialNumbersTableAdapter;
        private System.Windows.Forms.PictureBox ID_Device_Image;
        private MetroFramework.Controls.MetroLabel labchip_ID;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel labchip_Kit;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel labchip_Cliente;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private System.Windows.Forms.BindingSource sFAnagraficaClientiBindingSource;
        private ds_SLTableAdapters.SF_AnagraficaClientiTableAdapter sF_AnagraficaClientiTableAdapter;
        private MetroFramework.Controls.MetroButton but_Associa;
        private MetroFramework.Controls.MetroButton but_Annulla;
        private System.Windows.Forms.TableLayoutPanel layout_orizz_menu;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
        private System.Windows.Forms.TableLayoutPanel layout_spedizioni;
        private MetroFramework.Controls.MetroPanel panel_ID;
        private MetroFramework.Controls.MetroPanel panel_SN;
        private MetroFramework.Controls.MetroLabel labchip_Device;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private System.Windows.Forms.PictureBox Serial_Device_Image;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    }
}