﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;


namespace SmartLineProduction
{
    public partial class UC_Amm_AnalisiCosti : MetroFramework.Forms.MetroForm
    {
        public UC_Amm_AnalisiCosti()
        {
            InitializeComponent();
        }

        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UC_Amm_AnalisiCosti_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.Analisi_Costi_Distinte'. È possibile spostarla o rimuoverla se necessario.
            this.analisi_Costi_DistinteTableAdapter.Fill(this.ds_SL.Analisi_Costi_Distinte);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.Analisi_Costi_Distinte'. È possibile spostarla o rimuoverla se necessario.
            this.analisi_Costi_DistinteTableAdapter.Fill(this.ds_SL.Analisi_Costi_Distinte);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.Analisi_Costi_Venduto'. È possibile spostarla o rimuoverla se necessario.
            this.analisi_Costi_VendutoTableAdapter.Fill(this.ds_SL.Analisi_Costi_Venduto);

        }
    }
}
