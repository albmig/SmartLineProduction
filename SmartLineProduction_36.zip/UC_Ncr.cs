﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using System.IO;
using Spire.Pdf;
using Spire.Pdf.Widget;
using Spire.Pdf.Fields;

namespace SmartLineProduction
{
    public partial class UC_Ncr : MetroFramework.Forms.MetroForm
    {
        public static int NCR_Id = 0;
        private string displayform = "V"; // V-View/I-Insert/E-Edit
        public static int NCR_Phase = 0; //1-Identificazione/2-Azioni/3-Chiusura
        private string pathForPdf = @"\\192.168.0.8\sistematica\AREA_QUALITA\Modulo NON CONFORMITA\NCR - IT.pdf";
        private string PathDef = @"\\192.168.0.8\sistematica\AREA_QUALITA\Modulo NON CONFORMITA\";
        private string FileDef = "";
        public int Ncr_Progr;
        public string Ncr_Progr_Nome;
        public int Ncr_Phase;
        public int Ncr_Ident_Originatore;
        public string Ncr_Ident_Originatore_Nome;
        public string Ncr_Ident_Prodotto;
        public DateTime Ncr_Ident_DateCreation;
        public string Ncr_Ident_DateCreation_Nome;
        public string Ncr_Ident_Descrizione;
        public int Ncr_Ident_Level;
        public string Ncr_Ident_Level_Name;
        public string Ncr_Ident_Coinvolti;
        public bool Ncr_Ident_Customer;
        public bool Ncr_Ident_Deviazione;
        public string Ncr_Azioni_Pianificazione;
        public int Ncr_Azioni_Responsabile;
        public string Ncr_Azioni_Responsabile_Nome;
        public DateTime Ncr_Azioni_RespDate;
        public int Ncr_Azioni_RespApprovazione;
        public DateTime Ncr_Azioni_RespAppDate;
        public int Ncr_Close_Azione_RespUser;
        public DateTime Ncr_Close_Azione_RespUserDate;
        public string Ncr_Close_Azione_RespCustomer;
        public DateTime Ncr_Close_Azione_RespCustDate;
        public string Ncr_Close_Disposition;

        public UC_Ncr()
        {
            InitializeComponent();
        }

        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UC_Ncr_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_Ncr.User_Responsabile'. È possibile spostarla o rimuoverla se necessario.
            this.user_ResponsabileTableAdapter.Fill(this.ds_Ncr.User_Responsabile);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_Ncr.User_Originatore'. È possibile spostarla o rimuoverla se necessario.
            this.user_OriginatoreTableAdapter.Fill(this.ds_Ncr.User_Originatore);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_Ncr1.Ncr'. È possibile spostarla o rimuoverla se necessario.
            this.ncrTableAdapter.Fill(this.ds_Ncr.Ncr);

            //UC_Login uC_Login = new UC_Login();
            //uC_Login.ShowDialog();
            NCR_Id = 2;

            SettaForm();
            tab_fasi.SelectedTab = tab_fasi.TabPages["tab_identificazione"];
            ncrBindingSource.MoveFirst();
        }

        private void UC_Ncr_Activated(object sender, EventArgs e)
        {
            //string ppp = "Activated " + NCR_Id.ToString();
            //MessageBox.Show(ppp);
        }

        private void menu_new_Click(object sender, EventArgs e)
        {
            displayform = "I";
            Application.UseWaitCursor = true;
            SettaForm();
            Application.UseWaitCursor = false;

        }

        private void ncrBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            // Link per originatore
            if (ncrBindingSource.Current != null)
            {
                ToClass();
                ToScreen();
            }
        }

        private void tab_fasi_SelectedIndexChanged(object sender, EventArgs e)
        {

            switch (tab_fasi.SelectedIndex)
            {

                case 0: //Identificazione
                    {
                        break;
                    }
                case 1: //Azioni correttive/preventive e disposizioni
                    {
                        break;
                    }
                case 2: //Chiusura delle non conformità
                    {
                        break;
                    }
                case 3: //Visualizza Pdf
                    {
                        CreaPdf();
                        NCR_PDF.LoadDocument(FileDef);
                        break;
                    }
            }
        }

        private void cb_Originatore_TextChanged(object sender, EventArgs e)
        {
            Ncr_Ident_Originatore_Nome = cb_Originatore.Text;
        }

        private void menu_edit_Click(object sender, EventArgs e)
        {
            displayform = "E";
            SettaForm();
        }

        /////////////////////////////////////////////////////////////////////////////// FUNZIONI

        private void SettaForm()
        {

            switch (displayform)
            {
                case "V":
                    pan_Menu_comandi.Enabled = true;
                    pan_Menu_salva.Enabled = false;
                    pan_Menu_exit.Enabled = true;

                    panel_identificazione.Enabled = false;
                    panel_azioni.Enabled = false;
                    panel_chiusura.Enabled = false;
                    panel_pdf.Enabled = true;

                    //this.dt_QualityTableAdapter.FillBy_CodiceQuality(this.ds_Quality.dt_Quality);

                    //dtQualityBindingSource.ResumeBinding();
                    //gv_Quality.Enabled = true;
                    //tb_Des.Enabled = false;
                    //tb_folder.Enabled = false;
                    //tb_rev.Enabled = false;
                    //tb_vers.Enabled = false;

                    //dtQualityBindingSource.RemoveFilter();
                    //dtQualityBindingSource.MoveFirst();

                    //label_codview.Visible = true;
                    //label_codedit.Visible = false;
                    //lab_Codice_View.Visible = true;
                    //lab_Codice_Edit.Visible = false;
                    break;
                case "I":
                    //ncrBindingSource.SuspendBinding();
                    var newrow = ds_Ncr.Ncr.NewRow();

                    switch (NCR_Phase)
                    {
                        case 1:
                            panel_identificazione.Enabled = true;
                            panel_azioni.Enabled = false;
                            panel_chiusura.Enabled = false;
                            panel_pdf.Enabled = true;
                            break;
                        case 2:
                            panel_identificazione.Enabled = false;
                            panel_azioni.Enabled = true;
                            panel_chiusura.Enabled = false;
                            panel_pdf.Enabled = true;
                            break;
                        case 3:
                            panel_identificazione.Enabled = false;
                            panel_azioni.Enabled = false;
                            panel_chiusura.Enabled = true;
                            panel_pdf.Enabled = true;
                            break;
                    }

                    //dtQualityBindingSource.SuspendBinding();
                    //tb_Des.Enabled = true;
                    //tb_Des.Text = "";
                    //tb_folder.Enabled = true;
                    //tb_rev.Enabled = true;
                    //tb_vers.Enabled = true;

                    //gv_Quality.Enabled = false;

                    //usersBindingSource.RemoveFilter();
                    //dtQualityProjProdAreaBindingSource.RemoveFilter();
                    //dtQualityCompanyBindingSource.RemoveFilter();
                    //dtQualityTipoDocBindingSource.RemoveFilter();
                    //dtQualityClassificationBindingSource.RemoveFilter();

                    //usersBindingSource.RemoveFilter();
                    //dtQualityProjProdAreaBindingSource.Sort = "Qual_Des asc";
                    //dtQualityCompanyBindingSource.Sort = "Qual_Des asc";
                    //dtQualityTipoDocBindingSource.Sort = "Qual_Des asc";
                    //dtQualityClassificationBindingSource.Sort = "Qual_Des asc";

                    //label_codview.Visible = false;
                    //label_codedit.Visible = true;
                    //lab_Codice_View.Visible = false;
                    //lab_Codice_Edit.Visible = true;

                    //gv_Quality.Enabled = false;

                    //pan_Menu_comandi.Enabled = false;
                    //pan_Menu_salva.Enabled = true;
                    //pan_Menu_exit.Enabled = false;

                    break;
                case "E":
                    pan_Menu_comandi.Enabled = false;
                    pan_Menu_salva.Enabled = true;
                    pan_Menu_exit.Enabled = false;

                    panel_identificazione.Enabled = true;
                    panel_azioni.Enabled = true;
                    panel_chiusura.Enabled = true;
                    panel_pdf.Enabled = true;

                    //gv_Quality.Enabled = false;

                    //cb_User.Enabled = false;
                    //cb_projprodarea.Enabled = false;
                    //cb_org.Enabled = false;
                    //cb_type.Enabled = false;
                    //cb_class.Enabled = false;
                    //tb_Des.Enabled = true;
                    //tb_folder.Enabled = true;
                    //tb_rev.Enabled = false;
                    //tb_vers.Enabled = false;

                    //label_codview.Visible = true;
                    //label_codedit.Visible = false;
                    //lab_Codice_View.Visible = true;
                    //lab_Codice_Edit.Visible = false;



                    break;
            }
        }

        private void ToClass()
        {
            DataRowView current_ncr = (DataRowView)ncrBindingSource.Current;

            Ncr_Progr = convInt(current_ncr["Ncr_Progr"]);
            Ncr_Phase = convInt(current_ncr["Ncr_Phase"]);
            Ncr_Ident_Originatore = convInt(current_ncr["Ncr_Ident_Originatore"]);
            Ncr_Ident_Prodotto = convStr(current_ncr["Ncr_Ident_Prodotto"]);
            Ncr_Ident_DateCreation = convDate(current_ncr["Ncr_Ident_DateCreation"]);
            Ncr_Ident_Descrizione = convStr(current_ncr["Ncr_Ident_Descrizione"]);
            Ncr_Ident_Level = convInt(current_ncr["Ncr_Ident_Level"]);
            Ncr_Ident_Coinvolti = convStr(current_ncr["Ncr_Ident_Coinvolti"]);
            Ncr_Ident_Customer = convBool(current_ncr["Ncr_Ident_Customer"]);
            Ncr_Ident_Deviazione = convBool(current_ncr["Ncr_Ident_Deviazione"]);
            Ncr_Azioni_Pianificazione = convStr(current_ncr["Ncr_Azioni_Pianificazione"]);
            Ncr_Azioni_Responsabile = convInt(current_ncr["Ncr_Azioni_Responsabile"]);
            Ncr_Azioni_RespDate = convDate(current_ncr["Ncr_Azioni_RespDate"]);
            Ncr_Azioni_RespApprovazione = convInt(current_ncr["Ncr_Azioni_RespApprovazione"]);
            Ncr_Azioni_RespAppDate = convDate(current_ncr["Ncr_Azioni_RespAppDate"]);
            Ncr_Close_Azione_RespUser = convInt(current_ncr["Ncr_Close_Azione_RespUser"]);
            Ncr_Close_Azione_RespUserDate = convDate(current_ncr["Ncr_Close_Azione_RespUserDate"]);
            Ncr_Close_Azione_RespCustomer = convStr(current_ncr["Ncr_Close_Azione_RespCustomer"]);
            Ncr_Close_Azione_RespCustDate = convDate(current_ncr["Ncr_Close_Azione_RespCustDate"]);
            Ncr_Close_Disposition = convStr(current_ncr["Ncr_Close_Disposition"]);
        }

        private void ToScreen()
        {
            //cb_Originatore
            //tb_prodotto.Text = Ncr_Ident_Prodotto;
            cb_Criticità.SelectedIndex = Ncr_Ident_Level;
            string progr = Ncr_Progr.ToString();
            lab_Ncr_Progr.Text = progr.PadLeft(7, '0');
            lab_Ncr_Ident_DateCreation.Text = Ncr_Ident_DateCreation.ToString("dd/MM/yyyy");
            tb_Ncr_Ident_Descrizione.Text = Ncr_Ident_Descrizione;
            tb_Ncr_Azioni_Pianificazione.Text = Ncr_Azioni_Pianificazione;
        }

        private int convInt(object daconvertire)
        {
            int conv = 0;
            if (daconvertire != DBNull.Value) { conv = Convert.ToInt32(daconvertire); }
            return conv;
        }

        private string convStr(object daconvertire)
        {
            string conv = "";
            if (daconvertire != DBNull.Value) { conv = Convert.ToString(daconvertire); }
            return conv;
        }

        private DateTime convDate(object daconvertire)
        {
            DateTime conv = default(DateTime);
            if (daconvertire != DBNull.Value) { conv = Convert.ToDateTime(daconvertire); }
            return conv;
        }

        private bool convBool(object daconvertire)
        {
            bool conv = false;
            if (daconvertire != DBNull.Value) { conv = Convert.ToBoolean(daconvertire); }
            return conv;
        }

        private void CreaPdf()
        {
            NCR_PDF.CloseDocument();

            AggiornaVariabili();

            //Copia del modello su file temporaneo
            //string fileTmp = Path.GetTempFileName();
            //FileInfo fi = new FileInfo(fileTmp);
            //fi.Attributes = FileAttributes.Temporary;

            //Creazione del pdf interattivo
            PdfDocument doc = new PdfDocument();
            //Load from file
            doc.LoadFromFile(pathForPdf);

            //Get the PDF field collection on the Form.
            PdfFormWidget widget = doc.Form as PdfFormWidget;

            //Traverse each PDF field in pdf field collection.
            for (int i = 0; i < widget.FieldsWidget.List.Count; i++)
            {
                PdfField f = widget.FieldsWidget.List[i] as PdfField;

                //Find a PDF field named username and set the value for it.
                if (f.Name == "Originator 1")
                {
                    //Convert the pdf field to PdfTextBoxFieldWidget
                    PdfTextBoxFieldWidget textboxField = f as PdfTextBoxFieldWidget;
                    //Change its text
                    textboxField.Text = Ncr_Ident_Originatore_Nome;
                    f.Flatten = true;
                    f.ReadOnly = true;
                }
                if (f.Name == "Product 1")
                {
                    //Convert the pdf field to PdfTextBoxFieldWidget
                    PdfTextBoxFieldWidget textboxField = f as PdfTextBoxFieldWidget;
                    //Change its text
                    textboxField.Text = Ncr_Ident_Prodotto;
                    f.Flatten = true;
                    f.ReadOnly = true;
                }
                if (f.Name == "Date 1")
                {
                    //Convert the pdf field to PdfTextBoxFieldWidget
                    PdfTextBoxFieldWidget textboxField = f as PdfTextBoxFieldWidget;
                    //Change its text
                    textboxField.Text = Ncr_Ident_DateCreation_Nome;
                    f.Flatten = true;
                    f.ReadOnly = true;
                }
                if (f.Name == "Report Number 1")
                {
                    //Convert the pdf field to PdfTextBoxFieldWidget
                    PdfTextBoxFieldWidget textboxField = f as PdfTextBoxFieldWidget;
                    //Change its text
                    textboxField.Text = Ncr_Progr_Nome;
                    f.Flatten = true;
                    f.ReadOnly = true;
                }
                if (f.Name == "NonConformance Description 1")
                {
                    //Convert the pdf field to PdfTextBoxFieldWidget
                    PdfTextBoxFieldWidget textboxField = f as PdfTextBoxFieldWidget;
                    //Change its text
                    textboxField.Text = Ncr_Ident_Descrizione;
                    f.Flatten = true;
                    f.ReadOnly = true;
                }
                if (f.Name == "Criticality 1")
                {
                    //Convert the pdf field to PdfTextBoxFieldWidget
                    PdfTextBoxFieldWidget textboxField = f as PdfTextBoxFieldWidget;
                    //Change its text
                    textboxField.Text = Ncr_Ident_Level_Name;
                    f.Flatten = true;
                    f.ReadOnly = true;
                }
                if (f.Name == "Stepstoprevent 1")
                {
                    //Convert the pdf field to PdfTextBoxFieldWidget
                    PdfTextBoxFieldWidget textboxField = f as PdfTextBoxFieldWidget;
                    //Change its text
                    textboxField.Text = Ncr_Azioni_Pianificazione;
                    f.Flatten = true;
                    f.ReadOnly = true;
                }
                if (f.Name == "RensponsibleArea 1")
                {
                    //Convert the pdf field to PdfTextBoxFieldWidget
                    PdfTextBoxFieldWidget textboxField = f as PdfTextBoxFieldWidget;
                    //Change its text
                    textboxField.Text = Ncr_Azioni_Responsabile_Nome;
                    f.Flatten = true;
                    f.ReadOnly = true;
                }

            }

            //Save
            FileDef = PathDef + "NCR_" + Ncr_Progr_Nome + ".pdf";
            doc.SaveToFile(FileDef);
        }

        private void AggiornaVariabili()
        {
            Ncr_Ident_Originatore_Nome = cb_Originatore.Text;
            Ncr_Ident_Level_Name = cb_Criticità.Text;
            Ncr_Progr_Nome = lab_Ncr_Progr.Text;
            Ncr_Ident_DateCreation_Nome = lab_Ncr_Ident_DateCreation.Text;
            Ncr_Azioni_Responsabile_Nome = cb_Responsabile.Text;

        }

    }
}
