﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using DYMO.Label.Framework;

namespace SmartLineProduction
{
    public partial class MainMenu : MetroFramework.Forms.MetroForm
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void tile_Spedizione_Click(object sender, EventArgs e)
        {
            UC_Spedizione uC_Spedizione = new UC_Spedizione();
            uC_Spedizione.MdiParent = this;
            uC_Spedizione.Dock = DockStyle.Fill;
            uC_Spedizione.Show();
        }

        private void tile_Avanzamento_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_Avanzamento uC_Avanzamento = new UC_Avanzamento();
            SplashDB.Close();
            uC_Avanzamento.MdiParent = this;
            uC_Avanzamento.Dock = DockStyle.Fill;
            uC_Avanzamento.Show();
        }

        private void tile_Programmazione_Click(object sender, EventArgs e)
        {
            //if (glob_use_printer) { SetupLabelWriterSelection(true); }
            bool printerexist = false;
            printerexist = SetupLabelWriterSelection();
            if (!printerexist)
            {
                MetroFramework.MetroMessageBox.Show(this, "Warning", "Non esiste una stampante disponibile per l'applicazione su questa postazione!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            else
            {
                GVar.CloseSplash = false;
                Splash SplashDB = new Splash();
                SplashDB.Show();

                UC_Programmazione uC_Programmazione = new UC_Programmazione();
                SplashDB.Close();
                uC_Programmazione.MdiParent = this;
                uC_Programmazione.Dock = DockStyle.Fill;
                uC_Programmazione.Show();
            }
        }

        private void tile_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void MainMenu_MdiChildActivate(object sender, EventArgs e)
        {
            Form f = this.ActiveMdiChild;

            if (f == null)
            {
                //the last child form was just closed
                layout_Menu.Visible = true;
            }
            else
            {
                layout_Menu.Visible = false;
            }
        }

        private void tile_FW_R_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_FW_R uC_FW_R = new UC_FW_R();
            SplashDB.Close();
            uC_FW_R.MdiParent = this;
            uC_FW_R.Dock = DockStyle.Fill;
            uC_FW_R.Show();
        }

        private void tile_FW_P_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_FW_P uC_FW_P = new UC_FW_P();
            SplashDB.Close();
            uC_FW_P.MdiParent = this;
            uC_FW_P.Dock = DockStyle.Fill;
            uC_FW_P.Show();
        }

        private void MainMenu_Load(object sender, EventArgs e)
        {
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
        }

        private void pan_Menu_exit_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            Application.Exit();
        }

        private bool SetupLabelWriterSelection()
        {
            int contadymoprinters = 0;
            foreach (IPrinter printer in Framework.GetPrinters())
                contadymoprinters++;

            if (contadymoprinters>0) { return true; } else { return false; }
        }

        private void tile_ReportProdotti_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_ReportProdotti uC_ReportProdotti = new UC_ReportProdotti();
            SplashDB.Close();
            uC_ReportProdotti.MdiParent = this;
            uC_ReportProdotti.Dock = DockStyle.Fill;
            uC_ReportProdotti.Show();
        }

        private void tile_Schede_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_SchedeProdotti uC_SchedeProdotti = new UC_SchedeProdotti();
            SplashDB.Close();
            uC_SchedeProdotti.MdiParent = this;
            uC_SchedeProdotti.Dock = DockStyle.Fill;
            uC_SchedeProdotti.Show();

        }
    }
}
