﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using System.IO;
using Syncfusion.Windows.Forms;

namespace SmartLineProduction
{
    public partial class UC_SchedeProdotti : MetroFramework.Forms.MetroForm
    {
        public UC_SchedeProdotti()
        {
            InitializeComponent();
        }

        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UC_SchedeProdotti_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_ItemDevice_FW_Des'. È possibile spostarla o rimuoverla se necessario.
            this.sF_ItemDevice_FW_DesTableAdapter.Fill(this.ds_SL.SF_ItemDevice_FW_Des);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_ArticoliSchede'. È possibile spostarla o rimuoverla se necessario.
            this.sF_ArticoliSchedeTableAdapter.Fill(this.ds_SL.SF_ArticoliSchede);

            SetView();
        }

        private void tab_Kit_Enter(object sender, EventArgs e)
        {
            this.sF_ArticoliSchedeTableAdapter.FillBy_Kit(this.ds_SL.SF_ArticoliSchede);
            gv_Kit.Refresh();
        }

        private void sFArticoliSchedeBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            Kit_pdf_it.Unload();
            Kit_pdf_en.Unload();

            DataRowView drview = (DataRowView)sFArticoliSchedeBindingSource.Current;
            if (drview == null) { return; }

            string articolo = drview["Articolo"].ToString();

            if (articolo.Substring(0, 4) != "XKIT") { return; }

            string path = Properties.Settings.Default.Doc_folder;
            path = path + @"XKIT\";
            string path_it = path + drview["Articolo"].ToString() + @"\IT\" + drview["Articolo"].ToString() + ".pdf";
            string path_en = path + drview["Articolo"].ToString() + @"\EN\" + drview["Articolo"].ToString() + ".pdf";

            if (System.IO.File.Exists(path_it)) { Kit_pdf_it.Load(path_it); }
            if (System.IO.File.Exists(path_en)) { Kit_pdf_en.Load(path_en); }
        }

        private void SetView()
        {
            tb_grid_kit.Text = "";
            tb_grid_palmari.Text = "";
        }

        private void tb_grid_kit_TextChanged(object sender, EventArgs e)
        {
            string filtro = string.Format("Articolo LIKE '%{0}%'", tb_grid_kit.Text);
            sFArticoliSchedeBindingSource.Filter = filtro;
            tb_grid_kit.Focus();
        }

        private void sFItemDeviceFWDesBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            Palmari_pdf_it.Unload();
            Palmari_pdf_en.Unload();

            DataRowView drview = (DataRowView)sFItemDeviceFWDesBindingSource.Current;
            if (drview == null) { return; }

            string articolo = drview["Articolo_Device"].ToString();
            string famdevice = drview["FamDevice"].ToString();
            string tipodevice = drview["TipoDevice"].ToString();

            string path = Properties.Settings.Default.Doc_folder;
            path = path + famdevice + @"\";
            string path_it = path + drview["Articolo_Device"].ToString() + @"\IT\" + drview["Articolo_Device"].ToString() + ".pdf";
            string path_en = path + drview["Articolo_Device"].ToString() + @"\EN\" + drview["Articolo_Device"].ToString() + ".pdf";

            if (System.IO.File.Exists(path_it)) { Palmari_pdf_it.Load(path_it); }
            if (System.IO.File.Exists(path_en)) { Palmari_pdf_en.Load(path_en); }

        }

        private void tab_Palmari_Enter(object sender, EventArgs e)
        {
            this.sF_ItemDevice_FW_DesTableAdapter.FillBy_Palmari(this.ds_SL.SF_ItemDevice_FW_Des);
            gv_Palmari.Refresh();

        }

        private void tb_grid_palmari_TextChanged(object sender, EventArgs e)
        {
            string filtro = string.Format("Articolo_Device LIKE '%{0}%'", tb_grid_palmari.Text);
            sFItemDeviceFWDesBindingSource.Filter = filtro;
            tb_grid_palmari.Focus();
        }
    }
}
