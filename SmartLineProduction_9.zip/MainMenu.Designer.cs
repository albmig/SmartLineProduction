﻿namespace SmartLineProduction
{
    partial class MainMenu
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenu));
            this.tile_Programmazione = new MetroFramework.Controls.MetroTile();
            this.layout_Menu = new System.Windows.Forms.TableLayoutPanel();
            this.tile_Schede = new MetroFramework.Controls.MetroTile();
            this.tile_ReportProdotti = new MetroFramework.Controls.MetroTile();
            this.layout_orizz_menu = new System.Windows.Forms.TableLayoutPanel();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.tile_FW_P = new MetroFramework.Controls.MetroTile();
            this.tile_FW_R = new MetroFramework.Controls.MetroTile();
            this.tile_Avanzamento = new MetroFramework.Controls.MetroTile();
            this.tile_Spedizione = new MetroFramework.Controls.MetroTile();
            this.panel_Logo = new MetroFramework.Controls.MetroPanel();
            this.layout_Menu.SuspendLayout();
            this.layout_orizz_menu.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            this.SuspendLayout();
            // 
            // tile_Programmazione
            // 
            this.tile_Programmazione.ActiveControl = null;
            this.layout_Menu.SetColumnSpan(this.tile_Programmazione, 2);
            this.tile_Programmazione.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tile_Programmazione.Location = new System.Drawing.Point(3, 151);
            this.tile_Programmazione.Name = "tile_Programmazione";
            this.tile_Programmazione.Size = new System.Drawing.Size(88, 31);
            this.tile_Programmazione.Style = MetroFramework.MetroColorStyle.Red;
            this.tile_Programmazione.TabIndex = 0;
            this.tile_Programmazione.Text = "Programmazione";
            this.tile_Programmazione.TileImage = ((System.Drawing.Image)(resources.GetObject("tile_Programmazione.TileImage")));
            this.tile_Programmazione.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.tile_Programmazione.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile_Programmazione.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tile_Programmazione.UseSelectable = true;
            this.tile_Programmazione.UseTileImage = true;
            this.tile_Programmazione.Click += new System.EventHandler(this.tile_Programmazione_Click);
            // 
            // layout_Menu
            // 
            this.layout_Menu.AutoScroll = true;
            this.layout_Menu.AutoSize = true;
            this.layout_Menu.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.layout_Menu.ColumnCount = 16;
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.Controls.Add(this.tile_Schede, 9, 5);
            this.layout_Menu.Controls.Add(this.tile_ReportProdotti, 9, 4);
            this.layout_Menu.Controls.Add(this.layout_orizz_menu, 0, 0);
            this.layout_Menu.Controls.Add(this.tile_FW_P, 6, 4);
            this.layout_Menu.Controls.Add(this.tile_FW_R, 6, 5);
            this.layout_Menu.Controls.Add(this.tile_Avanzamento, 3, 4);
            this.layout_Menu.Controls.Add(this.tile_Spedizione, 0, 6);
            this.layout_Menu.Controls.Add(this.tile_Programmazione, 0, 4);
            this.layout_Menu.Controls.Add(this.panel_Logo, 15, 1);
            this.layout_Menu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Menu.Location = new System.Drawing.Point(20, 60);
            this.layout_Menu.Name = "layout_Menu";
            this.layout_Menu.RowCount = 10;
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.Size = new System.Drawing.Size(760, 370);
            this.layout_Menu.TabIndex = 1;
            // 
            // tile_Schede
            // 
            this.tile_Schede.ActiveControl = null;
            this.layout_Menu.SetColumnSpan(this.tile_Schede, 2);
            this.tile_Schede.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tile_Schede.Location = new System.Drawing.Point(426, 188);
            this.tile_Schede.Name = "tile_Schede";
            this.tile_Schede.Size = new System.Drawing.Size(88, 31);
            this.tile_Schede.Style = MetroFramework.MetroColorStyle.Orange;
            this.tile_Schede.TabIndex = 121;
            this.tile_Schede.Text = "Schede Prodotti";
            this.tile_Schede.TileImage = ((System.Drawing.Image)(resources.GetObject("tile_Schede.TileImage")));
            this.tile_Schede.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.tile_Schede.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile_Schede.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tile_Schede.UseSelectable = true;
            this.tile_Schede.UseStyleColors = true;
            this.tile_Schede.UseTileImage = true;
            this.tile_Schede.Click += new System.EventHandler(this.tile_Schede_Click);
            // 
            // tile_ReportProdotti
            // 
            this.tile_ReportProdotti.ActiveControl = null;
            this.layout_Menu.SetColumnSpan(this.tile_ReportProdotti, 2);
            this.tile_ReportProdotti.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tile_ReportProdotti.Location = new System.Drawing.Point(426, 151);
            this.tile_ReportProdotti.Name = "tile_ReportProdotti";
            this.tile_ReportProdotti.Size = new System.Drawing.Size(88, 31);
            this.tile_ReportProdotti.Style = MetroFramework.MetroColorStyle.Orange;
            this.tile_ReportProdotti.TabIndex = 120;
            this.tile_ReportProdotti.Text = "Prodotti attivati";
            this.tile_ReportProdotti.TileImage = ((System.Drawing.Image)(resources.GetObject("tile_ReportProdotti.TileImage")));
            this.tile_ReportProdotti.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.tile_ReportProdotti.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile_ReportProdotti.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tile_ReportProdotti.UseSelectable = true;
            this.tile_ReportProdotti.UseStyleColors = true;
            this.tile_ReportProdotti.UseTileImage = true;
            this.tile_ReportProdotti.Click += new System.EventHandler(this.tile_ReportProdotti_Click);
            // 
            // layout_orizz_menu
            // 
            this.layout_orizz_menu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.layout_orizz_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.ColumnCount = 10;
            this.layout_Menu.SetColumnSpan(this.layout_orizz_menu, 20);
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_exit, 10, 0);
            this.layout_orizz_menu.Location = new System.Drawing.Point(3, 3);
            this.layout_orizz_menu.Name = "layout_orizz_menu";
            this.layout_orizz_menu.RowCount = 1;
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_orizz_menu.Size = new System.Drawing.Size(754, 25);
            this.layout_orizz_menu.TabIndex = 119;
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Gainsboro;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(679, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(75, 24);
            this.pan_Menu_exit.TabIndex = 82;
            this.pan_Menu_exit.Text = "menuStrip1";
            this.pan_Menu_exit.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.pan_Menu_exit_ItemClicked);
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            // 
            // tile_FW_P
            // 
            this.tile_FW_P.ActiveControl = null;
            this.layout_Menu.SetColumnSpan(this.tile_FW_P, 2);
            this.tile_FW_P.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tile_FW_P.Location = new System.Drawing.Point(285, 151);
            this.tile_FW_P.Name = "tile_FW_P";
            this.tile_FW_P.Size = new System.Drawing.Size(88, 31);
            this.tile_FW_P.Style = MetroFramework.MetroColorStyle.Lime;
            this.tile_FW_P.TabIndex = 6;
            this.tile_FW_P.Text = "Firmware Palmari";
            this.tile_FW_P.TileImage = ((System.Drawing.Image)(resources.GetObject("tile_FW_P.TileImage")));
            this.tile_FW_P.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.tile_FW_P.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile_FW_P.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tile_FW_P.UseSelectable = true;
            this.tile_FW_P.UseStyleColors = true;
            this.tile_FW_P.UseTileImage = true;
            this.tile_FW_P.Click += new System.EventHandler(this.tile_FW_P_Click);
            // 
            // tile_FW_R
            // 
            this.tile_FW_R.ActiveControl = null;
            this.layout_Menu.SetColumnSpan(this.tile_FW_R, 2);
            this.tile_FW_R.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tile_FW_R.Location = new System.Drawing.Point(285, 188);
            this.tile_FW_R.Name = "tile_FW_R";
            this.tile_FW_R.Size = new System.Drawing.Size(88, 31);
            this.tile_FW_R.Style = MetroFramework.MetroColorStyle.Green;
            this.tile_FW_R.TabIndex = 5;
            this.tile_FW_R.Text = "Firmware Ricevitori";
            this.tile_FW_R.TileImage = ((System.Drawing.Image)(resources.GetObject("tile_FW_R.TileImage")));
            this.tile_FW_R.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.tile_FW_R.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile_FW_R.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tile_FW_R.UseSelectable = true;
            this.tile_FW_R.UseStyleColors = true;
            this.tile_FW_R.UseTileImage = true;
            this.tile_FW_R.Click += new System.EventHandler(this.tile_FW_R_Click);
            // 
            // tile_Avanzamento
            // 
            this.tile_Avanzamento.ActiveControl = null;
            this.layout_Menu.SetColumnSpan(this.tile_Avanzamento, 2);
            this.tile_Avanzamento.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tile_Avanzamento.Location = new System.Drawing.Point(144, 151);
            this.tile_Avanzamento.Name = "tile_Avanzamento";
            this.tile_Avanzamento.Size = new System.Drawing.Size(88, 31);
            this.tile_Avanzamento.Style = MetroFramework.MetroColorStyle.Blue;
            this.tile_Avanzamento.TabIndex = 3;
            this.tile_Avanzamento.Text = "Avanz. Commesse";
            this.tile_Avanzamento.TileImage = ((System.Drawing.Image)(resources.GetObject("tile_Avanzamento.TileImage")));
            this.tile_Avanzamento.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.tile_Avanzamento.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile_Avanzamento.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tile_Avanzamento.UseSelectable = true;
            this.tile_Avanzamento.UseStyleColors = true;
            this.tile_Avanzamento.UseTileImage = true;
            this.tile_Avanzamento.Click += new System.EventHandler(this.tile_Avanzamento_Click);
            // 
            // tile_Spedizione
            // 
            this.tile_Spedizione.ActiveControl = null;
            this.layout_Menu.SetColumnSpan(this.tile_Spedizione, 2);
            this.tile_Spedizione.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tile_Spedizione.Location = new System.Drawing.Point(3, 225);
            this.tile_Spedizione.Name = "tile_Spedizione";
            this.tile_Spedizione.Size = new System.Drawing.Size(88, 31);
            this.tile_Spedizione.Style = MetroFramework.MetroColorStyle.Red;
            this.tile_Spedizione.TabIndex = 1;
            this.tile_Spedizione.Text = "Spedizione";
            this.tile_Spedizione.TileImage = ((System.Drawing.Image)(resources.GetObject("tile_Spedizione.TileImage")));
            this.tile_Spedizione.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.tile_Spedizione.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile_Spedizione.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tile_Spedizione.UseSelectable = true;
            this.tile_Spedizione.UseTileImage = true;
            this.tile_Spedizione.Click += new System.EventHandler(this.tile_Spedizione_Click);
            // 
            // panel_Logo
            // 
            this.panel_Logo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_Logo.BackgroundImage")));
            this.panel_Logo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel_Logo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Logo.HorizontalScrollbarBarColor = true;
            this.panel_Logo.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_Logo.HorizontalScrollbarSize = 10;
            this.panel_Logo.Location = new System.Drawing.Point(708, 40);
            this.panel_Logo.Name = "panel_Logo";
            this.panel_Logo.Size = new System.Drawing.Size(49, 31);
            this.panel_Logo.TabIndex = 2;
            this.panel_Logo.VerticalScrollbarBarColor = true;
            this.panel_Logo.VerticalScrollbarHighlightOnWheel = false;
            this.panel_Logo.VerticalScrollbarSize = 10;
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.layout_Menu);
            this.IsMdiContainer = true;
            this.Name = "MainMenu";
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "Sistematica - SmartLine";
            this.TransparencyKey = System.Drawing.Color.Empty;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainMenu_Load);
            this.MdiChildActivate += new System.EventHandler(this.MainMenu_MdiChildActivate);
            this.layout_Menu.ResumeLayout(false);
            this.layout_orizz_menu.ResumeLayout(false);
            this.layout_orizz_menu.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTile tile_Programmazione;
        private System.Windows.Forms.TableLayoutPanel layout_Menu;
        private MetroFramework.Controls.MetroTile tile_Spedizione;
        private MetroFramework.Controls.MetroPanel panel_Logo;
        private MetroFramework.Controls.MetroTile tile_Avanzamento;
        private MetroFramework.Controls.MetroTile tile_FW_R;
        private MetroFramework.Controls.MetroTile tile_FW_P;
        private System.Windows.Forms.TableLayoutPanel layout_orizz_menu;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
        private MetroFramework.Controls.MetroTile tile_ReportProdotti;
        private MetroFramework.Controls.MetroTile tile_Schede;
    }
}

