﻿namespace SmartLineProduction
{
    partial class UC_Implosion
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.sFDistinteBasiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_DistinteBasiTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_DistinteBasiTableAdapter();
            this.gv_Implosion = new MetroFramework.Controls.MetroGrid();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.copytoclipboard = new MetroFramework.Controls.MetroContextMenu(this.components);
            this.copiaIlValoreNellaClipboardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gv_Implosion_Padre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.progrComponenteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.articoloComponenteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataInizioValiditaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataFineValiditaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantitaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Implosion_Descrizione = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descrizioneEstesaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.modelloDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFDistinteBasiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Implosion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.copytoclipboard.SuspendLayout();
            this.SuspendLayout();
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sFDistinteBasiBindingSource
            // 
            this.sFDistinteBasiBindingSource.DataMember = "SF_DistinteBasi";
            this.sFDistinteBasiBindingSource.DataSource = this.ds_SL;
            this.sFDistinteBasiBindingSource.Filter = "";
            this.sFDistinteBasiBindingSource.Sort = "ArticoloComposto asc";
            // 
            // sF_DistinteBasiTableAdapter
            // 
            this.sF_DistinteBasiTableAdapter.ClearBeforeFill = true;
            // 
            // gv_Implosion
            // 
            this.gv_Implosion.AllowUserToAddRows = false;
            this.gv_Implosion.AllowUserToDeleteRows = false;
            this.gv_Implosion.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_Implosion.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.gv_Implosion.AutoGenerateColumns = false;
            this.gv_Implosion.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Implosion.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Implosion.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_Implosion.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Implosion.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gv_Implosion.ColumnHeadersHeight = 40;
            this.gv_Implosion.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gv_Implosion_Padre,
            this.progrComponenteDataGridViewTextBoxColumn,
            this.articoloComponenteDataGridViewTextBoxColumn,
            this.dataInizioValiditaDataGridViewTextBoxColumn,
            this.dataFineValiditaDataGridViewTextBoxColumn,
            this.quantitaDataGridViewTextBoxColumn,
            this.gv_Implosion_Descrizione,
            this.descrizioneEstesaDataGridViewTextBoxColumn,
            this.modelloDataGridViewTextBoxColumn});
            this.gv_Implosion.ContextMenuStrip = this.copytoclipboard;
            this.gv_Implosion.DataSource = this.sFDistinteBasiBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Implosion.DefaultCellStyle = dataGridViewCellStyle3;
            this.gv_Implosion.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Implosion.EnableHeadersVisualStyles = false;
            this.gv_Implosion.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Implosion.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Implosion.Location = new System.Drawing.Point(20, 60);
            this.gv_Implosion.MultiSelect = false;
            this.gv_Implosion.Name = "gv_Implosion";
            this.gv_Implosion.ReadOnly = true;
            this.gv_Implosion.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Implosion.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.gv_Implosion.RowHeadersVisible = false;
            this.gv_Implosion.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Implosion.RowTemplate.Height = 30;
            this.gv_Implosion.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Implosion.Size = new System.Drawing.Size(460, 460);
            this.gv_Implosion.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_Implosion.TabIndex = 1;
            this.gv_Implosion.UseStyleColors = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::SmartLineProduction.Properties.Resources.NoImplosione;
            this.pictureBox1.Location = new System.Drawing.Point(20, 60);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(460, 460);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // copytoclipboard
            // 
            this.copytoclipboard.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copiaIlValoreNellaClipboardToolStripMenuItem});
            this.copytoclipboard.Name = "copytoclipboard";
            this.copytoclipboard.Size = new System.Drawing.Size(231, 26);
            // 
            // copiaIlValoreNellaClipboardToolStripMenuItem
            // 
            this.copiaIlValoreNellaClipboardToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.copiaIlValoreNellaClipboardToolStripMenuItem.Name = "copiaIlValoreNellaClipboardToolStripMenuItem";
            this.copiaIlValoreNellaClipboardToolStripMenuItem.Size = new System.Drawing.Size(230, 22);
            this.copiaIlValoreNellaClipboardToolStripMenuItem.Text = "Copia il valore nella clipboard";
            this.copiaIlValoreNellaClipboardToolStripMenuItem.Click += new System.EventHandler(this.copiaIlValoreNellaClipboardToolStripMenuItem_Click);
            // 
            // gv_Implosion_Padre
            // 
            this.gv_Implosion_Padre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Implosion_Padre.DataPropertyName = "ArticoloComposto";
            this.gv_Implosion_Padre.HeaderText = "Articolo Padre";
            this.gv_Implosion_Padre.Name = "gv_Implosion_Padre";
            this.gv_Implosion_Padre.ReadOnly = true;
            this.gv_Implosion_Padre.Width = 94;
            // 
            // progrComponenteDataGridViewTextBoxColumn
            // 
            this.progrComponenteDataGridViewTextBoxColumn.DataPropertyName = "ProgrComponente";
            this.progrComponenteDataGridViewTextBoxColumn.HeaderText = "ProgrComponente";
            this.progrComponenteDataGridViewTextBoxColumn.Name = "progrComponenteDataGridViewTextBoxColumn";
            this.progrComponenteDataGridViewTextBoxColumn.ReadOnly = true;
            this.progrComponenteDataGridViewTextBoxColumn.Visible = false;
            // 
            // articoloComponenteDataGridViewTextBoxColumn
            // 
            this.articoloComponenteDataGridViewTextBoxColumn.DataPropertyName = "ArticoloComponente";
            this.articoloComponenteDataGridViewTextBoxColumn.HeaderText = "ArticoloComponente";
            this.articoloComponenteDataGridViewTextBoxColumn.Name = "articoloComponenteDataGridViewTextBoxColumn";
            this.articoloComponenteDataGridViewTextBoxColumn.ReadOnly = true;
            this.articoloComponenteDataGridViewTextBoxColumn.Visible = false;
            // 
            // dataInizioValiditaDataGridViewTextBoxColumn
            // 
            this.dataInizioValiditaDataGridViewTextBoxColumn.DataPropertyName = "DataInizioValidita";
            this.dataInizioValiditaDataGridViewTextBoxColumn.HeaderText = "DataInizioValidita";
            this.dataInizioValiditaDataGridViewTextBoxColumn.Name = "dataInizioValiditaDataGridViewTextBoxColumn";
            this.dataInizioValiditaDataGridViewTextBoxColumn.ReadOnly = true;
            this.dataInizioValiditaDataGridViewTextBoxColumn.Visible = false;
            // 
            // dataFineValiditaDataGridViewTextBoxColumn
            // 
            this.dataFineValiditaDataGridViewTextBoxColumn.DataPropertyName = "DataFineValidita";
            this.dataFineValiditaDataGridViewTextBoxColumn.HeaderText = "DataFineValidita";
            this.dataFineValiditaDataGridViewTextBoxColumn.Name = "dataFineValiditaDataGridViewTextBoxColumn";
            this.dataFineValiditaDataGridViewTextBoxColumn.ReadOnly = true;
            this.dataFineValiditaDataGridViewTextBoxColumn.Visible = false;
            // 
            // quantitaDataGridViewTextBoxColumn
            // 
            this.quantitaDataGridViewTextBoxColumn.DataPropertyName = "Quantita";
            this.quantitaDataGridViewTextBoxColumn.HeaderText = "Quantita";
            this.quantitaDataGridViewTextBoxColumn.Name = "quantitaDataGridViewTextBoxColumn";
            this.quantitaDataGridViewTextBoxColumn.ReadOnly = true;
            this.quantitaDataGridViewTextBoxColumn.Visible = false;
            // 
            // gv_Implosion_Descrizione
            // 
            this.gv_Implosion_Descrizione.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_Implosion_Descrizione.DataPropertyName = "Descrizione";
            this.gv_Implosion_Descrizione.HeaderText = "Descrizione";
            this.gv_Implosion_Descrizione.Name = "gv_Implosion_Descrizione";
            this.gv_Implosion_Descrizione.ReadOnly = true;
            // 
            // descrizioneEstesaDataGridViewTextBoxColumn
            // 
            this.descrizioneEstesaDataGridViewTextBoxColumn.DataPropertyName = "DescrizioneEstesa";
            this.descrizioneEstesaDataGridViewTextBoxColumn.HeaderText = "DescrizioneEstesa";
            this.descrizioneEstesaDataGridViewTextBoxColumn.Name = "descrizioneEstesaDataGridViewTextBoxColumn";
            this.descrizioneEstesaDataGridViewTextBoxColumn.ReadOnly = true;
            this.descrizioneEstesaDataGridViewTextBoxColumn.Visible = false;
            // 
            // modelloDataGridViewTextBoxColumn
            // 
            this.modelloDataGridViewTextBoxColumn.DataPropertyName = "Modello";
            this.modelloDataGridViewTextBoxColumn.HeaderText = "Modello";
            this.modelloDataGridViewTextBoxColumn.Name = "modelloDataGridViewTextBoxColumn";
            this.modelloDataGridViewTextBoxColumn.ReadOnly = true;
            this.modelloDataGridViewTextBoxColumn.Visible = false;
            // 
            // UC_Implosion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 540);
            this.Controls.Add(this.gv_Implosion);
            this.Controls.Add(this.pictureBox1);
            this.Name = "UC_Implosion";
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "Implosione per: ";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.UC_Implosion_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFDistinteBasiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Implosion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.copytoclipboard.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private ds_SL ds_SL;
        private System.Windows.Forms.BindingSource sFDistinteBasiBindingSource;
        private ds_SLTableAdapters.SF_DistinteBasiTableAdapter sF_DistinteBasiTableAdapter;
        private MetroFramework.Controls.MetroGrid gv_Implosion;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MetroFramework.Controls.MetroContextMenu copytoclipboard;
        private System.Windows.Forms.ToolStripMenuItem copiaIlValoreNellaClipboardToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Implosion_Padre;
        private System.Windows.Forms.DataGridViewTextBoxColumn progrComponenteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloComponenteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataInizioValiditaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataFineValiditaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantitaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Implosion_Descrizione;
        private System.Windows.Forms.DataGridViewTextBoxColumn descrizioneEstesaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn modelloDataGridViewTextBoxColumn;
    }
}
