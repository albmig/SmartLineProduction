﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;

namespace SmartLineProduction
{
    public partial class UC_Implosion : MetroFramework.Forms.MetroForm
    {
        string codarticolo = "";

        public UC_Implosion()
        {
            InitializeComponent();
        }

        private void UC_Implosion_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_DistinteBasi'. È possibile spostarla o rimuoverla se necessario.
            this.sF_DistinteBasiTableAdapter.Fill(this.ds_SL.SF_DistinteBasi);

            string filtro = "ArticoloComponente = " + "'" + codarticolo + "'";
            sFDistinteBasiBindingSource.Filter = filtro;
            if (sFDistinteBasiBindingSource.Count == 0)
            {
                gv_Implosion.Visible = false;
            }
        }

        internal void LoadArticolo(String codart)
        {
            codarticolo = codart;
            this.Text = this.Text + codarticolo;
        }

        private void copiaIlValoreNellaClipboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string codart = "";
            if (gv_Implosion.SelectedCells.Count > 0)
            {
                int selectedrowindex = gv_Implosion.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = gv_Implosion.Rows[selectedrowindex];
                codart = Convert.ToString(selectedRow.Cells["gv_Implosion_Padre"].Value);
            }
            Clipboard.SetDataObject(codart);
        }
    }
}
