﻿namespace SmartLineProduction
{
}


namespace SmartLineProduction
{


    partial class ds_SL
    {
    }
}
