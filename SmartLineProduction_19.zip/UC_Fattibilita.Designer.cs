﻿namespace SmartLineProduction
{
    partial class UC_Fattibilita
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Fattibilita));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.layout_orizz_menu = new System.Windows.Forms.TableLayoutPanel();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.panel_fattibilita = new MetroFramework.Controls.MetroPanel();
            this.layout_Schede = new System.Windows.Forms.TableLayoutPanel();
            this.panel_grid_Articoli = new MetroFramework.Controls.MetroPanel();
            this.gv_Articoli = new MetroFramework.Controls.MetroGrid();
            this.articoloDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descrizioneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descrizioneEstesaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.giacenzaAttualeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.disponibilitaFuturaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.impegnatoClientiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ordinatoFornitoriDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtaInProduzioneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.annoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.magazzinoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sFFattibileArticoloBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.panel_search = new MetroFramework.Controls.MetroPanel();
            this.tb_search = new MetroFramework.Controls.MetroTextBox();
            this.panel_des_art_Kit = new MetroFramework.Controls.MetroPanel();
            this.Des_2 = new MetroFramework.Controls.MetroLabel();
            this.lab_des1_articolo = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.panel_qta = new MetroFramework.Controls.MetroPanel();
            this.btn_Calcola = new MetroFramework.Controls.MetroButton();
            this.tb_qta = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.gv_Explode = new System.Windows.Forms.DataGridView();
            this.sFFattibileArticolodtTmpFattibileExplodeBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.sF_Fattibile_ArticoloTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_Fattibile_ArticoloTableAdapter();
            this.sFFattibileArticolodtTmpFattibileExplodeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sFFattibileDBlevel1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_Fattibile_DB_level_1TableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_Fattibile_DB_level_1TableAdapter();
            this.articoloListaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descrizioneDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descrizioneEstesaDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Magazzino = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.giacenzaAttualeDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.disponibilitaFuturaDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.impegnatoClientiDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ordinatoFornitoriDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtaInProduzioneDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.daEsplodereDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.layout_orizz_menu.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            this.panel_fattibilita.SuspendLayout();
            this.layout_Schede.SuspendLayout();
            this.panel_grid_Articoli.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Articoli)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFFattibileArticoloBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            this.panel_search.SuspendLayout();
            this.panel_des_art_Kit.SuspendLayout();
            this.panel_qta.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Explode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFFattibileArticolodtTmpFattibileExplodeBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFFattibileArticolodtTmpFattibileExplodeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFFattibileDBlevel1BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // layout_orizz_menu
            // 
            this.layout_orizz_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.ColumnCount = 10;
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_exit, 10, 0);
            this.layout_orizz_menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_orizz_menu.Location = new System.Drawing.Point(20, 30);
            this.layout_orizz_menu.Name = "layout_orizz_menu";
            this.layout_orizz_menu.RowCount = 1;
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_orizz_menu.Size = new System.Drawing.Size(960, 25);
            this.layout_orizz_menu.TabIndex = 125;
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Gainsboro;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(885, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(75, 24);
            this.pan_Menu_exit.TabIndex = 82;
            this.pan_Menu_exit.Text = "menuStrip1";
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            this.menu_sw_exit.Click += new System.EventHandler(this.menu_sw_exit_Click);
            // 
            // panel_fattibilita
            // 
            this.panel_fattibilita.Controls.Add(this.layout_Schede);
            this.panel_fattibilita.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_fattibilita.HorizontalScrollbarBarColor = true;
            this.panel_fattibilita.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_fattibilita.HorizontalScrollbarSize = 10;
            this.panel_fattibilita.Location = new System.Drawing.Point(20, 55);
            this.panel_fattibilita.Name = "panel_fattibilita";
            this.panel_fattibilita.Size = new System.Drawing.Size(960, 425);
            this.panel_fattibilita.TabIndex = 126;
            this.panel_fattibilita.VerticalScrollbarBarColor = true;
            this.panel_fattibilita.VerticalScrollbarHighlightOnWheel = false;
            this.panel_fattibilita.VerticalScrollbarSize = 10;
            // 
            // layout_Schede
            // 
            this.layout_Schede.ColumnCount = 3;
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.layout_Schede.Controls.Add(this.panel_grid_Articoli, 0, 0);
            this.layout_Schede.Controls.Add(this.panel_des_art_Kit, 1, 0);
            this.layout_Schede.Controls.Add(this.panel_qta, 1, 1);
            this.layout_Schede.Controls.Add(this.gv_Explode, 1, 2);
            this.layout_Schede.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Schede.Location = new System.Drawing.Point(0, 0);
            this.layout_Schede.Name = "layout_Schede";
            this.layout_Schede.RowCount = 3;
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_Schede.Size = new System.Drawing.Size(960, 425);
            this.layout_Schede.TabIndex = 123;
            // 
            // panel_grid_Articoli
            // 
            this.panel_grid_Articoli.Controls.Add(this.gv_Articoli);
            this.panel_grid_Articoli.Controls.Add(this.panel_search);
            this.panel_grid_Articoli.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_grid_Articoli.HorizontalScrollbarBarColor = true;
            this.panel_grid_Articoli.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_grid_Articoli.HorizontalScrollbarSize = 10;
            this.panel_grid_Articoli.Location = new System.Drawing.Point(3, 3);
            this.panel_grid_Articoli.Name = "panel_grid_Articoli";
            this.layout_Schede.SetRowSpan(this.panel_grid_Articoli, 3);
            this.panel_grid_Articoli.Size = new System.Drawing.Size(144, 419);
            this.panel_grid_Articoli.TabIndex = 83;
            this.panel_grid_Articoli.VerticalScrollbarBarColor = true;
            this.panel_grid_Articoli.VerticalScrollbarHighlightOnWheel = false;
            this.panel_grid_Articoli.VerticalScrollbarSize = 10;
            // 
            // gv_Articoli
            // 
            this.gv_Articoli.AllowUserToAddRows = false;
            this.gv_Articoli.AllowUserToDeleteRows = false;
            this.gv_Articoli.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_Articoli.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.gv_Articoli.AutoGenerateColumns = false;
            this.gv_Articoli.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Articoli.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Articoli.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_Articoli.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Articoli.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gv_Articoli.ColumnHeadersHeight = 40;
            this.gv_Articoli.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.articoloDataGridViewTextBoxColumn,
            this.descrizioneDataGridViewTextBoxColumn,
            this.descrizioneEstesaDataGridViewTextBoxColumn,
            this.giacenzaAttualeDataGridViewTextBoxColumn,
            this.disponibilitaFuturaDataGridViewTextBoxColumn,
            this.impegnatoClientiDataGridViewTextBoxColumn,
            this.ordinatoFornitoriDataGridViewTextBoxColumn,
            this.qtaInProduzioneDataGridViewTextBoxColumn,
            this.annoDataGridViewTextBoxColumn,
            this.magazzinoDataGridViewTextBoxColumn});
            this.gv_Articoli.DataSource = this.sFFattibileArticoloBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Articoli.DefaultCellStyle = dataGridViewCellStyle3;
            this.gv_Articoli.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Articoli.EnableHeadersVisualStyles = false;
            this.gv_Articoli.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Articoli.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Articoli.Location = new System.Drawing.Point(0, 30);
            this.gv_Articoli.MultiSelect = false;
            this.gv_Articoli.Name = "gv_Articoli";
            this.gv_Articoli.ReadOnly = true;
            this.gv_Articoli.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Articoli.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.gv_Articoli.RowHeadersVisible = false;
            this.gv_Articoli.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Articoli.RowTemplate.Height = 30;
            this.gv_Articoli.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Articoli.Size = new System.Drawing.Size(144, 389);
            this.gv_Articoli.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_Articoli.TabIndex = 0;
            this.gv_Articoli.UseStyleColors = true;
            // 
            // articoloDataGridViewTextBoxColumn
            // 
            this.articoloDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.articoloDataGridViewTextBoxColumn.DataPropertyName = "Articolo";
            this.articoloDataGridViewTextBoxColumn.HeaderText = "Articolo";
            this.articoloDataGridViewTextBoxColumn.Name = "articoloDataGridViewTextBoxColumn";
            this.articoloDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // descrizioneDataGridViewTextBoxColumn
            // 
            this.descrizioneDataGridViewTextBoxColumn.DataPropertyName = "Descrizione";
            this.descrizioneDataGridViewTextBoxColumn.HeaderText = "Descrizione";
            this.descrizioneDataGridViewTextBoxColumn.Name = "descrizioneDataGridViewTextBoxColumn";
            this.descrizioneDataGridViewTextBoxColumn.ReadOnly = true;
            this.descrizioneDataGridViewTextBoxColumn.Visible = false;
            // 
            // descrizioneEstesaDataGridViewTextBoxColumn
            // 
            this.descrizioneEstesaDataGridViewTextBoxColumn.DataPropertyName = "DescrizioneEstesa";
            this.descrizioneEstesaDataGridViewTextBoxColumn.HeaderText = "DescrizioneEstesa";
            this.descrizioneEstesaDataGridViewTextBoxColumn.Name = "descrizioneEstesaDataGridViewTextBoxColumn";
            this.descrizioneEstesaDataGridViewTextBoxColumn.ReadOnly = true;
            this.descrizioneEstesaDataGridViewTextBoxColumn.Visible = false;
            // 
            // giacenzaAttualeDataGridViewTextBoxColumn
            // 
            this.giacenzaAttualeDataGridViewTextBoxColumn.DataPropertyName = "GiacenzaAttuale";
            this.giacenzaAttualeDataGridViewTextBoxColumn.HeaderText = "GiacenzaAttuale";
            this.giacenzaAttualeDataGridViewTextBoxColumn.Name = "giacenzaAttualeDataGridViewTextBoxColumn";
            this.giacenzaAttualeDataGridViewTextBoxColumn.ReadOnly = true;
            this.giacenzaAttualeDataGridViewTextBoxColumn.Visible = false;
            // 
            // disponibilitaFuturaDataGridViewTextBoxColumn
            // 
            this.disponibilitaFuturaDataGridViewTextBoxColumn.DataPropertyName = "DisponibilitaFutura";
            this.disponibilitaFuturaDataGridViewTextBoxColumn.HeaderText = "DisponibilitaFutura";
            this.disponibilitaFuturaDataGridViewTextBoxColumn.Name = "disponibilitaFuturaDataGridViewTextBoxColumn";
            this.disponibilitaFuturaDataGridViewTextBoxColumn.ReadOnly = true;
            this.disponibilitaFuturaDataGridViewTextBoxColumn.Visible = false;
            // 
            // impegnatoClientiDataGridViewTextBoxColumn
            // 
            this.impegnatoClientiDataGridViewTextBoxColumn.DataPropertyName = "ImpegnatoClienti";
            this.impegnatoClientiDataGridViewTextBoxColumn.HeaderText = "ImpegnatoClienti";
            this.impegnatoClientiDataGridViewTextBoxColumn.Name = "impegnatoClientiDataGridViewTextBoxColumn";
            this.impegnatoClientiDataGridViewTextBoxColumn.ReadOnly = true;
            this.impegnatoClientiDataGridViewTextBoxColumn.Visible = false;
            // 
            // ordinatoFornitoriDataGridViewTextBoxColumn
            // 
            this.ordinatoFornitoriDataGridViewTextBoxColumn.DataPropertyName = "OrdinatoFornitori";
            this.ordinatoFornitoriDataGridViewTextBoxColumn.HeaderText = "OrdinatoFornitori";
            this.ordinatoFornitoriDataGridViewTextBoxColumn.Name = "ordinatoFornitoriDataGridViewTextBoxColumn";
            this.ordinatoFornitoriDataGridViewTextBoxColumn.ReadOnly = true;
            this.ordinatoFornitoriDataGridViewTextBoxColumn.Visible = false;
            // 
            // qtaInProduzioneDataGridViewTextBoxColumn
            // 
            this.qtaInProduzioneDataGridViewTextBoxColumn.DataPropertyName = "QtaInProduzione";
            this.qtaInProduzioneDataGridViewTextBoxColumn.HeaderText = "QtaInProduzione";
            this.qtaInProduzioneDataGridViewTextBoxColumn.Name = "qtaInProduzioneDataGridViewTextBoxColumn";
            this.qtaInProduzioneDataGridViewTextBoxColumn.ReadOnly = true;
            this.qtaInProduzioneDataGridViewTextBoxColumn.Visible = false;
            // 
            // annoDataGridViewTextBoxColumn
            // 
            this.annoDataGridViewTextBoxColumn.DataPropertyName = "Anno";
            this.annoDataGridViewTextBoxColumn.HeaderText = "Anno";
            this.annoDataGridViewTextBoxColumn.Name = "annoDataGridViewTextBoxColumn";
            this.annoDataGridViewTextBoxColumn.ReadOnly = true;
            this.annoDataGridViewTextBoxColumn.Visible = false;
            // 
            // magazzinoDataGridViewTextBoxColumn
            // 
            this.magazzinoDataGridViewTextBoxColumn.DataPropertyName = "Magazzino";
            this.magazzinoDataGridViewTextBoxColumn.HeaderText = "Magazzino";
            this.magazzinoDataGridViewTextBoxColumn.Name = "magazzinoDataGridViewTextBoxColumn";
            this.magazzinoDataGridViewTextBoxColumn.ReadOnly = true;
            this.magazzinoDataGridViewTextBoxColumn.Visible = false;
            // 
            // sFFattibileArticoloBindingSource
            // 
            this.sFFattibileArticoloBindingSource.DataMember = "SF_Fattibile_Articolo";
            this.sFFattibileArticoloBindingSource.DataSource = this.ds_SL;
            this.sFFattibileArticoloBindingSource.Sort = "Articolo Asc";
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel_search
            // 
            this.panel_search.BackColor = System.Drawing.Color.Transparent;
            this.panel_search.Controls.Add(this.tb_search);
            this.panel_search.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_search.HorizontalScrollbarBarColor = true;
            this.panel_search.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_search.HorizontalScrollbarSize = 10;
            this.panel_search.Location = new System.Drawing.Point(0, 0);
            this.panel_search.Name = "panel_search";
            this.panel_search.Size = new System.Drawing.Size(144, 30);
            this.panel_search.TabIndex = 3;
            this.panel_search.UseCustomBackColor = true;
            this.panel_search.VerticalScrollbarBarColor = true;
            this.panel_search.VerticalScrollbarHighlightOnWheel = false;
            this.panel_search.VerticalScrollbarSize = 10;
            // 
            // tb_search
            // 
            this.tb_search.BackColor = System.Drawing.Color.LightYellow;
            // 
            // 
            // 
            this.tb_search.CustomButton.Image = null;
            this.tb_search.CustomButton.Location = new System.Drawing.Point(122, 1);
            this.tb_search.CustomButton.Name = "";
            this.tb_search.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_search.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_search.CustomButton.TabIndex = 1;
            this.tb_search.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_search.CustomButton.UseSelectable = true;
            this.tb_search.CustomButton.Visible = false;
            this.tb_search.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_search.Icon = global::SmartLineProduction.Properties.Resources.Lente;
            this.tb_search.IconRight = true;
            this.tb_search.Lines = new string[] {
        "metroTextBox1"};
            this.tb_search.Location = new System.Drawing.Point(0, 0);
            this.tb_search.MaxLength = 32767;
            this.tb_search.Name = "tb_search";
            this.tb_search.PasswordChar = '\0';
            this.tb_search.PromptText = "ricerca";
            this.tb_search.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_search.SelectedText = "";
            this.tb_search.SelectionLength = 0;
            this.tb_search.SelectionStart = 0;
            this.tb_search.ShortcutsEnabled = true;
            this.tb_search.Size = new System.Drawing.Size(144, 23);
            this.tb_search.TabIndex = 2;
            this.tb_search.Text = "metroTextBox1";
            this.tb_search.UseCustomBackColor = true;
            this.tb_search.UseSelectable = true;
            this.tb_search.WaterMark = "ricerca";
            this.tb_search.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_search.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tb_search.TextChanged += new System.EventHandler(this.tb_search_TextChanged);
            // 
            // panel_des_art_Kit
            // 
            this.layout_Schede.SetColumnSpan(this.panel_des_art_Kit, 2);
            this.panel_des_art_Kit.Controls.Add(this.Des_2);
            this.panel_des_art_Kit.Controls.Add(this.lab_des1_articolo);
            this.panel_des_art_Kit.Controls.Add(this.metroLabel1);
            this.panel_des_art_Kit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_des_art_Kit.HorizontalScrollbarBarColor = true;
            this.panel_des_art_Kit.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Kit.HorizontalScrollbarSize = 10;
            this.panel_des_art_Kit.Location = new System.Drawing.Point(153, 3);
            this.panel_des_art_Kit.Name = "panel_des_art_Kit";
            this.panel_des_art_Kit.Size = new System.Drawing.Size(804, 44);
            this.panel_des_art_Kit.TabIndex = 1;
            this.panel_des_art_Kit.VerticalScrollbarBarColor = true;
            this.panel_des_art_Kit.VerticalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Kit.VerticalScrollbarSize = 10;
            // 
            // Des_2
            // 
            this.Des_2.AutoSize = true;
            this.Des_2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFFattibileArticoloBindingSource, "DescrizioneEstesa", true));
            this.Des_2.Location = new System.Drawing.Point(124, 19);
            this.Des_2.Name = "Des_2";
            this.Des_2.Size = new System.Drawing.Size(41, 19);
            this.Des_2.Style = MetroFramework.MetroColorStyle.Red;
            this.Des_2.TabIndex = 4;
            this.Des_2.Text = "Des_1";
            this.Des_2.UseStyleColors = true;
            // 
            // lab_des1_articolo
            // 
            this.lab_des1_articolo.AutoSize = true;
            this.lab_des1_articolo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFFattibileArticoloBindingSource, "Descrizione", true));
            this.lab_des1_articolo.Location = new System.Drawing.Point(124, 0);
            this.lab_des1_articolo.Name = "lab_des1_articolo";
            this.lab_des1_articolo.Size = new System.Drawing.Size(41, 19);
            this.lab_des1_articolo.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_des1_articolo.TabIndex = 3;
            this.lab_des1_articolo.Text = "Des_1";
            this.lab_des1_articolo.UseStyleColors = true;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(3, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(75, 19);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "Descrizione";
            // 
            // panel_qta
            // 
            this.panel_qta.Controls.Add(this.btn_Calcola);
            this.panel_qta.Controls.Add(this.tb_qta);
            this.panel_qta.Controls.Add(this.metroLabel2);
            this.panel_qta.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_qta.HorizontalScrollbarBarColor = true;
            this.panel_qta.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_qta.HorizontalScrollbarSize = 10;
            this.panel_qta.Location = new System.Drawing.Point(153, 53);
            this.panel_qta.Name = "panel_qta";
            this.panel_qta.Size = new System.Drawing.Size(399, 25);
            this.panel_qta.TabIndex = 84;
            this.panel_qta.VerticalScrollbarBarColor = true;
            this.panel_qta.VerticalScrollbarHighlightOnWheel = false;
            this.panel_qta.VerticalScrollbarSize = 10;
            // 
            // btn_Calcola
            // 
            this.btn_Calcola.Location = new System.Drawing.Point(205, 0);
            this.btn_Calcola.Name = "btn_Calcola";
            this.btn_Calcola.Size = new System.Drawing.Size(75, 23);
            this.btn_Calcola.TabIndex = 5;
            this.btn_Calcola.Text = "Calcola";
            this.btn_Calcola.UseSelectable = true;
            this.btn_Calcola.Click += new System.EventHandler(this.btn_Calcola_Click);
            // 
            // tb_qta
            // 
            // 
            // 
            // 
            this.tb_qta.CustomButton.Image = null;
            this.tb_qta.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.tb_qta.CustomButton.Name = "";
            this.tb_qta.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_qta.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_qta.CustomButton.TabIndex = 1;
            this.tb_qta.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_qta.CustomButton.UseSelectable = true;
            this.tb_qta.CustomButton.Visible = false;
            this.tb_qta.Lines = new string[] {
        "tb_qta"};
            this.tb_qta.Location = new System.Drawing.Point(124, 0);
            this.tb_qta.MaxLength = 32767;
            this.tb_qta.Name = "tb_qta";
            this.tb_qta.PasswordChar = '\0';
            this.tb_qta.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_qta.SelectedText = "";
            this.tb_qta.SelectionLength = 0;
            this.tb_qta.SelectionStart = 0;
            this.tb_qta.ShortcutsEnabled = true;
            this.tb_qta.Size = new System.Drawing.Size(75, 23);
            this.tb_qta.TabIndex = 4;
            this.tb_qta.Text = "tb_qta";
            this.tb_qta.UseSelectable = true;
            this.tb_qta.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_qta.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(3, 0);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(112, 19);
            this.metroLabel2.TabIndex = 3;
            this.metroLabel2.Text = "Q.tà da realizzare";
            // 
            // gv_Explode
            // 
            this.gv_Explode.AllowUserToAddRows = false;
            this.gv_Explode.AllowUserToDeleteRows = false;
            this.gv_Explode.AutoGenerateColumns = false;
            this.gv_Explode.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gv_Explode.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.articoloListaDataGridViewTextBoxColumn,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.descrizioneDataGridViewTextBoxColumn1,
            this.descrizioneEstesaDataGridViewTextBoxColumn1,
            this.Magazzino,
            this.giacenzaAttualeDataGridViewTextBoxColumn1,
            this.disponibilitaFuturaDataGridViewTextBoxColumn1,
            this.impegnatoClientiDataGridViewTextBoxColumn1,
            this.ordinatoFornitoriDataGridViewTextBoxColumn1,
            this.qtaInProduzioneDataGridViewTextBoxColumn1,
            this.daEsplodereDataGridViewTextBoxColumn});
            this.layout_Schede.SetColumnSpan(this.gv_Explode, 2);
            this.gv_Explode.DataSource = this.sFFattibileArticolodtTmpFattibileExplodeBindingSource1;
            this.gv_Explode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Explode.Location = new System.Drawing.Point(153, 84);
            this.gv_Explode.Name = "gv_Explode";
            this.gv_Explode.ReadOnly = true;
            this.gv_Explode.RowHeadersVisible = false;
            this.gv_Explode.Size = new System.Drawing.Size(804, 338);
            this.gv_Explode.TabIndex = 85;
            this.gv_Explode.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gv_Explode_CellContentClick);
            // 
            // sFFattibileArticolodtTmpFattibileExplodeBindingSource1
            // 
            this.sFFattibileArticolodtTmpFattibileExplodeBindingSource1.DataMember = "SF_Fattibile_Articolo_dt_Tmp_Fattibile_Explode";
            this.sFFattibileArticolodtTmpFattibileExplodeBindingSource1.DataSource = this.sFFattibileArticoloBindingSource;
            // 
            // sF_Fattibile_ArticoloTableAdapter
            // 
            this.sF_Fattibile_ArticoloTableAdapter.ClearBeforeFill = true;
            // 
            // sFFattibileArticolodtTmpFattibileExplodeBindingSource
            // 
            this.sFFattibileArticolodtTmpFattibileExplodeBindingSource.DataMember = "SF_Fattibile_Articolo_dt_Tmp_Fattibile_Explode";
            this.sFFattibileArticolodtTmpFattibileExplodeBindingSource.DataSource = this.sFFattibileArticoloBindingSource;
            // 
            // sFFattibileDBlevel1BindingSource
            // 
            this.sFFattibileDBlevel1BindingSource.DataMember = "SF_Fattibile_DB_level_1";
            this.sFFattibileDBlevel1BindingSource.DataSource = this.ds_SL;
            // 
            // sF_Fattibile_DB_level_1TableAdapter
            // 
            this.sF_Fattibile_DB_level_1TableAdapter.ClearBeforeFill = true;
            // 
            // articoloListaDataGridViewTextBoxColumn
            // 
            this.articoloListaDataGridViewTextBoxColumn.DataPropertyName = "ArticoloLista";
            this.articoloListaDataGridViewTextBoxColumn.HeaderText = "ArticoloLista";
            this.articoloListaDataGridViewTextBoxColumn.Name = "articoloListaDataGridViewTextBoxColumn";
            this.articoloListaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ArticoloComposto";
            this.dataGridViewTextBoxColumn1.HeaderText = "ArticoloComposto";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "ArticoloComponente";
            this.dataGridViewTextBoxColumn2.HeaderText = "ArticoloComponente";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // descrizioneDataGridViewTextBoxColumn1
            // 
            this.descrizioneDataGridViewTextBoxColumn1.DataPropertyName = "Descrizione";
            this.descrizioneDataGridViewTextBoxColumn1.HeaderText = "Descrizione";
            this.descrizioneDataGridViewTextBoxColumn1.Name = "descrizioneDataGridViewTextBoxColumn1";
            this.descrizioneDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // descrizioneEstesaDataGridViewTextBoxColumn1
            // 
            this.descrizioneEstesaDataGridViewTextBoxColumn1.DataPropertyName = "DescrizioneEstesa";
            this.descrizioneEstesaDataGridViewTextBoxColumn1.HeaderText = "DescrizioneEstesa";
            this.descrizioneEstesaDataGridViewTextBoxColumn1.Name = "descrizioneEstesaDataGridViewTextBoxColumn1";
            this.descrizioneEstesaDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // Magazzino
            // 
            this.Magazzino.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Magazzino.DataPropertyName = "Magazzino";
            this.Magazzino.HeaderText = "Magazzino";
            this.Magazzino.Name = "Magazzino";
            this.Magazzino.ReadOnly = true;
            // 
            // giacenzaAttualeDataGridViewTextBoxColumn1
            // 
            this.giacenzaAttualeDataGridViewTextBoxColumn1.DataPropertyName = "GiacenzaAttuale";
            this.giacenzaAttualeDataGridViewTextBoxColumn1.HeaderText = "GiacenzaAttuale";
            this.giacenzaAttualeDataGridViewTextBoxColumn1.Name = "giacenzaAttualeDataGridViewTextBoxColumn1";
            this.giacenzaAttualeDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // disponibilitaFuturaDataGridViewTextBoxColumn1
            // 
            this.disponibilitaFuturaDataGridViewTextBoxColumn1.DataPropertyName = "DisponibilitaFutura";
            this.disponibilitaFuturaDataGridViewTextBoxColumn1.HeaderText = "DisponibilitaFutura";
            this.disponibilitaFuturaDataGridViewTextBoxColumn1.Name = "disponibilitaFuturaDataGridViewTextBoxColumn1";
            this.disponibilitaFuturaDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // impegnatoClientiDataGridViewTextBoxColumn1
            // 
            this.impegnatoClientiDataGridViewTextBoxColumn1.DataPropertyName = "ImpegnatoClienti";
            this.impegnatoClientiDataGridViewTextBoxColumn1.HeaderText = "ImpegnatoClienti";
            this.impegnatoClientiDataGridViewTextBoxColumn1.Name = "impegnatoClientiDataGridViewTextBoxColumn1";
            this.impegnatoClientiDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // ordinatoFornitoriDataGridViewTextBoxColumn1
            // 
            this.ordinatoFornitoriDataGridViewTextBoxColumn1.DataPropertyName = "OrdinatoFornitori";
            this.ordinatoFornitoriDataGridViewTextBoxColumn1.HeaderText = "OrdinatoFornitori";
            this.ordinatoFornitoriDataGridViewTextBoxColumn1.Name = "ordinatoFornitoriDataGridViewTextBoxColumn1";
            this.ordinatoFornitoriDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // qtaInProduzioneDataGridViewTextBoxColumn1
            // 
            this.qtaInProduzioneDataGridViewTextBoxColumn1.DataPropertyName = "QtaInProduzione";
            this.qtaInProduzioneDataGridViewTextBoxColumn1.HeaderText = "QtaInProduzione";
            this.qtaInProduzioneDataGridViewTextBoxColumn1.Name = "qtaInProduzioneDataGridViewTextBoxColumn1";
            this.qtaInProduzioneDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // daEsplodereDataGridViewTextBoxColumn
            // 
            this.daEsplodereDataGridViewTextBoxColumn.DataPropertyName = "DaEsplodere";
            this.daEsplodereDataGridViewTextBoxColumn.HeaderText = "DaEsplodere";
            this.daEsplodereDataGridViewTextBoxColumn.Name = "daEsplodereDataGridViewTextBoxColumn";
            this.daEsplodereDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // UC_Fattibilita
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 500);
            this.ControlBox = false;
            this.Controls.Add(this.panel_fattibilita);
            this.Controls.Add(this.layout_orizz_menu);
            this.DisplayHeader = false;
            this.Name = "UC_Fattibilita";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UC_Fattibilita_Load);
            this.layout_orizz_menu.ResumeLayout(false);
            this.layout_orizz_menu.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            this.panel_fattibilita.ResumeLayout(false);
            this.layout_Schede.ResumeLayout(false);
            this.panel_grid_Articoli.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_Articoli)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFFattibileArticoloBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            this.panel_search.ResumeLayout(false);
            this.panel_des_art_Kit.ResumeLayout(false);
            this.panel_des_art_Kit.PerformLayout();
            this.panel_qta.ResumeLayout(false);
            this.panel_qta.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Explode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFFattibileArticolodtTmpFattibileExplodeBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFFattibileArticolodtTmpFattibileExplodeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFFattibileDBlevel1BindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel layout_orizz_menu;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
        private MetroFramework.Controls.MetroPanel panel_fattibilita;
        private System.Windows.Forms.TableLayoutPanel layout_Schede;
        private MetroFramework.Controls.MetroPanel panel_grid_Articoli;
        private MetroFramework.Controls.MetroGrid gv_Articoli;
        private MetroFramework.Controls.MetroPanel panel_search;
        private MetroFramework.Controls.MetroTextBox tb_search;
        private MetroFramework.Controls.MetroPanel panel_des_art_Kit;
        private MetroFramework.Controls.MetroLabel lab_des1_articolo;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private ds_SL ds_SL;
        private System.Windows.Forms.BindingSource sFFattibileArticoloBindingSource;
        private ds_SLTableAdapters.SF_Fattibile_ArticoloTableAdapter sF_Fattibile_ArticoloTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descrizioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descrizioneEstesaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn giacenzaAttualeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn disponibilitaFuturaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn impegnatoClientiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ordinatoFornitoriDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtaInProduzioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn annoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn magazzinoDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroLabel Des_2;
        private MetroFramework.Controls.MetroPanel panel_qta;
        private MetroFramework.Controls.MetroTextBox tb_qta;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroButton btn_Calcola;
        private System.Windows.Forms.DataGridView gv_Explode;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloCompostoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloComponenteDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource sFFattibileArticolodtTmpFattibileExplodeBindingSource;
        private System.Windows.Forms.BindingSource sFFattibileDBlevel1BindingSource;
        private ds_SLTableAdapters.SF_Fattibile_DB_level_1TableAdapter sF_Fattibile_DB_level_1TableAdapter;
        private System.Windows.Forms.BindingSource sFFattibileArticolodtTmpFattibileExplodeBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloListaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn descrizioneDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn descrizioneEstesaDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Magazzino;
        private System.Windows.Forms.DataGridViewTextBoxColumn giacenzaAttualeDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn disponibilitaFuturaDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn impegnatoClientiDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ordinatoFornitoriDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtaInProduzioneDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn daEsplodereDataGridViewTextBoxColumn;
    }
}