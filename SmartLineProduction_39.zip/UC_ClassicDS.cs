﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using System.IO;
using System.Drawing.Imaging;

namespace SmartLineProduction
{
    public partial class UC_ClassicDS : MetroFramework.Forms.MetroForm
    {
        public static string qr_read_device = "";                               // la lettura "pura" del barcode
        public static string qr_sn = "";                                        // serial number del barcode (non ID Smartline)
        public static string qr_ID = "";                                        // lettura del barcode, può essere codice articolo (classic) o ID Smartline (smartline)
        public static string qr_fw = "";                                        // lettura del barcode
        public static string qr_ClassicSmart = "";                              // C Classic - S Smartline
        public static string path_classic = @"\\192.168.0.8\sistematica\AREA_PRODOTTO\CLASSICLINE\DATASHEET\";

        public UC_ClassicDS()
        {
            InitializeComponent();
        }

        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tbx_ReadLabel_Device_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if (e.KeyChar == '\t' || e.KeyChar == (char)13)
            //{
            //    e.Handled = true;
            //    qr_read_device = tbx_ReadLabel_Device.Text;
            //    AnalizzaQrDevice(qr_read_device);
            //    but_Reset.Focus();
            //}
        }

        private void tbx_ReadLabel_Device_Leave(object sender, EventArgs e)
        {
            //qr_read_device = tbx_ReadLabel_Device.Text;
            //if (AnalizzaQrDevice(qr_read_device))
            //{
            //    but_Reset.Focus();

            //    string filtro = "ArticoloComposto = " + "'" + qr_read_device + "'";
            //    sFDbarXSLVBindingSource.Filter = filtro;
            //    gv_result.Visible = true;

            //    if (sFDbarXSLVBindingSource.Count == 0)
            //    {
            //        pdf_viewer_xslv.LoadDocument(@"Resources\NO_XSLV.pdf");
            //    }

            //    //Carica Immagine
            //    string famdevice = qr_read_device.Substring(0, 3);
            //    if (famdevice == "XSB")
            //    {
            //        famdevice = qr_read_device.Substring(0, 5);
            //    }
            //    //Carica immagine scheda
            //    string sigla = qr_read_device.Substring(7, 2);
            //    string path_SL = WEB_path_image + famdevice + @"\" + sigla + @"\" + qr_read_device + @"\" + qr_read_device + "_Full.png";
            //    string path_CL = CLASSIC_path_image + @"\" + qr_read_device + ".jpg";
            //    string path_prodotto_SL = SMARTLINE_path_image + @"\" + qr_read_device + ".jpg";
            //    panel_device.Visible = true;

            //    if (File.Exists(path_SL))
            //    {
            //        Device_Image.Image = Image.FromFile(path_SL);
            //        Device_Image.Image.RotateFlip(Rotate(Image.FromFile(path_SL)));
            //    }
            //    else
            //    if (File.Exists(path_CL))
            //    {
            //        Device_Image.Image = Image.FromFile(path_CL);
            //        Device_Image.Image.RotateFlip(Rotate(Image.FromFile(path_CL)));

            //    }
            //    else
            //    if (File.Exists(path_prodotto_SL))
            //    {
            //        Device_Image.Image = Image.FromFile(path_prodotto_SL);
            //        Device_Image.Image.RotateFlip(Rotate(Image.FromFile(path_prodotto_SL)));
            //    }
            //    else
            //    {
            //        Device_Image.Image = Properties.Resources.ImageNotPresent;
            //    }
            //}
        }

        public static RotateFlipType Rotate(Image bmp)
        {
            const int OrientationId = 0x0112;
            PropertyItem pi = bmp.PropertyItems.Select(x => x)
                                        .FirstOrDefault(x => x.Id == OrientationId);
            if (pi == null)
                return RotateFlipType.RotateNoneFlipNone;

            byte o = pi.Value[0];

            //Orientations
            if (o == 2) //TopRight
                return RotateFlipType.RotateNoneFlipX;
            if (o == 3) //BottomRight
                return RotateFlipType.RotateNoneFlipXY;
            if (o == 4) //BottomLeft
                return RotateFlipType.RotateNoneFlipY;
            if (o == 5) //LeftTop
                return RotateFlipType.Rotate90FlipX;
            if (o == 6) //RightTop
                return RotateFlipType.Rotate90FlipNone;
            if (o == 7) //RightBottom
                return RotateFlipType.Rotate90FlipY;
            if (o == 8) //LeftBottom
                return RotateFlipType.Rotate90FlipXY;

            return RotateFlipType.RotateNoneFlipNone; //TopLeft (what the image looks by default) [or] Unknown
        }

        private bool AnalizzaQrDevice(string letturabarcode)
        {
            return true;
            //string[] codici = letturabarcode.Split('|');
            //int conta = 1;
            //foreach (var word in codici)
            //{
            //    switch (conta)
            //    {
            //        case 1: qr_sn = word; conta++; break;
            //        case 2: qr_ID = word; conta++; break;
            //        case 3: qr_fw = word; conta++; break;
            //    }
            //}

            //int lungSN = qr_sn.Length;
            //if (lungSN == 16)
            //{
            //    qr_ID = qr_sn; // aggiusto la situazione di confusione che si può creare...
            //    qr_sn = "";
            //    qr_ClassicSmart = "S";
            //}
            //else
            //{
            //    qr_ClassicSmart = "C";
            //}

            //this.Refresh();

            //return true;
        }

        private void UC_ClassicDS_Load(object sender, EventArgs e)
        {
            SettaForm();

            this.WindowState = FormWindowState.Maximized;

            tbx_ReadLabel_Device.Focus();

            UC_SyncroDS uC_SyncroDS = new UC_SyncroDS();
            uC_SyncroDS.Show();
            Cursor.Current = Cursors.Default;
        }

        private void SettaForm()
        {
            if (this.ActiveControl == null)
            {
                tbx_ReadLabel_Device.Focus();
            }
            tbx_ReadLabel_Device.Text = "";
            tbx_ReadLabel_Device.Focus();

            gv_result.Visible = false;
            panel_pdf_xslv.Visible = false;
        }

        private void but_AttivaProc_Click(object sender, EventArgs e)
        {
            SettaForm();

            pdf_viewer_xslv.CloseDocument();
            panel_device.Visible = false;
        }

        private void UC_ClassicDS_Shown(object sender, EventArgs e)
        {
            tbx_ReadLabel_Device.Focus();
        }

        private void aggiornaArchiviToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UC_SyncroDS uC_SyncroDS = new UC_SyncroDS();
            uC_SyncroDS.Show();
            Cursor.Current = Cursors.Default;
        }
    }
}
