﻿namespace SmartLineProduction
{
    partial class UC_ClassicDS
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_ClassicDS));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.layout_orizz_menu = new System.Windows.Forms.TableLayoutPanel();
            this.MainMenu = new System.Windows.Forms.MenuStrip();
            this.aggiornaArchiviToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.panel_SN = new MetroFramework.Controls.MetroPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel_input = new MetroFramework.Controls.MetroPanel();
            this.lab_Etichetta = new MetroFramework.Controls.MetroLabel();
            this.tbx_ReadLabel_Device = new MetroFramework.Controls.MetroTextBox();
            this.but_Reset = new MetroFramework.Controls.MetroButton();
            this.panel_pdf_xslv = new MetroFramework.Controls.MetroPanel();
            this.pdf_viewer_xslv = new DevExpress.XtraPdfViewer.PdfViewer();
            this.barManager1 = new DevExpress.XtraBars.BarManager(this.components);
            this.repositoryItemPageNumberEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemPageNumberEdit();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.panel_device = new MetroFramework.Controls.MetroPanel();
            this.Device_Image = new System.Windows.Forms.PictureBox();
            this.panel_result = new MetroFramework.Controls.MetroPanel();
            this.gv_result = new MetroFramework.Controls.MetroGrid();
            this.ArticoloComposto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ArticoloComponente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.layout_orizz_menu.SuspendLayout();
            this.MainMenu.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            this.panel_SN.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel_input.SuspendLayout();
            this.panel_pdf_xslv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPageNumberEdit1)).BeginInit();
            this.panel_device.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Device_Image)).BeginInit();
            this.panel_result.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_result)).BeginInit();
            this.SuspendLayout();
            // 
            // layout_orizz_menu
            // 
            this.layout_orizz_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.ColumnCount = 10;
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.Controls.Add(this.MainMenu, 0, 0);
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_exit, 10, 0);
            this.layout_orizz_menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_orizz_menu.Location = new System.Drawing.Point(20, 30);
            this.layout_orizz_menu.Name = "layout_orizz_menu";
            this.layout_orizz_menu.RowCount = 1;
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_orizz_menu.Size = new System.Drawing.Size(839, 25);
            this.layout_orizz_menu.TabIndex = 120;
            // 
            // MainMenu
            // 
            this.MainMenu.BackColor = System.Drawing.Color.Transparent;
            this.layout_orizz_menu.SetColumnSpan(this.MainMenu, 6);
            this.MainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aggiornaArchiviToolStripMenuItem});
            this.MainMenu.Location = new System.Drawing.Point(0, 0);
            this.MainMenu.Name = "MainMenu";
            this.MainMenu.Size = new System.Drawing.Size(498, 24);
            this.MainMenu.TabIndex = 83;
            this.MainMenu.Text = "menuStrip1";
            // 
            // aggiornaArchiviToolStripMenuItem
            // 
            this.aggiornaArchiviToolStripMenuItem.Name = "aggiornaArchiviToolStripMenuItem";
            this.aggiornaArchiviToolStripMenuItem.Size = new System.Drawing.Size(133, 20);
            this.aggiornaArchiviToolStripMenuItem.Text = "Sincronizza Datasheet";
            this.aggiornaArchiviToolStripMenuItem.Click += new System.EventHandler(this.aggiornaArchiviToolStripMenuItem_Click);
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Gainsboro;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(764, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(75, 24);
            this.pan_Menu_exit.TabIndex = 82;
            this.pan_Menu_exit.Text = "menuStrip1";
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            this.menu_sw_exit.Click += new System.EventHandler(this.menu_sw_exit_Click);
            // 
            // panel_SN
            // 
            this.panel_SN.Controls.Add(this.tableLayoutPanel1);
            this.panel_SN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_SN.HorizontalScrollbarBarColor = true;
            this.panel_SN.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_SN.HorizontalScrollbarSize = 10;
            this.panel_SN.Location = new System.Drawing.Point(20, 55);
            this.panel_SN.Name = "panel_SN";
            this.panel_SN.Size = new System.Drawing.Size(839, 657);
            this.panel_SN.TabIndex = 0;
            this.panel_SN.VerticalScrollbarBarColor = true;
            this.panel_SN.VerticalScrollbarHighlightOnWheel = false;
            this.panel_SN.VerticalScrollbarSize = 10;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.panel_input, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel_pdf_xslv, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel_device, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel_result, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(839, 657);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // panel_input
            // 
            this.panel_input.Controls.Add(this.lab_Etichetta);
            this.panel_input.Controls.Add(this.tbx_ReadLabel_Device);
            this.panel_input.Controls.Add(this.but_Reset);
            this.panel_input.HorizontalScrollbarBarColor = true;
            this.panel_input.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_input.HorizontalScrollbarSize = 10;
            this.panel_input.Location = new System.Drawing.Point(3, 3);
            this.panel_input.Name = "panel_input";
            this.panel_input.Size = new System.Drawing.Size(400, 60);
            this.panel_input.TabIndex = 3;
            this.panel_input.VerticalScrollbarBarColor = true;
            this.panel_input.VerticalScrollbarHighlightOnWheel = false;
            this.panel_input.VerticalScrollbarSize = 10;
            // 
            // lab_Etichetta
            // 
            this.lab_Etichetta.AutoSize = true;
            this.lab_Etichetta.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_Etichetta.Location = new System.Drawing.Point(0, 0);
            this.lab_Etichetta.Name = "lab_Etichetta";
            this.lab_Etichetta.Size = new System.Drawing.Size(257, 19);
            this.lab_Etichetta.TabIndex = 0;
            this.lab_Etichetta.Text = "Lettura dell\'etichetta presente sul device:";
            // 
            // tbx_ReadLabel_Device
            // 
            // 
            // 
            // 
            this.tbx_ReadLabel_Device.CustomButton.Image = null;
            this.tbx_ReadLabel_Device.CustomButton.Location = new System.Drawing.Point(254, 1);
            this.tbx_ReadLabel_Device.CustomButton.Name = "";
            this.tbx_ReadLabel_Device.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tbx_ReadLabel_Device.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbx_ReadLabel_Device.CustomButton.TabIndex = 1;
            this.tbx_ReadLabel_Device.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbx_ReadLabel_Device.CustomButton.UseSelectable = true;
            this.tbx_ReadLabel_Device.CustomButton.Visible = false;
            this.tbx_ReadLabel_Device.Lines = new string[0];
            this.tbx_ReadLabel_Device.Location = new System.Drawing.Point(0, 26);
            this.tbx_ReadLabel_Device.MaxLength = 32767;
            this.tbx_ReadLabel_Device.Multiline = true;
            this.tbx_ReadLabel_Device.Name = "tbx_ReadLabel_Device";
            this.tbx_ReadLabel_Device.PasswordChar = '\0';
            this.tbx_ReadLabel_Device.PromptText = "Lettura del QR-Code";
            this.tbx_ReadLabel_Device.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbx_ReadLabel_Device.SelectedText = "";
            this.tbx_ReadLabel_Device.SelectionLength = 0;
            this.tbx_ReadLabel_Device.SelectionStart = 0;
            this.tbx_ReadLabel_Device.ShortcutsEnabled = true;
            this.tbx_ReadLabel_Device.Size = new System.Drawing.Size(276, 23);
            this.tbx_ReadLabel_Device.TabIndex = 0;
            this.tbx_ReadLabel_Device.UseSelectable = true;
            this.tbx_ReadLabel_Device.WaterMark = "Lettura del QR-Code";
            this.tbx_ReadLabel_Device.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tbx_ReadLabel_Device.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tbx_ReadLabel_Device.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbx_ReadLabel_Device_KeyPress);
            this.tbx_ReadLabel_Device.Leave += new System.EventHandler(this.tbx_ReadLabel_Device_Leave);
            // 
            // but_Reset
            // 
            this.but_Reset.BackColor = System.Drawing.Color.White;
            this.but_Reset.Location = new System.Drawing.Point(282, 26);
            this.but_Reset.Name = "but_Reset";
            this.but_Reset.Size = new System.Drawing.Size(105, 23);
            this.but_Reset.Style = MetroFramework.MetroColorStyle.Green;
            this.but_Reset.TabIndex = 1;
            this.but_Reset.Text = "Reset";
            this.but_Reset.UseSelectable = true;
            this.but_Reset.UseStyleColors = true;
            this.but_Reset.Click += new System.EventHandler(this.but_AttivaProc_Click);
            // 
            // panel_pdf_xslv
            // 
            this.panel_pdf_xslv.Controls.Add(this.pdf_viewer_xslv);
            this.panel_pdf_xslv.Controls.Add(this.barDockControlLeft);
            this.panel_pdf_xslv.Controls.Add(this.barDockControlRight);
            this.panel_pdf_xslv.Controls.Add(this.barDockControlBottom);
            this.panel_pdf_xslv.Controls.Add(this.barDockControlTop);
            this.panel_pdf_xslv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_pdf_xslv.HorizontalScrollbarBarColor = true;
            this.panel_pdf_xslv.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_pdf_xslv.HorizontalScrollbarSize = 10;
            this.panel_pdf_xslv.Location = new System.Drawing.Point(409, 3);
            this.panel_pdf_xslv.Name = "panel_pdf_xslv";
            this.tableLayoutPanel1.SetRowSpan(this.panel_pdf_xslv, 3);
            this.panel_pdf_xslv.Size = new System.Drawing.Size(427, 672);
            this.panel_pdf_xslv.TabIndex = 4;
            this.panel_pdf_xslv.VerticalScrollbarBarColor = true;
            this.panel_pdf_xslv.VerticalScrollbarHighlightOnWheel = false;
            this.panel_pdf_xslv.VerticalScrollbarSize = 10;
            // 
            // pdf_viewer_xslv
            // 
            this.pdf_viewer_xslv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pdf_viewer_xslv.Location = new System.Drawing.Point(0, 0);
            this.pdf_viewer_xslv.MenuManager = this.barManager1;
            this.pdf_viewer_xslv.Name = "pdf_viewer_xslv";
            this.pdf_viewer_xslv.NavigationPaneInitialVisibility = DevExpress.XtraPdfViewer.PdfNavigationPaneVisibility.Hidden;
            this.pdf_viewer_xslv.Size = new System.Drawing.Size(427, 672);
            this.pdf_viewer_xslv.TabIndex = 2;
            this.pdf_viewer_xslv.ZoomMode = DevExpress.XtraPdfViewer.PdfZoomMode.PageLevel;
            // 
            // barManager1
            // 
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this.panel_pdf_xslv;
            this.barManager1.MaxItemId = 24;
            this.barManager1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemPageNumberEdit1});
            // 
            // repositoryItemPageNumberEdit1
            // 
            this.repositoryItemPageNumberEdit1.AutoHeight = false;
            this.repositoryItemPageNumberEdit1.Mask.EditMask = "########;";
            this.repositoryItemPageNumberEdit1.Name = "repositoryItemPageNumberEdit1";
            this.repositoryItemPageNumberEdit1.Orientation = DevExpress.XtraEditors.PagerOrientation.Horizontal;
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Manager = this.barManager1;
            this.barDockControlTop.Size = new System.Drawing.Size(427, 0);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 672);
            this.barDockControlBottom.Manager = this.barManager1;
            this.barDockControlBottom.Size = new System.Drawing.Size(427, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 0);
            this.barDockControlLeft.Manager = this.barManager1;
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 672);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(427, 0);
            this.barDockControlRight.Manager = this.barManager1;
            this.barDockControlRight.Size = new System.Drawing.Size(0, 672);
            // 
            // panel_device
            // 
            this.panel_device.Controls.Add(this.Device_Image);
            this.panel_device.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_device.HorizontalScrollbarBarColor = true;
            this.panel_device.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_device.HorizontalScrollbarSize = 10;
            this.panel_device.Location = new System.Drawing.Point(3, 375);
            this.panel_device.Name = "panel_device";
            this.panel_device.Size = new System.Drawing.Size(400, 300);
            this.panel_device.TabIndex = 6;
            this.panel_device.VerticalScrollbarBarColor = true;
            this.panel_device.VerticalScrollbarHighlightOnWheel = false;
            this.panel_device.VerticalScrollbarSize = 10;
            // 
            // Device_Image
            // 
            this.Device_Image.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Device_Image.ErrorImage = global::SmartLineProduction.Properties.Resources.ImageNotPresent;
            this.Device_Image.InitialImage = null;
            this.Device_Image.Location = new System.Drawing.Point(0, 0);
            this.Device_Image.Name = "Device_Image";
            this.Device_Image.Size = new System.Drawing.Size(400, 300);
            this.Device_Image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Device_Image.TabIndex = 2;
            this.Device_Image.TabStop = false;
            // 
            // panel_result
            // 
            this.panel_result.Controls.Add(this.gv_result);
            this.panel_result.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_result.HorizontalScrollbarBarColor = true;
            this.panel_result.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_result.HorizontalScrollbarSize = 10;
            this.panel_result.Location = new System.Drawing.Point(3, 69);
            this.panel_result.Name = "panel_result";
            this.panel_result.Size = new System.Drawing.Size(400, 300);
            this.panel_result.TabIndex = 5;
            this.panel_result.VerticalScrollbarBarColor = true;
            this.panel_result.VerticalScrollbarHighlightOnWheel = false;
            this.panel_result.VerticalScrollbarSize = 10;
            // 
            // gv_result
            // 
            this.gv_result.AllowUserToAddRows = false;
            this.gv_result.AllowUserToDeleteRows = false;
            this.gv_result.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_result.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.gv_result.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_result.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_result.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_result.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_result.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gv_result.ColumnHeadersHeight = 40;
            this.gv_result.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ArticoloComposto,
            this.ArticoloComponente});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_result.DefaultCellStyle = dataGridViewCellStyle3;
            this.gv_result.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_result.EnableHeadersVisualStyles = false;
            this.gv_result.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_result.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_result.Location = new System.Drawing.Point(0, 0);
            this.gv_result.MultiSelect = false;
            this.gv_result.Name = "gv_result";
            this.gv_result.ReadOnly = true;
            this.gv_result.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_result.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.gv_result.RowHeadersVisible = false;
            this.gv_result.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_result.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Wheat;
            this.gv_result.RowTemplate.Height = 30;
            this.gv_result.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_result.Size = new System.Drawing.Size(400, 300);
            this.gv_result.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_result.TabIndex = 122;
            this.gv_result.UseStyleColors = true;
            this.gv_result.Visible = false;
            // 
            // ArticoloComposto
            // 
            this.ArticoloComposto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.ArticoloComposto.DataPropertyName = "ArticoloComposto";
            this.ArticoloComposto.HeaderText = "ArticoloComposto";
            this.ArticoloComposto.Name = "ArticoloComposto";
            this.ArticoloComposto.ReadOnly = true;
            this.ArticoloComposto.Visible = false;
            this.ArticoloComposto.Width = 123;
            // 
            // ArticoloComponente
            // 
            this.ArticoloComponente.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.ArticoloComponente.DataPropertyName = "ArticoloComponente";
            this.ArticoloComponente.HeaderText = "Codice Scheda";
            this.ArticoloComponente.Name = "ArticoloComponente";
            this.ArticoloComponente.ReadOnly = true;
            this.ArticoloComponente.Width = 96;
            // 
            // UC_ClassicDS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(879, 732);
            this.ControlBox = false;
            this.Controls.Add(this.panel_SN);
            this.Controls.Add(this.layout_orizz_menu);
            this.DisplayHeader = false;
            this.Name = "UC_ClassicDS";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UC_ClassicDS_Load);
            this.Shown += new System.EventHandler(this.UC_ClassicDS_Shown);
            this.layout_orizz_menu.ResumeLayout(false);
            this.layout_orizz_menu.PerformLayout();
            this.MainMenu.ResumeLayout(false);
            this.MainMenu.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            this.panel_SN.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel_input.ResumeLayout(false);
            this.panel_input.PerformLayout();
            this.panel_pdf_xslv.ResumeLayout(false);
            this.panel_pdf_xslv.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPageNumberEdit1)).EndInit();
            this.panel_device.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Device_Image)).EndInit();
            this.panel_result.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_result)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel layout_orizz_menu;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
        private MetroFramework.Controls.MetroPanel panel_SN;
        private MetroFramework.Controls.MetroLabel lab_Etichetta;
        private MetroFramework.Controls.MetroTextBox tbx_ReadLabel_Device;
        private MetroFramework.Controls.MetroButton but_Reset;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private MetroFramework.Controls.MetroPanel panel_input;
        private MetroFramework.Controls.MetroPanel panel_pdf_xslv;
        private DevExpress.XtraPdfViewer.PdfViewer pdf_viewer_xslv;
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraEditors.Repository.RepositoryItemPageNumberEdit repositoryItemPageNumberEdit1;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private MetroFramework.Controls.MetroPanel panel_result;
        private MetroFramework.Controls.MetroGrid gv_result;
        private MetroFramework.Controls.MetroPanel panel_device;
        private System.Windows.Forms.PictureBox Device_Image;
        private System.Windows.Forms.DataGridViewTextBoxColumn ArticoloComposto;
        private System.Windows.Forms.DataGridViewTextBoxColumn ArticoloComponente;
        private System.Windows.Forms.MenuStrip MainMenu;
        private System.Windows.Forms.ToolStripMenuItem aggiornaArchiviToolStripMenuItem;
    }
}
