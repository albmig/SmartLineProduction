﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;

namespace SmartLineProduction
{
    public partial class UC_Reprint_Label : MetroFramework.Forms.MetroForm
    {
        public string Answer { get { return cb_Correzione.Text; } }

        public UC_Reprint_Label(string correzione)
        {
            InitializeComponent();
            cb_Correzione.SelectedItem = correzione;
        }

        private void but_abort_UC_Reprint_Label_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void but_close_UC_Reprint_Label_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
