﻿namespace SmartLineProduction
{


    public partial class ds_Proj
    {
    }
}
namespace SmartLineProduction {
    
    
    public partial class ds_Proj {
    }
}
