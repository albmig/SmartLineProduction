﻿namespace SmartLineProduction
{
    partial class UC_Amm_AnalisiCosti
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Amm_AnalisiCosti));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.layout_orizz_menu = new System.Windows.Forms.TableLayoutPanel();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.gv_Venduto = new MetroFramework.Controls.MetroGrid();
            this.gv_Venduto_Cliente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Venduto_Articolo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Venduto_QtaTot = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Venduto_Prezzo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Venduto_TotRicavi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Venduto_TotCosti = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Venduto_CostoMat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Venduto_CostoProd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Venduto_CostoMan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Venduto_CostoLav = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.margineDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totFatturatoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Venduto_Margine = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.analisiCostiVendutoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.analisiCostiDistinteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.colQuantita = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colFlEsplodiSemilav = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colCosto_Materia_Prima = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colCosto_Uomo = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colCosto_Lav_Est = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colCosto_Unit = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colCosto_Tot = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colTipoProduzione = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colLvl_DB = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colNum_Art = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colNum_Exp = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colArticoloIniziale = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colElaborato = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListBand1 = new DevExpress.XtraTreeList.Columns.TreeListBand();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.analisi_Costi_VendutoTableAdapter = new SmartLineProduction.ds_SLTableAdapters.Analisi_Costi_VendutoTableAdapter();
            this.layout_filter = new System.Windows.Forms.TableLayoutPanel();
            this.btn_AzzeraFiltroArticoli = new MetroFramework.Controls.MetroButton();
            this.cb_elencoarticoli = new System.Windows.Forms.ComboBox();
            this.aCVClienteArticoloBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.cb_elencoClienti = new System.Windows.Forms.ComboBox();
            this.aCVClienteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btn_AzzeraFiltroClienti = new MetroFramework.Controls.MetroButton();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.lab_tot_ricavi = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.lab_tot_costi = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.lab_tot_diff = new MetroFramework.Controls.MetroLabel();
            this.aCV_Cliente = new SmartLineProduction.ds_SLTableAdapters.ACV_Cliente();
            this.aCV_ClienteArticolo = new SmartLineProduction.ds_SLTableAdapters.ACV_ClienteArticolo();
            this.clienteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Qta_Tot = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Prezzo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Costo_Materiali = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Costo_Manodopera = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Costo_Lav_Est = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Costo_Produzione = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Margine = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cliente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tree_Distinta = new DevExpress.XtraTreeList.TreeList();
            this.analisiCostiVendutoSFExplDistintaSaleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_Expl_Distinta_SaleTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_Expl_Distinta_SaleTableAdapter();
            this.colArticoloComposto = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colArticoloComponente = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colQuantita1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colCosto_Materia_Prima1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colCosto_Uomo1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colCosto_Lav_Est1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colArticoloIniziale1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colCalc_Costo_Tot_Unitario = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colCalc_Costo_Tot_Totale = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            this.layout_orizz_menu.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Venduto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analisiCostiVendutoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analisiCostiDistinteBindingSource)).BeginInit();
            this.toolStripContainer1.SuspendLayout();
            this.layout_filter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aCVClienteArticoloBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCVClienteBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tree_Distinta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analisiCostiVendutoSFExplDistintaSaleBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // layout_orizz_menu
            // 
            this.layout_orizz_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.ColumnCount = 10;
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_exit, 10, 0);
            this.layout_orizz_menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_orizz_menu.Location = new System.Drawing.Point(20, 30);
            this.layout_orizz_menu.Name = "layout_orizz_menu";
            this.layout_orizz_menu.RowCount = 1;
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_orizz_menu.Size = new System.Drawing.Size(839, 25);
            this.layout_orizz_menu.TabIndex = 120;
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Gainsboro;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(764, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(75, 24);
            this.pan_Menu_exit.TabIndex = 82;
            this.pan_Menu_exit.Text = "menuStrip1";
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            this.menu_sw_exit.Click += new System.EventHandler(this.menu_sw_exit_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.gv_Venduto, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tree_Distinta, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(20, 130);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(839, 850);
            this.tableLayoutPanel1.TabIndex = 121;
            // 
            // gv_Venduto
            // 
            this.gv_Venduto.AllowUserToAddRows = false;
            this.gv_Venduto.AllowUserToDeleteRows = false;
            this.gv_Venduto.AllowUserToResizeRows = false;
            this.gv_Venduto.AutoGenerateColumns = false;
            this.gv_Venduto.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Venduto.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Venduto.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_Venduto.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Venduto.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle25;
            this.gv_Venduto.ColumnHeadersHeight = 40;
            this.gv_Venduto.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gv_Venduto_Cliente,
            this.gv_Venduto_Articolo,
            this.gv_Venduto_QtaTot,
            this.gv_Venduto_Prezzo,
            this.gv_Venduto_TotRicavi,
            this.gv_Venduto_TotCosti,
            this.gv_Venduto_CostoMat,
            this.gv_Venduto_CostoProd,
            this.gv_Venduto_CostoMan,
            this.gv_Venduto_CostoLav,
            this.margineDataGridViewTextBoxColumn,
            this.totFatturatoDataGridViewTextBoxColumn,
            this.gv_Venduto_Margine});
            this.gv_Venduto.DataSource = this.analisiCostiVendutoBindingSource;
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle35.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle35.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Venduto.DefaultCellStyle = dataGridViewCellStyle35;
            this.gv_Venduto.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Venduto.EnableHeadersVisualStyles = false;
            this.gv_Venduto.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Venduto.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Venduto.Location = new System.Drawing.Point(3, 3);
            this.gv_Venduto.MultiSelect = false;
            this.gv_Venduto.Name = "gv_Venduto";
            this.gv_Venduto.ReadOnly = true;
            this.gv_Venduto.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle36.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle36.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle36.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Venduto.RowHeadersDefaultCellStyle = dataGridViewCellStyle36;
            this.gv_Venduto.RowHeadersVisible = false;
            this.gv_Venduto.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Venduto.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Wheat;
            this.gv_Venduto.RowTemplate.Height = 30;
            this.gv_Venduto.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Venduto.Size = new System.Drawing.Size(833, 334);
            this.gv_Venduto.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_Venduto.TabIndex = 2;
            this.gv_Venduto.UseStyleColors = true;
            this.gv_Venduto.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.gv_Venduto_CellFormatting);
            this.gv_Venduto.SelectionChanged += new System.EventHandler(this.gv_Venduto_SelectionChanged);
            // 
            // gv_Venduto_Cliente
            // 
            this.gv_Venduto_Cliente.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_Venduto_Cliente.DataPropertyName = "Cliente";
            this.gv_Venduto_Cliente.HeaderText = "Cliente";
            this.gv_Venduto_Cliente.Name = "gv_Venduto_Cliente";
            this.gv_Venduto_Cliente.ReadOnly = true;
            // 
            // gv_Venduto_Articolo
            // 
            this.gv_Venduto_Articolo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Venduto_Articolo.DataPropertyName = "Articolo";
            this.gv_Venduto_Articolo.HeaderText = "Articolo";
            this.gv_Venduto_Articolo.Name = "gv_Venduto_Articolo";
            this.gv_Venduto_Articolo.ReadOnly = true;
            this.gv_Venduto_Articolo.Width = 70;
            // 
            // gv_Venduto_QtaTot
            // 
            this.gv_Venduto_QtaTot.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Venduto_QtaTot.DataPropertyName = "Qta_Tot";
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle26.Format = "N0";
            dataGridViewCellStyle26.NullValue = null;
            this.gv_Venduto_QtaTot.DefaultCellStyle = dataGridViewCellStyle26;
            this.gv_Venduto_QtaTot.HeaderText = "Q.tà Venduto";
            this.gv_Venduto_QtaTot.Name = "gv_Venduto_QtaTot";
            this.gv_Venduto_QtaTot.ReadOnly = true;
            this.gv_Venduto_QtaTot.Width = 90;
            // 
            // gv_Venduto_Prezzo
            // 
            this.gv_Venduto_Prezzo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Venduto_Prezzo.DataPropertyName = "Prezzo";
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle27.Format = "C2";
            dataGridViewCellStyle27.NullValue = null;
            this.gv_Venduto_Prezzo.DefaultCellStyle = dataGridViewCellStyle27;
            this.gv_Venduto_Prezzo.HeaderText = "Prezzo Vendita";
            this.gv_Venduto_Prezzo.Name = "gv_Venduto_Prezzo";
            this.gv_Venduto_Prezzo.ReadOnly = true;
            this.gv_Venduto_Prezzo.Width = 96;
            // 
            // gv_Venduto_TotRicavi
            // 
            this.gv_Venduto_TotRicavi.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Venduto_TotRicavi.DataPropertyName = "Tot_Ricavi";
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle28.Format = "C2";
            dataGridViewCellStyle28.NullValue = null;
            this.gv_Venduto_TotRicavi.DefaultCellStyle = dataGridViewCellStyle28;
            this.gv_Venduto_TotRicavi.HeaderText = "Totale Ricavo";
            this.gv_Venduto_TotRicavi.Name = "gv_Venduto_TotRicavi";
            this.gv_Venduto_TotRicavi.ReadOnly = true;
            this.gv_Venduto_TotRicavi.Width = 89;
            // 
            // gv_Venduto_TotCosti
            // 
            this.gv_Venduto_TotCosti.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Venduto_TotCosti.DataPropertyName = "Tot_Costi";
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle29.Format = "C2";
            dataGridViewCellStyle29.NullValue = null;
            this.gv_Venduto_TotCosti.DefaultCellStyle = dataGridViewCellStyle29;
            this.gv_Venduto_TotCosti.HeaderText = "Totale Costo";
            this.gv_Venduto_TotCosti.Name = "gv_Venduto_TotCosti";
            this.gv_Venduto_TotCosti.ReadOnly = true;
            this.gv_Venduto_TotCosti.Width = 86;
            // 
            // gv_Venduto_CostoMat
            // 
            this.gv_Venduto_CostoMat.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Venduto_CostoMat.DataPropertyName = "Costo_Materiali";
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle30.Format = "C2";
            dataGridViewCellStyle30.NullValue = null;
            this.gv_Venduto_CostoMat.DefaultCellStyle = dataGridViewCellStyle30;
            this.gv_Venduto_CostoMat.HeaderText = "Costo dei materiali";
            this.gv_Venduto_CostoMat.Name = "gv_Venduto_CostoMat";
            this.gv_Venduto_CostoMat.ReadOnly = true;
            this.gv_Venduto_CostoMat.Width = 115;
            // 
            // gv_Venduto_CostoProd
            // 
            this.gv_Venduto_CostoProd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Venduto_CostoProd.DataPropertyName = "Costo_Produzione";
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle31.Format = "N2";
            dataGridViewCellStyle31.NullValue = null;
            this.gv_Venduto_CostoProd.DefaultCellStyle = dataGridViewCellStyle31;
            this.gv_Venduto_CostoProd.HeaderText = "Costo di produzione";
            this.gv_Venduto_CostoProd.Name = "gv_Venduto_CostoProd";
            this.gv_Venduto_CostoProd.ReadOnly = true;
            this.gv_Venduto_CostoProd.Visible = false;
            this.gv_Venduto_CostoProd.Width = 124;
            // 
            // gv_Venduto_CostoMan
            // 
            this.gv_Venduto_CostoMan.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Venduto_CostoMan.DataPropertyName = "Costo_Manodopera";
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle32.Format = "C2";
            dataGridViewCellStyle32.NullValue = null;
            this.gv_Venduto_CostoMan.DefaultCellStyle = dataGridViewCellStyle32;
            this.gv_Venduto_CostoMan.HeaderText = "Costo della manodopera";
            this.gv_Venduto_CostoMan.Name = "gv_Venduto_CostoMan";
            this.gv_Venduto_CostoMan.ReadOnly = true;
            this.gv_Venduto_CostoMan.Width = 143;
            // 
            // gv_Venduto_CostoLav
            // 
            this.gv_Venduto_CostoLav.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Venduto_CostoLav.DataPropertyName = "Costo_Lav_Est";
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle33.Format = "C2";
            dataGridViewCellStyle33.NullValue = null;
            this.gv_Venduto_CostoLav.DefaultCellStyle = dataGridViewCellStyle33;
            this.gv_Venduto_CostoLav.HeaderText = "Costo Lav. Esterne";
            this.gv_Venduto_CostoLav.Name = "gv_Venduto_CostoLav";
            this.gv_Venduto_CostoLav.ReadOnly = true;
            this.gv_Venduto_CostoLav.Width = 112;
            // 
            // margineDataGridViewTextBoxColumn
            // 
            this.margineDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.margineDataGridViewTextBoxColumn.DataPropertyName = "Margine";
            this.margineDataGridViewTextBoxColumn.HeaderText = "Margine";
            this.margineDataGridViewTextBoxColumn.Name = "margineDataGridViewTextBoxColumn";
            this.margineDataGridViewTextBoxColumn.ReadOnly = true;
            this.margineDataGridViewTextBoxColumn.Visible = false;
            this.margineDataGridViewTextBoxColumn.Width = 73;
            // 
            // totFatturatoDataGridViewTextBoxColumn
            // 
            this.totFatturatoDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.totFatturatoDataGridViewTextBoxColumn.DataPropertyName = "Tot_Fatturato";
            this.totFatturatoDataGridViewTextBoxColumn.HeaderText = "Tot_Fatturato";
            this.totFatturatoDataGridViewTextBoxColumn.Name = "totFatturatoDataGridViewTextBoxColumn";
            this.totFatturatoDataGridViewTextBoxColumn.ReadOnly = true;
            this.totFatturatoDataGridViewTextBoxColumn.Visible = false;
            this.totFatturatoDataGridViewTextBoxColumn.Width = 99;
            // 
            // gv_Venduto_Margine
            // 
            this.gv_Venduto_Margine.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Venduto_Margine.DataPropertyName = "Margine_Perc";
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle34.Format = "P";
            dataGridViewCellStyle34.NullValue = null;
            this.gv_Venduto_Margine.DefaultCellStyle = dataGridViewCellStyle34;
            this.gv_Venduto_Margine.HeaderText = "Margine";
            this.gv_Venduto_Margine.Name = "gv_Venduto_Margine";
            this.gv_Venduto_Margine.ReadOnly = true;
            this.gv_Venduto_Margine.Width = 73;
            // 
            // analisiCostiVendutoBindingSource
            // 
            this.analisiCostiVendutoBindingSource.DataMember = "Analisi_Costi_Venduto";
            this.analisiCostiVendutoBindingSource.DataSource = this.ds_SL;
            this.analisiCostiVendutoBindingSource.Sort = "Cliente asc, Articolo asc";
            this.analisiCostiVendutoBindingSource.CurrentChanged += new System.EventHandler(this.analisiCostiVendutoBindingSource_CurrentChanged);
            // 
            // colQuantita
            // 
            this.colQuantita.FieldName = "Quantita";
            this.colQuantita.Name = "colQuantita";
            this.colQuantita.Visible = true;
            this.colQuantita.VisibleIndex = 0;
            // 
            // colFlEsplodiSemilav
            // 
            this.colFlEsplodiSemilav.FieldName = "FlEsplodiSemilav";
            this.colFlEsplodiSemilav.Name = "colFlEsplodiSemilav";
            this.colFlEsplodiSemilav.Visible = true;
            this.colFlEsplodiSemilav.VisibleIndex = 1;
            // 
            // colCosto_Materia_Prima
            // 
            this.colCosto_Materia_Prima.FieldName = "Costo_Materia_Prima";
            this.colCosto_Materia_Prima.Name = "colCosto_Materia_Prima";
            this.colCosto_Materia_Prima.Visible = true;
            this.colCosto_Materia_Prima.VisibleIndex = 2;
            // 
            // colCosto_Uomo
            // 
            this.colCosto_Uomo.FieldName = "Costo_Uomo";
            this.colCosto_Uomo.Name = "colCosto_Uomo";
            this.colCosto_Uomo.Visible = true;
            this.colCosto_Uomo.VisibleIndex = 3;
            // 
            // colCosto_Lav_Est
            // 
            this.colCosto_Lav_Est.FieldName = "Costo_Lav_Est";
            this.colCosto_Lav_Est.Name = "colCosto_Lav_Est";
            this.colCosto_Lav_Est.Visible = true;
            this.colCosto_Lav_Est.VisibleIndex = 4;
            // 
            // colCosto_Unit
            // 
            this.colCosto_Unit.FieldName = "Costo_Unit";
            this.colCosto_Unit.Name = "colCosto_Unit";
            this.colCosto_Unit.Visible = true;
            this.colCosto_Unit.VisibleIndex = 5;
            // 
            // colCosto_Tot
            // 
            this.colCosto_Tot.FieldName = "Costo_Tot";
            this.colCosto_Tot.Name = "colCosto_Tot";
            this.colCosto_Tot.Visible = true;
            this.colCosto_Tot.VisibleIndex = 6;
            // 
            // colTipoProduzione
            // 
            this.colTipoProduzione.FieldName = "TipoProduzione";
            this.colTipoProduzione.Name = "colTipoProduzione";
            this.colTipoProduzione.Visible = true;
            this.colTipoProduzione.VisibleIndex = 7;
            // 
            // colLvl_DB
            // 
            this.colLvl_DB.FieldName = "Lvl_DB";
            this.colLvl_DB.Name = "colLvl_DB";
            this.colLvl_DB.Visible = true;
            this.colLvl_DB.VisibleIndex = 8;
            // 
            // colNum_Art
            // 
            this.colNum_Art.FieldName = "Num_Art";
            this.colNum_Art.Name = "colNum_Art";
            this.colNum_Art.Visible = true;
            this.colNum_Art.VisibleIndex = 9;
            // 
            // colNum_Exp
            // 
            this.colNum_Exp.FieldName = "Num_Exp";
            this.colNum_Exp.Name = "colNum_Exp";
            this.colNum_Exp.Visible = true;
            this.colNum_Exp.VisibleIndex = 10;
            // 
            // colArticoloIniziale
            // 
            this.colArticoloIniziale.FieldName = "ArticoloIniziale";
            this.colArticoloIniziale.Name = "colArticoloIniziale";
            this.colArticoloIniziale.Visible = true;
            this.colArticoloIniziale.VisibleIndex = 11;
            // 
            // colElaborato
            // 
            this.colElaborato.FieldName = "Elaborato";
            this.colElaborato.Name = "colElaborato";
            this.colElaborato.Visible = true;
            this.colElaborato.VisibleIndex = 12;
            // 
            // treeListBand1
            // 
            this.treeListBand1.Caption = "treeListBand1";
            this.treeListBand1.Name = "treeListBand1";
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(150, 150);
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(150, 175);
            this.toolStripContainer1.TabIndex = 0;
            // 
            // analisi_Costi_VendutoTableAdapter
            // 
            this.analisi_Costi_VendutoTableAdapter.ClearBeforeFill = true;
            // 
            // layout_filter
            // 
            this.layout_filter.ColumnCount = 10;
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.Controls.Add(this.btn_AzzeraFiltroArticoli, 2, 2);
            this.layout_filter.Controls.Add(this.cb_elencoarticoli, 2, 1);
            this.layout_filter.Controls.Add(this.metroLabel3, 2, 0);
            this.layout_filter.Controls.Add(this.metroLabel1, 0, 0);
            this.layout_filter.Controls.Add(this.cb_elencoClienti, 0, 1);
            this.layout_filter.Controls.Add(this.btn_AzzeraFiltroClienti, 0, 2);
            this.layout_filter.Controls.Add(this.metroLabel4, 6, 0);
            this.layout_filter.Controls.Add(this.lab_tot_ricavi, 8, 0);
            this.layout_filter.Controls.Add(this.metroLabel5, 6, 1);
            this.layout_filter.Controls.Add(this.lab_tot_costi, 8, 1);
            this.layout_filter.Controls.Add(this.metroLabel2, 6, 2);
            this.layout_filter.Controls.Add(this.lab_tot_diff, 8, 2);
            this.layout_filter.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_filter.Location = new System.Drawing.Point(20, 55);
            this.layout_filter.Name = "layout_filter";
            this.layout_filter.RowCount = 3;
            this.layout_filter.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_filter.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_filter.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_filter.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_filter.Size = new System.Drawing.Size(839, 75);
            this.layout_filter.TabIndex = 128;
            // 
            // btn_AzzeraFiltroArticoli
            // 
            this.btn_AzzeraFiltroArticoli.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.layout_filter.SetColumnSpan(this.btn_AzzeraFiltroArticoli, 2);
            this.btn_AzzeraFiltroArticoli.Location = new System.Drawing.Point(207, 53);
            this.btn_AzzeraFiltroArticoli.Name = "btn_AzzeraFiltroArticoli";
            this.btn_AzzeraFiltroArticoli.Size = new System.Drawing.Size(83, 19);
            this.btn_AzzeraFiltroArticoli.Style = MetroFramework.MetroColorStyle.Red;
            this.btn_AzzeraFiltroArticoli.TabIndex = 33;
            this.btn_AzzeraFiltroArticoli.Text = "Tutti";
            this.btn_AzzeraFiltroArticoli.UseSelectable = true;
            this.btn_AzzeraFiltroArticoli.Click += new System.EventHandler(this.btn_AzzeraFiltroArticoli_Click);
            // 
            // cb_elencoarticoli
            // 
            this.layout_filter.SetColumnSpan(this.cb_elencoarticoli, 2);
            this.cb_elencoarticoli.DataSource = this.aCVClienteArticoloBindingSource;
            this.cb_elencoarticoli.DisplayMember = "Articolo";
            this.cb_elencoarticoli.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cb_elencoarticoli.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_elencoarticoli.FormattingEnabled = true;
            this.cb_elencoarticoli.Location = new System.Drawing.Point(169, 28);
            this.cb_elencoarticoli.Name = "cb_elencoarticoli";
            this.cb_elencoarticoli.Size = new System.Drawing.Size(160, 23);
            this.cb_elencoarticoli.TabIndex = 32;
            this.cb_elencoarticoli.SelectedIndexChanged += new System.EventHandler(this.cb_elencoarticoli_SelectedIndexChanged);
            // 
            // aCVClienteArticoloBindingSource
            // 
            this.aCVClienteArticoloBindingSource.DataMember = "ACV_ClienteArticolo";
            this.aCVClienteArticoloBindingSource.DataSource = this.ds_SL;
            // 
            // metroLabel3
            // 
            this.metroLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel3.AutoSize = true;
            this.layout_filter.SetColumnSpan(this.metroLabel3, 2);
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Location = new System.Drawing.Point(169, 3);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(160, 19);
            this.metroLabel3.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel3.TabIndex = 24;
            this.metroLabel3.Text = "Articolo";
            this.metroLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroLabel3.UseStyleColors = true;
            // 
            // metroLabel1
            // 
            this.metroLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel1.AutoSize = true;
            this.layout_filter.SetColumnSpan(this.metroLabel1, 2);
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(3, 3);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(160, 19);
            this.metroLabel1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel1.TabIndex = 22;
            this.metroLabel1.Text = "Cliente";
            this.metroLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroLabel1.UseStyleColors = true;
            // 
            // cb_elencoClienti
            // 
            this.layout_filter.SetColumnSpan(this.cb_elencoClienti, 2);
            this.cb_elencoClienti.DataSource = this.aCVClienteBindingSource;
            this.cb_elencoClienti.DisplayMember = "Cliente";
            this.cb_elencoClienti.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cb_elencoClienti.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_elencoClienti.FormattingEnabled = true;
            this.cb_elencoClienti.Location = new System.Drawing.Point(3, 28);
            this.cb_elencoClienti.Name = "cb_elencoClienti";
            this.cb_elencoClienti.Size = new System.Drawing.Size(160, 23);
            this.cb_elencoClienti.TabIndex = 27;
            this.cb_elencoClienti.SelectedIndexChanged += new System.EventHandler(this.cb_elencoClienti_SelectedIndexChanged);
            // 
            // aCVClienteBindingSource
            // 
            this.aCVClienteBindingSource.DataMember = "ACV_Cliente";
            this.aCVClienteBindingSource.DataSource = this.ds_SL;
            // 
            // btn_AzzeraFiltroClienti
            // 
            this.btn_AzzeraFiltroClienti.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.layout_filter.SetColumnSpan(this.btn_AzzeraFiltroClienti, 2);
            this.btn_AzzeraFiltroClienti.Location = new System.Drawing.Point(41, 53);
            this.btn_AzzeraFiltroClienti.Name = "btn_AzzeraFiltroClienti";
            this.btn_AzzeraFiltroClienti.Size = new System.Drawing.Size(83, 19);
            this.btn_AzzeraFiltroClienti.Style = MetroFramework.MetroColorStyle.Red;
            this.btn_AzzeraFiltroClienti.TabIndex = 29;
            this.btn_AzzeraFiltroClienti.Text = "Tutti";
            this.btn_AzzeraFiltroClienti.UseSelectable = true;
            this.btn_AzzeraFiltroClienti.Click += new System.EventHandler(this.btn_AzzeraFiltroClienti_Click);
            // 
            // metroLabel4
            // 
            this.metroLabel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel4.AutoSize = true;
            this.layout_filter.SetColumnSpan(this.metroLabel4, 2);
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(501, 3);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(160, 19);
            this.metroLabel4.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel4.TabIndex = 35;
            this.metroLabel4.Text = "Totale Fatturato:";
            this.metroLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.metroLabel4.UseStyleColors = true;
            // 
            // lab_tot_ricavi
            // 
            this.lab_tot_ricavi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lab_tot_ricavi.AutoSize = true;
            this.layout_filter.SetColumnSpan(this.lab_tot_ricavi, 2);
            this.lab_tot_ricavi.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_tot_ricavi.Location = new System.Drawing.Point(667, 3);
            this.lab_tot_ricavi.Name = "lab_tot_ricavi";
            this.lab_tot_ricavi.Size = new System.Drawing.Size(169, 19);
            this.lab_tot_ricavi.Style = MetroFramework.MetroColorStyle.Black;
            this.lab_tot_ricavi.TabIndex = 34;
            this.lab_tot_ricavi.Text = "Totale Fatturato:";
            this.lab_tot_ricavi.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_tot_ricavi.UseStyleColors = true;
            // 
            // metroLabel5
            // 
            this.metroLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel5.AutoSize = true;
            this.layout_filter.SetColumnSpan(this.metroLabel5, 2);
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel5.Location = new System.Drawing.Point(501, 28);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(160, 19);
            this.metroLabel5.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel5.TabIndex = 36;
            this.metroLabel5.Text = "Totale Costi:";
            this.metroLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.metroLabel5.UseStyleColors = true;
            // 
            // lab_tot_costi
            // 
            this.lab_tot_costi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lab_tot_costi.AutoSize = true;
            this.layout_filter.SetColumnSpan(this.lab_tot_costi, 2);
            this.lab_tot_costi.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_tot_costi.Location = new System.Drawing.Point(667, 28);
            this.lab_tot_costi.Name = "lab_tot_costi";
            this.lab_tot_costi.Size = new System.Drawing.Size(169, 19);
            this.lab_tot_costi.Style = MetroFramework.MetroColorStyle.Black;
            this.lab_tot_costi.TabIndex = 37;
            this.lab_tot_costi.Text = "Totale Costi:";
            this.lab_tot_costi.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_tot_costi.UseStyleColors = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel2.AutoSize = true;
            this.layout_filter.SetColumnSpan(this.metroLabel2, 2);
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Location = new System.Drawing.Point(501, 53);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(160, 19);
            this.metroLabel2.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel2.TabIndex = 38;
            this.metroLabel2.Text = "Utile/Perdita:";
            this.metroLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.metroLabel2.UseStyleColors = true;
            // 
            // lab_tot_diff
            // 
            this.lab_tot_diff.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lab_tot_diff.AutoSize = true;
            this.layout_filter.SetColumnSpan(this.lab_tot_diff, 2);
            this.lab_tot_diff.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_tot_diff.Location = new System.Drawing.Point(667, 53);
            this.lab_tot_diff.Name = "lab_tot_diff";
            this.lab_tot_diff.Size = new System.Drawing.Size(169, 19);
            this.lab_tot_diff.Style = MetroFramework.MetroColorStyle.Black;
            this.lab_tot_diff.TabIndex = 39;
            this.lab_tot_diff.Text = "Totale Costi:";
            this.lab_tot_diff.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lab_tot_diff.UseStyleColors = true;
            // 
            // aCV_Cliente
            // 
            this.aCV_Cliente.ClearBeforeFill = true;
            // 
            // aCV_ClienteArticolo
            // 
            this.aCV_ClienteArticolo.ClearBeforeFill = true;
            // 
            // clienteDataGridViewTextBoxColumn
            // 
            this.clienteDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.clienteDataGridViewTextBoxColumn.DataPropertyName = "Cliente";
            this.clienteDataGridViewTextBoxColumn.HeaderText = "Cliente";
            this.clienteDataGridViewTextBoxColumn.Name = "clienteDataGridViewTextBoxColumn";
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "Articolo";
            this.Column1.HeaderText = "Column1";
            this.Column1.Name = "Column1";
            // 
            // Qta_Tot
            // 
            this.Qta_Tot.DataPropertyName = "Qta_Tot";
            this.Qta_Tot.HeaderText = "Qta_Tot";
            this.Qta_Tot.Name = "Qta_Tot";
            // 
            // Prezzo
            // 
            this.Prezzo.DataPropertyName = "Prezzo";
            this.Prezzo.HeaderText = "Prezzo";
            this.Prezzo.Name = "Prezzo";
            // 
            // Costo_Materiali
            // 
            this.Costo_Materiali.DataPropertyName = "Costo_Materiali";
            this.Costo_Materiali.HeaderText = "Costo_Materiali";
            this.Costo_Materiali.Name = "Costo_Materiali";
            // 
            // Costo_Manodopera
            // 
            this.Costo_Manodopera.DataPropertyName = "Costo_Manodopera";
            this.Costo_Manodopera.HeaderText = "Costo_Manodopera";
            this.Costo_Manodopera.Name = "Costo_Manodopera";
            // 
            // Costo_Lav_Est
            // 
            this.Costo_Lav_Est.DataPropertyName = "Costo_Lav_Est";
            this.Costo_Lav_Est.HeaderText = "Costo_Lav_Est";
            this.Costo_Lav_Est.Name = "Costo_Lav_Est";
            // 
            // Costo_Produzione
            // 
            this.Costo_Produzione.DataPropertyName = "Costo_Produzione";
            this.Costo_Produzione.HeaderText = "Costo_Produzione";
            this.Costo_Produzione.Name = "Costo_Produzione";
            // 
            // Margine
            // 
            this.Margine.DataPropertyName = "Margine";
            this.Margine.HeaderText = "Margine";
            this.Margine.Name = "Margine";
            // 
            // Cliente
            // 
            this.Cliente.DataPropertyName = "Cliente";
            this.Cliente.HeaderText = "Cliente";
            this.Cliente.Name = "Cliente";
            // 
            // tree_Distinta
            // 
            this.tree_Distinta.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.colArticoloComposto,
            this.colArticoloComponente,
            this.colQuantita1,
            this.colCosto_Materia_Prima1,
            this.colCosto_Uomo1,
            this.colCosto_Lav_Est1,
            this.colArticoloIniziale1,
            this.colCalc_Costo_Tot_Unitario,
            this.colCalc_Costo_Tot_Totale});
            this.tree_Distinta.DataSource = this.analisiCostiVendutoSFExplDistintaSaleBindingSource;
            this.tree_Distinta.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tree_Distinta.KeyFieldName = "id_figlio";
            this.tree_Distinta.Location = new System.Drawing.Point(3, 343);
            this.tree_Distinta.Name = "tree_Distinta";
            this.tree_Distinta.ParentFieldName = "id_padre";
            this.tree_Distinta.RootValue = "--LABEL--";
            this.tree_Distinta.Size = new System.Drawing.Size(833, 504);
            this.tree_Distinta.TabIndex = 3;
            // 
            // analisiCostiVendutoSFExplDistintaSaleBindingSource
            // 
            this.analisiCostiVendutoSFExplDistintaSaleBindingSource.DataMember = "Analisi_Costi_Venduto_SF_Expl_Distinta_Sale";
            this.analisiCostiVendutoSFExplDistintaSaleBindingSource.DataSource = this.analisiCostiVendutoBindingSource;
            // 
            // sF_Expl_Distinta_SaleTableAdapter
            // 
            this.sF_Expl_Distinta_SaleTableAdapter.ClearBeforeFill = true;
            // 
            // colArticoloComposto
            // 
            this.colArticoloComposto.FieldName = "ArticoloComposto";
            this.colArticoloComposto.Name = "colArticoloComposto";
            // 
            // colArticoloComponente
            // 
            this.colArticoloComponente.FieldName = "ArticoloComponente";
            this.colArticoloComponente.Name = "colArticoloComponente";
            this.colArticoloComponente.Visible = true;
            this.colArticoloComponente.VisibleIndex = 1;
            // 
            // colQuantita1
            // 
            this.colQuantita1.FieldName = "Quantita";
            this.colQuantita1.Name = "colQuantita1";
            this.colQuantita1.Visible = true;
            this.colQuantita1.VisibleIndex = 2;
            // 
            // colCosto_Materia_Prima1
            // 
            this.colCosto_Materia_Prima1.FieldName = "Costo_Materia_Prima";
            this.colCosto_Materia_Prima1.Name = "colCosto_Materia_Prima1";
            this.colCosto_Materia_Prima1.Visible = true;
            this.colCosto_Materia_Prima1.VisibleIndex = 3;
            // 
            // colCosto_Uomo1
            // 
            this.colCosto_Uomo1.FieldName = "Costo_Uomo";
            this.colCosto_Uomo1.Name = "colCosto_Uomo1";
            this.colCosto_Uomo1.Visible = true;
            this.colCosto_Uomo1.VisibleIndex = 4;
            // 
            // colCosto_Lav_Est1
            // 
            this.colCosto_Lav_Est1.FieldName = "Costo_Lav_Est";
            this.colCosto_Lav_Est1.Name = "colCosto_Lav_Est1";
            this.colCosto_Lav_Est1.Visible = true;
            this.colCosto_Lav_Est1.VisibleIndex = 5;
            // 
            // colArticoloIniziale1
            // 
            this.colArticoloIniziale1.FieldName = "ArticoloIniziale";
            this.colArticoloIniziale1.Name = "colArticoloIniziale1";
            // 
            // colCalc_Costo_Tot_Unitario
            // 
            this.colCalc_Costo_Tot_Unitario.FieldName = "Calc_Costo_Tot_Unitario";
            this.colCalc_Costo_Tot_Unitario.Name = "colCalc_Costo_Tot_Unitario";
            this.colCalc_Costo_Tot_Unitario.Visible = true;
            this.colCalc_Costo_Tot_Unitario.VisibleIndex = 9;
            // 
            // colCalc_Costo_Tot_Totale
            // 
            this.colCalc_Costo_Tot_Totale.FieldName = "Calc_Costo_Tot_Totale";
            this.colCalc_Costo_Tot_Totale.Name = "colCalc_Costo_Tot_Totale";
            this.colCalc_Costo_Tot_Totale.Visible = true;
            this.colCalc_Costo_Tot_Totale.VisibleIndex = 10;
            // 
            // UC_Amm_AnalisiCosti
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(879, 1000);
            this.ControlBox = false;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.layout_filter);
            this.Controls.Add(this.layout_orizz_menu);
            this.DisplayHeader = false;
            this.Name = "UC_Amm_AnalisiCosti";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UC_Amm_AnalisiCosti_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            this.layout_orizz_menu.ResumeLayout(false);
            this.layout_orizz_menu.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_Venduto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analisiCostiVendutoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analisiCostiDistinteBindingSource)).EndInit();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.layout_filter.ResumeLayout(false);
            this.layout_filter.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aCVClienteArticoloBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aCVClienteBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tree_Distinta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analisiCostiVendutoSFExplDistintaSaleBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel layout_orizz_menu;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
        private ds_SL ds_SL;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.ToolStripContainer toolStripContainer2;
        private DevExpress.XtraTreeList.Columns.TreeListBand treeListBand1;
        private System.Windows.Forms.BindingSource analisiCostiDistinteBindingSource;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colQuantita;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colFlEsplodiSemilav;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colCosto_Materia_Prima;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colCosto_Uomo;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colCosto_Lav_Est;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colCosto_Unit;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colCosto_Tot;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colTipoProduzione;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colLvl_DB;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colNum_Art;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colNum_Exp;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colArticoloIniziale;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colElaborato;
        private System.Windows.Forms.BindingSource analisiCostiVendutoBindingSource;
        private ds_SLTableAdapters.Analisi_Costi_VendutoTableAdapter analisi_Costi_VendutoTableAdapter;
        private MetroFramework.Controls.MetroGrid gv_Venduto;
        private System.Windows.Forms.TableLayoutPanel layout_filter;
        private MetroFramework.Controls.MetroButton btn_AzzeraFiltroArticoli;
        private System.Windows.Forms.ComboBox cb_elencoarticoli;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.ComboBox cb_elencoClienti;
        private MetroFramework.Controls.MetroButton btn_AzzeraFiltroClienti;
        private System.Windows.Forms.BindingSource aCVClienteBindingSource;
        private ds_SLTableAdapters.ACV_Cliente aCV_Cliente;
        private System.Windows.Forms.BindingSource aCVClienteArticoloBindingSource;
        private ds_SLTableAdapters.ACV_ClienteArticolo aCV_ClienteArticolo;
        private MetroFramework.Controls.MetroLabel lab_tot_ricavi;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel lab_tot_costi;
        private System.Windows.Forms.DataGridViewTextBoxColumn clienteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Qta_Tot;
        private System.Windows.Forms.DataGridViewTextBoxColumn Prezzo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Costo_Materiali;
        private System.Windows.Forms.DataGridViewTextBoxColumn Costo_Manodopera;
        private System.Windows.Forms.DataGridViewTextBoxColumn Costo_Lav_Est;
        private System.Windows.Forms.DataGridViewTextBoxColumn Costo_Produzione;
        private System.Windows.Forms.DataGridViewTextBoxColumn Margine;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cliente;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel lab_tot_diff;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Venduto_Cliente;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Venduto_Articolo;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Venduto_QtaTot;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Venduto_Prezzo;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Venduto_TotRicavi;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Venduto_TotCosti;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Venduto_CostoMat;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Venduto_CostoProd;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Venduto_CostoMan;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Venduto_CostoLav;
        private System.Windows.Forms.DataGridViewTextBoxColumn margineDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totFatturatoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Venduto_Margine;
        private DevExpress.XtraTreeList.TreeList tree_Distinta;
        private System.Windows.Forms.BindingSource analisiCostiVendutoSFExplDistintaSaleBindingSource;
        private ds_SLTableAdapters.SF_Expl_Distinta_SaleTableAdapter sF_Expl_Distinta_SaleTableAdapter;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colArticoloComposto;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colArticoloComponente;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colQuantita1;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colCosto_Materia_Prima1;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colCosto_Uomo1;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colCosto_Lav_Est1;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colArticoloIniziale1;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colCalc_Costo_Tot_Unitario;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colCalc_Costo_Tot_Totale;
    }
}
