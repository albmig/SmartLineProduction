﻿namespace SmartLineProduction
{
}


namespace SmartLineProduction
{


    partial class ds_SL
    {
        partial class dt_Tmp_Fattibile_ExplodeDataTable
        {
        }
    }
}

