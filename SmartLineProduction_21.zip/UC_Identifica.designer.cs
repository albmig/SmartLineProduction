﻿namespace SmartLineProduction
{
    partial class UC_Identifica
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Identifica));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            this.layout_orizz_menu = new System.Windows.Forms.TableLayoutPanel();
            this.pan_Menu_comandi = new System.Windows.Forms.MenuStrip();
            this.verificaSaltiNumerazioneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.panel_fattibilita = new MetroFramework.Controls.MetroPanel();
            this.layout_Schede = new System.Windows.Forms.TableLayoutPanel();
            this.metroLabel26 = new MetroFramework.Controls.MetroLabel();
            this.sFSNarsnSFSNmosnBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sFSNarsnBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.metroLabel25 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel24 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel23 = new MetroFramework.Controls.MetroLabel();
            this.metroGrid2 = new MetroFramework.Controls.MetroGrid();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serKitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serIDCliDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serDeviceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serDeviceIDCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serOfficialSerialDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serReadSerialDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serSWCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serSWCodeRevDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rAGIONESOCIALEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iNDIRIZZODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nUMEROCIVICODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fRAZIONEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cAPDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cOMUNEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pROVINCIADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rEGIONEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pREFISSOTELEFONODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nUMEROTELEFONODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pREFISSOTELEFONOAGGIUNTIVODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nUMEROTELEFONOAGGIUNTIVODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eMailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eMAILPECDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWDescrizioneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWRevisioniDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWFunzionamentoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.desKitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.desEstKitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.modelloDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.desDeviceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.desEstDeviceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fWversDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fWrevDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serSWStdTypeDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.serSNprodDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serCommessaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serDateProductionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serSpeditoDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.serDataSpeditoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serSubstitionIDReadSerialDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serNoteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sWObsoleteverDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sWObsoleteverfromdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sFSNarsnSFSNQueryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.sFSNarsnSFSNartaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.panel_grid = new MetroFramework.Controls.MetroPanel();
            this.gv_SN = new MetroFramework.Controls.MetroGrid();
            this.serialNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.articoloDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.entitaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serieDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.partitaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataInizioGarForDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.flObsoletoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataTrasfObsoletoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nume01DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataRegMovInizDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.progRegMovInizDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.progContrMovInizDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serialNumberEstDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.flTrasfWebDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDUtenteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDTerminaleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataUltModificaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroGrid1 = new MetroFramework.Controls.MetroGrid();
            this.articoloDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serialNumberDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ragSocCognomeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ragSocNomeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ragSocCompletaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descrizioneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codAnagraficoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataDocumentoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numeroOrdineDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataOrdineDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rigaOrdineDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipoBollaFatturaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numeroBollaFatturaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataBollaFatturaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numeroBrogliaccioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rigaBrogliaccioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.commessaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.articoloOrdineDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sFSNarsnSFmomamosnBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroGrid3 = new MetroFramework.Controls.MetroGrid();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.metroCheckBox2 = new MetroFramework.Controls.MetroCheckBox();
            this.metroCheckBox1 = new MetroFramework.Controls.MetroCheckBox();
            this.metroLabel22 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel21 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel20 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel19 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel18 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel17 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel16 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.sF_SN_arsnTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_SN_arsnTableAdapter();
            this.sF_SN_artaTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_SN_artaTableAdapter();
            this.sF_SN_QueryTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_SN_QueryTableAdapter();
            this.sF_SN_mosnTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_SN_mosnTableAdapter();
            this.sFSNmomamosnSFSNbrorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_SN_brorTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_SN_brorTableAdapter();
            this.layout_orizz_menu.SuspendLayout();
            this.pan_Menu_comandi.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            this.panel_fattibilita.SuspendLayout();
            this.layout_Schede.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFSNmosnBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFSNQueryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFSNartaBindingSource)).BeginInit();
            this.panel_grid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_SN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFmomamosnBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid3)).BeginInit();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNmomamosnSFSNbrorBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // layout_orizz_menu
            // 
            this.layout_orizz_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.ColumnCount = 10;
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_comandi, 0, 0);
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_exit, 10, 0);
            this.layout_orizz_menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_orizz_menu.Location = new System.Drawing.Point(20, 30);
            this.layout_orizz_menu.Name = "layout_orizz_menu";
            this.layout_orizz_menu.RowCount = 1;
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_orizz_menu.Size = new System.Drawing.Size(960, 25);
            this.layout_orizz_menu.TabIndex = 125;
            // 
            // pan_Menu_comandi
            // 
            this.pan_Menu_comandi.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.SetColumnSpan(this.pan_Menu_comandi, 5);
            this.pan_Menu_comandi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_Menu_comandi.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.verificaSaltiNumerazioneToolStripMenuItem});
            this.pan_Menu_comandi.Location = new System.Drawing.Point(0, 0);
            this.pan_Menu_comandi.Name = "pan_Menu_comandi";
            this.pan_Menu_comandi.Size = new System.Drawing.Size(480, 25);
            this.pan_Menu_comandi.TabIndex = 86;
            this.pan_Menu_comandi.Text = "menuStrip1";
            // 
            // verificaSaltiNumerazioneToolStripMenuItem
            // 
            this.verificaSaltiNumerazioneToolStripMenuItem.Image = global::SmartLineProduction.Properties.Resources.FindInFile_16x;
            this.verificaSaltiNumerazioneToolStripMenuItem.Name = "verificaSaltiNumerazioneToolStripMenuItem";
            this.verificaSaltiNumerazioneToolStripMenuItem.Size = new System.Drawing.Size(169, 21);
            this.verificaSaltiNumerazioneToolStripMenuItem.Text = "Verifica salti numerazione";
            this.verificaSaltiNumerazioneToolStripMenuItem.Click += new System.EventHandler(this.verificaSaltiNumerazioneToolStripMenuItem_Click);
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Gainsboro;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(885, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(75, 24);
            this.pan_Menu_exit.TabIndex = 82;
            this.pan_Menu_exit.Text = "menuStrip1";
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            this.menu_sw_exit.Click += new System.EventHandler(this.menu_sw_exit_Click);
            // 
            // panel_fattibilita
            // 
            this.panel_fattibilita.Controls.Add(this.layout_Schede);
            this.panel_fattibilita.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_fattibilita.HorizontalScrollbarBarColor = true;
            this.panel_fattibilita.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_fattibilita.HorizontalScrollbarSize = 10;
            this.panel_fattibilita.Location = new System.Drawing.Point(20, 55);
            this.panel_fattibilita.Name = "panel_fattibilita";
            this.panel_fattibilita.Size = new System.Drawing.Size(960, 725);
            this.panel_fattibilita.TabIndex = 126;
            this.panel_fattibilita.VerticalScrollbarBarColor = true;
            this.panel_fattibilita.VerticalScrollbarHighlightOnWheel = false;
            this.panel_fattibilita.VerticalScrollbarSize = 10;
            // 
            // layout_Schede
            // 
            this.layout_Schede.ColumnCount = 8;
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.Controls.Add(this.metroLabel26, 3, 4);
            this.layout_Schede.Controls.Add(this.metroLabel25, 3, 3);
            this.layout_Schede.Controls.Add(this.metroLabel11, 3, 5);
            this.layout_Schede.Controls.Add(this.metroLabel24, 3, 2);
            this.layout_Schede.Controls.Add(this.metroLabel23, 2, 2);
            this.layout_Schede.Controls.Add(this.metroGrid2, 0, 21);
            this.layout_Schede.Controls.Add(this.metroLabel3, 3, 1);
            this.layout_Schede.Controls.Add(this.metroLabel2, 3, 0);
            this.layout_Schede.Controls.Add(this.metroLabel1, 2, 0);
            this.layout_Schede.Controls.Add(this.panel_grid, 0, 0);
            this.layout_Schede.Controls.Add(this.metroGrid1, 3, 21);
            this.layout_Schede.Controls.Add(this.metroGrid3, 0, 26);
            this.layout_Schede.Controls.Add(this.metroPanel1, 2, 6);
            this.layout_Schede.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Schede.Location = new System.Drawing.Point(0, 0);
            this.layout_Schede.Name = "layout_Schede";
            this.layout_Schede.RowCount = 27;
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666665F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666666F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.Size = new System.Drawing.Size(960, 725);
            this.layout_Schede.TabIndex = 123;
            // 
            // metroLabel26
            // 
            this.metroLabel26.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel26.AutoSize = true;
            this.layout_Schede.SetColumnSpan(this.metroLabel26, 5);
            this.metroLabel26.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNmosnBindingSource, "RagSocNome", true));
            this.metroLabel26.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel26.Location = new System.Drawing.Point(363, 95);
            this.metroLabel26.Name = "metroLabel26";
            this.metroLabel26.Size = new System.Drawing.Size(138, 19);
            this.metroLabel26.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel26.TabIndex = 32;
            this.metroLabel26.Text = "Cliente_RagSocNome";
            this.metroLabel26.UseCustomBackColor = true;
            this.metroLabel26.UseStyleColors = true;
            // 
            // sFSNarsnSFSNmosnBindingSource
            // 
            this.sFSNarsnSFSNmosnBindingSource.DataMember = "SF_SN_arsn_SF_SN_mosn";
            this.sFSNarsnSFSNmosnBindingSource.DataSource = this.sFSNarsnBindingSource;
            // 
            // sFSNarsnBindingSource
            // 
            this.sFSNarsnBindingSource.DataMember = "SF_SN_arsn";
            this.sFSNarsnBindingSource.DataSource = this.ds_SL;
            this.sFSNarsnBindingSource.Filter = "";
            this.sFSNarsnBindingSource.Sort = "SerialNumber asc";
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // metroLabel25
            // 
            this.metroLabel25.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel25.AutoSize = true;
            this.layout_Schede.SetColumnSpan(this.metroLabel25, 5);
            this.metroLabel25.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNmosnBindingSource, "RagSocCognome", true));
            this.metroLabel25.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel25.Location = new System.Drawing.Point(363, 75);
            this.metroLabel25.Name = "metroLabel25";
            this.metroLabel25.Size = new System.Drawing.Size(161, 19);
            this.metroLabel25.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel25.TabIndex = 31;
            this.metroLabel25.Text = "Cliente_RagSocCognome";
            this.metroLabel25.UseCustomBackColor = true;
            this.metroLabel25.UseStyleColors = true;
            // 
            // metroLabel11
            // 
            this.metroLabel11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNmosnBindingSource, "NazioneFiscale", true));
            this.metroLabel11.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel11.Location = new System.Drawing.Point(363, 118);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(114, 19);
            this.metroLabel11.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel11.TabIndex = 30;
            this.metroLabel11.Text = "Cliente_NazioneFiscale";
            this.metroLabel11.UseCustomBackColor = true;
            this.metroLabel11.UseStyleColors = true;
            // 
            // metroLabel24
            // 
            this.metroLabel24.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel24.AutoSize = true;
            this.layout_Schede.SetColumnSpan(this.metroLabel24, 5);
            this.metroLabel24.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNmosnBindingSource, "RagSocCompleta", true));
            this.metroLabel24.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel24.Location = new System.Drawing.Point(363, 53);
            this.metroLabel24.Name = "metroLabel24";
            this.metroLabel24.Size = new System.Drawing.Size(160, 19);
            this.metroLabel24.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel24.TabIndex = 29;
            this.metroLabel24.Text = "Cliente_RagSocCompleta";
            this.metroLabel24.UseCustomBackColor = true;
            this.metroLabel24.UseStyleColors = true;
            // 
            // metroLabel23
            // 
            this.metroLabel23.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel23.AutoSize = true;
            this.metroLabel23.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel23.Location = new System.Drawing.Point(243, 53);
            this.metroLabel23.Name = "metroLabel23";
            this.metroLabel23.Size = new System.Drawing.Size(54, 19);
            this.metroLabel23.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel23.TabIndex = 28;
            this.metroLabel23.Text = "Cliente:";
            this.metroLabel23.UseCustomBackColor = true;
            // 
            // metroGrid2
            // 
            this.metroGrid2.AllowUserToResizeRows = false;
            this.metroGrid2.AutoGenerateColumns = false;
            this.metroGrid2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.metroGrid2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.serKitDataGridViewTextBoxColumn,
            this.serIDCliDataGridViewTextBoxColumn,
            this.serDeviceDataGridViewTextBoxColumn,
            this.serDeviceIDCodeDataGridViewTextBoxColumn,
            this.serOfficialSerialDataGridViewTextBoxColumn,
            this.serReadSerialDataGridViewTextBoxColumn,
            this.serSWCodeDataGridViewTextBoxColumn,
            this.serSWCodeRevDataGridViewTextBoxColumn,
            this.rAGIONESOCIALEDataGridViewTextBoxColumn,
            this.iNDIRIZZODataGridViewTextBoxColumn,
            this.nUMEROCIVICODataGridViewTextBoxColumn,
            this.fRAZIONEDataGridViewTextBoxColumn,
            this.cAPDataGridViewTextBoxColumn,
            this.cOMUNEDataGridViewTextBoxColumn,
            this.pROVINCIADataGridViewTextBoxColumn,
            this.rEGIONEDataGridViewTextBoxColumn,
            this.pREFISSOTELEFONODataGridViewTextBoxColumn,
            this.nUMEROTELEFONODataGridViewTextBoxColumn,
            this.pREFISSOTELEFONOAGGIUNTIVODataGridViewTextBoxColumn,
            this.nUMEROTELEFONOAGGIUNTIVODataGridViewTextBoxColumn,
            this.eMailDataGridViewTextBoxColumn,
            this.eMAILPECDataGridViewTextBoxColumn,
            this.sWDescrizioneDataGridViewTextBoxColumn,
            this.sWRevisioniDataGridViewTextBoxColumn,
            this.sWFunzionamentoDataGridViewTextBoxColumn,
            this.desKitDataGridViewTextBoxColumn,
            this.desEstKitDataGridViewTextBoxColumn,
            this.modelloDataGridViewTextBoxColumn,
            this.desDeviceDataGridViewTextBoxColumn,
            this.desEstDeviceDataGridViewTextBoxColumn,
            this.fWversDataGridViewTextBoxColumn,
            this.fWrevDataGridViewTextBoxColumn,
            this.serSWStdTypeDataGridViewCheckBoxColumn,
            this.serSNprodDataGridViewTextBoxColumn,
            this.serCommessaDataGridViewTextBoxColumn,
            this.serDateProductionDataGridViewTextBoxColumn,
            this.serSpeditoDataGridViewCheckBoxColumn,
            this.serDataSpeditoDataGridViewTextBoxColumn,
            this.serSubstitionIDReadSerialDataGridViewTextBoxColumn,
            this.serNoteDataGridViewTextBoxColumn,
            this.sWObsoleteverDataGridViewCheckBoxColumn,
            this.sWObsoleteverfromdateDataGridViewTextBoxColumn});
            this.layout_Schede.SetColumnSpan(this.metroGrid2, 3);
            this.metroGrid2.DataSource = this.sFSNarsnSFSNQueryBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid2.DefaultCellStyle = dataGridViewCellStyle2;
            this.metroGrid2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroGrid2.EnableHeadersVisualStyles = false;
            this.metroGrid2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid2.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid2.Location = new System.Drawing.Point(3, 499);
            this.metroGrid2.Name = "metroGrid2";
            this.metroGrid2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid2.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.metroGrid2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.layout_Schede.SetRowSpan(this.metroGrid2, 6);
            this.metroGrid2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid2.Size = new System.Drawing.Size(354, 98);
            this.metroGrid2.TabIndex = 25;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            // 
            // serKitDataGridViewTextBoxColumn
            // 
            this.serKitDataGridViewTextBoxColumn.DataPropertyName = "Ser_Kit";
            this.serKitDataGridViewTextBoxColumn.HeaderText = "Ser_Kit";
            this.serKitDataGridViewTextBoxColumn.Name = "serKitDataGridViewTextBoxColumn";
            // 
            // serIDCliDataGridViewTextBoxColumn
            // 
            this.serIDCliDataGridViewTextBoxColumn.DataPropertyName = "Ser_ID_Cli";
            this.serIDCliDataGridViewTextBoxColumn.HeaderText = "Ser_ID_Cli";
            this.serIDCliDataGridViewTextBoxColumn.Name = "serIDCliDataGridViewTextBoxColumn";
            // 
            // serDeviceDataGridViewTextBoxColumn
            // 
            this.serDeviceDataGridViewTextBoxColumn.DataPropertyName = "Ser_Device";
            this.serDeviceDataGridViewTextBoxColumn.HeaderText = "Ser_Device";
            this.serDeviceDataGridViewTextBoxColumn.Name = "serDeviceDataGridViewTextBoxColumn";
            // 
            // serDeviceIDCodeDataGridViewTextBoxColumn
            // 
            this.serDeviceIDCodeDataGridViewTextBoxColumn.DataPropertyName = "Ser_Device_ID_Code";
            this.serDeviceIDCodeDataGridViewTextBoxColumn.HeaderText = "Ser_Device_ID_Code";
            this.serDeviceIDCodeDataGridViewTextBoxColumn.Name = "serDeviceIDCodeDataGridViewTextBoxColumn";
            // 
            // serOfficialSerialDataGridViewTextBoxColumn
            // 
            this.serOfficialSerialDataGridViewTextBoxColumn.DataPropertyName = "Ser_OfficialSerial";
            this.serOfficialSerialDataGridViewTextBoxColumn.HeaderText = "Ser_OfficialSerial";
            this.serOfficialSerialDataGridViewTextBoxColumn.Name = "serOfficialSerialDataGridViewTextBoxColumn";
            // 
            // serReadSerialDataGridViewTextBoxColumn
            // 
            this.serReadSerialDataGridViewTextBoxColumn.DataPropertyName = "Ser_ReadSerial";
            this.serReadSerialDataGridViewTextBoxColumn.HeaderText = "Ser_ReadSerial";
            this.serReadSerialDataGridViewTextBoxColumn.Name = "serReadSerialDataGridViewTextBoxColumn";
            // 
            // serSWCodeDataGridViewTextBoxColumn
            // 
            this.serSWCodeDataGridViewTextBoxColumn.DataPropertyName = "Ser_SW_Code";
            this.serSWCodeDataGridViewTextBoxColumn.HeaderText = "Ser_SW_Code";
            this.serSWCodeDataGridViewTextBoxColumn.Name = "serSWCodeDataGridViewTextBoxColumn";
            // 
            // serSWCodeRevDataGridViewTextBoxColumn
            // 
            this.serSWCodeRevDataGridViewTextBoxColumn.DataPropertyName = "Ser_SW_Code_Rev";
            this.serSWCodeRevDataGridViewTextBoxColumn.HeaderText = "Ser_SW_Code_Rev";
            this.serSWCodeRevDataGridViewTextBoxColumn.Name = "serSWCodeRevDataGridViewTextBoxColumn";
            // 
            // rAGIONESOCIALEDataGridViewTextBoxColumn
            // 
            this.rAGIONESOCIALEDataGridViewTextBoxColumn.DataPropertyName = "RAGIONESOCIALE";
            this.rAGIONESOCIALEDataGridViewTextBoxColumn.HeaderText = "RAGIONESOCIALE";
            this.rAGIONESOCIALEDataGridViewTextBoxColumn.Name = "rAGIONESOCIALEDataGridViewTextBoxColumn";
            // 
            // iNDIRIZZODataGridViewTextBoxColumn
            // 
            this.iNDIRIZZODataGridViewTextBoxColumn.DataPropertyName = "INDIRIZZO";
            this.iNDIRIZZODataGridViewTextBoxColumn.HeaderText = "INDIRIZZO";
            this.iNDIRIZZODataGridViewTextBoxColumn.Name = "iNDIRIZZODataGridViewTextBoxColumn";
            // 
            // nUMEROCIVICODataGridViewTextBoxColumn
            // 
            this.nUMEROCIVICODataGridViewTextBoxColumn.DataPropertyName = "NUMERO_CIVICO";
            this.nUMEROCIVICODataGridViewTextBoxColumn.HeaderText = "NUMERO_CIVICO";
            this.nUMEROCIVICODataGridViewTextBoxColumn.Name = "nUMEROCIVICODataGridViewTextBoxColumn";
            // 
            // fRAZIONEDataGridViewTextBoxColumn
            // 
            this.fRAZIONEDataGridViewTextBoxColumn.DataPropertyName = "FRAZIONE";
            this.fRAZIONEDataGridViewTextBoxColumn.HeaderText = "FRAZIONE";
            this.fRAZIONEDataGridViewTextBoxColumn.Name = "fRAZIONEDataGridViewTextBoxColumn";
            // 
            // cAPDataGridViewTextBoxColumn
            // 
            this.cAPDataGridViewTextBoxColumn.DataPropertyName = "CAP";
            this.cAPDataGridViewTextBoxColumn.HeaderText = "CAP";
            this.cAPDataGridViewTextBoxColumn.Name = "cAPDataGridViewTextBoxColumn";
            // 
            // cOMUNEDataGridViewTextBoxColumn
            // 
            this.cOMUNEDataGridViewTextBoxColumn.DataPropertyName = "COMUNE";
            this.cOMUNEDataGridViewTextBoxColumn.HeaderText = "COMUNE";
            this.cOMUNEDataGridViewTextBoxColumn.Name = "cOMUNEDataGridViewTextBoxColumn";
            // 
            // pROVINCIADataGridViewTextBoxColumn
            // 
            this.pROVINCIADataGridViewTextBoxColumn.DataPropertyName = "PROVINCIA";
            this.pROVINCIADataGridViewTextBoxColumn.HeaderText = "PROVINCIA";
            this.pROVINCIADataGridViewTextBoxColumn.Name = "pROVINCIADataGridViewTextBoxColumn";
            // 
            // rEGIONEDataGridViewTextBoxColumn
            // 
            this.rEGIONEDataGridViewTextBoxColumn.DataPropertyName = "REGIONE";
            this.rEGIONEDataGridViewTextBoxColumn.HeaderText = "REGIONE";
            this.rEGIONEDataGridViewTextBoxColumn.Name = "rEGIONEDataGridViewTextBoxColumn";
            // 
            // pREFISSOTELEFONODataGridViewTextBoxColumn
            // 
            this.pREFISSOTELEFONODataGridViewTextBoxColumn.DataPropertyName = "PREFISSO_TELEFONO";
            this.pREFISSOTELEFONODataGridViewTextBoxColumn.HeaderText = "PREFISSO_TELEFONO";
            this.pREFISSOTELEFONODataGridViewTextBoxColumn.Name = "pREFISSOTELEFONODataGridViewTextBoxColumn";
            // 
            // nUMEROTELEFONODataGridViewTextBoxColumn
            // 
            this.nUMEROTELEFONODataGridViewTextBoxColumn.DataPropertyName = "NUMERO_TELEFONO";
            this.nUMEROTELEFONODataGridViewTextBoxColumn.HeaderText = "NUMERO_TELEFONO";
            this.nUMEROTELEFONODataGridViewTextBoxColumn.Name = "nUMEROTELEFONODataGridViewTextBoxColumn";
            // 
            // pREFISSOTELEFONOAGGIUNTIVODataGridViewTextBoxColumn
            // 
            this.pREFISSOTELEFONOAGGIUNTIVODataGridViewTextBoxColumn.DataPropertyName = "PREFISSO_TELEFONO_AGGIUNTIVO";
            this.pREFISSOTELEFONOAGGIUNTIVODataGridViewTextBoxColumn.HeaderText = "PREFISSO_TELEFONO_AGGIUNTIVO";
            this.pREFISSOTELEFONOAGGIUNTIVODataGridViewTextBoxColumn.Name = "pREFISSOTELEFONOAGGIUNTIVODataGridViewTextBoxColumn";
            // 
            // nUMEROTELEFONOAGGIUNTIVODataGridViewTextBoxColumn
            // 
            this.nUMEROTELEFONOAGGIUNTIVODataGridViewTextBoxColumn.DataPropertyName = "NUMERO_TELEFONO_AGGIUNTIVO";
            this.nUMEROTELEFONOAGGIUNTIVODataGridViewTextBoxColumn.HeaderText = "NUMERO_TELEFONO_AGGIUNTIVO";
            this.nUMEROTELEFONOAGGIUNTIVODataGridViewTextBoxColumn.Name = "nUMEROTELEFONOAGGIUNTIVODataGridViewTextBoxColumn";
            // 
            // eMailDataGridViewTextBoxColumn
            // 
            this.eMailDataGridViewTextBoxColumn.DataPropertyName = "EMail";
            this.eMailDataGridViewTextBoxColumn.HeaderText = "EMail";
            this.eMailDataGridViewTextBoxColumn.Name = "eMailDataGridViewTextBoxColumn";
            // 
            // eMAILPECDataGridViewTextBoxColumn
            // 
            this.eMAILPECDataGridViewTextBoxColumn.DataPropertyName = "EMAIL_PEC";
            this.eMAILPECDataGridViewTextBoxColumn.HeaderText = "EMAIL_PEC";
            this.eMAILPECDataGridViewTextBoxColumn.Name = "eMAILPECDataGridViewTextBoxColumn";
            // 
            // sWDescrizioneDataGridViewTextBoxColumn
            // 
            this.sWDescrizioneDataGridViewTextBoxColumn.DataPropertyName = "SW_Descrizione";
            this.sWDescrizioneDataGridViewTextBoxColumn.HeaderText = "SW_Descrizione";
            this.sWDescrizioneDataGridViewTextBoxColumn.Name = "sWDescrizioneDataGridViewTextBoxColumn";
            // 
            // sWRevisioniDataGridViewTextBoxColumn
            // 
            this.sWRevisioniDataGridViewTextBoxColumn.DataPropertyName = "SW_Revisioni";
            this.sWRevisioniDataGridViewTextBoxColumn.HeaderText = "SW_Revisioni";
            this.sWRevisioniDataGridViewTextBoxColumn.Name = "sWRevisioniDataGridViewTextBoxColumn";
            // 
            // sWFunzionamentoDataGridViewTextBoxColumn
            // 
            this.sWFunzionamentoDataGridViewTextBoxColumn.DataPropertyName = "SW_Funzionamento";
            this.sWFunzionamentoDataGridViewTextBoxColumn.HeaderText = "SW_Funzionamento";
            this.sWFunzionamentoDataGridViewTextBoxColumn.Name = "sWFunzionamentoDataGridViewTextBoxColumn";
            // 
            // desKitDataGridViewTextBoxColumn
            // 
            this.desKitDataGridViewTextBoxColumn.DataPropertyName = "Des_Kit";
            this.desKitDataGridViewTextBoxColumn.HeaderText = "Des_Kit";
            this.desKitDataGridViewTextBoxColumn.Name = "desKitDataGridViewTextBoxColumn";
            // 
            // desEstKitDataGridViewTextBoxColumn
            // 
            this.desEstKitDataGridViewTextBoxColumn.DataPropertyName = "DesEst_Kit";
            this.desEstKitDataGridViewTextBoxColumn.HeaderText = "DesEst_Kit";
            this.desEstKitDataGridViewTextBoxColumn.Name = "desEstKitDataGridViewTextBoxColumn";
            // 
            // modelloDataGridViewTextBoxColumn
            // 
            this.modelloDataGridViewTextBoxColumn.DataPropertyName = "Modello";
            this.modelloDataGridViewTextBoxColumn.HeaderText = "Modello";
            this.modelloDataGridViewTextBoxColumn.Name = "modelloDataGridViewTextBoxColumn";
            this.modelloDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // desDeviceDataGridViewTextBoxColumn
            // 
            this.desDeviceDataGridViewTextBoxColumn.DataPropertyName = "Des_Device";
            this.desDeviceDataGridViewTextBoxColumn.HeaderText = "Des_Device";
            this.desDeviceDataGridViewTextBoxColumn.Name = "desDeviceDataGridViewTextBoxColumn";
            // 
            // desEstDeviceDataGridViewTextBoxColumn
            // 
            this.desEstDeviceDataGridViewTextBoxColumn.DataPropertyName = "DesEst_Device";
            this.desEstDeviceDataGridViewTextBoxColumn.HeaderText = "DesEst_Device";
            this.desEstDeviceDataGridViewTextBoxColumn.Name = "desEstDeviceDataGridViewTextBoxColumn";
            // 
            // fWversDataGridViewTextBoxColumn
            // 
            this.fWversDataGridViewTextBoxColumn.DataPropertyName = "FW_vers";
            this.fWversDataGridViewTextBoxColumn.HeaderText = "FW_vers";
            this.fWversDataGridViewTextBoxColumn.Name = "fWversDataGridViewTextBoxColumn";
            // 
            // fWrevDataGridViewTextBoxColumn
            // 
            this.fWrevDataGridViewTextBoxColumn.DataPropertyName = "FW_rev";
            this.fWrevDataGridViewTextBoxColumn.HeaderText = "FW_rev";
            this.fWrevDataGridViewTextBoxColumn.Name = "fWrevDataGridViewTextBoxColumn";
            // 
            // serSWStdTypeDataGridViewCheckBoxColumn
            // 
            this.serSWStdTypeDataGridViewCheckBoxColumn.DataPropertyName = "Ser_SW_Std_Type";
            this.serSWStdTypeDataGridViewCheckBoxColumn.HeaderText = "Ser_SW_Std_Type";
            this.serSWStdTypeDataGridViewCheckBoxColumn.Name = "serSWStdTypeDataGridViewCheckBoxColumn";
            // 
            // serSNprodDataGridViewTextBoxColumn
            // 
            this.serSNprodDataGridViewTextBoxColumn.DataPropertyName = "Ser_SN_prod";
            this.serSNprodDataGridViewTextBoxColumn.HeaderText = "Ser_SN_prod";
            this.serSNprodDataGridViewTextBoxColumn.Name = "serSNprodDataGridViewTextBoxColumn";
            // 
            // serCommessaDataGridViewTextBoxColumn
            // 
            this.serCommessaDataGridViewTextBoxColumn.DataPropertyName = "Ser_Commessa";
            this.serCommessaDataGridViewTextBoxColumn.HeaderText = "Ser_Commessa";
            this.serCommessaDataGridViewTextBoxColumn.Name = "serCommessaDataGridViewTextBoxColumn";
            // 
            // serDateProductionDataGridViewTextBoxColumn
            // 
            this.serDateProductionDataGridViewTextBoxColumn.DataPropertyName = "Ser_DateProduction";
            this.serDateProductionDataGridViewTextBoxColumn.HeaderText = "Ser_DateProduction";
            this.serDateProductionDataGridViewTextBoxColumn.Name = "serDateProductionDataGridViewTextBoxColumn";
            // 
            // serSpeditoDataGridViewCheckBoxColumn
            // 
            this.serSpeditoDataGridViewCheckBoxColumn.DataPropertyName = "Ser_Spedito";
            this.serSpeditoDataGridViewCheckBoxColumn.HeaderText = "Ser_Spedito";
            this.serSpeditoDataGridViewCheckBoxColumn.Name = "serSpeditoDataGridViewCheckBoxColumn";
            // 
            // serDataSpeditoDataGridViewTextBoxColumn
            // 
            this.serDataSpeditoDataGridViewTextBoxColumn.DataPropertyName = "Ser_Data_Spedito";
            this.serDataSpeditoDataGridViewTextBoxColumn.HeaderText = "Ser_Data_Spedito";
            this.serDataSpeditoDataGridViewTextBoxColumn.Name = "serDataSpeditoDataGridViewTextBoxColumn";
            // 
            // serSubstitionIDReadSerialDataGridViewTextBoxColumn
            // 
            this.serSubstitionIDReadSerialDataGridViewTextBoxColumn.DataPropertyName = "Ser_Substition_ID_ReadSerial";
            this.serSubstitionIDReadSerialDataGridViewTextBoxColumn.HeaderText = "Ser_Substition_ID_ReadSerial";
            this.serSubstitionIDReadSerialDataGridViewTextBoxColumn.Name = "serSubstitionIDReadSerialDataGridViewTextBoxColumn";
            // 
            // serNoteDataGridViewTextBoxColumn
            // 
            this.serNoteDataGridViewTextBoxColumn.DataPropertyName = "Ser_Note";
            this.serNoteDataGridViewTextBoxColumn.HeaderText = "Ser_Note";
            this.serNoteDataGridViewTextBoxColumn.Name = "serNoteDataGridViewTextBoxColumn";
            // 
            // sWObsoleteverDataGridViewCheckBoxColumn
            // 
            this.sWObsoleteverDataGridViewCheckBoxColumn.DataPropertyName = "SW_Obsolete_ver";
            this.sWObsoleteverDataGridViewCheckBoxColumn.HeaderText = "SW_Obsolete_ver";
            this.sWObsoleteverDataGridViewCheckBoxColumn.Name = "sWObsoleteverDataGridViewCheckBoxColumn";
            // 
            // sWObsoleteverfromdateDataGridViewTextBoxColumn
            // 
            this.sWObsoleteverfromdateDataGridViewTextBoxColumn.DataPropertyName = "SW_Obsolete_ver_from_date";
            this.sWObsoleteverfromdateDataGridViewTextBoxColumn.HeaderText = "SW_Obsolete_ver_from_date";
            this.sWObsoleteverfromdateDataGridViewTextBoxColumn.Name = "sWObsoleteverfromdateDataGridViewTextBoxColumn";
            // 
            // sFSNarsnSFSNQueryBindingSource
            // 
            this.sFSNarsnSFSNQueryBindingSource.DataMember = "SF_SN_arsn_SF_SN_Query";
            this.sFSNarsnSFSNQueryBindingSource.DataSource = this.sFSNarsnBindingSource;
            // 
            // metroLabel3
            // 
            this.metroLabel3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel3.AutoSize = true;
            this.layout_Schede.SetColumnSpan(this.metroLabel3, 5);
            this.metroLabel3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNartaBindingSource, "DescrizioneEstesa", true));
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Location = new System.Drawing.Point(363, 28);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(69, 19);
            this.metroLabel3.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel3.TabIndex = 23;
            this.metroLabel3.Text = "DesEstArt";
            this.metroLabel3.UseStyleColors = true;
            // 
            // sFSNarsnSFSNartaBindingSource
            // 
            this.sFSNarsnSFSNartaBindingSource.DataMember = "SF_SN_arsn_SF_SN_arta";
            this.sFSNarsnSFSNartaBindingSource.DataSource = this.sFSNarsnBindingSource;
            // 
            // metroLabel2
            // 
            this.metroLabel2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel2.AutoSize = true;
            this.layout_Schede.SetColumnSpan(this.metroLabel2, 5);
            this.metroLabel2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNartaBindingSource, "Descrizione", true));
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Location = new System.Drawing.Point(363, 3);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(51, 19);
            this.metroLabel2.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel2.TabIndex = 22;
            this.metroLabel2.Text = "DesArt";
            this.metroLabel2.UseStyleColors = true;
            // 
            // metroLabel1
            // 
            this.metroLabel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(243, 3);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(81, 19);
            this.metroLabel1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel1.TabIndex = 21;
            this.metroLabel1.Text = "Descrizione:";
            // 
            // panel_grid
            // 
            this.layout_Schede.SetColumnSpan(this.panel_grid, 2);
            this.panel_grid.Controls.Add(this.gv_SN);
            this.panel_grid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_grid.HorizontalScrollbarBarColor = true;
            this.panel_grid.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_grid.HorizontalScrollbarSize = 10;
            this.panel_grid.Location = new System.Drawing.Point(3, 3);
            this.panel_grid.Name = "panel_grid";
            this.layout_Schede.SetRowSpan(this.panel_grid, 13);
            this.panel_grid.Size = new System.Drawing.Size(234, 458);
            this.panel_grid.TabIndex = 17;
            this.panel_grid.VerticalScrollbarBarColor = true;
            this.panel_grid.VerticalScrollbarHighlightOnWheel = false;
            this.panel_grid.VerticalScrollbarSize = 10;
            // 
            // gv_SN
            // 
            this.gv_SN.AllowUserToAddRows = false;
            this.gv_SN.AllowUserToDeleteRows = false;
            this.gv_SN.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_SN.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.gv_SN.AutoGenerateColumns = false;
            this.gv_SN.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_SN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_SN.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_SN.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_SN.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.gv_SN.ColumnHeadersHeight = 40;
            this.gv_SN.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serialNumberDataGridViewTextBoxColumn,
            this.articoloDataGridViewTextBoxColumn,
            this.entitaDataGridViewTextBoxColumn,
            this.serieDataGridViewTextBoxColumn,
            this.partitaDataGridViewTextBoxColumn,
            this.dataInizioGarForDataGridViewTextBoxColumn,
            this.flObsoletoDataGridViewTextBoxColumn,
            this.dataTrasfObsoletoDataGridViewTextBoxColumn,
            this.nume01DataGridViewTextBoxColumn,
            this.dataRegMovInizDataGridViewTextBoxColumn,
            this.progRegMovInizDataGridViewTextBoxColumn,
            this.progContrMovInizDataGridViewTextBoxColumn,
            this.serialNumberEstDataGridViewTextBoxColumn,
            this.flTrasfWebDataGridViewTextBoxColumn,
            this.iDUtenteDataGridViewTextBoxColumn,
            this.iDTerminaleDataGridViewTextBoxColumn,
            this.dataUltModificaDataGridViewTextBoxColumn});
            this.gv_SN.DataSource = this.sFSNarsnBindingSource;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_SN.DefaultCellStyle = dataGridViewCellStyle6;
            this.gv_SN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_SN.EnableHeadersVisualStyles = false;
            this.gv_SN.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_SN.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_SN.Location = new System.Drawing.Point(0, 0);
            this.gv_SN.MultiSelect = false;
            this.gv_SN.Name = "gv_SN";
            this.gv_SN.ReadOnly = true;
            this.gv_SN.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_SN.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.gv_SN.RowHeadersVisible = false;
            this.gv_SN.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_SN.RowTemplate.Height = 30;
            this.gv_SN.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_SN.Size = new System.Drawing.Size(234, 458);
            this.gv_SN.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_SN.TabIndex = 2;
            this.gv_SN.UseStyleColors = true;
            // 
            // serialNumberDataGridViewTextBoxColumn
            // 
            this.serialNumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.serialNumberDataGridViewTextBoxColumn.DataPropertyName = "SerialNumber";
            this.serialNumberDataGridViewTextBoxColumn.HeaderText = "S/N";
            this.serialNumberDataGridViewTextBoxColumn.Name = "serialNumberDataGridViewTextBoxColumn";
            this.serialNumberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // articoloDataGridViewTextBoxColumn
            // 
            this.articoloDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.articoloDataGridViewTextBoxColumn.DataPropertyName = "Articolo";
            this.articoloDataGridViewTextBoxColumn.HeaderText = "Articolo";
            this.articoloDataGridViewTextBoxColumn.Name = "articoloDataGridViewTextBoxColumn";
            this.articoloDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // entitaDataGridViewTextBoxColumn
            // 
            this.entitaDataGridViewTextBoxColumn.DataPropertyName = "Entita";
            this.entitaDataGridViewTextBoxColumn.HeaderText = "Entita";
            this.entitaDataGridViewTextBoxColumn.Name = "entitaDataGridViewTextBoxColumn";
            this.entitaDataGridViewTextBoxColumn.ReadOnly = true;
            this.entitaDataGridViewTextBoxColumn.Visible = false;
            // 
            // serieDataGridViewTextBoxColumn
            // 
            this.serieDataGridViewTextBoxColumn.DataPropertyName = "Serie";
            this.serieDataGridViewTextBoxColumn.HeaderText = "Serie";
            this.serieDataGridViewTextBoxColumn.Name = "serieDataGridViewTextBoxColumn";
            this.serieDataGridViewTextBoxColumn.ReadOnly = true;
            this.serieDataGridViewTextBoxColumn.Visible = false;
            // 
            // partitaDataGridViewTextBoxColumn
            // 
            this.partitaDataGridViewTextBoxColumn.DataPropertyName = "Partita";
            this.partitaDataGridViewTextBoxColumn.HeaderText = "Partita";
            this.partitaDataGridViewTextBoxColumn.Name = "partitaDataGridViewTextBoxColumn";
            this.partitaDataGridViewTextBoxColumn.ReadOnly = true;
            this.partitaDataGridViewTextBoxColumn.Visible = false;
            // 
            // dataInizioGarForDataGridViewTextBoxColumn
            // 
            this.dataInizioGarForDataGridViewTextBoxColumn.DataPropertyName = "DataInizioGarFor";
            this.dataInizioGarForDataGridViewTextBoxColumn.HeaderText = "DataInizioGarFor";
            this.dataInizioGarForDataGridViewTextBoxColumn.Name = "dataInizioGarForDataGridViewTextBoxColumn";
            this.dataInizioGarForDataGridViewTextBoxColumn.ReadOnly = true;
            this.dataInizioGarForDataGridViewTextBoxColumn.Visible = false;
            // 
            // flObsoletoDataGridViewTextBoxColumn
            // 
            this.flObsoletoDataGridViewTextBoxColumn.DataPropertyName = "FlObsoleto";
            this.flObsoletoDataGridViewTextBoxColumn.HeaderText = "FlObsoleto";
            this.flObsoletoDataGridViewTextBoxColumn.Name = "flObsoletoDataGridViewTextBoxColumn";
            this.flObsoletoDataGridViewTextBoxColumn.ReadOnly = true;
            this.flObsoletoDataGridViewTextBoxColumn.Visible = false;
            // 
            // dataTrasfObsoletoDataGridViewTextBoxColumn
            // 
            this.dataTrasfObsoletoDataGridViewTextBoxColumn.DataPropertyName = "DataTrasfObsoleto";
            this.dataTrasfObsoletoDataGridViewTextBoxColumn.HeaderText = "DataTrasfObsoleto";
            this.dataTrasfObsoletoDataGridViewTextBoxColumn.Name = "dataTrasfObsoletoDataGridViewTextBoxColumn";
            this.dataTrasfObsoletoDataGridViewTextBoxColumn.ReadOnly = true;
            this.dataTrasfObsoletoDataGridViewTextBoxColumn.Visible = false;
            // 
            // nume01DataGridViewTextBoxColumn
            // 
            this.nume01DataGridViewTextBoxColumn.DataPropertyName = "Nume01";
            this.nume01DataGridViewTextBoxColumn.HeaderText = "Nume01";
            this.nume01DataGridViewTextBoxColumn.Name = "nume01DataGridViewTextBoxColumn";
            this.nume01DataGridViewTextBoxColumn.ReadOnly = true;
            this.nume01DataGridViewTextBoxColumn.Visible = false;
            // 
            // dataRegMovInizDataGridViewTextBoxColumn
            // 
            this.dataRegMovInizDataGridViewTextBoxColumn.DataPropertyName = "DataRegMovIniz";
            this.dataRegMovInizDataGridViewTextBoxColumn.HeaderText = "DataRegMovIniz";
            this.dataRegMovInizDataGridViewTextBoxColumn.Name = "dataRegMovInizDataGridViewTextBoxColumn";
            this.dataRegMovInizDataGridViewTextBoxColumn.ReadOnly = true;
            this.dataRegMovInizDataGridViewTextBoxColumn.Visible = false;
            // 
            // progRegMovInizDataGridViewTextBoxColumn
            // 
            this.progRegMovInizDataGridViewTextBoxColumn.DataPropertyName = "ProgRegMovIniz";
            this.progRegMovInizDataGridViewTextBoxColumn.HeaderText = "ProgRegMovIniz";
            this.progRegMovInizDataGridViewTextBoxColumn.Name = "progRegMovInizDataGridViewTextBoxColumn";
            this.progRegMovInizDataGridViewTextBoxColumn.ReadOnly = true;
            this.progRegMovInizDataGridViewTextBoxColumn.Visible = false;
            // 
            // progContrMovInizDataGridViewTextBoxColumn
            // 
            this.progContrMovInizDataGridViewTextBoxColumn.DataPropertyName = "ProgContrMovIniz";
            this.progContrMovInizDataGridViewTextBoxColumn.HeaderText = "ProgContrMovIniz";
            this.progContrMovInizDataGridViewTextBoxColumn.Name = "progContrMovInizDataGridViewTextBoxColumn";
            this.progContrMovInizDataGridViewTextBoxColumn.ReadOnly = true;
            this.progContrMovInizDataGridViewTextBoxColumn.Visible = false;
            // 
            // serialNumberEstDataGridViewTextBoxColumn
            // 
            this.serialNumberEstDataGridViewTextBoxColumn.DataPropertyName = "SerialNumberEst";
            this.serialNumberEstDataGridViewTextBoxColumn.HeaderText = "SerialNumberEst";
            this.serialNumberEstDataGridViewTextBoxColumn.Name = "serialNumberEstDataGridViewTextBoxColumn";
            this.serialNumberEstDataGridViewTextBoxColumn.ReadOnly = true;
            this.serialNumberEstDataGridViewTextBoxColumn.Visible = false;
            // 
            // flTrasfWebDataGridViewTextBoxColumn
            // 
            this.flTrasfWebDataGridViewTextBoxColumn.DataPropertyName = "FlTrasfWeb";
            this.flTrasfWebDataGridViewTextBoxColumn.HeaderText = "FlTrasfWeb";
            this.flTrasfWebDataGridViewTextBoxColumn.Name = "flTrasfWebDataGridViewTextBoxColumn";
            this.flTrasfWebDataGridViewTextBoxColumn.ReadOnly = true;
            this.flTrasfWebDataGridViewTextBoxColumn.Visible = false;
            // 
            // iDUtenteDataGridViewTextBoxColumn
            // 
            this.iDUtenteDataGridViewTextBoxColumn.DataPropertyName = "IDUtente";
            this.iDUtenteDataGridViewTextBoxColumn.HeaderText = "IDUtente";
            this.iDUtenteDataGridViewTextBoxColumn.Name = "iDUtenteDataGridViewTextBoxColumn";
            this.iDUtenteDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDUtenteDataGridViewTextBoxColumn.Visible = false;
            // 
            // iDTerminaleDataGridViewTextBoxColumn
            // 
            this.iDTerminaleDataGridViewTextBoxColumn.DataPropertyName = "IDTerminale";
            this.iDTerminaleDataGridViewTextBoxColumn.HeaderText = "IDTerminale";
            this.iDTerminaleDataGridViewTextBoxColumn.Name = "iDTerminaleDataGridViewTextBoxColumn";
            this.iDTerminaleDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDTerminaleDataGridViewTextBoxColumn.Visible = false;
            // 
            // dataUltModificaDataGridViewTextBoxColumn
            // 
            this.dataUltModificaDataGridViewTextBoxColumn.DataPropertyName = "DataUltModifica";
            this.dataUltModificaDataGridViewTextBoxColumn.HeaderText = "DataUltModifica";
            this.dataUltModificaDataGridViewTextBoxColumn.Name = "dataUltModificaDataGridViewTextBoxColumn";
            this.dataUltModificaDataGridViewTextBoxColumn.ReadOnly = true;
            this.dataUltModificaDataGridViewTextBoxColumn.Visible = false;
            // 
            // metroGrid1
            // 
            this.metroGrid1.AllowUserToResizeRows = false;
            this.metroGrid1.AutoGenerateColumns = false;
            this.metroGrid1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.metroGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.articoloDataGridViewTextBoxColumn1,
            this.serialNumberDataGridViewTextBoxColumn1,
            this.ragSocCognomeDataGridViewTextBoxColumn,
            this.ragSocNomeDataGridViewTextBoxColumn,
            this.ragSocCompletaDataGridViewTextBoxColumn,
            this.descrizioneDataGridViewTextBoxColumn,
            this.codAnagraficoDataGridViewTextBoxColumn,
            this.dataDocumentoDataGridViewTextBoxColumn,
            this.numeroOrdineDataGridViewTextBoxColumn,
            this.dataOrdineDataGridViewTextBoxColumn,
            this.rigaOrdineDataGridViewTextBoxColumn,
            this.tipoBollaFatturaDataGridViewTextBoxColumn,
            this.numeroBollaFatturaDataGridViewTextBoxColumn,
            this.dataBollaFatturaDataGridViewTextBoxColumn,
            this.numeroBrogliaccioDataGridViewTextBoxColumn,
            this.rigaBrogliaccioDataGridViewTextBoxColumn,
            this.commessaDataGridViewTextBoxColumn,
            this.articoloOrdineDataGridViewTextBoxColumn});
            this.layout_Schede.SetColumnSpan(this.metroGrid1, 3);
            this.metroGrid1.DataSource = this.sFSNarsnSFmomamosnBindingSource;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid1.DefaultCellStyle = dataGridViewCellStyle9;
            this.metroGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroGrid1.EnableHeadersVisualStyles = false;
            this.metroGrid1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.Location = new System.Drawing.Point(363, 499);
            this.metroGrid1.Name = "metroGrid1";
            this.metroGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.RowHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.metroGrid1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.layout_Schede.SetRowSpan(this.metroGrid1, 6);
            this.metroGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid1.Size = new System.Drawing.Size(354, 98);
            this.metroGrid1.TabIndex = 24;
            // 
            // articoloDataGridViewTextBoxColumn1
            // 
            this.articoloDataGridViewTextBoxColumn1.DataPropertyName = "Articolo";
            this.articoloDataGridViewTextBoxColumn1.HeaderText = "Articolo";
            this.articoloDataGridViewTextBoxColumn1.Name = "articoloDataGridViewTextBoxColumn1";
            this.articoloDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // serialNumberDataGridViewTextBoxColumn1
            // 
            this.serialNumberDataGridViewTextBoxColumn1.DataPropertyName = "SerialNumber";
            this.serialNumberDataGridViewTextBoxColumn1.HeaderText = "SerialNumber";
            this.serialNumberDataGridViewTextBoxColumn1.Name = "serialNumberDataGridViewTextBoxColumn1";
            // 
            // ragSocCognomeDataGridViewTextBoxColumn
            // 
            this.ragSocCognomeDataGridViewTextBoxColumn.DataPropertyName = "RagSocCognome";
            this.ragSocCognomeDataGridViewTextBoxColumn.HeaderText = "RagSocCognome";
            this.ragSocCognomeDataGridViewTextBoxColumn.Name = "ragSocCognomeDataGridViewTextBoxColumn";
            // 
            // ragSocNomeDataGridViewTextBoxColumn
            // 
            this.ragSocNomeDataGridViewTextBoxColumn.DataPropertyName = "RagSocNome";
            this.ragSocNomeDataGridViewTextBoxColumn.HeaderText = "RagSocNome";
            this.ragSocNomeDataGridViewTextBoxColumn.Name = "ragSocNomeDataGridViewTextBoxColumn";
            // 
            // ragSocCompletaDataGridViewTextBoxColumn
            // 
            this.ragSocCompletaDataGridViewTextBoxColumn.DataPropertyName = "RagSocCompleta";
            this.ragSocCompletaDataGridViewTextBoxColumn.HeaderText = "RagSocCompleta";
            this.ragSocCompletaDataGridViewTextBoxColumn.Name = "ragSocCompletaDataGridViewTextBoxColumn";
            // 
            // descrizioneDataGridViewTextBoxColumn
            // 
            this.descrizioneDataGridViewTextBoxColumn.DataPropertyName = "Descrizione";
            this.descrizioneDataGridViewTextBoxColumn.HeaderText = "Descrizione";
            this.descrizioneDataGridViewTextBoxColumn.Name = "descrizioneDataGridViewTextBoxColumn";
            // 
            // codAnagraficoDataGridViewTextBoxColumn
            // 
            this.codAnagraficoDataGridViewTextBoxColumn.DataPropertyName = "CodAnagrafico";
            this.codAnagraficoDataGridViewTextBoxColumn.HeaderText = "CodAnagrafico";
            this.codAnagraficoDataGridViewTextBoxColumn.Name = "codAnagraficoDataGridViewTextBoxColumn";
            // 
            // dataDocumentoDataGridViewTextBoxColumn
            // 
            this.dataDocumentoDataGridViewTextBoxColumn.DataPropertyName = "DataDocumento";
            this.dataDocumentoDataGridViewTextBoxColumn.HeaderText = "DataDocumento";
            this.dataDocumentoDataGridViewTextBoxColumn.Name = "dataDocumentoDataGridViewTextBoxColumn";
            // 
            // numeroOrdineDataGridViewTextBoxColumn
            // 
            this.numeroOrdineDataGridViewTextBoxColumn.DataPropertyName = "NumeroOrdine";
            this.numeroOrdineDataGridViewTextBoxColumn.HeaderText = "NumeroOrdine";
            this.numeroOrdineDataGridViewTextBoxColumn.Name = "numeroOrdineDataGridViewTextBoxColumn";
            // 
            // dataOrdineDataGridViewTextBoxColumn
            // 
            this.dataOrdineDataGridViewTextBoxColumn.DataPropertyName = "DataOrdine";
            this.dataOrdineDataGridViewTextBoxColumn.HeaderText = "DataOrdine";
            this.dataOrdineDataGridViewTextBoxColumn.Name = "dataOrdineDataGridViewTextBoxColumn";
            // 
            // rigaOrdineDataGridViewTextBoxColumn
            // 
            this.rigaOrdineDataGridViewTextBoxColumn.DataPropertyName = "RigaOrdine";
            this.rigaOrdineDataGridViewTextBoxColumn.HeaderText = "RigaOrdine";
            this.rigaOrdineDataGridViewTextBoxColumn.Name = "rigaOrdineDataGridViewTextBoxColumn";
            // 
            // tipoBollaFatturaDataGridViewTextBoxColumn
            // 
            this.tipoBollaFatturaDataGridViewTextBoxColumn.DataPropertyName = "TipoBollaFattura";
            this.tipoBollaFatturaDataGridViewTextBoxColumn.HeaderText = "TipoBollaFattura";
            this.tipoBollaFatturaDataGridViewTextBoxColumn.Name = "tipoBollaFatturaDataGridViewTextBoxColumn";
            // 
            // numeroBollaFatturaDataGridViewTextBoxColumn
            // 
            this.numeroBollaFatturaDataGridViewTextBoxColumn.DataPropertyName = "NumeroBollaFattura";
            this.numeroBollaFatturaDataGridViewTextBoxColumn.HeaderText = "NumeroBollaFattura";
            this.numeroBollaFatturaDataGridViewTextBoxColumn.Name = "numeroBollaFatturaDataGridViewTextBoxColumn";
            // 
            // dataBollaFatturaDataGridViewTextBoxColumn
            // 
            this.dataBollaFatturaDataGridViewTextBoxColumn.DataPropertyName = "DataBollaFattura";
            this.dataBollaFatturaDataGridViewTextBoxColumn.HeaderText = "DataBollaFattura";
            this.dataBollaFatturaDataGridViewTextBoxColumn.Name = "dataBollaFatturaDataGridViewTextBoxColumn";
            // 
            // numeroBrogliaccioDataGridViewTextBoxColumn
            // 
            this.numeroBrogliaccioDataGridViewTextBoxColumn.DataPropertyName = "NumeroBrogliaccio";
            this.numeroBrogliaccioDataGridViewTextBoxColumn.HeaderText = "NumeroBrogliaccio";
            this.numeroBrogliaccioDataGridViewTextBoxColumn.Name = "numeroBrogliaccioDataGridViewTextBoxColumn";
            // 
            // rigaBrogliaccioDataGridViewTextBoxColumn
            // 
            this.rigaBrogliaccioDataGridViewTextBoxColumn.DataPropertyName = "RigaBrogliaccio";
            this.rigaBrogliaccioDataGridViewTextBoxColumn.HeaderText = "RigaBrogliaccio";
            this.rigaBrogliaccioDataGridViewTextBoxColumn.Name = "rigaBrogliaccioDataGridViewTextBoxColumn";
            // 
            // commessaDataGridViewTextBoxColumn
            // 
            this.commessaDataGridViewTextBoxColumn.DataPropertyName = "Commessa";
            this.commessaDataGridViewTextBoxColumn.HeaderText = "Commessa";
            this.commessaDataGridViewTextBoxColumn.Name = "commessaDataGridViewTextBoxColumn";
            // 
            // articoloOrdineDataGridViewTextBoxColumn
            // 
            this.articoloOrdineDataGridViewTextBoxColumn.DataPropertyName = "Articolo_Ordine";
            this.articoloOrdineDataGridViewTextBoxColumn.HeaderText = "Articolo_Ordine";
            this.articoloOrdineDataGridViewTextBoxColumn.Name = "articoloOrdineDataGridViewTextBoxColumn";
            // 
            // sFSNarsnSFmomamosnBindingSource
            // 
            this.sFSNarsnSFmomamosnBindingSource.DataMember = "SF_SN_arsn_SF_momamosn";
            this.sFSNarsnSFmomamosnBindingSource.DataSource = this.sFSNarsnBindingSource;
            // 
            // metroGrid3
            // 
            this.metroGrid3.AllowUserToResizeRows = false;
            this.metroGrid3.AutoGenerateColumns = false;
            this.metroGrid3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid3.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.metroGrid3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.metroGrid3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn18});
            this.layout_Schede.SetColumnSpan(this.metroGrid3, 3);
            this.metroGrid3.DataSource = this.sFSNmomamosnSFSNbrorBindingSource;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid3.DefaultCellStyle = dataGridViewCellStyle12;
            this.metroGrid3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroGrid3.EnableHeadersVisualStyles = false;
            this.metroGrid3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid3.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid3.Location = new System.Drawing.Point(3, 603);
            this.metroGrid3.Name = "metroGrid3";
            this.metroGrid3.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid3.RowHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.metroGrid3.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.layout_Schede.SetRowSpan(this.metroGrid3, 6);
            this.metroGrid3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid3.Size = new System.Drawing.Size(354, 119);
            this.metroGrid3.TabIndex = 33;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Articolo";
            this.dataGridViewTextBoxColumn2.HeaderText = "Articolo";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Descrizione";
            this.dataGridViewTextBoxColumn7.HeaderText = "Descrizione";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "Commessa";
            this.dataGridViewTextBoxColumn18.HeaderText = "Commessa";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.layout_Schede.SetColumnSpan(this.metroPanel1, 6);
            this.metroPanel1.Controls.Add(this.metroCheckBox2);
            this.metroPanel1.Controls.Add(this.metroCheckBox1);
            this.metroPanel1.Controls.Add(this.metroLabel22);
            this.metroPanel1.Controls.Add(this.metroLabel21);
            this.metroPanel1.Controls.Add(this.metroLabel20);
            this.metroPanel1.Controls.Add(this.metroLabel19);
            this.metroPanel1.Controls.Add(this.metroLabel18);
            this.metroPanel1.Controls.Add(this.metroLabel17);
            this.metroPanel1.Controls.Add(this.metroLabel16);
            this.metroPanel1.Controls.Add(this.metroLabel15);
            this.metroPanel1.Controls.Add(this.metroLabel14);
            this.metroPanel1.Controls.Add(this.metroLabel13);
            this.metroPanel1.Controls.Add(this.metroLabel12);
            this.metroPanel1.Controls.Add(this.metroLabel10);
            this.metroPanel1.Controls.Add(this.metroLabel9);
            this.metroPanel1.Controls.Add(this.metroLabel8);
            this.metroPanel1.Controls.Add(this.metroLabel7);
            this.metroPanel1.Controls.Add(this.metroLabel6);
            this.metroPanel1.Controls.Add(this.metroLabel5);
            this.metroPanel1.Controls.Add(this.metroLabel4);
            this.metroPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(243, 143);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(714, 294);
            this.metroPanel1.TabIndex = 26;
            this.metroPanel1.UseCustomBackColor = true;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // metroCheckBox2
            // 
            this.metroCheckBox2.AutoSize = true;
            this.metroCheckBox2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.metroCheckBox2.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.sFSNarsnSFSNQueryBindingSource, "SW_Obsolete_ver", true));
            this.metroCheckBox2.Location = new System.Drawing.Point(589, 166);
            this.metroCheckBox2.Name = "metroCheckBox2";
            this.metroCheckBox2.Size = new System.Drawing.Size(121, 15);
            this.metroCheckBox2.Style = MetroFramework.MetroColorStyle.Red;
            this.metroCheckBox2.TabIndex = 42;
            this.metroCheckBox2.Text = "Revisione obsoleta";
            this.metroCheckBox2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.metroCheckBox2.UseCustomBackColor = true;
            this.metroCheckBox2.UseSelectable = true;
            this.metroCheckBox2.UseStyleColors = true;
            // 
            // metroCheckBox1
            // 
            this.metroCheckBox1.AutoSize = true;
            this.metroCheckBox1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.metroCheckBox1.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.sFSNarsnSFSNQueryBindingSource, "Ser_SW_Std_Type", true));
            this.metroCheckBox1.Location = new System.Drawing.Point(429, 166);
            this.metroCheckBox1.Name = "metroCheckBox1";
            this.metroCheckBox1.Size = new System.Drawing.Size(122, 15);
            this.metroCheckBox1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroCheckBox1.TabIndex = 41;
            this.metroCheckBox1.Text = "Firmware Standard";
            this.metroCheckBox1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.metroCheckBox1.UseCustomBackColor = true;
            this.metroCheckBox1.UseSelectable = true;
            this.metroCheckBox1.UseStyleColors = true;
            // 
            // metroLabel22
            // 
            this.metroLabel22.AutoSize = true;
            this.metroLabel22.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "DesEst_Device", true));
            this.metroLabel22.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel22.Location = new System.Drawing.Point(300, 106);
            this.metroLabel22.Name = "metroLabel22";
            this.metroLabel22.Size = new System.Drawing.Size(96, 19);
            this.metroLabel22.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel22.TabIndex = 40;
            this.metroLabel22.Text = "DesEst_Device";
            this.metroLabel22.UseCustomBackColor = true;
            this.metroLabel22.UseStyleColors = true;
            // 
            // metroLabel21
            // 
            this.metroLabel21.AutoSize = true;
            this.metroLabel21.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "Des_Device", true));
            this.metroLabel21.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel21.Location = new System.Drawing.Point(300, 87);
            this.metroLabel21.Name = "metroLabel21";
            this.metroLabel21.Size = new System.Drawing.Size(78, 19);
            this.metroLabel21.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel21.TabIndex = 39;
            this.metroLabel21.Text = "Des_Device";
            this.metroLabel21.UseCustomBackColor = true;
            this.metroLabel21.UseStyleColors = true;
            // 
            // metroLabel20
            // 
            this.metroLabel20.AutoSize = true;
            this.metroLabel20.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "DesEst_Kit", true));
            this.metroLabel20.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel20.Location = new System.Drawing.Point(300, 68);
            this.metroLabel20.Name = "metroLabel20";
            this.metroLabel20.Size = new System.Drawing.Size(72, 19);
            this.metroLabel20.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel20.TabIndex = 38;
            this.metroLabel20.Text = "DesEst_Kit";
            this.metroLabel20.UseCustomBackColor = true;
            this.metroLabel20.UseStyleColors = true;
            // 
            // metroLabel19
            // 
            this.metroLabel19.AutoSize = true;
            this.metroLabel19.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "Des_Kit", true));
            this.metroLabel19.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel19.Location = new System.Drawing.Point(300, 49);
            this.metroLabel19.Name = "metroLabel19";
            this.metroLabel19.Size = new System.Drawing.Size(54, 19);
            this.metroLabel19.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel19.TabIndex = 37;
            this.metroLabel19.Text = "Des_Kit";
            this.metroLabel19.UseCustomBackColor = true;
            this.metroLabel19.UseStyleColors = true;
            // 
            // metroLabel18
            // 
            this.metroLabel18.AutoSize = true;
            this.metroLabel18.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "Ser_SW_Code_Rev", true));
            this.metroLabel18.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel18.Location = new System.Drawing.Point(300, 163);
            this.metroLabel18.Name = "metroLabel18";
            this.metroLabel18.Size = new System.Drawing.Size(54, 19);
            this.metroLabel18.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel18.TabIndex = 36;
            this.metroLabel18.Text = "FW_rev";
            this.metroLabel18.UseCustomBackColor = true;
            this.metroLabel18.UseStyleColors = true;
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "Ser_SW_Code", true));
            this.metroLabel17.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel17.Location = new System.Drawing.Point(120, 163);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(65, 19);
            this.metroLabel17.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel17.TabIndex = 35;
            this.metroLabel17.Text = "Firmware";
            this.metroLabel17.UseCustomBackColor = true;
            this.metroLabel17.UseStyleColors = true;
            // 
            // metroLabel16
            // 
            this.metroLabel16.AutoSize = true;
            this.metroLabel16.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel16.Location = new System.Drawing.Point(0, 163);
            this.metroLabel16.Name = "metroLabel16";
            this.metroLabel16.Size = new System.Drawing.Size(112, 19);
            this.metroLabel16.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel16.TabIndex = 34;
            this.metroLabel16.Text = "Firmware iniziale:";
            this.metroLabel16.UseCustomBackColor = true;
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "Ser_OfficialSerial", true));
            this.metroLabel15.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel15.Location = new System.Drawing.Point(120, 144);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(41, 19);
            this.metroLabel15.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel15.TabIndex = 33;
            this.metroLabel15.Text = "Serial";
            this.metroLabel15.UseCustomBackColor = true;
            this.metroLabel15.UseStyleColors = true;
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "Ser_Device_ID_Code", true));
            this.metroLabel14.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel14.Location = new System.Drawing.Point(120, 125);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(55, 19);
            this.metroLabel14.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel14.TabIndex = 32;
            this.metroLabel14.Text = "IDCode";
            this.metroLabel14.UseCustomBackColor = true;
            this.metroLabel14.UseStyleColors = true;
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel13.Location = new System.Drawing.Point(0, 144);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(108, 19);
            this.metroLabel13.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel13.TabIndex = 31;
            this.metroLabel13.Text = "Serial Microchip:";
            this.metroLabel13.UseCustomBackColor = true;
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel12.Location = new System.Drawing.Point(0, 125);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(62, 19);
            this.metroLabel12.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel12.TabIndex = 30;
            this.metroLabel12.Text = "ID Code:";
            this.metroLabel12.UseCustomBackColor = true;
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "RAGIONESOCIALE", true));
            this.metroLabel10.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel10.Location = new System.Drawing.Point(120, 30);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(101, 19);
            this.metroLabel10.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel10.TabIndex = 28;
            this.metroLabel10.Text = "Cliente_RagSoc";
            this.metroLabel10.UseCustomBackColor = true;
            this.metroLabel10.UseStyleColors = true;
            this.metroLabel10.Click += new System.EventHandler(this.metroLabel10_Click);
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel9.Location = new System.Drawing.Point(0, 30);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(54, 19);
            this.metroLabel9.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel9.TabIndex = 27;
            this.metroLabel9.Text = "Cliente:";
            this.metroLabel9.UseCustomBackColor = true;
            this.metroLabel9.Click += new System.EventHandler(this.metroLabel9_Click);
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "Ser_Device", true));
            this.metroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel8.Location = new System.Drawing.Point(120, 87);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(49, 19);
            this.metroLabel8.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel8.TabIndex = 26;
            this.metroLabel8.Text = "Device";
            this.metroLabel8.UseCustomBackColor = true;
            this.metroLabel8.UseStyleColors = true;
            this.metroLabel8.Click += new System.EventHandler(this.metroLabel8_Click);
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel7.Location = new System.Drawing.Point(0, 87);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(52, 19);
            this.metroLabel7.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel7.TabIndex = 25;
            this.metroLabel7.Text = "Device:";
            this.metroLabel7.UseCustomBackColor = true;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "Ser_Kit", true));
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel6.Location = new System.Drawing.Point(120, 49);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(25, 19);
            this.metroLabel6.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel6.TabIndex = 24;
            this.metroLabel6.Text = "Kit";
            this.metroLabel6.UseCustomBackColor = true;
            this.metroLabel6.UseStyleColors = true;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel5.Location = new System.Drawing.Point(0, 49);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(28, 19);
            this.metroLabel5.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel5.TabIndex = 23;
            this.metroLabel5.Text = "Kit:";
            this.metroLabel5.UseCustomBackColor = true;
            this.metroLabel5.Click += new System.EventHandler(this.metroLabel5_Click);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(0, 0);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(90, 25);
            this.metroLabel4.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel4.TabIndex = 22;
            this.metroLabel4.Text = "SmartLine";
            this.metroLabel4.UseCustomBackColor = true;
            this.metroLabel4.UseStyleColors = true;
            // 
            // sF_SN_arsnTableAdapter
            // 
            this.sF_SN_arsnTableAdapter.ClearBeforeFill = true;
            // 
            // sF_SN_artaTableAdapter
            // 
            this.sF_SN_artaTableAdapter.ClearBeforeFill = true;
            // 
            // sF_SN_QueryTableAdapter
            // 
            this.sF_SN_QueryTableAdapter.ClearBeforeFill = true;
            // 
            // sF_SN_mosnTableAdapter
            // 
            this.sF_SN_mosnTableAdapter.ClearBeforeFill = true;
            // 
            // sFSNmomamosnSFSNbrorBindingSource
            // 
            this.sFSNmomamosnSFSNbrorBindingSource.DataMember = "SF_SN_momamosn_SF_SN_bror";
            this.sFSNmomamosnSFSNbrorBindingSource.DataSource = this.sFSNarsnSFmomamosnBindingSource;
            // 
            // sF_SN_brorTableAdapter
            // 
            this.sF_SN_brorTableAdapter.ClearBeforeFill = true;
            // 
            // UC_Identifica
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 800);
            this.ControlBox = false;
            this.Controls.Add(this.panel_fattibilita);
            this.Controls.Add(this.layout_orizz_menu);
            this.DisplayHeader = false;
            this.Name = "UC_Identifica";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UC_Identifica_Load);
            this.layout_orizz_menu.ResumeLayout(false);
            this.layout_orizz_menu.PerformLayout();
            this.pan_Menu_comandi.ResumeLayout(false);
            this.pan_Menu_comandi.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            this.panel_fattibilita.ResumeLayout(false);
            this.layout_Schede.ResumeLayout(false);
            this.layout_Schede.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFSNmosnBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFSNQueryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFSNartaBindingSource)).EndInit();
            this.panel_grid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_SN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFmomamosnBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid3)).EndInit();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNmomamosnSFSNbrorBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel layout_orizz_menu;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
        private MetroFramework.Controls.MetroPanel panel_fattibilita;
        private System.Windows.Forms.TableLayoutPanel layout_Schede;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloCompostoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloComponenteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Explode_Mag;
        private MetroFramework.Controls.MetroPanel panel_grid;
        private System.Windows.Forms.DataGridViewTextBoxColumn qualProg1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private MetroFramework.Controls.MetroGrid gv_SN;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.MenuStrip pan_Menu_comandi;
        private System.Windows.Forms.ToolStripMenuItem verificaSaltiNumerazioneToolStripMenuItem;
        private ds_SL ds_SL;
        private System.Windows.Forms.BindingSource sFSNarsnBindingSource;
        private ds_SLTableAdapters.SF_SN_arsnTableAdapter sF_SN_arsnTableAdapter;
        private MetroFramework.Controls.MetroGrid metroGrid1;
        private System.Windows.Forms.BindingSource sFSNarsnSFSNartaBindingSource;
        private ds_SLTableAdapters.SF_SN_artaTableAdapter sF_SN_artaTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn serialNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn entitaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serieDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn partitaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataInizioGarForDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn flObsoletoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataTrasfObsoletoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nume01DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataRegMovInizDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn progRegMovInizDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn progContrMovInizDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serialNumberEstDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn flTrasfWebDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDUtenteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDTerminaleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataUltModificaDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroGrid metroGrid2;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private System.Windows.Forms.BindingSource sFSNarsnSFSNQueryBindingSource;
        private ds_SLTableAdapters.SF_SN_QueryTableAdapter sF_SN_QueryTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serKitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serIDCliDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serDeviceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serDeviceIDCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serOfficialSerialDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serReadSerialDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serSWCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serSWCodeRevDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rAGIONESOCIALEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iNDIRIZZODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nUMEROCIVICODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fRAZIONEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cAPDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cOMUNEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pROVINCIADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rEGIONEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pREFISSOTELEFONODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nUMEROTELEFONODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pREFISSOTELEFONOAGGIUNTIVODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nUMEROTELEFONOAGGIUNTIVODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eMailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eMAILPECDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWDescrizioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWRevisioniDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWFunzionamentoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn desKitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn desEstKitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn modelloDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn desDeviceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn desEstDeviceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fWversDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fWrevDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn serSWStdTypeDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serSNprodDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serCommessaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serDateProductionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn serSpeditoDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serDataSpeditoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serSubstitionIDReadSerialDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serNoteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn sWObsoleteverDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sWObsoleteverfromdateDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroLabel metroLabel16;
        private MetroFramework.Controls.MetroLabel metroLabel18;
        private MetroFramework.Controls.MetroLabel metroLabel17;
        private MetroFramework.Controls.MetroLabel metroLabel20;
        private MetroFramework.Controls.MetroLabel metroLabel19;
        private MetroFramework.Controls.MetroLabel metroLabel22;
        private MetroFramework.Controls.MetroLabel metroLabel21;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel24;
        private MetroFramework.Controls.MetroLabel metroLabel23;
        private System.Windows.Forms.BindingSource sFSNarsnSFSNmosnBindingSource;
        private ds_SLTableAdapters.SF_SN_mosnTableAdapter sF_SN_mosnTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn entitaDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serieDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn partitaDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataRegistrazioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn progRegistrazioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn progContropDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn flStatoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoMovimentoDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroCheckBox metroCheckBox1;
        private MetroFramework.Controls.MetroCheckBox metroCheckBox2;
        private MetroFramework.Controls.MetroLabel metroLabel26;
        private MetroFramework.Controls.MetroLabel metroLabel25;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serialNumberDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ragSocCognomeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ragSocNomeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ragSocCompletaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descrizioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn codAnagraficoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataDocumentoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeroOrdineDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataOrdineDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rigaOrdineDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoBollaFatturaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeroBollaFatturaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataBollaFatturaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeroBrogliaccioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rigaBrogliaccioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn commessaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloOrdineDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource sFSNarsnSFmomamosnBindingSource;
        private MetroFramework.Controls.MetroGrid metroGrid3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.BindingSource sFSNmomamosnSFSNbrorBindingSource;
        private ds_SLTableAdapters.SF_SN_brorTableAdapter sF_SN_brorTableAdapter;
    }
}