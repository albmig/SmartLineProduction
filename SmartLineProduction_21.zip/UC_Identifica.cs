﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using Syncfusion.Windows.Forms.Grid.Grouping;

namespace SmartLineProduction
{
    public partial class UC_Identifica : MetroFramework.Forms.MetroForm
    {

        private string numerimancanti = "";

        public UC_Identifica()
        {
            InitializeComponent();
        }

        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UC_Identifica_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_SN_bror'. È possibile spostarla o rimuoverla se necessario.
            this.sF_SN_brorTableAdapter.Fill(this.ds_SL.SF_SN_bror);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_SN_mosn'. È possibile spostarla o rimuoverla se necessario.
            this.sF_SN_mosnTableAdapter.Fill(this.ds_SL.SF_SN_mosn);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_SN_Query'. È possibile spostarla o rimuoverla se necessario.
            this.sF_SN_QueryTableAdapter.Fill(this.ds_SL.SF_SN_Query);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_SN_arta'. È possibile spostarla o rimuoverla se necessario.
            this.sF_SN_artaTableAdapter.Fill(this.ds_SL.SF_SN_arta);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_SN_arsn'. È possibile spostarla o rimuoverla se necessario.
            this.sF_SN_arsnTableAdapter.Fill(this.ds_SL.SF_SN_arsn);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_SN_arsn'. È possibile spostarla o rimuoverla se necessario.
            this.sF_SN_arsnTableAdapter.Fill(this.ds_SL.SF_SN_arsn);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_SN_arta'. È possibile spostarla o rimuoverla se necessario.
            this.sF_SN_artaTableAdapter.Fill(this.ds_SL.SF_SN_arta);
            //// TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_SN_mosn'. È possibile spostarla o rimuoverla se necessario.
            //this.sF_SN_mosnTableAdapter.Fill(this.ds_SL.SF_SN_mosn);
        }

        private void verificaSaltiNumerazioneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!VerificaSalti())
            {
                MessageBox.Show("Nessun salto di numerazione rilevato!");
            }
            else
            {
                string text = "Salto di numerazione rilevato!" + "\n" + numerimancanti;
                MessageBox.Show(text);
            }
        }


        private bool VerificaSalti()
        {
            object firstsn = this.ds_SL.SF_SN_mosn.Compute("MIN(SerialNumber)", null);
            object lastsn = this.ds_SL.SF_SN_mosn.Compute("MAX(SerialNumber)", null);
            int primo = Convert.ToInt32(firstsn);
            int ultimo = Convert.ToInt32(lastsn);
            int conta = primo;
            sFSNarsnBindingSource.MoveFirst();
            foreach (DataRowView snrow in sFSNarsnBindingSource)
            {
                int snletto = Convert.ToInt32(snrow["SerialNumber"]);
                if (snletto != conta)
                {
                    for (int i = conta; i < snletto; i++)
                    {
                        conta = i;
                        numerimancanti = numerimancanti + conta.ToString() + "//";
                    }
                }
                conta++;
            }

            if (numerimancanti == "") return false; else return true;
        }

        private void metroLabel5_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel8_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel11_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel10_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel9_Click(object sender, EventArgs e)
        {

        }
    }
}
