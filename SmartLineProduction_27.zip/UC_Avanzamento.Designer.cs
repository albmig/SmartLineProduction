﻿namespace SmartLineProduction
{
    partial class UC_Avanzamento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Avanzamento));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gv_Commesse = new MetroFramework.Controls.MetroGrid();
            this.gv_Commesse_Entita = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_TipoOrdine = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_DataOrdine = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_NumeroOrdine = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_NumeroRiga = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_CodAnagrafico = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_CommesseDataConfConsegna = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_RagioneSociale = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_NazioneFiscale = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_CommessaLong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_QtaInevasa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_CommessaShort = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_DataConsegnaSort = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_Articolo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_Um = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_PrezzoUnitario = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_QtaOrdinata = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_QtaSpedita = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_Importo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_ImportoEvaso = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_ImportoDaEvadere = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_MeseConsegna = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_NomeMeseConsegna = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_AnnoConsegna = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_CommessaLong2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_QtaProgrammazione = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_CellaProgrammazione = new System.Windows.Forms.DataGridViewImageColumn();
            this.gv_Commesse_CellaProgrammazione_Note = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_QtaMontaggio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_CellaMontaggio = new System.Windows.Forms.DataGridViewImageColumn();
            this.gv_Commesse_CellaMontaggio_Note = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_QtaCollaudoConfezionamento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_CellaCollConf = new System.Windows.Forms.DataGridViewImageColumn();
            this.gv_Commesse_CellaCollConf_Note = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_CellaSpedizione = new System.Windows.Forms.DataGridViewImageColumn();
            this.gv_Commesse_CellaSpedizione_Note = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_QtaVendita = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_CellaVendita = new System.Windows.Forms.DataGridViewImageColumn();
            this.gv_Commesse_CellaVendita_Note = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Commesse_DistintaBase = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sFCommesseAperteCLSLBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.sF_CommesseAperte_CL_SLTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_CommesseAperte_CL_SLTableAdapter();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.layout_filter = new System.Windows.Forms.TableLayoutPanel();
            this.btn_AzzeraFiltroNote = new MetroFramework.Controls.MetroButton();
            this.cb_note = new System.Windows.Forms.ComboBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.btn_AzzeraFiltroFase = new MetroFramework.Controls.MetroButton();
            this.cb_fase = new System.Windows.Forms.ComboBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.btn_AzzeraFiltroDate = new MetroFramework.Controls.MetroButton();
            this.cb_elencodate = new System.Windows.Forms.ComboBox();
            this.sFElencoDateCommAperteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btn_AzzeraFiltroArticoli = new MetroFramework.Controls.MetroButton();
            this.cb_elencoarticoli = new System.Windows.Forms.ComboBox();
            this.sFElencoArticoliCommAperteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btn_AzzeraFiltroCommesse = new MetroFramework.Controls.MetroButton();
            this.cb_elencocommesse = new System.Windows.Forms.ComboBox();
            this.sFElencoCommesseCommAperteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.cb_elencoClienti = new System.Windows.Forms.ComboBox();
            this.sFElencoClientiCommAperteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btn_AzzeraFiltroClienti = new MetroFramework.Controls.MetroButton();
            this.sF_ElencoClienti_CommAperteTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_ElencoClienti_CommAperteTableAdapter();
            this.distanziatore = new MetroFramework.Controls.MetroPanel();
            this.sF_ElencoCommesse_CommAperteTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_ElencoCommesse_CommAperteTableAdapter();
            this.sF_ElencoArticoli_CommAperteTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_ElencoArticoli_CommAperteTableAdapter();
            this.sF_ElencoDate_CommAperteTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_ElencoDate_CommAperteTableAdapter();
            this.miniToolStrip = new System.Windows.Forms.MenuStrip();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.layout_orizz_menu = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_sw = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.avanzamentoOrdiniBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.avanzamento_OrdiniTableAdapter = new SmartLineProduction.ds_SLTableAdapters.Avanzamento_OrdiniTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Commesse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFCommesseAperteCLSLBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            this.layout_filter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sFElencoDateCommAperteBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFElencoArticoliCommAperteBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFElencoCommesseCommAperteBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFElencoClientiCommAperteBindingSource)).BeginInit();
            this.layout_orizz_menu.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.menu_sw.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.avanzamentoOrdiniBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // gv_Commesse
            // 
            this.gv_Commesse.AllowUserToAddRows = false;
            this.gv_Commesse.AllowUserToDeleteRows = false;
            this.gv_Commesse.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.gv_Commesse.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.gv_Commesse.AutoGenerateColumns = false;
            this.gv_Commesse.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.gv_Commesse.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Commesse.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Commesse.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_Commesse.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Commesse.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gv_Commesse.ColumnHeadersHeight = 40;
            this.gv_Commesse.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gv_Commesse_Entita,
            this.gv_Commesse_TipoOrdine,
            this.gv_Commesse_DataOrdine,
            this.gv_Commesse_NumeroOrdine,
            this.gv_Commesse_NumeroRiga,
            this.gv_Commesse_CodAnagrafico,
            this.gv_CommesseDataConfConsegna,
            this.gv_Commesse_RagioneSociale,
            this.gv_Commesse_NazioneFiscale,
            this.gv_Commesse_CommessaLong,
            this.gv_Commesse_QtaInevasa,
            this.gv_Commesse_CommessaShort,
            this.gv_Commesse_DataConsegnaSort,
            this.gv_Commesse_Articolo,
            this.gv_Commesse_Um,
            this.gv_Commesse_PrezzoUnitario,
            this.gv_Commesse_QtaOrdinata,
            this.gv_Commesse_QtaSpedita,
            this.gv_Commesse_Importo,
            this.gv_Commesse_ImportoEvaso,
            this.gv_Commesse_ImportoDaEvadere,
            this.gv_Commesse_MeseConsegna,
            this.gv_Commesse_NomeMeseConsegna,
            this.gv_Commesse_AnnoConsegna,
            this.gv_Commesse_CommessaLong2,
            this.gv_Commesse_QtaProgrammazione,
            this.gv_Commesse_CellaProgrammazione,
            this.gv_Commesse_CellaProgrammazione_Note,
            this.gv_Commesse_QtaMontaggio,
            this.gv_Commesse_CellaMontaggio,
            this.gv_Commesse_CellaMontaggio_Note,
            this.gv_Commesse_QtaCollaudoConfezionamento,
            this.gv_Commesse_CellaCollConf,
            this.gv_Commesse_CellaCollConf_Note,
            this.gv_Commesse_CellaSpedizione,
            this.gv_Commesse_CellaSpedizione_Note,
            this.gv_Commesse_QtaVendita,
            this.gv_Commesse_CellaVendita,
            this.gv_Commesse_CellaVendita_Note,
            this.gv_Commesse_DistintaBase});
            this.gv_Commesse.DataSource = this.sFCommesseAperteCLSLBindingSource;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Commesse.DefaultCellStyle = dataGridViewCellStyle18;
            this.gv_Commesse.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Commesse.EnableHeadersVisualStyles = false;
            this.gv_Commesse.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Commesse.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Commesse.Location = new System.Drawing.Point(20, 132);
            this.gv_Commesse.MultiSelect = false;
            this.gv_Commesse.Name = "gv_Commesse";
            this.gv_Commesse.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Commesse.RowHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.gv_Commesse.RowHeadersVisible = false;
            this.gv_Commesse.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Commesse.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Wheat;
            this.gv_Commesse.RowTemplate.DividerHeight = 1;
            this.gv_Commesse.RowTemplate.Height = 60;
            this.gv_Commesse.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Commesse.Size = new System.Drawing.Size(1003, 427);
            this.gv_Commesse.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_Commesse.TabIndex = 0;
            this.gv_Commesse.UseCustomBackColor = true;
            this.gv_Commesse.UseCustomForeColor = true;
            this.gv_Commesse.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gv_Commesse_CellClick);
            this.gv_Commesse.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.gv_Commesse_CellFormatting);
            this.gv_Commesse.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.gv_Commesse_CellPainting);
            this.gv_Commesse.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.gv_Commesse_DataError);
            // 
            // gv_Commesse_Entita
            // 
            this.gv_Commesse_Entita.DataPropertyName = "Entita";
            this.gv_Commesse_Entita.HeaderText = "Entita";
            this.gv_Commesse_Entita.Name = "gv_Commesse_Entita";
            this.gv_Commesse_Entita.Visible = false;
            // 
            // gv_Commesse_TipoOrdine
            // 
            this.gv_Commesse_TipoOrdine.DataPropertyName = "TIPO_ORDINE";
            this.gv_Commesse_TipoOrdine.HeaderText = "TIPO_ORDINE";
            this.gv_Commesse_TipoOrdine.Name = "gv_Commesse_TipoOrdine";
            this.gv_Commesse_TipoOrdine.ReadOnly = true;
            this.gv_Commesse_TipoOrdine.Visible = false;
            // 
            // gv_Commesse_DataOrdine
            // 
            this.gv_Commesse_DataOrdine.DataPropertyName = "DATA_ORDINE";
            this.gv_Commesse_DataOrdine.HeaderText = "DATA_ORDINE";
            this.gv_Commesse_DataOrdine.Name = "gv_Commesse_DataOrdine";
            this.gv_Commesse_DataOrdine.ReadOnly = true;
            this.gv_Commesse_DataOrdine.Visible = false;
            // 
            // gv_Commesse_NumeroOrdine
            // 
            this.gv_Commesse_NumeroOrdine.DataPropertyName = "NUMERO_ORDINE";
            this.gv_Commesse_NumeroOrdine.HeaderText = "NUMERO_ORDINE";
            this.gv_Commesse_NumeroOrdine.Name = "gv_Commesse_NumeroOrdine";
            this.gv_Commesse_NumeroOrdine.Visible = false;
            // 
            // gv_Commesse_NumeroRiga
            // 
            this.gv_Commesse_NumeroRiga.DataPropertyName = "NUMERO_RIGA";
            this.gv_Commesse_NumeroRiga.HeaderText = "NUMERO_RIGA";
            this.gv_Commesse_NumeroRiga.Name = "gv_Commesse_NumeroRiga";
            this.gv_Commesse_NumeroRiga.Visible = false;
            // 
            // gv_Commesse_CodAnagrafico
            // 
            this.gv_Commesse_CodAnagrafico.DataPropertyName = "CodAnagrafico";
            this.gv_Commesse_CodAnagrafico.HeaderText = "CodAnagrafico";
            this.gv_Commesse_CodAnagrafico.Name = "gv_Commesse_CodAnagrafico";
            this.gv_Commesse_CodAnagrafico.Visible = false;
            // 
            // gv_CommesseDataConfConsegna
            // 
            this.gv_CommesseDataConfConsegna.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_CommesseDataConfConsegna.DataPropertyName = "DATA_CONFERMA_CONSEGNA";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.Format = "d";
            dataGridViewCellStyle3.NullValue = null;
            this.gv_CommesseDataConfConsegna.DefaultCellStyle = dataGridViewCellStyle3;
            this.gv_CommesseDataConfConsegna.HeaderText = "Data di Consegna (non usare)";
            this.gv_CommesseDataConfConsegna.Name = "gv_CommesseDataConfConsegna";
            this.gv_CommesseDataConfConsegna.ReadOnly = true;
            this.gv_CommesseDataConfConsegna.Visible = false;
            this.gv_CommesseDataConfConsegna.Width = 139;
            // 
            // gv_Commesse_RagioneSociale
            // 
            this.gv_Commesse_RagioneSociale.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_Commesse_RagioneSociale.DataPropertyName = "RAGIONE_SOCIALE";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.gv_Commesse_RagioneSociale.DefaultCellStyle = dataGridViewCellStyle4;
            this.gv_Commesse_RagioneSociale.HeaderText = "Ragione Sociale";
            this.gv_Commesse_RagioneSociale.Name = "gv_Commesse_RagioneSociale";
            // 
            // gv_Commesse_NazioneFiscale
            // 
            this.gv_Commesse_NazioneFiscale.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Commesse_NazioneFiscale.DataPropertyName = "NazioneFiscale";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.gv_Commesse_NazioneFiscale.DefaultCellStyle = dataGridViewCellStyle5;
            this.gv_Commesse_NazioneFiscale.HeaderText = "Nazione";
            this.gv_Commesse_NazioneFiscale.Name = "gv_Commesse_NazioneFiscale";
            this.gv_Commesse_NazioneFiscale.Width = 72;
            // 
            // gv_Commesse_CommessaLong
            // 
            this.gv_Commesse_CommessaLong.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Commesse_CommessaLong.DataPropertyName = "COMMESSALONG";
            this.gv_Commesse_CommessaLong.HeaderText = "Commessa";
            this.gv_Commesse_CommessaLong.Name = "gv_Commesse_CommessaLong";
            this.gv_Commesse_CommessaLong.ReadOnly = true;
            this.gv_Commesse_CommessaLong.Width = 84;
            // 
            // gv_Commesse_QtaInevasa
            // 
            this.gv_Commesse_QtaInevasa.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Commesse_QtaInevasa.DataPropertyName = "QTA_DA_EVADERE";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.Format = "N0";
            dataGridViewCellStyle6.NullValue = "- - -";
            this.gv_Commesse_QtaInevasa.DefaultCellStyle = dataGridViewCellStyle6;
            this.gv_Commesse_QtaInevasa.HeaderText = "Q.tà Residua";
            this.gv_Commesse_QtaInevasa.Name = "gv_Commesse_QtaInevasa";
            this.gv_Commesse_QtaInevasa.ReadOnly = true;
            this.gv_Commesse_QtaInevasa.Width = 87;
            // 
            // gv_Commesse_CommessaShort
            // 
            this.gv_Commesse_CommessaShort.DataPropertyName = "COMMESSASHORT";
            this.gv_Commesse_CommessaShort.HeaderText = "COMMESSASHORT";
            this.gv_Commesse_CommessaShort.Name = "gv_Commesse_CommessaShort";
            this.gv_Commesse_CommessaShort.ReadOnly = true;
            this.gv_Commesse_CommessaShort.Visible = false;
            // 
            // gv_Commesse_DataConsegnaSort
            // 
            this.gv_Commesse_DataConsegnaSort.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Commesse_DataConsegnaSort.DataPropertyName = "SortDataConsegna";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Format = "d";
            dataGridViewCellStyle7.NullValue = null;
            this.gv_Commesse_DataConsegnaSort.DefaultCellStyle = dataGridViewCellStyle7;
            this.gv_Commesse_DataConsegnaSort.HeaderText = "Data di Consegna";
            this.gv_Commesse_DataConsegnaSort.Name = "gv_Commesse_DataConsegnaSort";
            this.gv_Commesse_DataConsegnaSort.Width = 112;
            // 
            // gv_Commesse_Articolo
            // 
            this.gv_Commesse_Articolo.DataPropertyName = "ARTICOLO";
            this.gv_Commesse_Articolo.HeaderText = "Articolo";
            this.gv_Commesse_Articolo.Name = "gv_Commesse_Articolo";
            this.gv_Commesse_Articolo.ReadOnly = true;
            // 
            // gv_Commesse_Um
            // 
            this.gv_Commesse_Um.DataPropertyName = "UM";
            this.gv_Commesse_Um.HeaderText = "UM";
            this.gv_Commesse_Um.Name = "gv_Commesse_Um";
            this.gv_Commesse_Um.ReadOnly = true;
            this.gv_Commesse_Um.Visible = false;
            // 
            // gv_Commesse_PrezzoUnitario
            // 
            this.gv_Commesse_PrezzoUnitario.DataPropertyName = "PREZZO_UNITARIO";
            this.gv_Commesse_PrezzoUnitario.HeaderText = "PREZZO_UNITARIO";
            this.gv_Commesse_PrezzoUnitario.Name = "gv_Commesse_PrezzoUnitario";
            this.gv_Commesse_PrezzoUnitario.Visible = false;
            // 
            // gv_Commesse_QtaOrdinata
            // 
            this.gv_Commesse_QtaOrdinata.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Commesse_QtaOrdinata.DataPropertyName = "QTA_ORDINATA";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.Format = "N0";
            dataGridViewCellStyle8.NullValue = "- - -";
            this.gv_Commesse_QtaOrdinata.DefaultCellStyle = dataGridViewCellStyle8;
            this.gv_Commesse_QtaOrdinata.HeaderText = "Q.tà Ordinata";
            this.gv_Commesse_QtaOrdinata.Name = "gv_Commesse_QtaOrdinata";
            this.gv_Commesse_QtaOrdinata.Visible = false;
            this.gv_Commesse_QtaOrdinata.Width = 92;
            // 
            // gv_Commesse_QtaSpedita
            // 
            this.gv_Commesse_QtaSpedita.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Commesse_QtaSpedita.DataPropertyName = "QTA_SPEDITA";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.Format = "N0";
            dataGridViewCellStyle9.NullValue = "- - -";
            this.gv_Commesse_QtaSpedita.DefaultCellStyle = dataGridViewCellStyle9;
            this.gv_Commesse_QtaSpedita.HeaderText = "Q.tà Spedita";
            this.gv_Commesse_QtaSpedita.Name = "gv_Commesse_QtaSpedita";
            this.gv_Commesse_QtaSpedita.Visible = false;
            this.gv_Commesse_QtaSpedita.Width = 85;
            // 
            // gv_Commesse_Importo
            // 
            this.gv_Commesse_Importo.DataPropertyName = "IMPORTO";
            this.gv_Commesse_Importo.HeaderText = "IMPORTO";
            this.gv_Commesse_Importo.Name = "gv_Commesse_Importo";
            this.gv_Commesse_Importo.ReadOnly = true;
            this.gv_Commesse_Importo.Visible = false;
            // 
            // gv_Commesse_ImportoEvaso
            // 
            this.gv_Commesse_ImportoEvaso.DataPropertyName = "IMPORTO_EVASO";
            this.gv_Commesse_ImportoEvaso.HeaderText = "IMPORTO_EVASO";
            this.gv_Commesse_ImportoEvaso.Name = "gv_Commesse_ImportoEvaso";
            this.gv_Commesse_ImportoEvaso.ReadOnly = true;
            this.gv_Commesse_ImportoEvaso.Visible = false;
            // 
            // gv_Commesse_ImportoDaEvadere
            // 
            this.gv_Commesse_ImportoDaEvadere.DataPropertyName = "IMPORTO_DA_EVADERE";
            this.gv_Commesse_ImportoDaEvadere.HeaderText = "IMPORTO_DA_EVADERE";
            this.gv_Commesse_ImportoDaEvadere.Name = "gv_Commesse_ImportoDaEvadere";
            this.gv_Commesse_ImportoDaEvadere.ReadOnly = true;
            this.gv_Commesse_ImportoDaEvadere.Visible = false;
            // 
            // gv_Commesse_MeseConsegna
            // 
            this.gv_Commesse_MeseConsegna.DataPropertyName = "MeseConsegna";
            this.gv_Commesse_MeseConsegna.HeaderText = "MeseConsegna";
            this.gv_Commesse_MeseConsegna.Name = "gv_Commesse_MeseConsegna";
            this.gv_Commesse_MeseConsegna.ReadOnly = true;
            this.gv_Commesse_MeseConsegna.Visible = false;
            // 
            // gv_Commesse_NomeMeseConsegna
            // 
            this.gv_Commesse_NomeMeseConsegna.DataPropertyName = "NomeMeseConsegna";
            this.gv_Commesse_NomeMeseConsegna.HeaderText = "NomeMeseConsegna";
            this.gv_Commesse_NomeMeseConsegna.Name = "gv_Commesse_NomeMeseConsegna";
            this.gv_Commesse_NomeMeseConsegna.ReadOnly = true;
            this.gv_Commesse_NomeMeseConsegna.Visible = false;
            // 
            // gv_Commesse_AnnoConsegna
            // 
            this.gv_Commesse_AnnoConsegna.DataPropertyName = "AnnoConsegna";
            this.gv_Commesse_AnnoConsegna.HeaderText = "AnnoConsegna";
            this.gv_Commesse_AnnoConsegna.Name = "gv_Commesse_AnnoConsegna";
            this.gv_Commesse_AnnoConsegna.ReadOnly = true;
            this.gv_Commesse_AnnoConsegna.Visible = false;
            // 
            // gv_Commesse_CommessaLong2
            // 
            this.gv_Commesse_CommessaLong2.DataPropertyName = "Commessa";
            this.gv_Commesse_CommessaLong2.HeaderText = "Commessa";
            this.gv_Commesse_CommessaLong2.Name = "gv_Commesse_CommessaLong2";
            this.gv_Commesse_CommessaLong2.Visible = false;
            // 
            // gv_Commesse_QtaProgrammazione
            // 
            this.gv_Commesse_QtaProgrammazione.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Commesse_QtaProgrammazione.DataPropertyName = "qta_programmazione";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.gv_Commesse_QtaProgrammazione.DefaultCellStyle = dataGridViewCellStyle10;
            this.gv_Commesse_QtaProgrammazione.HeaderText = "Q.tà Programmazione";
            this.gv_Commesse_QtaProgrammazione.Name = "gv_Commesse_QtaProgrammazione";
            this.gv_Commesse_QtaProgrammazione.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Commesse_QtaProgrammazione.Width = 128;
            // 
            // gv_Commesse_CellaProgrammazione
            // 
            this.gv_Commesse_CellaProgrammazione.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Commesse_CellaProgrammazione.DataPropertyName = "AO_Programmazione";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.NullValue = ((object)(resources.GetObject("dataGridViewCellStyle11.NullValue")));
            this.gv_Commesse_CellaProgrammazione.DefaultCellStyle = dataGridViewCellStyle11;
            this.gv_Commesse_CellaProgrammazione.HeaderText = "Programmazione";
            this.gv_Commesse_CellaProgrammazione.Name = "gv_Commesse_CellaProgrammazione";
            this.gv_Commesse_CellaProgrammazione.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Commesse_CellaProgrammazione.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.gv_Commesse_CellaProgrammazione.Width = 116;
            // 
            // gv_Commesse_CellaProgrammazione_Note
            // 
            this.gv_Commesse_CellaProgrammazione_Note.DataPropertyName = "AO_Programmazione_Note";
            this.gv_Commesse_CellaProgrammazione_Note.HeaderText = "AO_Programmazione_Note";
            this.gv_Commesse_CellaProgrammazione_Note.Name = "gv_Commesse_CellaProgrammazione_Note";
            this.gv_Commesse_CellaProgrammazione_Note.Visible = false;
            // 
            // gv_Commesse_QtaMontaggio
            // 
            this.gv_Commesse_QtaMontaggio.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Commesse_QtaMontaggio.DataPropertyName = "qta_montaggio";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.gv_Commesse_QtaMontaggio.DefaultCellStyle = dataGridViewCellStyle12;
            this.gv_Commesse_QtaMontaggio.HeaderText = "Q.tà Montaggio";
            this.gv_Commesse_QtaMontaggio.Name = "gv_Commesse_QtaMontaggio";
            this.gv_Commesse_QtaMontaggio.Width = 103;
            // 
            // gv_Commesse_CellaMontaggio
            // 
            this.gv_Commesse_CellaMontaggio.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Commesse_CellaMontaggio.DataPropertyName = "AO_Montaggio";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.NullValue = ((object)(resources.GetObject("dataGridViewCellStyle13.NullValue")));
            this.gv_Commesse_CellaMontaggio.DefaultCellStyle = dataGridViewCellStyle13;
            this.gv_Commesse_CellaMontaggio.HeaderText = "Montaggio";
            this.gv_Commesse_CellaMontaggio.Name = "gv_Commesse_CellaMontaggio";
            this.gv_Commesse_CellaMontaggio.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Commesse_CellaMontaggio.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.gv_Commesse_CellaMontaggio.Width = 88;
            // 
            // gv_Commesse_CellaMontaggio_Note
            // 
            this.gv_Commesse_CellaMontaggio_Note.DataPropertyName = "AO_Montaggio_Note";
            this.gv_Commesse_CellaMontaggio_Note.HeaderText = "AO_Montaggio_Note";
            this.gv_Commesse_CellaMontaggio_Note.Name = "gv_Commesse_CellaMontaggio_Note";
            this.gv_Commesse_CellaMontaggio_Note.Visible = false;
            // 
            // gv_Commesse_QtaCollaudoConfezionamento
            // 
            this.gv_Commesse_QtaCollaudoConfezionamento.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Commesse_QtaCollaudoConfezionamento.DataPropertyName = "qta_collaudoconfezionamento";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.gv_Commesse_QtaCollaudoConfezionamento.DefaultCellStyle = dataGridViewCellStyle14;
            this.gv_Commesse_QtaCollaudoConfezionamento.HeaderText = "Q.tà Collaudo/Conf.";
            this.gv_Commesse_QtaCollaudoConfezionamento.Name = "gv_Commesse_QtaCollaudoConfezionamento";
            this.gv_Commesse_QtaCollaudoConfezionamento.Width = 121;
            // 
            // gv_Commesse_CellaCollConf
            // 
            this.gv_Commesse_CellaCollConf.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Commesse_CellaCollConf.DataPropertyName = "AO_CollaudoConfezionamento";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.NullValue = ((object)(resources.GetObject("dataGridViewCellStyle15.NullValue")));
            this.gv_Commesse_CellaCollConf.DefaultCellStyle = dataGridViewCellStyle15;
            this.gv_Commesse_CellaCollConf.HeaderText = "Coll./Conf.";
            this.gv_Commesse_CellaCollConf.Name = "gv_Commesse_CellaCollConf";
            this.gv_Commesse_CellaCollConf.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Commesse_CellaCollConf.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.gv_Commesse_CellaCollConf.Width = 85;
            // 
            // gv_Commesse_CellaCollConf_Note
            // 
            this.gv_Commesse_CellaCollConf_Note.DataPropertyName = "AO_CollaudoConfezionamento_Note";
            this.gv_Commesse_CellaCollConf_Note.HeaderText = "AO_CollaudoConfezionamento_Note";
            this.gv_Commesse_CellaCollConf_Note.Name = "gv_Commesse_CellaCollConf_Note";
            this.gv_Commesse_CellaCollConf_Note.Visible = false;
            // 
            // gv_Commesse_CellaSpedizione
            // 
            this.gv_Commesse_CellaSpedizione.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Commesse_CellaSpedizione.DataPropertyName = "AO_Spedizione";
            this.gv_Commesse_CellaSpedizione.HeaderText = "Spedizione";
            this.gv_Commesse_CellaSpedizione.Name = "gv_Commesse_CellaSpedizione";
            this.gv_Commesse_CellaSpedizione.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Commesse_CellaSpedizione.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.gv_Commesse_CellaSpedizione.Visible = false;
            this.gv_Commesse_CellaSpedizione.Width = 87;
            // 
            // gv_Commesse_CellaSpedizione_Note
            // 
            this.gv_Commesse_CellaSpedizione_Note.DataPropertyName = "AO_Spedizione_Note";
            this.gv_Commesse_CellaSpedizione_Note.HeaderText = "AO_Spedizione_Note";
            this.gv_Commesse_CellaSpedizione_Note.Name = "gv_Commesse_CellaSpedizione_Note";
            this.gv_Commesse_CellaSpedizione_Note.Visible = false;
            // 
            // gv_Commesse_QtaVendita
            // 
            this.gv_Commesse_QtaVendita.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Commesse_QtaVendita.DataPropertyName = "qta_vendita";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.gv_Commesse_QtaVendita.DefaultCellStyle = dataGridViewCellStyle16;
            this.gv_Commesse_QtaVendita.HeaderText = "Q.tà Vendita";
            this.gv_Commesse_QtaVendita.Name = "gv_Commesse_QtaVendita";
            this.gv_Commesse_QtaVendita.Width = 85;
            // 
            // gv_Commesse_CellaVendita
            // 
            this.gv_Commesse_CellaVendita.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Commesse_CellaVendita.DataPropertyName = "AO_Vendita";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.NullValue = ((object)(resources.GetObject("dataGridViewCellStyle17.NullValue")));
            this.gv_Commesse_CellaVendita.DefaultCellStyle = dataGridViewCellStyle17;
            this.gv_Commesse_CellaVendita.HeaderText = "Vendita";
            this.gv_Commesse_CellaVendita.Name = "gv_Commesse_CellaVendita";
            this.gv_Commesse_CellaVendita.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Commesse_CellaVendita.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.gv_Commesse_CellaVendita.Width = 69;
            // 
            // gv_Commesse_CellaVendita_Note
            // 
            this.gv_Commesse_CellaVendita_Note.DataPropertyName = "AO_Vendita_Note";
            this.gv_Commesse_CellaVendita_Note.HeaderText = "AO_Vendita_Note";
            this.gv_Commesse_CellaVendita_Note.Name = "gv_Commesse_CellaVendita_Note";
            this.gv_Commesse_CellaVendita_Note.Visible = false;
            // 
            // gv_Commesse_DistintaBase
            // 
            this.gv_Commesse_DistintaBase.DataPropertyName = "Distinta_Base";
            this.gv_Commesse_DistintaBase.HeaderText = "Distinta_Base";
            this.gv_Commesse_DistintaBase.Name = "gv_Commesse_DistintaBase";
            this.gv_Commesse_DistintaBase.Visible = false;
            // 
            // sFCommesseAperteCLSLBindingSource
            // 
            this.sFCommesseAperteCLSLBindingSource.DataMember = "SF_CommesseAperte_CL_SL";
            this.sFCommesseAperteCLSLBindingSource.DataSource = this.ds_SL;
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sF_CommesseAperte_CL_SLTableAdapter
            // 
            this.sF_CommesseAperte_CL_SLTableAdapter.ClearBeforeFill = true;
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            this.menu_sw_exit.Click += new System.EventHandler(this.menu_sw_exit_Click);
            // 
            // layout_filter
            // 
            this.layout_filter.ColumnCount = 10;
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_filter.Controls.Add(this.btn_AzzeraFiltroNote, 6, 2);
            this.layout_filter.Controls.Add(this.cb_note, 6, 1);
            this.layout_filter.Controls.Add(this.metroLabel6, 7, 0);
            this.layout_filter.Controls.Add(this.btn_AzzeraFiltroFase, 5, 2);
            this.layout_filter.Controls.Add(this.cb_fase, 5, 1);
            this.layout_filter.Controls.Add(this.metroLabel5, 5, 0);
            this.layout_filter.Controls.Add(this.btn_AzzeraFiltroDate, 4, 2);
            this.layout_filter.Controls.Add(this.cb_elencodate, 4, 1);
            this.layout_filter.Controls.Add(this.btn_AzzeraFiltroArticoli, 3, 2);
            this.layout_filter.Controls.Add(this.cb_elencoarticoli, 3, 1);
            this.layout_filter.Controls.Add(this.btn_AzzeraFiltroCommesse, 1, 2);
            this.layout_filter.Controls.Add(this.cb_elencocommesse, 2, 1);
            this.layout_filter.Controls.Add(this.metroLabel4, 4, 0);
            this.layout_filter.Controls.Add(this.metroLabel3, 3, 0);
            this.layout_filter.Controls.Add(this.metroLabel2, 2, 0);
            this.layout_filter.Controls.Add(this.metroLabel1, 0, 0);
            this.layout_filter.Controls.Add(this.cb_elencoClienti, 0, 1);
            this.layout_filter.Controls.Add(this.btn_AzzeraFiltroClienti, 0, 2);
            this.layout_filter.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_filter.Location = new System.Drawing.Point(20, 55);
            this.layout_filter.Name = "layout_filter";
            this.layout_filter.RowCount = 3;
            this.layout_filter.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_filter.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_filter.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_filter.Size = new System.Drawing.Size(1003, 72);
            this.layout_filter.TabIndex = 127;
            // 
            // btn_AzzeraFiltroNote
            // 
            this.btn_AzzeraFiltroNote.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_AzzeraFiltroNote.Location = new System.Drawing.Point(708, 51);
            this.btn_AzzeraFiltroNote.Name = "btn_AzzeraFiltroNote";
            this.btn_AzzeraFiltroNote.Size = new System.Drawing.Size(83, 19);
            this.btn_AzzeraFiltroNote.Style = MetroFramework.MetroColorStyle.Red;
            this.btn_AzzeraFiltroNote.TabIndex = 41;
            this.btn_AzzeraFiltroNote.Text = "Tutti";
            this.btn_AzzeraFiltroNote.UseSelectable = true;
            this.btn_AzzeraFiltroNote.Click += new System.EventHandler(this.btn_AzzeraFiltroNote_Click);
            // 
            // cb_note
            // 
            this.cb_note.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cb_note.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_note.FormattingEnabled = true;
            this.cb_note.Items.AddRange(new object[] {
            "Tutti",
            "Con note",
            "Senza note"});
            this.cb_note.Location = new System.Drawing.Point(703, 22);
            this.cb_note.Name = "cb_note";
            this.cb_note.Size = new System.Drawing.Size(94, 23);
            this.cb_note.TabIndex = 40;
            this.cb_note.SelectedIndexChanged += new System.EventHandler(this.cb_note_SelectedIndexChanged);
            this.cb_note.Click += new System.EventHandler(this.cb_note_Click);
            // 
            // metroLabel6
            // 
            this.metroLabel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel6.Location = new System.Drawing.Point(703, 0);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(94, 19);
            this.metroLabel6.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel6.TabIndex = 39;
            this.metroLabel6.Text = "Note";
            this.metroLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroLabel6.UseStyleColors = true;
            // 
            // btn_AzzeraFiltroFase
            // 
            this.btn_AzzeraFiltroFase.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.layout_filter.SetColumnSpan(this.btn_AzzeraFiltroFase, 2);
            this.btn_AzzeraFiltroFase.Location = new System.Drawing.Point(558, 51);
            this.btn_AzzeraFiltroFase.Name = "btn_AzzeraFiltroFase";
            this.btn_AzzeraFiltroFase.Size = new System.Drawing.Size(83, 19);
            this.btn_AzzeraFiltroFase.Style = MetroFramework.MetroColorStyle.Red;
            this.btn_AzzeraFiltroFase.TabIndex = 38;
            this.btn_AzzeraFiltroFase.Text = "Tutti";
            this.btn_AzzeraFiltroFase.UseSelectable = true;
            this.btn_AzzeraFiltroFase.Click += new System.EventHandler(this.btn_AzzeraFiltroFase_Click);
            // 
            // cb_fase
            // 
            this.layout_filter.SetColumnSpan(this.cb_fase, 2);
            this.cb_fase.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cb_fase.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_fase.FormattingEnabled = true;
            this.cb_fase.Items.AddRange(new object[] {
            "Tutti",
            "Nessuna fase ancora effettuata",
            "Effettuata fase di Programmazione",
            "Effettuata fase di Montaggio",
            "Effettuata fase di Collaudo/Confezionamento",
            "Effettuata fase di Spedizione",
            "Effettuata fase di Vendita"});
            this.cb_fase.Location = new System.Drawing.Point(503, 22);
            this.cb_fase.Name = "cb_fase";
            this.cb_fase.Size = new System.Drawing.Size(194, 23);
            this.cb_fase.TabIndex = 37;
            this.cb_fase.SelectedIndexChanged += new System.EventHandler(this.cb_fase_SelectedIndexChanged);
            this.cb_fase.Click += new System.EventHandler(this.cb_fase_Click);
            // 
            // metroLabel5
            // 
            this.metroLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel5.AutoSize = true;
            this.layout_filter.SetColumnSpan(this.metroLabel5, 2);
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel5.Location = new System.Drawing.Point(503, 0);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(194, 19);
            this.metroLabel5.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel5.TabIndex = 36;
            this.metroLabel5.Text = "Fase";
            this.metroLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroLabel5.UseStyleColors = true;
            // 
            // btn_AzzeraFiltroDate
            // 
            this.btn_AzzeraFiltroDate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_AzzeraFiltroDate.Location = new System.Drawing.Point(408, 51);
            this.btn_AzzeraFiltroDate.Name = "btn_AzzeraFiltroDate";
            this.btn_AzzeraFiltroDate.Size = new System.Drawing.Size(83, 19);
            this.btn_AzzeraFiltroDate.Style = MetroFramework.MetroColorStyle.Red;
            this.btn_AzzeraFiltroDate.TabIndex = 35;
            this.btn_AzzeraFiltroDate.Text = "Tutti";
            this.btn_AzzeraFiltroDate.UseSelectable = true;
            this.btn_AzzeraFiltroDate.Click += new System.EventHandler(this.btn_AzzeraFiltroDate_Click);
            // 
            // cb_elencodate
            // 
            this.cb_elencodate.DataSource = this.sFElencoDateCommAperteBindingSource;
            this.cb_elencodate.DisplayMember = "DataDisplay";
            this.cb_elencodate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cb_elencodate.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_elencodate.FormattingEnabled = true;
            this.cb_elencodate.Location = new System.Drawing.Point(403, 22);
            this.cb_elencodate.Name = "cb_elencodate";
            this.cb_elencodate.Size = new System.Drawing.Size(94, 23);
            this.cb_elencodate.TabIndex = 34;
            this.cb_elencodate.ValueMember = "DataSort";
            this.cb_elencodate.SelectedValueChanged += new System.EventHandler(this.cb_elencodate_SelectedValueChanged);
            this.cb_elencodate.Click += new System.EventHandler(this.cb_elencodate_Click);
            // 
            // sFElencoDateCommAperteBindingSource
            // 
            this.sFElencoDateCommAperteBindingSource.DataMember = "SF_ElencoDate_CommAperte";
            this.sFElencoDateCommAperteBindingSource.DataSource = this.ds_SL;
            this.sFElencoDateCommAperteBindingSource.Sort = "DataSort asc";
            // 
            // btn_AzzeraFiltroArticoli
            // 
            this.btn_AzzeraFiltroArticoli.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_AzzeraFiltroArticoli.Location = new System.Drawing.Point(308, 51);
            this.btn_AzzeraFiltroArticoli.Name = "btn_AzzeraFiltroArticoli";
            this.btn_AzzeraFiltroArticoli.Size = new System.Drawing.Size(83, 19);
            this.btn_AzzeraFiltroArticoli.Style = MetroFramework.MetroColorStyle.Red;
            this.btn_AzzeraFiltroArticoli.TabIndex = 33;
            this.btn_AzzeraFiltroArticoli.Text = "Tutti";
            this.btn_AzzeraFiltroArticoli.UseSelectable = true;
            this.btn_AzzeraFiltroArticoli.Click += new System.EventHandler(this.btn_AzzeraFiltroArticoli_Click);
            // 
            // cb_elencoarticoli
            // 
            this.cb_elencoarticoli.DataSource = this.sFElencoArticoliCommAperteBindingSource;
            this.cb_elencoarticoli.DisplayMember = "ARTICOLO";
            this.cb_elencoarticoli.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cb_elencoarticoli.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_elencoarticoli.FormattingEnabled = true;
            this.cb_elencoarticoli.Location = new System.Drawing.Point(303, 22);
            this.cb_elencoarticoli.Name = "cb_elencoarticoli";
            this.cb_elencoarticoli.Size = new System.Drawing.Size(94, 23);
            this.cb_elencoarticoli.TabIndex = 32;
            this.cb_elencoarticoli.ValueMember = "ARTICOLO";
            this.cb_elencoarticoli.SelectedIndexChanged += new System.EventHandler(this.cb_elencoarticoli_SelectedIndexChanged);
            this.cb_elencoarticoli.Click += new System.EventHandler(this.cb_elencoarticoli_Click);
            // 
            // sFElencoArticoliCommAperteBindingSource
            // 
            this.sFElencoArticoliCommAperteBindingSource.DataMember = "SF_ElencoArticoli_CommAperte";
            this.sFElencoArticoliCommAperteBindingSource.DataSource = this.ds_SL;
            this.sFElencoArticoliCommAperteBindingSource.Sort = "ARTICOLO asc";
            // 
            // btn_AzzeraFiltroCommesse
            // 
            this.btn_AzzeraFiltroCommesse.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_AzzeraFiltroCommesse.Location = new System.Drawing.Point(208, 51);
            this.btn_AzzeraFiltroCommesse.Name = "btn_AzzeraFiltroCommesse";
            this.btn_AzzeraFiltroCommesse.Size = new System.Drawing.Size(83, 19);
            this.btn_AzzeraFiltroCommesse.Style = MetroFramework.MetroColorStyle.Red;
            this.btn_AzzeraFiltroCommesse.TabIndex = 31;
            this.btn_AzzeraFiltroCommesse.Text = "Tutti";
            this.btn_AzzeraFiltroCommesse.UseSelectable = true;
            this.btn_AzzeraFiltroCommesse.Click += new System.EventHandler(this.btn_AzzeraFiltroCommesse_Click);
            // 
            // cb_elencocommesse
            // 
            this.cb_elencocommesse.DataSource = this.sFElencoCommesseCommAperteBindingSource;
            this.cb_elencocommesse.DisplayMember = "COMMESSASHORT";
            this.cb_elencocommesse.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cb_elencocommesse.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_elencocommesse.FormattingEnabled = true;
            this.cb_elencocommesse.Location = new System.Drawing.Point(203, 22);
            this.cb_elencocommesse.Name = "cb_elencocommesse";
            this.cb_elencocommesse.Size = new System.Drawing.Size(94, 23);
            this.cb_elencocommesse.TabIndex = 30;
            this.cb_elencocommesse.ValueMember = "COMMESSASHORT";
            this.cb_elencocommesse.SelectedIndexChanged += new System.EventHandler(this.cb_elencocommesse_SelectedIndexChanged);
            this.cb_elencocommesse.Click += new System.EventHandler(this.cb_elencocommesse_Click);
            // 
            // sFElencoCommesseCommAperteBindingSource
            // 
            this.sFElencoCommesseCommAperteBindingSource.DataMember = "SF_ElencoCommesse_CommAperte";
            this.sFElencoCommesseCommAperteBindingSource.DataSource = this.ds_SL;
            this.sFElencoCommesseCommAperteBindingSource.Sort = "COMMESSASHORT asc";
            // 
            // metroLabel4
            // 
            this.metroLabel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(403, 0);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(94, 19);
            this.metroLabel4.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel4.TabIndex = 25;
            this.metroLabel4.Text = "Consegna";
            this.metroLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroLabel4.UseStyleColors = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Location = new System.Drawing.Point(303, 0);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(94, 19);
            this.metroLabel3.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel3.TabIndex = 24;
            this.metroLabel3.Text = "Articolo";
            this.metroLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroLabel3.UseStyleColors = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Location = new System.Drawing.Point(203, 0);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(94, 19);
            this.metroLabel2.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel2.TabIndex = 23;
            this.metroLabel2.Text = "Commessa";
            this.metroLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroLabel2.UseStyleColors = true;
            // 
            // metroLabel1
            // 
            this.metroLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel1.AutoSize = true;
            this.layout_filter.SetColumnSpan(this.metroLabel1, 2);
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(3, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(194, 19);
            this.metroLabel1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel1.TabIndex = 22;
            this.metroLabel1.Text = "Cliente";
            this.metroLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroLabel1.UseStyleColors = true;
            // 
            // cb_elencoClienti
            // 
            this.layout_filter.SetColumnSpan(this.cb_elencoClienti, 2);
            this.cb_elencoClienti.DataSource = this.sFElencoClientiCommAperteBindingSource;
            this.cb_elencoClienti.DisplayMember = "RAGIONE_SOCIALE";
            this.cb_elencoClienti.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cb_elencoClienti.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_elencoClienti.FormattingEnabled = true;
            this.cb_elencoClienti.Location = new System.Drawing.Point(3, 22);
            this.cb_elencoClienti.Name = "cb_elencoClienti";
            this.cb_elencoClienti.Size = new System.Drawing.Size(194, 23);
            this.cb_elencoClienti.TabIndex = 27;
            this.cb_elencoClienti.ValueMember = "CodAnagrafico";
            this.cb_elencoClienti.SelectedIndexChanged += new System.EventHandler(this.cb_elencoClienti_SelectedIndexChanged);
            this.cb_elencoClienti.Click += new System.EventHandler(this.cb_elencoClienti_Click);
            // 
            // sFElencoClientiCommAperteBindingSource
            // 
            this.sFElencoClientiCommAperteBindingSource.DataMember = "SF_ElencoClienti_CommAperte";
            this.sFElencoClientiCommAperteBindingSource.DataSource = this.ds_SL;
            // 
            // btn_AzzeraFiltroClienti
            // 
            this.btn_AzzeraFiltroClienti.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.layout_filter.SetColumnSpan(this.btn_AzzeraFiltroClienti, 2);
            this.btn_AzzeraFiltroClienti.Location = new System.Drawing.Point(58, 51);
            this.btn_AzzeraFiltroClienti.Name = "btn_AzzeraFiltroClienti";
            this.btn_AzzeraFiltroClienti.Size = new System.Drawing.Size(83, 19);
            this.btn_AzzeraFiltroClienti.Style = MetroFramework.MetroColorStyle.Red;
            this.btn_AzzeraFiltroClienti.TabIndex = 29;
            this.btn_AzzeraFiltroClienti.Text = "Tutti";
            this.btn_AzzeraFiltroClienti.UseSelectable = true;
            this.btn_AzzeraFiltroClienti.Click += new System.EventHandler(this.btn_AzzeraFiltroClienti_Click);
            // 
            // sF_ElencoClienti_CommAperteTableAdapter
            // 
            this.sF_ElencoClienti_CommAperteTableAdapter.ClearBeforeFill = true;
            // 
            // distanziatore
            // 
            this.distanziatore.Dock = System.Windows.Forms.DockStyle.Top;
            this.distanziatore.HorizontalScrollbarBarColor = true;
            this.distanziatore.HorizontalScrollbarHighlightOnWheel = false;
            this.distanziatore.HorizontalScrollbarSize = 10;
            this.distanziatore.Location = new System.Drawing.Point(20, 127);
            this.distanziatore.Name = "distanziatore";
            this.distanziatore.Size = new System.Drawing.Size(1003, 5);
            this.distanziatore.TabIndex = 128;
            this.distanziatore.VerticalScrollbarBarColor = true;
            this.distanziatore.VerticalScrollbarHighlightOnWheel = false;
            this.distanziatore.VerticalScrollbarSize = 10;
            // 
            // sF_ElencoCommesse_CommAperteTableAdapter
            // 
            this.sF_ElencoCommesse_CommAperteTableAdapter.ClearBeforeFill = true;
            // 
            // sF_ElencoArticoli_CommAperteTableAdapter
            // 
            this.sF_ElencoArticoli_CommAperteTableAdapter.ClearBeforeFill = true;
            // 
            // sF_ElencoDate_CommAperteTableAdapter
            // 
            this.sF_ElencoDate_CommAperteTableAdapter.ClearBeforeFill = true;
            // 
            // miniToolStrip
            // 
            this.miniToolStrip.AccessibleName = "Selezione nuovo elemento";
            this.miniToolStrip.AccessibleRole = System.Windows.Forms.AccessibleRole.ComboBox;
            this.miniToolStrip.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.miniToolStrip.AutoSize = false;
            this.miniToolStrip.BackColor = System.Drawing.Color.Gainsboro;
            this.miniToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.miniToolStrip.Location = new System.Drawing.Point(107, 27);
            this.miniToolStrip.Name = "miniToolStrip";
            this.miniToolStrip.Size = new System.Drawing.Size(100, 24);
            this.miniToolStrip.TabIndex = 82;
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Gainsboro;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Location = new System.Drawing.Point(100, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(100, 24);
            this.pan_Menu_exit.TabIndex = 82;
            this.pan_Menu_exit.Text = "menuStrip1";
            // 
            // layout_orizz_menu
            // 
            this.layout_orizz_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.ColumnCount = 10;
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.Controls.Add(this.menuStrip1, 0, 0);
            this.layout_orizz_menu.Controls.Add(this.menu_sw, 10, 0);
            this.layout_orizz_menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_orizz_menu.Location = new System.Drawing.Point(20, 30);
            this.layout_orizz_menu.Name = "layout_orizz_menu";
            this.layout_orizz_menu.RowCount = 1;
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_orizz_menu.Size = new System.Drawing.Size(1003, 25);
            this.layout_orizz_menu.TabIndex = 129;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Gainsboro;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(100, 24);
            this.menuStrip1.TabIndex = 83;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Image = global::SmartLineProduction.Properties.Resources.Refresh_16x;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.ShortcutKeyDisplayString = "F5";
            this.toolStripMenuItem2.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.toolStripMenuItem2.Size = new System.Drawing.Size(123, 20);
            this.toolStripMenuItem2.Text = "Refresh data (F5)";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // menu_sw
            // 
            this.menu_sw.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.menu_sw.BackColor = System.Drawing.Color.Gainsboro;
            this.menu_sw.Dock = System.Windows.Forms.DockStyle.None;
            this.menu_sw.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.menu_sw.Location = new System.Drawing.Point(928, 0);
            this.menu_sw.Name = "menu_sw";
            this.menu_sw.Size = new System.Drawing.Size(75, 24);
            this.menu_sw.TabIndex = 82;
            this.menu_sw.Text = "menuStrip1";
            this.menu_sw.Click += new System.EventHandler(this.menu_sw_exit_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem1.Image")));
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(67, 20);
            this.toolStripMenuItem1.Text = "Uscita";
            // 
            // avanzamentoOrdiniBindingSource
            // 
            this.avanzamentoOrdiniBindingSource.DataMember = "Avanzamento_Ordini";
            this.avanzamentoOrdiniBindingSource.DataSource = this.ds_SL;
            // 
            // avanzamento_OrdiniTableAdapter
            // 
            this.avanzamento_OrdiniTableAdapter.ClearBeforeFill = true;
            // 
            // UC_Avanzamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1043, 579);
            this.ControlBox = false;
            this.Controls.Add(this.gv_Commesse);
            this.Controls.Add(this.distanziatore);
            this.Controls.Add(this.layout_filter);
            this.Controls.Add(this.layout_orizz_menu);
            this.DisplayHeader = false;
            this.Name = "UC_Avanzamento";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Resizable = false;
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.UC_Avanzamento_FormClosing);
            this.Load += new System.EventHandler(this.UC_Avanzamento_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gv_Commesse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFCommesseAperteCLSLBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            this.layout_filter.ResumeLayout(false);
            this.layout_filter.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sFElencoDateCommAperteBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFElencoArticoliCommAperteBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFElencoCommesseCommAperteBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFElencoClientiCommAperteBindingSource)).EndInit();
            this.layout_orizz_menu.ResumeLayout(false);
            this.layout_orizz_menu.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.menu_sw.ResumeLayout(false);
            this.menu_sw.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.avanzamentoOrdiniBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroGrid gv_Commesse;
        private ds_SL ds_SL;
        private System.Windows.Forms.BindingSource sFCommesseAperteCLSLBindingSource;
        private ds_SLTableAdapters.SF_CommesseAperte_CL_SLTableAdapter sF_CommesseAperte_CL_SLTableAdapter;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
        private System.Windows.Forms.TableLayoutPanel layout_filter;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.ComboBox cb_elencoClienti;
        private System.Windows.Forms.BindingSource sFElencoClientiCommAperteBindingSource;
        private ds_SLTableAdapters.SF_ElencoClienti_CommAperteTableAdapter sF_ElencoClienti_CommAperteTableAdapter;
        private MetroFramework.Controls.MetroPanel distanziatore;
        private MetroFramework.Controls.MetroButton btn_AzzeraFiltroClienti;
        private System.Windows.Forms.ComboBox cb_elencocommesse;
        private System.Windows.Forms.BindingSource sFElencoCommesseCommAperteBindingSource;
        private ds_SLTableAdapters.SF_ElencoCommesse_CommAperteTableAdapter sF_ElencoCommesse_CommAperteTableAdapter;
        private MetroFramework.Controls.MetroButton btn_AzzeraFiltroCommesse;
        private MetroFramework.Controls.MetroButton btn_AzzeraFiltroArticoli;
        private System.Windows.Forms.ComboBox cb_elencoarticoli;
        private System.Windows.Forms.BindingSource sFElencoArticoliCommAperteBindingSource;
        private ds_SLTableAdapters.SF_ElencoArticoli_CommAperteTableAdapter sF_ElencoArticoli_CommAperteTableAdapter;
        private MetroFramework.Controls.MetroButton btn_AzzeraFiltroDate;
        private System.Windows.Forms.ComboBox cb_elencodate;
        private System.Windows.Forms.BindingSource sFElencoDateCommAperteBindingSource;
        private ds_SLTableAdapters.SF_ElencoDate_CommAperteTableAdapter sF_ElencoDate_CommAperteTableAdapter;
        private System.Windows.Forms.ComboBox cb_fase;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroButton btn_AzzeraFiltroFase;
        private MetroFramework.Controls.MetroButton btn_AzzeraFiltroNote;
        private System.Windows.Forms.ComboBox cb_note;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private System.Windows.Forms.MenuStrip miniToolStrip;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.TableLayoutPanel layout_orizz_menu;
        private System.Windows.Forms.MenuStrip menu_sw;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_Entita;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_TipoOrdine;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_DataOrdine;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_NumeroOrdine;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_NumeroRiga;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_CodAnagrafico;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_CommesseDataConfConsegna;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_RagioneSociale;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_NazioneFiscale;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_CommessaLong;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_QtaInevasa;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_CommessaShort;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_DataConsegnaSort;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_Articolo;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_Um;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_PrezzoUnitario;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_QtaOrdinata;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_QtaSpedita;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_Importo;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_ImportoEvaso;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_ImportoDaEvadere;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_MeseConsegna;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_NomeMeseConsegna;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_AnnoConsegna;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_CommessaLong2;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_QtaProgrammazione;
        private System.Windows.Forms.DataGridViewImageColumn gv_Commesse_CellaProgrammazione;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_CellaProgrammazione_Note;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_QtaMontaggio;
        private System.Windows.Forms.DataGridViewImageColumn gv_Commesse_CellaMontaggio;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_CellaMontaggio_Note;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_QtaCollaudoConfezionamento;
        private System.Windows.Forms.DataGridViewImageColumn gv_Commesse_CellaCollConf;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_CellaCollConf_Note;
        private System.Windows.Forms.DataGridViewImageColumn gv_Commesse_CellaSpedizione;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_CellaSpedizione_Note;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_QtaVendita;
        private System.Windows.Forms.DataGridViewImageColumn gv_Commesse_CellaVendita;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_CellaVendita_Note;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Commesse_DistintaBase;
        private System.Windows.Forms.BindingSource avanzamentoOrdiniBindingSource;
        private ds_SLTableAdapters.Avanzamento_OrdiniTableAdapter avanzamento_OrdiniTableAdapter;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
    }
}