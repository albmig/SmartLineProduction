﻿namespace SmartLineProduction
{
    partial class UC_FW_P
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.uscitaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MainMenu = new System.Windows.Forms.MenuStrip();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            this.MainMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // uscitaToolStripMenuItem
            // 
            this.uscitaToolStripMenuItem.Name = "uscitaToolStripMenuItem";
            this.uscitaToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.uscitaToolStripMenuItem.Text = "Uscita";
            this.uscitaToolStripMenuItem.Click += new System.EventHandler(this.uscitaToolStripMenuItem_Click);
            // 
            // MainMenu
            // 
            this.MainMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.MainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uscitaToolStripMenuItem});
            this.MainMenu.Location = new System.Drawing.Point(20, 30);
            this.MainMenu.Name = "MainMenu";
            this.MainMenu.Size = new System.Drawing.Size(1003, 24);
            this.MainMenu.TabIndex = 71;
            this.MainMenu.Text = "menuStrip1";
            // 
            // UC_FW_P
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1043, 579);
            this.ControlBox = false;
            this.Controls.Add(this.MainMenu);
            this.DisplayHeader = false;
            this.Name = "UC_FW_P";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Resizable = false;
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            this.MainMenu.ResumeLayout(false);
            this.MainMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private ds_SL ds_SL;
        private System.Windows.Forms.ToolStripMenuItem uscitaToolStripMenuItem;
        private System.Windows.Forms.MenuStrip MainMenu;
    }
}