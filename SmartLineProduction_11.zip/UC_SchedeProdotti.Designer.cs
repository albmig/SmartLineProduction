﻿namespace SmartLineProduction
{
    partial class UC_SchedeProdotti
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_SchedeProdotti));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            this.layout_orizz_menu = new System.Windows.Forms.TableLayoutPanel();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.panel_Schede = new MetroFramework.Controls.MetroPanel();
            this.Tab_Schede = new MetroFramework.Controls.MetroTabControl();
            this.tab_Kit = new System.Windows.Forms.TabPage();
            this.layout_Kit = new System.Windows.Forms.TableLayoutPanel();
            this.panel_grid_Kit = new MetroFramework.Controls.MetroPanel();
            this.gv_Kit = new MetroFramework.Controls.MetroGrid();
            this.articoloDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descrizioneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descrizioneEstesaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.modelloDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sFArticoliSchedeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.panel_search_kit = new MetroFramework.Controls.MetroPanel();
            this.tb_grid_kit = new MetroFramework.Controls.MetroTextBox();
            this.layout_pdf_Kit = new System.Windows.Forms.TableLayoutPanel();
            this.Kit_pdf_it = new AxAcroPDFLib.AxAcroPDF();
            this.Kit_pdf_en = new AxAcroPDFLib.AxAcroPDF();
            this.panel_des_art_Kit = new MetroFramework.Controls.MetroPanel();
            this.lab_des1_articolo = new MetroFramework.Controls.MetroLabel();
            this.lab_des2_articolo = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.tab_Palmari = new System.Windows.Forms.TabPage();
            this.layout_Palmari = new System.Windows.Forms.TableLayoutPanel();
            this.panel_grid_Palmari = new MetroFramework.Controls.MetroPanel();
            this.gv_Palmari = new MetroFramework.Controls.MetroGrid();
            this.articoloDeviceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descrizioneDeviceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descrizioneEstesaDeviceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.modelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.famDeviceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numFunzioniDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipoDeviceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clienteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.articoloPadreDBDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataInizioValiditaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataFineValiditaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.articoloFWDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.desFWDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.desEstFWDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sFItemDeviceFWDesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.tb_grid_palmari = new MetroFramework.Controls.MetroTextBox();
            this.layout_pdf_Palmari = new System.Windows.Forms.TableLayoutPanel();
            this.Palmari_pdf_it = new AxAcroPDFLib.AxAcroPDF();
            this.Palmari_pdf_en = new AxAcroPDFLib.AxAcroPDF();
            this.panel_des_art_Palmari = new MetroFramework.Controls.MetroPanel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.tab_Ricevitori = new System.Windows.Forms.TabPage();
            this.layout_Ricevitori = new System.Windows.Forms.TableLayoutPanel();
            this.panel_grid_Ricevitori = new MetroFramework.Controls.MetroPanel();
            this.gv_Ricevitori = new MetroFramework.Controls.MetroGrid();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.metroPanel3 = new MetroFramework.Controls.MetroPanel();
            this.tb_grid_ricevitori = new MetroFramework.Controls.MetroTextBox();
            this.layout_pdf_Ricevitori = new System.Windows.Forms.TableLayoutPanel();
            this.Ricevitori_pdf_it = new AxAcroPDFLib.AxAcroPDF();
            this.Ricevitori_pdf_en = new AxAcroPDFLib.AxAcroPDF();
            this.panel_des_art_Ricevitori = new MetroFramework.Controls.MetroPanel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.tab_Cablaggi = new System.Windows.Forms.TabPage();
            this.layout_Cablaggi = new System.Windows.Forms.TableLayoutPanel();
            this.panel_grid_Cablaggi = new MetroFramework.Controls.MetroPanel();
            this.gv_Cablaggi = new MetroFramework.Controls.MetroGrid();
            this.articoloDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descrizioneDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descrizioneEstesaDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.modelloDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sFCablaggiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroPanel4 = new MetroFramework.Controls.MetroPanel();
            this.tb_grid_cablaggi = new MetroFramework.Controls.MetroTextBox();
            this.layout_pdf_Cablaggi = new System.Windows.Forms.TableLayoutPanel();
            this.Cablaggi_pdf_it = new AxAcroPDFLib.AxAcroPDF();
            this.Cablaggi_pdf_en = new AxAcroPDFLib.AxAcroPDF();
            this.panel_des_art_Cablaggi = new MetroFramework.Controls.MetroPanel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.tab_FW_P = new System.Windows.Forms.TabPage();
            this.tab_FW_R = new System.Windows.Forms.TabPage();
            this.sF_ArticoliSchedeTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_ArticoliSchedeTableAdapter();
            this.sF_ItemDevice_FW_DesTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_ItemDevice_FW_DesTableAdapter();
            this.sF_CablaggiTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_CablaggiTableAdapter();
            this.layout_orizz_menu.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            this.panel_Schede.SuspendLayout();
            this.Tab_Schede.SuspendLayout();
            this.tab_Kit.SuspendLayout();
            this.layout_Kit.SuspendLayout();
            this.panel_grid_Kit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Kit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFArticoliSchedeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            this.panel_search_kit.SuspendLayout();
            this.layout_pdf_Kit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Kit_pdf_it)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kit_pdf_en)).BeginInit();
            this.panel_des_art_Kit.SuspendLayout();
            this.tab_Palmari.SuspendLayout();
            this.layout_Palmari.SuspendLayout();
            this.panel_grid_Palmari.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Palmari)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFItemDeviceFWDesBindingSource)).BeginInit();
            this.metroPanel2.SuspendLayout();
            this.layout_pdf_Palmari.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Palmari_pdf_it)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Palmari_pdf_en)).BeginInit();
            this.panel_des_art_Palmari.SuspendLayout();
            this.tab_Ricevitori.SuspendLayout();
            this.layout_Ricevitori.SuspendLayout();
            this.panel_grid_Ricevitori.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Ricevitori)).BeginInit();
            this.metroPanel3.SuspendLayout();
            this.layout_pdf_Ricevitori.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Ricevitori_pdf_it)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ricevitori_pdf_en)).BeginInit();
            this.panel_des_art_Ricevitori.SuspendLayout();
            this.tab_Cablaggi.SuspendLayout();
            this.layout_Cablaggi.SuspendLayout();
            this.panel_grid_Cablaggi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Cablaggi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFCablaggiBindingSource)).BeginInit();
            this.metroPanel4.SuspendLayout();
            this.layout_pdf_Cablaggi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Cablaggi_pdf_it)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cablaggi_pdf_en)).BeginInit();
            this.panel_des_art_Cablaggi.SuspendLayout();
            this.SuspendLayout();
            // 
            // layout_orizz_menu
            // 
            this.layout_orizz_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.ColumnCount = 10;
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_exit, 10, 0);
            this.layout_orizz_menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_orizz_menu.Location = new System.Drawing.Point(20, 30);
            this.layout_orizz_menu.Name = "layout_orizz_menu";
            this.layout_orizz_menu.RowCount = 1;
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_orizz_menu.Size = new System.Drawing.Size(948, 25);
            this.layout_orizz_menu.TabIndex = 120;
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Gainsboro;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(873, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(75, 24);
            this.pan_Menu_exit.TabIndex = 82;
            this.pan_Menu_exit.Text = "menuStrip1";
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            this.menu_sw_exit.Click += new System.EventHandler(this.menu_sw_exit_Click);
            // 
            // panel_Schede
            // 
            this.panel_Schede.Controls.Add(this.Tab_Schede);
            this.panel_Schede.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Schede.HorizontalScrollbarBarColor = true;
            this.panel_Schede.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_Schede.HorizontalScrollbarSize = 10;
            this.panel_Schede.Location = new System.Drawing.Point(20, 55);
            this.panel_Schede.Name = "panel_Schede";
            this.panel_Schede.Size = new System.Drawing.Size(948, 351);
            this.panel_Schede.TabIndex = 121;
            this.panel_Schede.VerticalScrollbarBarColor = true;
            this.panel_Schede.VerticalScrollbarHighlightOnWheel = false;
            this.panel_Schede.VerticalScrollbarSize = 10;
            // 
            // Tab_Schede
            // 
            this.Tab_Schede.Controls.Add(this.tab_Kit);
            this.Tab_Schede.Controls.Add(this.tab_Palmari);
            this.Tab_Schede.Controls.Add(this.tab_Ricevitori);
            this.Tab_Schede.Controls.Add(this.tab_Cablaggi);
            this.Tab_Schede.Controls.Add(this.tab_FW_P);
            this.Tab_Schede.Controls.Add(this.tab_FW_R);
            this.Tab_Schede.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Tab_Schede.ItemSize = new System.Drawing.Size(150, 34);
            this.Tab_Schede.Location = new System.Drawing.Point(0, 0);
            this.Tab_Schede.Name = "Tab_Schede";
            this.Tab_Schede.SelectedIndex = 2;
            this.Tab_Schede.Size = new System.Drawing.Size(948, 351);
            this.Tab_Schede.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.Tab_Schede.Style = MetroFramework.MetroColorStyle.Red;
            this.Tab_Schede.TabIndex = 2;
            this.Tab_Schede.UseSelectable = true;
            this.Tab_Schede.UseStyleColors = true;
            // 
            // tab_Kit
            // 
            this.tab_Kit.Controls.Add(this.layout_Kit);
            this.tab_Kit.Location = new System.Drawing.Point(4, 38);
            this.tab_Kit.Name = "tab_Kit";
            this.tab_Kit.Size = new System.Drawing.Size(940, 309);
            this.tab_Kit.TabIndex = 0;
            this.tab_Kit.Text = "Kit";
            this.tab_Kit.Enter += new System.EventHandler(this.tab_Kit_Enter);
            // 
            // layout_Kit
            // 
            this.layout_Kit.ColumnCount = 2;
            this.layout_Kit.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.layout_Kit.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.layout_Kit.Controls.Add(this.panel_grid_Kit, 0, 0);
            this.layout_Kit.Controls.Add(this.layout_pdf_Kit, 1, 1);
            this.layout_Kit.Controls.Add(this.panel_des_art_Kit, 1, 0);
            this.layout_Kit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Kit.Location = new System.Drawing.Point(0, 0);
            this.layout_Kit.Name = "layout_Kit";
            this.layout_Kit.RowCount = 2;
            this.layout_Kit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.layout_Kit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_Kit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Kit.Size = new System.Drawing.Size(940, 309);
            this.layout_Kit.TabIndex = 123;
            // 
            // panel_grid_Kit
            // 
            this.panel_grid_Kit.Controls.Add(this.gv_Kit);
            this.panel_grid_Kit.Controls.Add(this.panel_search_kit);
            this.panel_grid_Kit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_grid_Kit.HorizontalScrollbarBarColor = true;
            this.panel_grid_Kit.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_grid_Kit.HorizontalScrollbarSize = 10;
            this.panel_grid_Kit.Location = new System.Drawing.Point(3, 3);
            this.panel_grid_Kit.Name = "panel_grid_Kit";
            this.layout_Kit.SetRowSpan(this.panel_grid_Kit, 2);
            this.panel_grid_Kit.Size = new System.Drawing.Size(144, 303);
            this.panel_grid_Kit.TabIndex = 83;
            this.panel_grid_Kit.VerticalScrollbarBarColor = true;
            this.panel_grid_Kit.VerticalScrollbarHighlightOnWheel = false;
            this.panel_grid_Kit.VerticalScrollbarSize = 10;
            // 
            // gv_Kit
            // 
            this.gv_Kit.AllowUserToAddRows = false;
            this.gv_Kit.AllowUserToDeleteRows = false;
            this.gv_Kit.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_Kit.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.gv_Kit.AutoGenerateColumns = false;
            this.gv_Kit.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Kit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Kit.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_Kit.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Kit.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gv_Kit.ColumnHeadersHeight = 40;
            this.gv_Kit.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.articoloDataGridViewTextBoxColumn,
            this.descrizioneDataGridViewTextBoxColumn,
            this.descrizioneEstesaDataGridViewTextBoxColumn,
            this.modelloDataGridViewTextBoxColumn});
            this.gv_Kit.DataSource = this.sFArticoliSchedeBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Kit.DefaultCellStyle = dataGridViewCellStyle3;
            this.gv_Kit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Kit.EnableHeadersVisualStyles = false;
            this.gv_Kit.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Kit.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Kit.Location = new System.Drawing.Point(0, 30);
            this.gv_Kit.MultiSelect = false;
            this.gv_Kit.Name = "gv_Kit";
            this.gv_Kit.ReadOnly = true;
            this.gv_Kit.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Kit.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.gv_Kit.RowHeadersVisible = false;
            this.gv_Kit.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Kit.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Kit.Size = new System.Drawing.Size(144, 273);
            this.gv_Kit.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_Kit.TabIndex = 0;
            this.gv_Kit.UseStyleColors = true;
            // 
            // articoloDataGridViewTextBoxColumn
            // 
            this.articoloDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.articoloDataGridViewTextBoxColumn.DataPropertyName = "Articolo";
            this.articoloDataGridViewTextBoxColumn.HeaderText = "Kit";
            this.articoloDataGridViewTextBoxColumn.Name = "articoloDataGridViewTextBoxColumn";
            this.articoloDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // descrizioneDataGridViewTextBoxColumn
            // 
            this.descrizioneDataGridViewTextBoxColumn.DataPropertyName = "Descrizione";
            this.descrizioneDataGridViewTextBoxColumn.HeaderText = "Descrizione";
            this.descrizioneDataGridViewTextBoxColumn.Name = "descrizioneDataGridViewTextBoxColumn";
            this.descrizioneDataGridViewTextBoxColumn.ReadOnly = true;
            this.descrizioneDataGridViewTextBoxColumn.Visible = false;
            // 
            // descrizioneEstesaDataGridViewTextBoxColumn
            // 
            this.descrizioneEstesaDataGridViewTextBoxColumn.DataPropertyName = "DescrizioneEstesa";
            this.descrizioneEstesaDataGridViewTextBoxColumn.HeaderText = "DescrizioneEstesa";
            this.descrizioneEstesaDataGridViewTextBoxColumn.Name = "descrizioneEstesaDataGridViewTextBoxColumn";
            this.descrizioneEstesaDataGridViewTextBoxColumn.ReadOnly = true;
            this.descrizioneEstesaDataGridViewTextBoxColumn.Visible = false;
            // 
            // modelloDataGridViewTextBoxColumn
            // 
            this.modelloDataGridViewTextBoxColumn.DataPropertyName = "Modello";
            this.modelloDataGridViewTextBoxColumn.HeaderText = "Modello";
            this.modelloDataGridViewTextBoxColumn.Name = "modelloDataGridViewTextBoxColumn";
            this.modelloDataGridViewTextBoxColumn.ReadOnly = true;
            this.modelloDataGridViewTextBoxColumn.Visible = false;
            // 
            // sFArticoliSchedeBindingSource
            // 
            this.sFArticoliSchedeBindingSource.DataMember = "SF_ArticoliSchede";
            this.sFArticoliSchedeBindingSource.DataSource = this.ds_SL;
            this.sFArticoliSchedeBindingSource.CurrentChanged += new System.EventHandler(this.sFArticoliSchedeBindingSource_CurrentChanged);
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel_search_kit
            // 
            this.panel_search_kit.BackColor = System.Drawing.Color.Transparent;
            this.panel_search_kit.Controls.Add(this.tb_grid_kit);
            this.panel_search_kit.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_search_kit.HorizontalScrollbarBarColor = true;
            this.panel_search_kit.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_search_kit.HorizontalScrollbarSize = 10;
            this.panel_search_kit.Location = new System.Drawing.Point(0, 0);
            this.panel_search_kit.Name = "panel_search_kit";
            this.panel_search_kit.Size = new System.Drawing.Size(144, 30);
            this.panel_search_kit.TabIndex = 3;
            this.panel_search_kit.UseCustomBackColor = true;
            this.panel_search_kit.VerticalScrollbarBarColor = true;
            this.panel_search_kit.VerticalScrollbarHighlightOnWheel = false;
            this.panel_search_kit.VerticalScrollbarSize = 10;
            // 
            // tb_grid_kit
            // 
            // 
            // 
            // 
            this.tb_grid_kit.CustomButton.Image = null;
            this.tb_grid_kit.CustomButton.Location = new System.Drawing.Point(122, 1);
            this.tb_grid_kit.CustomButton.Name = "";
            this.tb_grid_kit.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_grid_kit.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_grid_kit.CustomButton.TabIndex = 1;
            this.tb_grid_kit.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_grid_kit.CustomButton.UseSelectable = true;
            this.tb_grid_kit.CustomButton.Visible = false;
            this.tb_grid_kit.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_grid_kit.Icon = global::SmartLineProduction.Properties.Resources.Lente;
            this.tb_grid_kit.IconRight = true;
            this.tb_grid_kit.Lines = new string[] {
        "metroTextBox1"};
            this.tb_grid_kit.Location = new System.Drawing.Point(0, 0);
            this.tb_grid_kit.MaxLength = 32767;
            this.tb_grid_kit.Name = "tb_grid_kit";
            this.tb_grid_kit.PasswordChar = '\0';
            this.tb_grid_kit.PromptText = "ricerca";
            this.tb_grid_kit.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_grid_kit.SelectedText = "";
            this.tb_grid_kit.SelectionLength = 0;
            this.tb_grid_kit.SelectionStart = 0;
            this.tb_grid_kit.ShortcutsEnabled = true;
            this.tb_grid_kit.Size = new System.Drawing.Size(144, 23);
            this.tb_grid_kit.TabIndex = 2;
            this.tb_grid_kit.Text = "metroTextBox1";
            this.tb_grid_kit.UseSelectable = true;
            this.tb_grid_kit.WaterMark = "ricerca";
            this.tb_grid_kit.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_grid_kit.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tb_grid_kit.TextChanged += new System.EventHandler(this.tb_grid_kit_TextChanged);
            // 
            // layout_pdf_Kit
            // 
            this.layout_pdf_Kit.ColumnCount = 2;
            this.layout_pdf_Kit.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.layout_pdf_Kit.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.layout_pdf_Kit.Controls.Add(this.Kit_pdf_it, 0, 0);
            this.layout_pdf_Kit.Controls.Add(this.Kit_pdf_en, 1, 0);
            this.layout_pdf_Kit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_pdf_Kit.Location = new System.Drawing.Point(153, 53);
            this.layout_pdf_Kit.Name = "layout_pdf_Kit";
            this.layout_pdf_Kit.RowCount = 1;
            this.layout_pdf_Kit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_pdf_Kit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 253F));
            this.layout_pdf_Kit.Size = new System.Drawing.Size(784, 253);
            this.layout_pdf_Kit.TabIndex = 122;
            // 
            // Kit_pdf_it
            // 
            this.Kit_pdf_it.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Kit_pdf_it.Enabled = true;
            this.Kit_pdf_it.Location = new System.Drawing.Point(3, 3);
            this.Kit_pdf_it.Name = "Kit_pdf_it";
            this.Kit_pdf_it.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Kit_pdf_it.OcxState")));
            this.Kit_pdf_it.Size = new System.Drawing.Size(386, 247);
            this.Kit_pdf_it.TabIndex = 0;
            // 
            // Kit_pdf_en
            // 
            this.Kit_pdf_en.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Kit_pdf_en.Enabled = true;
            this.Kit_pdf_en.Location = new System.Drawing.Point(395, 3);
            this.Kit_pdf_en.Name = "Kit_pdf_en";
            this.Kit_pdf_en.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Kit_pdf_en.OcxState")));
            this.Kit_pdf_en.Size = new System.Drawing.Size(386, 247);
            this.Kit_pdf_en.TabIndex = 1;
            // 
            // panel_des_art_Kit
            // 
            this.panel_des_art_Kit.Controls.Add(this.lab_des1_articolo);
            this.panel_des_art_Kit.Controls.Add(this.lab_des2_articolo);
            this.panel_des_art_Kit.Controls.Add(this.metroLabel1);
            this.panel_des_art_Kit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_des_art_Kit.HorizontalScrollbarBarColor = true;
            this.panel_des_art_Kit.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Kit.HorizontalScrollbarSize = 10;
            this.panel_des_art_Kit.Location = new System.Drawing.Point(153, 3);
            this.panel_des_art_Kit.Name = "panel_des_art_Kit";
            this.panel_des_art_Kit.Size = new System.Drawing.Size(784, 44);
            this.panel_des_art_Kit.TabIndex = 1;
            this.panel_des_art_Kit.VerticalScrollbarBarColor = true;
            this.panel_des_art_Kit.VerticalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Kit.VerticalScrollbarSize = 10;
            // 
            // lab_des1_articolo
            // 
            this.lab_des1_articolo.AutoSize = true;
            this.lab_des1_articolo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFArticoliSchedeBindingSource, "Descrizione", true));
            this.lab_des1_articolo.Location = new System.Drawing.Point(93, 0);
            this.lab_des1_articolo.Name = "lab_des1_articolo";
            this.lab_des1_articolo.Size = new System.Drawing.Size(41, 19);
            this.lab_des1_articolo.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_des1_articolo.TabIndex = 3;
            this.lab_des1_articolo.Text = "Des_1";
            this.lab_des1_articolo.UseStyleColors = true;
            // 
            // lab_des2_articolo
            // 
            this.lab_des2_articolo.AutoSize = true;
            this.lab_des2_articolo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFArticoliSchedeBindingSource, "DescrizioneEstesa", true));
            this.lab_des2_articolo.Location = new System.Drawing.Point(93, 19);
            this.lab_des2_articolo.Name = "lab_des2_articolo";
            this.lab_des2_articolo.Size = new System.Drawing.Size(43, 19);
            this.lab_des2_articolo.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_des2_articolo.TabIndex = 4;
            this.lab_des2_articolo.Text = "Des_2";
            this.lab_des2_articolo.UseStyleColors = true;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(3, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(75, 19);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "Descrizione";
            // 
            // tab_Palmari
            // 
            this.tab_Palmari.Controls.Add(this.layout_Palmari);
            this.tab_Palmari.Location = new System.Drawing.Point(4, 38);
            this.tab_Palmari.Name = "tab_Palmari";
            this.tab_Palmari.Size = new System.Drawing.Size(940, 309);
            this.tab_Palmari.TabIndex = 1;
            this.tab_Palmari.Text = "Palmari";
            this.tab_Palmari.Enter += new System.EventHandler(this.tab_Palmari_Enter);
            // 
            // layout_Palmari
            // 
            this.layout_Palmari.ColumnCount = 2;
            this.layout_Palmari.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.layout_Palmari.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.layout_Palmari.Controls.Add(this.panel_grid_Palmari, 0, 0);
            this.layout_Palmari.Controls.Add(this.layout_pdf_Palmari, 1, 1);
            this.layout_Palmari.Controls.Add(this.panel_des_art_Palmari, 1, 0);
            this.layout_Palmari.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Palmari.Location = new System.Drawing.Point(0, 0);
            this.layout_Palmari.Name = "layout_Palmari";
            this.layout_Palmari.RowCount = 2;
            this.layout_Palmari.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.layout_Palmari.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_Palmari.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Palmari.Size = new System.Drawing.Size(940, 309);
            this.layout_Palmari.TabIndex = 124;
            // 
            // panel_grid_Palmari
            // 
            this.panel_grid_Palmari.Controls.Add(this.gv_Palmari);
            this.panel_grid_Palmari.Controls.Add(this.metroPanel2);
            this.panel_grid_Palmari.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_grid_Palmari.HorizontalScrollbarBarColor = true;
            this.panel_grid_Palmari.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_grid_Palmari.HorizontalScrollbarSize = 10;
            this.panel_grid_Palmari.Location = new System.Drawing.Point(3, 3);
            this.panel_grid_Palmari.Name = "panel_grid_Palmari";
            this.layout_Palmari.SetRowSpan(this.panel_grid_Palmari, 2);
            this.panel_grid_Palmari.Size = new System.Drawing.Size(144, 303);
            this.panel_grid_Palmari.TabIndex = 83;
            this.panel_grid_Palmari.VerticalScrollbarBarColor = true;
            this.panel_grid_Palmari.VerticalScrollbarHighlightOnWheel = false;
            this.panel_grid_Palmari.VerticalScrollbarSize = 10;
            // 
            // gv_Palmari
            // 
            this.gv_Palmari.AllowUserToAddRows = false;
            this.gv_Palmari.AllowUserToDeleteRows = false;
            this.gv_Palmari.AllowUserToResizeRows = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_Palmari.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.gv_Palmari.AutoGenerateColumns = false;
            this.gv_Palmari.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Palmari.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Palmari.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_Palmari.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Palmari.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.gv_Palmari.ColumnHeadersHeight = 40;
            this.gv_Palmari.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.articoloDeviceDataGridViewTextBoxColumn,
            this.descrizioneDeviceDataGridViewTextBoxColumn,
            this.descrizioneEstesaDeviceDataGridViewTextBoxColumn,
            this.modelDataGridViewTextBoxColumn,
            this.famDeviceDataGridViewTextBoxColumn,
            this.numFunzioniDataGridViewTextBoxColumn,
            this.tipoDeviceDataGridViewTextBoxColumn,
            this.clienteDataGridViewTextBoxColumn,
            this.articoloPadreDBDataGridViewTextBoxColumn,
            this.dataInizioValiditaDataGridViewTextBoxColumn,
            this.dataFineValiditaDataGridViewTextBoxColumn,
            this.articoloFWDataGridViewTextBoxColumn,
            this.desFWDataGridViewTextBoxColumn,
            this.desEstFWDataGridViewTextBoxColumn});
            this.gv_Palmari.DataSource = this.sFItemDeviceFWDesBindingSource;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Palmari.DefaultCellStyle = dataGridViewCellStyle7;
            this.gv_Palmari.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Palmari.EnableHeadersVisualStyles = false;
            this.gv_Palmari.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Palmari.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Palmari.Location = new System.Drawing.Point(0, 30);
            this.gv_Palmari.MultiSelect = false;
            this.gv_Palmari.Name = "gv_Palmari";
            this.gv_Palmari.ReadOnly = true;
            this.gv_Palmari.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Palmari.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.gv_Palmari.RowHeadersVisible = false;
            this.gv_Palmari.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Palmari.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Palmari.Size = new System.Drawing.Size(144, 273);
            this.gv_Palmari.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_Palmari.TabIndex = 0;
            this.gv_Palmari.UseStyleColors = true;
            // 
            // articoloDeviceDataGridViewTextBoxColumn
            // 
            this.articoloDeviceDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.articoloDeviceDataGridViewTextBoxColumn.DataPropertyName = "Articolo_Device";
            this.articoloDeviceDataGridViewTextBoxColumn.HeaderText = "Palmare";
            this.articoloDeviceDataGridViewTextBoxColumn.Name = "articoloDeviceDataGridViewTextBoxColumn";
            this.articoloDeviceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // descrizioneDeviceDataGridViewTextBoxColumn
            // 
            this.descrizioneDeviceDataGridViewTextBoxColumn.DataPropertyName = "Descrizione_Device";
            this.descrizioneDeviceDataGridViewTextBoxColumn.HeaderText = "Descrizione_Device";
            this.descrizioneDeviceDataGridViewTextBoxColumn.Name = "descrizioneDeviceDataGridViewTextBoxColumn";
            this.descrizioneDeviceDataGridViewTextBoxColumn.ReadOnly = true;
            this.descrizioneDeviceDataGridViewTextBoxColumn.Visible = false;
            // 
            // descrizioneEstesaDeviceDataGridViewTextBoxColumn
            // 
            this.descrizioneEstesaDeviceDataGridViewTextBoxColumn.DataPropertyName = "DescrizioneEstesa_Device";
            this.descrizioneEstesaDeviceDataGridViewTextBoxColumn.HeaderText = "DescrizioneEstesa_Device";
            this.descrizioneEstesaDeviceDataGridViewTextBoxColumn.Name = "descrizioneEstesaDeviceDataGridViewTextBoxColumn";
            this.descrizioneEstesaDeviceDataGridViewTextBoxColumn.ReadOnly = true;
            this.descrizioneEstesaDeviceDataGridViewTextBoxColumn.Visible = false;
            // 
            // modelDataGridViewTextBoxColumn
            // 
            this.modelDataGridViewTextBoxColumn.DataPropertyName = "Model";
            this.modelDataGridViewTextBoxColumn.HeaderText = "Model";
            this.modelDataGridViewTextBoxColumn.Name = "modelDataGridViewTextBoxColumn";
            this.modelDataGridViewTextBoxColumn.ReadOnly = true;
            this.modelDataGridViewTextBoxColumn.Visible = false;
            // 
            // famDeviceDataGridViewTextBoxColumn
            // 
            this.famDeviceDataGridViewTextBoxColumn.DataPropertyName = "FamDevice";
            this.famDeviceDataGridViewTextBoxColumn.HeaderText = "FamDevice";
            this.famDeviceDataGridViewTextBoxColumn.Name = "famDeviceDataGridViewTextBoxColumn";
            this.famDeviceDataGridViewTextBoxColumn.ReadOnly = true;
            this.famDeviceDataGridViewTextBoxColumn.Visible = false;
            // 
            // numFunzioniDataGridViewTextBoxColumn
            // 
            this.numFunzioniDataGridViewTextBoxColumn.DataPropertyName = "NumFunzioni";
            this.numFunzioniDataGridViewTextBoxColumn.HeaderText = "NumFunzioni";
            this.numFunzioniDataGridViewTextBoxColumn.Name = "numFunzioniDataGridViewTextBoxColumn";
            this.numFunzioniDataGridViewTextBoxColumn.ReadOnly = true;
            this.numFunzioniDataGridViewTextBoxColumn.Visible = false;
            // 
            // tipoDeviceDataGridViewTextBoxColumn
            // 
            this.tipoDeviceDataGridViewTextBoxColumn.DataPropertyName = "TipoDevice";
            this.tipoDeviceDataGridViewTextBoxColumn.HeaderText = "TipoDevice";
            this.tipoDeviceDataGridViewTextBoxColumn.Name = "tipoDeviceDataGridViewTextBoxColumn";
            this.tipoDeviceDataGridViewTextBoxColumn.ReadOnly = true;
            this.tipoDeviceDataGridViewTextBoxColumn.Visible = false;
            // 
            // clienteDataGridViewTextBoxColumn
            // 
            this.clienteDataGridViewTextBoxColumn.DataPropertyName = "Cliente";
            this.clienteDataGridViewTextBoxColumn.HeaderText = "Cliente";
            this.clienteDataGridViewTextBoxColumn.Name = "clienteDataGridViewTextBoxColumn";
            this.clienteDataGridViewTextBoxColumn.ReadOnly = true;
            this.clienteDataGridViewTextBoxColumn.Visible = false;
            // 
            // articoloPadreDBDataGridViewTextBoxColumn
            // 
            this.articoloPadreDBDataGridViewTextBoxColumn.DataPropertyName = "ArticoloPadreDB";
            this.articoloPadreDBDataGridViewTextBoxColumn.HeaderText = "ArticoloPadreDB";
            this.articoloPadreDBDataGridViewTextBoxColumn.Name = "articoloPadreDBDataGridViewTextBoxColumn";
            this.articoloPadreDBDataGridViewTextBoxColumn.ReadOnly = true;
            this.articoloPadreDBDataGridViewTextBoxColumn.Visible = false;
            // 
            // dataInizioValiditaDataGridViewTextBoxColumn
            // 
            this.dataInizioValiditaDataGridViewTextBoxColumn.DataPropertyName = "DataInizioValidita";
            this.dataInizioValiditaDataGridViewTextBoxColumn.HeaderText = "DataInizioValidita";
            this.dataInizioValiditaDataGridViewTextBoxColumn.Name = "dataInizioValiditaDataGridViewTextBoxColumn";
            this.dataInizioValiditaDataGridViewTextBoxColumn.ReadOnly = true;
            this.dataInizioValiditaDataGridViewTextBoxColumn.Visible = false;
            // 
            // dataFineValiditaDataGridViewTextBoxColumn
            // 
            this.dataFineValiditaDataGridViewTextBoxColumn.DataPropertyName = "DataFineValidita";
            this.dataFineValiditaDataGridViewTextBoxColumn.HeaderText = "DataFineValidita";
            this.dataFineValiditaDataGridViewTextBoxColumn.Name = "dataFineValiditaDataGridViewTextBoxColumn";
            this.dataFineValiditaDataGridViewTextBoxColumn.ReadOnly = true;
            this.dataFineValiditaDataGridViewTextBoxColumn.Visible = false;
            // 
            // articoloFWDataGridViewTextBoxColumn
            // 
            this.articoloFWDataGridViewTextBoxColumn.DataPropertyName = "ArticoloFW";
            this.articoloFWDataGridViewTextBoxColumn.HeaderText = "ArticoloFW";
            this.articoloFWDataGridViewTextBoxColumn.Name = "articoloFWDataGridViewTextBoxColumn";
            this.articoloFWDataGridViewTextBoxColumn.ReadOnly = true;
            this.articoloFWDataGridViewTextBoxColumn.Visible = false;
            // 
            // desFWDataGridViewTextBoxColumn
            // 
            this.desFWDataGridViewTextBoxColumn.DataPropertyName = "Des_FW";
            this.desFWDataGridViewTextBoxColumn.HeaderText = "Des_FW";
            this.desFWDataGridViewTextBoxColumn.Name = "desFWDataGridViewTextBoxColumn";
            this.desFWDataGridViewTextBoxColumn.ReadOnly = true;
            this.desFWDataGridViewTextBoxColumn.Visible = false;
            // 
            // desEstFWDataGridViewTextBoxColumn
            // 
            this.desEstFWDataGridViewTextBoxColumn.DataPropertyName = "DesEst_FW";
            this.desEstFWDataGridViewTextBoxColumn.HeaderText = "DesEst_FW";
            this.desEstFWDataGridViewTextBoxColumn.Name = "desEstFWDataGridViewTextBoxColumn";
            this.desEstFWDataGridViewTextBoxColumn.ReadOnly = true;
            this.desEstFWDataGridViewTextBoxColumn.Visible = false;
            // 
            // sFItemDeviceFWDesBindingSource
            // 
            this.sFItemDeviceFWDesBindingSource.DataMember = "SF_ItemDevice_FW_Des";
            this.sFItemDeviceFWDesBindingSource.DataSource = this.ds_SL;
            this.sFItemDeviceFWDesBindingSource.CurrentChanged += new System.EventHandler(this.sFItemDeviceFWDesBindingSource_CurrentChanged);
            // 
            // metroPanel2
            // 
            this.metroPanel2.BackColor = System.Drawing.Color.Transparent;
            this.metroPanel2.Controls.Add(this.tb_grid_palmari);
            this.metroPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroPanel2.HorizontalScrollbarBarColor = true;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 10;
            this.metroPanel2.Location = new System.Drawing.Point(0, 0);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(144, 30);
            this.metroPanel2.TabIndex = 3;
            this.metroPanel2.UseCustomBackColor = true;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 10;
            // 
            // tb_grid_palmari
            // 
            // 
            // 
            // 
            this.tb_grid_palmari.CustomButton.Image = null;
            this.tb_grid_palmari.CustomButton.Location = new System.Drawing.Point(122, 1);
            this.tb_grid_palmari.CustomButton.Name = "";
            this.tb_grid_palmari.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_grid_palmari.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_grid_palmari.CustomButton.TabIndex = 1;
            this.tb_grid_palmari.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_grid_palmari.CustomButton.UseSelectable = true;
            this.tb_grid_palmari.CustomButton.Visible = false;
            this.tb_grid_palmari.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_grid_palmari.Icon = global::SmartLineProduction.Properties.Resources.Lente;
            this.tb_grid_palmari.IconRight = true;
            this.tb_grid_palmari.Lines = new string[] {
        "metroTextBox1"};
            this.tb_grid_palmari.Location = new System.Drawing.Point(0, 0);
            this.tb_grid_palmari.MaxLength = 32767;
            this.tb_grid_palmari.Name = "tb_grid_palmari";
            this.tb_grid_palmari.PasswordChar = '\0';
            this.tb_grid_palmari.PromptText = "ricerca";
            this.tb_grid_palmari.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_grid_palmari.SelectedText = "";
            this.tb_grid_palmari.SelectionLength = 0;
            this.tb_grid_palmari.SelectionStart = 0;
            this.tb_grid_palmari.ShortcutsEnabled = true;
            this.tb_grid_palmari.Size = new System.Drawing.Size(144, 23);
            this.tb_grid_palmari.TabIndex = 2;
            this.tb_grid_palmari.Text = "metroTextBox1";
            this.tb_grid_palmari.UseSelectable = true;
            this.tb_grid_palmari.WaterMark = "ricerca";
            this.tb_grid_palmari.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_grid_palmari.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tb_grid_palmari.TextChanged += new System.EventHandler(this.tb_grid_palmari_TextChanged);
            // 
            // layout_pdf_Palmari
            // 
            this.layout_pdf_Palmari.ColumnCount = 2;
            this.layout_pdf_Palmari.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.layout_pdf_Palmari.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.layout_pdf_Palmari.Controls.Add(this.Palmari_pdf_it, 0, 0);
            this.layout_pdf_Palmari.Controls.Add(this.Palmari_pdf_en, 1, 0);
            this.layout_pdf_Palmari.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_pdf_Palmari.Location = new System.Drawing.Point(153, 53);
            this.layout_pdf_Palmari.Name = "layout_pdf_Palmari";
            this.layout_pdf_Palmari.RowCount = 1;
            this.layout_pdf_Palmari.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_pdf_Palmari.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 253F));
            this.layout_pdf_Palmari.Size = new System.Drawing.Size(784, 253);
            this.layout_pdf_Palmari.TabIndex = 122;
            // 
            // Palmari_pdf_it
            // 
            this.Palmari_pdf_it.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Palmari_pdf_it.Enabled = true;
            this.Palmari_pdf_it.Location = new System.Drawing.Point(3, 3);
            this.Palmari_pdf_it.Name = "Palmari_pdf_it";
            this.Palmari_pdf_it.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Palmari_pdf_it.OcxState")));
            this.Palmari_pdf_it.Size = new System.Drawing.Size(386, 247);
            this.Palmari_pdf_it.TabIndex = 0;
            // 
            // Palmari_pdf_en
            // 
            this.Palmari_pdf_en.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Palmari_pdf_en.Enabled = true;
            this.Palmari_pdf_en.Location = new System.Drawing.Point(395, 3);
            this.Palmari_pdf_en.Name = "Palmari_pdf_en";
            this.Palmari_pdf_en.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Palmari_pdf_en.OcxState")));
            this.Palmari_pdf_en.Size = new System.Drawing.Size(386, 247);
            this.Palmari_pdf_en.TabIndex = 1;
            // 
            // panel_des_art_Palmari
            // 
            this.panel_des_art_Palmari.Controls.Add(this.metroLabel2);
            this.panel_des_art_Palmari.Controls.Add(this.metroLabel3);
            this.panel_des_art_Palmari.Controls.Add(this.metroLabel4);
            this.panel_des_art_Palmari.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_des_art_Palmari.HorizontalScrollbarBarColor = true;
            this.panel_des_art_Palmari.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Palmari.HorizontalScrollbarSize = 10;
            this.panel_des_art_Palmari.Location = new System.Drawing.Point(153, 3);
            this.panel_des_art_Palmari.Name = "panel_des_art_Palmari";
            this.panel_des_art_Palmari.Size = new System.Drawing.Size(784, 44);
            this.panel_des_art_Palmari.TabIndex = 1;
            this.panel_des_art_Palmari.VerticalScrollbarBarColor = true;
            this.panel_des_art_Palmari.VerticalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Palmari.VerticalScrollbarSize = 10;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFItemDeviceFWDesBindingSource, "Descrizione_Device", true));
            this.metroLabel2.Location = new System.Drawing.Point(93, 0);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(41, 19);
            this.metroLabel2.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel2.TabIndex = 3;
            this.metroLabel2.Text = "Des_1";
            this.metroLabel2.UseStyleColors = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFItemDeviceFWDesBindingSource, "DescrizioneEstesa_Device", true));
            this.metroLabel3.Location = new System.Drawing.Point(93, 19);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(43, 19);
            this.metroLabel3.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel3.TabIndex = 4;
            this.metroLabel3.Text = "Des_2";
            this.metroLabel3.UseStyleColors = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(3, 0);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(75, 19);
            this.metroLabel4.TabIndex = 2;
            this.metroLabel4.Text = "Descrizione";
            // 
            // tab_Ricevitori
            // 
            this.tab_Ricevitori.Controls.Add(this.layout_Ricevitori);
            this.tab_Ricevitori.Location = new System.Drawing.Point(4, 38);
            this.tab_Ricevitori.Name = "tab_Ricevitori";
            this.tab_Ricevitori.Size = new System.Drawing.Size(940, 309);
            this.tab_Ricevitori.TabIndex = 2;
            this.tab_Ricevitori.Text = "Ricevitori";
            this.tab_Ricevitori.Enter += new System.EventHandler(this.tab_Ricevitori_Enter);
            // 
            // layout_Ricevitori
            // 
            this.layout_Ricevitori.ColumnCount = 2;
            this.layout_Ricevitori.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.layout_Ricevitori.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.layout_Ricevitori.Controls.Add(this.panel_grid_Ricevitori, 0, 0);
            this.layout_Ricevitori.Controls.Add(this.layout_pdf_Ricevitori, 0, 1);
            this.layout_Ricevitori.Controls.Add(this.panel_des_art_Ricevitori, 1, 0);
            this.layout_Ricevitori.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Ricevitori.Location = new System.Drawing.Point(0, 0);
            this.layout_Ricevitori.Name = "layout_Ricevitori";
            this.layout_Ricevitori.RowCount = 2;
            this.layout_Ricevitori.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.layout_Ricevitori.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_Ricevitori.Size = new System.Drawing.Size(940, 309);
            this.layout_Ricevitori.TabIndex = 125;
            // 
            // panel_grid_Ricevitori
            // 
            this.panel_grid_Ricevitori.Controls.Add(this.gv_Ricevitori);
            this.panel_grid_Ricevitori.Controls.Add(this.metroPanel3);
            this.panel_grid_Ricevitori.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_grid_Ricevitori.HorizontalScrollbarBarColor = true;
            this.panel_grid_Ricevitori.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_grid_Ricevitori.HorizontalScrollbarSize = 10;
            this.panel_grid_Ricevitori.Location = new System.Drawing.Point(3, 3);
            this.panel_grid_Ricevitori.Name = "panel_grid_Ricevitori";
            this.layout_Ricevitori.SetRowSpan(this.panel_grid_Ricevitori, 2);
            this.panel_grid_Ricevitori.Size = new System.Drawing.Size(144, 303);
            this.panel_grid_Ricevitori.TabIndex = 83;
            this.panel_grid_Ricevitori.VerticalScrollbarBarColor = true;
            this.panel_grid_Ricevitori.VerticalScrollbarHighlightOnWheel = false;
            this.panel_grid_Ricevitori.VerticalScrollbarSize = 10;
            // 
            // gv_Ricevitori
            // 
            this.gv_Ricevitori.AllowUserToAddRows = false;
            this.gv_Ricevitori.AllowUserToDeleteRows = false;
            this.gv_Ricevitori.AllowUserToResizeRows = false;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_Ricevitori.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.gv_Ricevitori.AutoGenerateColumns = false;
            this.gv_Ricevitori.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Ricevitori.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Ricevitori.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_Ricevitori.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Ricevitori.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.gv_Ricevitori.ColumnHeadersHeight = 40;
            this.gv_Ricevitori.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14});
            this.gv_Ricevitori.DataSource = this.sFItemDeviceFWDesBindingSource;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Ricevitori.DefaultCellStyle = dataGridViewCellStyle11;
            this.gv_Ricevitori.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Ricevitori.EnableHeadersVisualStyles = false;
            this.gv_Ricevitori.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Ricevitori.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Ricevitori.Location = new System.Drawing.Point(0, 30);
            this.gv_Ricevitori.MultiSelect = false;
            this.gv_Ricevitori.Name = "gv_Ricevitori";
            this.gv_Ricevitori.ReadOnly = true;
            this.gv_Ricevitori.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Ricevitori.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.gv_Ricevitori.RowHeadersVisible = false;
            this.gv_Ricevitori.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Ricevitori.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Ricevitori.Size = new System.Drawing.Size(144, 273);
            this.gv_Ricevitori.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_Ricevitori.TabIndex = 0;
            this.gv_Ricevitori.UseStyleColors = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Articolo_Device";
            this.dataGridViewTextBoxColumn1.HeaderText = "Ricevitore";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Descrizione_Device";
            this.dataGridViewTextBoxColumn2.HeaderText = "Descrizione_Device";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Visible = false;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "DescrizioneEstesa_Device";
            this.dataGridViewTextBoxColumn3.HeaderText = "DescrizioneEstesa_Device";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Visible = false;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Model";
            this.dataGridViewTextBoxColumn4.HeaderText = "Model";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Visible = false;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "FamDevice";
            this.dataGridViewTextBoxColumn5.HeaderText = "FamDevice";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Visible = false;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "NumFunzioni";
            this.dataGridViewTextBoxColumn6.HeaderText = "NumFunzioni";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Visible = false;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "TipoDevice";
            this.dataGridViewTextBoxColumn7.HeaderText = "TipoDevice";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Visible = false;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Cliente";
            this.dataGridViewTextBoxColumn8.HeaderText = "Cliente";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Visible = false;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "ArticoloPadreDB";
            this.dataGridViewTextBoxColumn9.HeaderText = "ArticoloPadreDB";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Visible = false;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "DataInizioValidita";
            this.dataGridViewTextBoxColumn10.HeaderText = "DataInizioValidita";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Visible = false;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "DataFineValidita";
            this.dataGridViewTextBoxColumn11.HeaderText = "DataFineValidita";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Visible = false;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "ArticoloFW";
            this.dataGridViewTextBoxColumn12.HeaderText = "ArticoloFW";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Visible = false;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Des_FW";
            this.dataGridViewTextBoxColumn13.HeaderText = "Des_FW";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Visible = false;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "DesEst_FW";
            this.dataGridViewTextBoxColumn14.HeaderText = "DesEst_FW";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Visible = false;
            // 
            // metroPanel3
            // 
            this.metroPanel3.BackColor = System.Drawing.Color.Transparent;
            this.metroPanel3.Controls.Add(this.tb_grid_ricevitori);
            this.metroPanel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroPanel3.HorizontalScrollbarBarColor = true;
            this.metroPanel3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel3.HorizontalScrollbarSize = 10;
            this.metroPanel3.Location = new System.Drawing.Point(0, 0);
            this.metroPanel3.Name = "metroPanel3";
            this.metroPanel3.Size = new System.Drawing.Size(144, 30);
            this.metroPanel3.TabIndex = 3;
            this.metroPanel3.UseCustomBackColor = true;
            this.metroPanel3.VerticalScrollbarBarColor = true;
            this.metroPanel3.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel3.VerticalScrollbarSize = 10;
            // 
            // tb_grid_ricevitori
            // 
            // 
            // 
            // 
            this.tb_grid_ricevitori.CustomButton.Image = null;
            this.tb_grid_ricevitori.CustomButton.Location = new System.Drawing.Point(122, 1);
            this.tb_grid_ricevitori.CustomButton.Name = "";
            this.tb_grid_ricevitori.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_grid_ricevitori.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_grid_ricevitori.CustomButton.TabIndex = 1;
            this.tb_grid_ricevitori.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_grid_ricevitori.CustomButton.UseSelectable = true;
            this.tb_grid_ricevitori.CustomButton.Visible = false;
            this.tb_grid_ricevitori.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_grid_ricevitori.Icon = global::SmartLineProduction.Properties.Resources.Lente;
            this.tb_grid_ricevitori.IconRight = true;
            this.tb_grid_ricevitori.Lines = new string[] {
        "metroTextBox1"};
            this.tb_grid_ricevitori.Location = new System.Drawing.Point(0, 0);
            this.tb_grid_ricevitori.MaxLength = 32767;
            this.tb_grid_ricevitori.Name = "tb_grid_ricevitori";
            this.tb_grid_ricevitori.PasswordChar = '\0';
            this.tb_grid_ricevitori.PromptText = "ricerca";
            this.tb_grid_ricevitori.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_grid_ricevitori.SelectedText = "";
            this.tb_grid_ricevitori.SelectionLength = 0;
            this.tb_grid_ricevitori.SelectionStart = 0;
            this.tb_grid_ricevitori.ShortcutsEnabled = true;
            this.tb_grid_ricevitori.Size = new System.Drawing.Size(144, 23);
            this.tb_grid_ricevitori.TabIndex = 2;
            this.tb_grid_ricevitori.Text = "metroTextBox1";
            this.tb_grid_ricevitori.UseSelectable = true;
            this.tb_grid_ricevitori.WaterMark = "ricerca";
            this.tb_grid_ricevitori.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_grid_ricevitori.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tb_grid_ricevitori.TextChanged += new System.EventHandler(this.tb_grid_ricevitori_TextChanged);
            // 
            // layout_pdf_Ricevitori
            // 
            this.layout_pdf_Ricevitori.ColumnCount = 2;
            this.layout_pdf_Ricevitori.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.layout_pdf_Ricevitori.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.layout_pdf_Ricevitori.Controls.Add(this.Ricevitori_pdf_it, 0, 0);
            this.layout_pdf_Ricevitori.Controls.Add(this.Ricevitori_pdf_en, 1, 0);
            this.layout_pdf_Ricevitori.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_pdf_Ricevitori.Location = new System.Drawing.Point(153, 53);
            this.layout_pdf_Ricevitori.Name = "layout_pdf_Ricevitori";
            this.layout_pdf_Ricevitori.RowCount = 1;
            this.layout_pdf_Ricevitori.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_pdf_Ricevitori.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 253F));
            this.layout_pdf_Ricevitori.Size = new System.Drawing.Size(784, 253);
            this.layout_pdf_Ricevitori.TabIndex = 123;
            // 
            // Ricevitori_pdf_it
            // 
            this.Ricevitori_pdf_it.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Ricevitori_pdf_it.Enabled = true;
            this.Ricevitori_pdf_it.Location = new System.Drawing.Point(3, 3);
            this.Ricevitori_pdf_it.Name = "Ricevitori_pdf_it";
            this.Ricevitori_pdf_it.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Ricevitori_pdf_it.OcxState")));
            this.Ricevitori_pdf_it.Size = new System.Drawing.Size(386, 247);
            this.Ricevitori_pdf_it.TabIndex = 2;
            // 
            // Ricevitori_pdf_en
            // 
            this.Ricevitori_pdf_en.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Ricevitori_pdf_en.Enabled = true;
            this.Ricevitori_pdf_en.Location = new System.Drawing.Point(395, 3);
            this.Ricevitori_pdf_en.Name = "Ricevitori_pdf_en";
            this.Ricevitori_pdf_en.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Ricevitori_pdf_en.OcxState")));
            this.Ricevitori_pdf_en.Size = new System.Drawing.Size(386, 247);
            this.Ricevitori_pdf_en.TabIndex = 3;
            // 
            // panel_des_art_Ricevitori
            // 
            this.panel_des_art_Ricevitori.Controls.Add(this.metroLabel5);
            this.panel_des_art_Ricevitori.Controls.Add(this.metroLabel6);
            this.panel_des_art_Ricevitori.Controls.Add(this.metroLabel7);
            this.panel_des_art_Ricevitori.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_des_art_Ricevitori.HorizontalScrollbarBarColor = true;
            this.panel_des_art_Ricevitori.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Ricevitori.HorizontalScrollbarSize = 10;
            this.panel_des_art_Ricevitori.Location = new System.Drawing.Point(153, 3);
            this.panel_des_art_Ricevitori.Name = "panel_des_art_Ricevitori";
            this.panel_des_art_Ricevitori.Size = new System.Drawing.Size(784, 44);
            this.panel_des_art_Ricevitori.TabIndex = 1;
            this.panel_des_art_Ricevitori.VerticalScrollbarBarColor = true;
            this.panel_des_art_Ricevitori.VerticalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Ricevitori.VerticalScrollbarSize = 10;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFItemDeviceFWDesBindingSource, "Descrizione_Device", true));
            this.metroLabel5.Location = new System.Drawing.Point(93, 0);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(41, 19);
            this.metroLabel5.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel5.TabIndex = 3;
            this.metroLabel5.Text = "Des_1";
            this.metroLabel5.UseStyleColors = true;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFItemDeviceFWDesBindingSource, "DescrizioneEstesa_Device", true));
            this.metroLabel6.Location = new System.Drawing.Point(93, 19);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(43, 19);
            this.metroLabel6.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel6.TabIndex = 4;
            this.metroLabel6.Text = "Des_2";
            this.metroLabel6.UseStyleColors = true;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(3, 0);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(75, 19);
            this.metroLabel7.TabIndex = 2;
            this.metroLabel7.Text = "Descrizione";
            // 
            // tab_Cablaggi
            // 
            this.tab_Cablaggi.Controls.Add(this.layout_Cablaggi);
            this.tab_Cablaggi.Location = new System.Drawing.Point(4, 38);
            this.tab_Cablaggi.Name = "tab_Cablaggi";
            this.tab_Cablaggi.Size = new System.Drawing.Size(940, 309);
            this.tab_Cablaggi.TabIndex = 3;
            this.tab_Cablaggi.Text = "Cablaggi";
            this.tab_Cablaggi.Enter += new System.EventHandler(this.tab_Cablaggi_Enter);
            // 
            // layout_Cablaggi
            // 
            this.layout_Cablaggi.ColumnCount = 2;
            this.layout_Cablaggi.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.layout_Cablaggi.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.layout_Cablaggi.Controls.Add(this.panel_grid_Cablaggi, 0, 0);
            this.layout_Cablaggi.Controls.Add(this.layout_pdf_Cablaggi, 0, 1);
            this.layout_Cablaggi.Controls.Add(this.panel_des_art_Cablaggi, 1, 0);
            this.layout_Cablaggi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Cablaggi.Location = new System.Drawing.Point(0, 0);
            this.layout_Cablaggi.Name = "layout_Cablaggi";
            this.layout_Cablaggi.RowCount = 2;
            this.layout_Cablaggi.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.layout_Cablaggi.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_Cablaggi.Size = new System.Drawing.Size(940, 309);
            this.layout_Cablaggi.TabIndex = 126;
            // 
            // panel_grid_Cablaggi
            // 
            this.panel_grid_Cablaggi.Controls.Add(this.gv_Cablaggi);
            this.panel_grid_Cablaggi.Controls.Add(this.metroPanel4);
            this.panel_grid_Cablaggi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_grid_Cablaggi.HorizontalScrollbarBarColor = true;
            this.panel_grid_Cablaggi.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_grid_Cablaggi.HorizontalScrollbarSize = 10;
            this.panel_grid_Cablaggi.Location = new System.Drawing.Point(3, 3);
            this.panel_grid_Cablaggi.Name = "panel_grid_Cablaggi";
            this.layout_Cablaggi.SetRowSpan(this.panel_grid_Cablaggi, 2);
            this.panel_grid_Cablaggi.Size = new System.Drawing.Size(144, 303);
            this.panel_grid_Cablaggi.TabIndex = 83;
            this.panel_grid_Cablaggi.VerticalScrollbarBarColor = true;
            this.panel_grid_Cablaggi.VerticalScrollbarHighlightOnWheel = false;
            this.panel_grid_Cablaggi.VerticalScrollbarSize = 10;
            // 
            // gv_Cablaggi
            // 
            this.gv_Cablaggi.AllowUserToAddRows = false;
            this.gv_Cablaggi.AllowUserToDeleteRows = false;
            this.gv_Cablaggi.AllowUserToResizeRows = false;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_Cablaggi.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            this.gv_Cablaggi.AutoGenerateColumns = false;
            this.gv_Cablaggi.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Cablaggi.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Cablaggi.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_Cablaggi.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Cablaggi.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.gv_Cablaggi.ColumnHeadersHeight = 40;
            this.gv_Cablaggi.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.articoloDataGridViewTextBoxColumn1,
            this.descrizioneDataGridViewTextBoxColumn1,
            this.descrizioneEstesaDataGridViewTextBoxColumn1,
            this.modelloDataGridViewTextBoxColumn1});
            this.gv_Cablaggi.DataSource = this.sFCablaggiBindingSource;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Cablaggi.DefaultCellStyle = dataGridViewCellStyle15;
            this.gv_Cablaggi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Cablaggi.EnableHeadersVisualStyles = false;
            this.gv_Cablaggi.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Cablaggi.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Cablaggi.Location = new System.Drawing.Point(0, 30);
            this.gv_Cablaggi.MultiSelect = false;
            this.gv_Cablaggi.Name = "gv_Cablaggi";
            this.gv_Cablaggi.ReadOnly = true;
            this.gv_Cablaggi.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Cablaggi.RowHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.gv_Cablaggi.RowHeadersVisible = false;
            this.gv_Cablaggi.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Cablaggi.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Cablaggi.Size = new System.Drawing.Size(144, 273);
            this.gv_Cablaggi.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_Cablaggi.TabIndex = 0;
            this.gv_Cablaggi.UseStyleColors = true;
            // 
            // articoloDataGridViewTextBoxColumn1
            // 
            this.articoloDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.articoloDataGridViewTextBoxColumn1.DataPropertyName = "Articolo";
            this.articoloDataGridViewTextBoxColumn1.HeaderText = "Cablaggio";
            this.articoloDataGridViewTextBoxColumn1.Name = "articoloDataGridViewTextBoxColumn1";
            this.articoloDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // descrizioneDataGridViewTextBoxColumn1
            // 
            this.descrizioneDataGridViewTextBoxColumn1.DataPropertyName = "Descrizione";
            this.descrizioneDataGridViewTextBoxColumn1.HeaderText = "Descrizione";
            this.descrizioneDataGridViewTextBoxColumn1.Name = "descrizioneDataGridViewTextBoxColumn1";
            this.descrizioneDataGridViewTextBoxColumn1.ReadOnly = true;
            this.descrizioneDataGridViewTextBoxColumn1.Visible = false;
            // 
            // descrizioneEstesaDataGridViewTextBoxColumn1
            // 
            this.descrizioneEstesaDataGridViewTextBoxColumn1.DataPropertyName = "DescrizioneEstesa";
            this.descrizioneEstesaDataGridViewTextBoxColumn1.HeaderText = "DescrizioneEstesa";
            this.descrizioneEstesaDataGridViewTextBoxColumn1.Name = "descrizioneEstesaDataGridViewTextBoxColumn1";
            this.descrizioneEstesaDataGridViewTextBoxColumn1.ReadOnly = true;
            this.descrizioneEstesaDataGridViewTextBoxColumn1.Visible = false;
            // 
            // modelloDataGridViewTextBoxColumn1
            // 
            this.modelloDataGridViewTextBoxColumn1.DataPropertyName = "Modello";
            this.modelloDataGridViewTextBoxColumn1.HeaderText = "Modello";
            this.modelloDataGridViewTextBoxColumn1.Name = "modelloDataGridViewTextBoxColumn1";
            this.modelloDataGridViewTextBoxColumn1.ReadOnly = true;
            this.modelloDataGridViewTextBoxColumn1.Visible = false;
            // 
            // sFCablaggiBindingSource
            // 
            this.sFCablaggiBindingSource.DataMember = "SF_Cablaggi";
            this.sFCablaggiBindingSource.DataSource = this.ds_SL;
            this.sFCablaggiBindingSource.CurrentChanged += new System.EventHandler(this.sFCablaggiBindingSource_CurrentChanged);
            // 
            // metroPanel4
            // 
            this.metroPanel4.BackColor = System.Drawing.Color.Transparent;
            this.metroPanel4.Controls.Add(this.tb_grid_cablaggi);
            this.metroPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroPanel4.HorizontalScrollbarBarColor = true;
            this.metroPanel4.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel4.HorizontalScrollbarSize = 10;
            this.metroPanel4.Location = new System.Drawing.Point(0, 0);
            this.metroPanel4.Name = "metroPanel4";
            this.metroPanel4.Size = new System.Drawing.Size(144, 30);
            this.metroPanel4.TabIndex = 3;
            this.metroPanel4.UseCustomBackColor = true;
            this.metroPanel4.VerticalScrollbarBarColor = true;
            this.metroPanel4.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel4.VerticalScrollbarSize = 10;
            // 
            // tb_grid_cablaggi
            // 
            // 
            // 
            // 
            this.tb_grid_cablaggi.CustomButton.Image = null;
            this.tb_grid_cablaggi.CustomButton.Location = new System.Drawing.Point(122, 1);
            this.tb_grid_cablaggi.CustomButton.Name = "";
            this.tb_grid_cablaggi.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_grid_cablaggi.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_grid_cablaggi.CustomButton.TabIndex = 1;
            this.tb_grid_cablaggi.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_grid_cablaggi.CustomButton.UseSelectable = true;
            this.tb_grid_cablaggi.CustomButton.Visible = false;
            this.tb_grid_cablaggi.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_grid_cablaggi.Icon = global::SmartLineProduction.Properties.Resources.Lente;
            this.tb_grid_cablaggi.IconRight = true;
            this.tb_grid_cablaggi.Lines = new string[] {
        "metroTextBox1"};
            this.tb_grid_cablaggi.Location = new System.Drawing.Point(0, 0);
            this.tb_grid_cablaggi.MaxLength = 32767;
            this.tb_grid_cablaggi.Name = "tb_grid_cablaggi";
            this.tb_grid_cablaggi.PasswordChar = '\0';
            this.tb_grid_cablaggi.PromptText = "ricerca";
            this.tb_grid_cablaggi.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_grid_cablaggi.SelectedText = "";
            this.tb_grid_cablaggi.SelectionLength = 0;
            this.tb_grid_cablaggi.SelectionStart = 0;
            this.tb_grid_cablaggi.ShortcutsEnabled = true;
            this.tb_grid_cablaggi.Size = new System.Drawing.Size(144, 23);
            this.tb_grid_cablaggi.TabIndex = 2;
            this.tb_grid_cablaggi.Text = "metroTextBox1";
            this.tb_grid_cablaggi.UseSelectable = true;
            this.tb_grid_cablaggi.WaterMark = "ricerca";
            this.tb_grid_cablaggi.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_grid_cablaggi.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // layout_pdf_Cablaggi
            // 
            this.layout_pdf_Cablaggi.ColumnCount = 2;
            this.layout_pdf_Cablaggi.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.layout_pdf_Cablaggi.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.layout_pdf_Cablaggi.Controls.Add(this.Cablaggi_pdf_it, 0, 0);
            this.layout_pdf_Cablaggi.Controls.Add(this.Cablaggi_pdf_en, 1, 0);
            this.layout_pdf_Cablaggi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_pdf_Cablaggi.Location = new System.Drawing.Point(153, 53);
            this.layout_pdf_Cablaggi.Name = "layout_pdf_Cablaggi";
            this.layout_pdf_Cablaggi.RowCount = 1;
            this.layout_pdf_Cablaggi.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_pdf_Cablaggi.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 253F));
            this.layout_pdf_Cablaggi.Size = new System.Drawing.Size(784, 253);
            this.layout_pdf_Cablaggi.TabIndex = 123;
            // 
            // Cablaggi_pdf_it
            // 
            this.Cablaggi_pdf_it.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Cablaggi_pdf_it.Enabled = true;
            this.Cablaggi_pdf_it.Location = new System.Drawing.Point(3, 3);
            this.Cablaggi_pdf_it.Name = "Cablaggi_pdf_it";
            this.Cablaggi_pdf_it.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Cablaggi_pdf_it.OcxState")));
            this.Cablaggi_pdf_it.Size = new System.Drawing.Size(386, 247);
            this.Cablaggi_pdf_it.TabIndex = 2;
            // 
            // Cablaggi_pdf_en
            // 
            this.Cablaggi_pdf_en.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Cablaggi_pdf_en.Enabled = true;
            this.Cablaggi_pdf_en.Location = new System.Drawing.Point(395, 3);
            this.Cablaggi_pdf_en.Name = "Cablaggi_pdf_en";
            this.Cablaggi_pdf_en.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Cablaggi_pdf_en.OcxState")));
            this.Cablaggi_pdf_en.Size = new System.Drawing.Size(386, 247);
            this.Cablaggi_pdf_en.TabIndex = 3;
            // 
            // panel_des_art_Cablaggi
            // 
            this.panel_des_art_Cablaggi.Controls.Add(this.metroLabel8);
            this.panel_des_art_Cablaggi.Controls.Add(this.metroLabel9);
            this.panel_des_art_Cablaggi.Controls.Add(this.metroLabel10);
            this.panel_des_art_Cablaggi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_des_art_Cablaggi.HorizontalScrollbarBarColor = true;
            this.panel_des_art_Cablaggi.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Cablaggi.HorizontalScrollbarSize = 10;
            this.panel_des_art_Cablaggi.Location = new System.Drawing.Point(153, 3);
            this.panel_des_art_Cablaggi.Name = "panel_des_art_Cablaggi";
            this.panel_des_art_Cablaggi.Size = new System.Drawing.Size(784, 44);
            this.panel_des_art_Cablaggi.TabIndex = 1;
            this.panel_des_art_Cablaggi.VerticalScrollbarBarColor = true;
            this.panel_des_art_Cablaggi.VerticalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Cablaggi.VerticalScrollbarSize = 10;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFCablaggiBindingSource, "Descrizione", true));
            this.metroLabel8.Location = new System.Drawing.Point(93, 0);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(41, 19);
            this.metroLabel8.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel8.TabIndex = 3;
            this.metroLabel8.Text = "Des_1";
            this.metroLabel8.UseStyleColors = true;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFCablaggiBindingSource, "DescrizioneEstesa", true));
            this.metroLabel9.Location = new System.Drawing.Point(93, 19);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(43, 19);
            this.metroLabel9.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel9.TabIndex = 4;
            this.metroLabel9.Text = "Des_2";
            this.metroLabel9.UseStyleColors = true;
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.Location = new System.Drawing.Point(3, 0);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(75, 19);
            this.metroLabel10.TabIndex = 2;
            this.metroLabel10.Text = "Descrizione";
            // 
            // tab_FW_P
            // 
            this.tab_FW_P.Location = new System.Drawing.Point(4, 38);
            this.tab_FW_P.Name = "tab_FW_P";
            this.tab_FW_P.Size = new System.Drawing.Size(940, 309);
            this.tab_FW_P.TabIndex = 4;
            this.tab_FW_P.Text = "Firmware Palm.";
            // 
            // tab_FW_R
            // 
            this.tab_FW_R.Location = new System.Drawing.Point(4, 38);
            this.tab_FW_R.Name = "tab_FW_R";
            this.tab_FW_R.Size = new System.Drawing.Size(940, 309);
            this.tab_FW_R.TabIndex = 5;
            this.tab_FW_R.Text = "Firmware Ric.";
            // 
            // sF_ArticoliSchedeTableAdapter
            // 
            this.sF_ArticoliSchedeTableAdapter.ClearBeforeFill = true;
            // 
            // sF_ItemDevice_FW_DesTableAdapter
            // 
            this.sF_ItemDevice_FW_DesTableAdapter.ClearBeforeFill = true;
            // 
            // sF_CablaggiTableAdapter
            // 
            this.sF_CablaggiTableAdapter.ClearBeforeFill = true;
            // 
            // UC_SchedeProdotti
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(988, 426);
            this.ControlBox = false;
            this.Controls.Add(this.panel_Schede);
            this.Controls.Add(this.layout_orizz_menu);
            this.DisplayHeader = false;
            this.Name = "UC_SchedeProdotti";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UC_SchedeProdotti_Load);
            this.layout_orizz_menu.ResumeLayout(false);
            this.layout_orizz_menu.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            this.panel_Schede.ResumeLayout(false);
            this.Tab_Schede.ResumeLayout(false);
            this.tab_Kit.ResumeLayout(false);
            this.layout_Kit.ResumeLayout(false);
            this.panel_grid_Kit.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_Kit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFArticoliSchedeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            this.panel_search_kit.ResumeLayout(false);
            this.layout_pdf_Kit.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Kit_pdf_it)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kit_pdf_en)).EndInit();
            this.panel_des_art_Kit.ResumeLayout(false);
            this.panel_des_art_Kit.PerformLayout();
            this.tab_Palmari.ResumeLayout(false);
            this.layout_Palmari.ResumeLayout(false);
            this.panel_grid_Palmari.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_Palmari)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFItemDeviceFWDesBindingSource)).EndInit();
            this.metroPanel2.ResumeLayout(false);
            this.layout_pdf_Palmari.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Palmari_pdf_it)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Palmari_pdf_en)).EndInit();
            this.panel_des_art_Palmari.ResumeLayout(false);
            this.panel_des_art_Palmari.PerformLayout();
            this.tab_Ricevitori.ResumeLayout(false);
            this.layout_Ricevitori.ResumeLayout(false);
            this.panel_grid_Ricevitori.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_Ricevitori)).EndInit();
            this.metroPanel3.ResumeLayout(false);
            this.layout_pdf_Ricevitori.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Ricevitori_pdf_it)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ricevitori_pdf_en)).EndInit();
            this.panel_des_art_Ricevitori.ResumeLayout(false);
            this.panel_des_art_Ricevitori.PerformLayout();
            this.tab_Cablaggi.ResumeLayout(false);
            this.layout_Cablaggi.ResumeLayout(false);
            this.panel_grid_Cablaggi.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_Cablaggi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFCablaggiBindingSource)).EndInit();
            this.metroPanel4.ResumeLayout(false);
            this.layout_pdf_Cablaggi.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Cablaggi_pdf_it)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cablaggi_pdf_en)).EndInit();
            this.panel_des_art_Cablaggi.ResumeLayout(false);
            this.panel_des_art_Cablaggi.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel layout_orizz_menu;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
        private MetroFramework.Controls.MetroPanel panel_Schede;
        private MetroFramework.Controls.MetroTabControl Tab_Schede;
        private System.Windows.Forms.TabPage tab_Kit;
        private System.Windows.Forms.TabPage tab_Palmari;
        private System.Windows.Forms.TabPage tab_Ricevitori;
        private System.Windows.Forms.TableLayoutPanel layout_Kit;
        private MetroFramework.Controls.MetroGrid gv_Kit;
        private System.Windows.Forms.TableLayoutPanel layout_pdf_Kit;
        private ds_SL ds_SL;
        private System.Windows.Forms.BindingSource sFArticoliSchedeBindingSource;
        private ds_SLTableAdapters.SF_ArticoliSchedeTableAdapter sF_ArticoliSchedeTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descrizioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descrizioneEstesaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn modelloDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroPanel panel_des_art_Kit;
        private MetroFramework.Controls.MetroLabel lab_des2_articolo;
        private MetroFramework.Controls.MetroLabel lab_des1_articolo;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroPanel panel_grid_Kit;
        private MetroFramework.Controls.MetroTextBox tb_grid_kit;
        private MetroFramework.Controls.MetroPanel panel_search_kit;
        private System.Windows.Forms.TableLayoutPanel layout_Palmari;
        private MetroFramework.Controls.MetroPanel panel_grid_Palmari;
        private MetroFramework.Controls.MetroGrid gv_Palmari;
        private MetroFramework.Controls.MetroPanel metroPanel2;
        private MetroFramework.Controls.MetroTextBox tb_grid_palmari;
        private System.Windows.Forms.TableLayoutPanel layout_pdf_Palmari;
        private MetroFramework.Controls.MetroPanel panel_des_art_Palmari;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private System.Windows.Forms.BindingSource sFItemDeviceFWDesBindingSource;
        private ds_SLTableAdapters.SF_ItemDevice_FW_DesTableAdapter sF_ItemDevice_FW_DesTableAdapter;
        private System.Windows.Forms.TableLayoutPanel layout_Ricevitori;
        private MetroFramework.Controls.MetroPanel panel_grid_Ricevitori;
        private MetroFramework.Controls.MetroGrid gv_Ricevitori;
        private MetroFramework.Controls.MetroPanel metroPanel3;
        private MetroFramework.Controls.MetroTextBox tb_grid_ricevitori;
        private MetroFramework.Controls.MetroPanel panel_des_art_Ricevitori;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloDeviceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descrizioneDeviceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descrizioneEstesaDeviceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn modelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn famDeviceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numFunzioniDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoDeviceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clienteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloPadreDBDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataInizioValiditaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataFineValiditaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloFWDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn desFWDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn desEstFWDataGridViewTextBoxColumn;
        private System.Windows.Forms.TableLayoutPanel layout_pdf_Ricevitori;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private AxAcroPDFLib.AxAcroPDF Ricevitori_pdf_it;
        private AxAcroPDFLib.AxAcroPDF Ricevitori_pdf_en;
        private AxAcroPDFLib.AxAcroPDF Palmari_pdf_it;
        private AxAcroPDFLib.AxAcroPDF Palmari_pdf_en;
        private AxAcroPDFLib.AxAcroPDF Kit_pdf_it;
        private AxAcroPDFLib.AxAcroPDF Kit_pdf_en;
        private System.Windows.Forms.TabPage tab_Cablaggi;
        private System.Windows.Forms.TableLayoutPanel layout_Cablaggi;
        private MetroFramework.Controls.MetroPanel panel_grid_Cablaggi;
        private MetroFramework.Controls.MetroGrid gv_Cablaggi;
        private MetroFramework.Controls.MetroPanel metroPanel4;
        private MetroFramework.Controls.MetroTextBox tb_grid_cablaggi;
        private System.Windows.Forms.TableLayoutPanel layout_pdf_Cablaggi;
        private AxAcroPDFLib.AxAcroPDF Cablaggi_pdf_it;
        private AxAcroPDFLib.AxAcroPDF Cablaggi_pdf_en;
        private MetroFramework.Controls.MetroPanel panel_des_art_Cablaggi;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private System.Windows.Forms.BindingSource sFCablaggiBindingSource;
        private ds_SLTableAdapters.SF_CablaggiTableAdapter sF_CablaggiTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn descrizioneDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn descrizioneEstesaDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn modelloDataGridViewTextBoxColumn1;
        private System.Windows.Forms.TabPage tab_FW_P;
        private System.Windows.Forms.TabPage tab_FW_R;
    }
}
