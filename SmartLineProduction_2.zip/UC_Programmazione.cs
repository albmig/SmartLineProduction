﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using System.IO;
//using Dymo;
using DYMO.Label.Framework;

namespace SmartLineProduction
{
    public partial class UC_Programmazione : MetroFramework.Forms.MetroForm
    {
        public bool glob_edit_config = false;

        public static string glob_FW_folder = "";
        public static string glob_IP_printer = "";
        public static bool glob_use_printer = false;
        public static string glob_Commander_path = "";
        public string glob_device = "--device EFR32BG13P733F512GM48";
        //public string glob_device = "--device EFR32MG12P332F1024GL125";
        public bool glob_Program_OK = true;
        public string glob_codice_kit = "";
        public string glob_codice_sistema = "";
        public string glob_codice_fw = "";
        public string glob_codice_fw_fulltmppath = "";
        public string glob_ser_num_read = "";
        public string glob_ser_num_write = "";
        public string glob_ID_code = "";
        public string glob_ID_newcode = "";
        public string glob_UNIQUE_ID = "";
        public string glob_Form_ID = "";
        public string WEB_path_image = @"\\192.168.0.8\ricerca e sviluppo\Documentazione_SL\doc_SL (sinc per web)\";
        public string glob_tipo_progr = ""; //C-Commessa K-Kit D-Device L-Libera
        public string glob_ID_cli = "";

        public string glob_Printer_Name = "";
        public string glob_Printer_Tray = "";
        public bool glob_show_evasi = true;

        public UC_Programmazione()
        {
            InitializeComponent();
        }

        private void uscitaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void nascondiVisualizzaFirmwareToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tv_FW.Visible)
            {
                tv_FW.Visible = false;
            }
            else
            {
                tv_FW.Visible = true;
            }
        }

        private void UC_Programmazione_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SerialNumbers'. È possibile spostarla o rimuoverla se necessario.
            this.serialNumbersTableAdapter.Fill(this.ds_SL.SerialNumbers);

            //tab_control_Program.SelectedTab = tab_kit;
            //tab_control_Program.SelectedTab = tab_libera;
            //tab_control_Program.SelectedTab = tab_item;
            tab_control_Program.SelectedTab = tab_commessa;

            // Abilita zone dello schermo
            ds_SL.dt_Tmp_Fw.Clear();
            ds_SL.dt_Tmp_Programma.Clear();
            AbilitaSchermo();
            CaricaTreeView();

            CaricaArchivi();
            cb_sceltaCliente.Refresh();

            //if (glob_use_printer) { SetupLabelWriterSelection(true); }
            if (glob_use_printer) { SetupLabelWriterSelection(); }

        }

        /// <summary>
        /// Routines generiche
        /// </summary>
        private void AbilitaSchermo()
        {
            lab_IDNumber_read.Text = "---";
            lab_IDNumber_write.Text = "---";
            lab_PartNumber.Text = "---";
            lab_SN.Text = "---";

            //ds_commander.dt_Tmp_Fw.Clear();
            dg_dt_tmp_programmazione.Refresh();

            LeggiConfig();

            if (glob_edit_config)
            {
                //Entro in fase di modifica
                tb_FW_folder.Enabled = true;
                tb_IP_Printer.Enabled = true;
                tog_Use_printer.Enabled = true;
                tb_Commander_path.Enabled = true;
                but_Edit_Config.Enabled = false;
                but_Save_Config.Enabled = true;
                but_Abort_Config.Enabled = true;
            }
            else
            {
                //Schermo inattivo
                tb_FW_folder.Enabled = false;
                tb_IP_Printer.Enabled = false;
                tog_Use_printer.Enabled = false;
                tb_Commander_path.Enabled = false;
                but_Edit_Config.Enabled = true;
                but_Save_Config.Enabled = false;
                but_Abort_Config.Enabled = false;
            }

            //Verifica pagina attiva
            if (tab_control_Program.SelectedIndex == 2) //Singolo device
            {
                SetFilterDevice();
                lab_device_desart.Text = "";
                lab_device_desestart.Text = "";
                lab_device_codfw.Text = "";
                lab_device_desfw.Text = "";
                lab_device_desestfw.Text = "";
                lab_device_ID.Text = "";
            }

            if (tab_control_Program.SelectedIndex == 3) // tab_libera
            {
                tb_Id_Hardware.Text = "";

                //Gestione tipo device - tab_libera
                if (toggle_tipo_device_Libera.Checked) // Allora è ricevitore
                {
                    lab_tipo_device_palmare.Style = MetroColorStyle.Silver;
                    lab_tipo_device_ricevitore.Style = MetroColorStyle.Red;
                    lab_tipo_device_palmare.FontWeight = MetroLabelWeight.Regular;
                    lab_tipo_device_ricevitore.FontWeight = MetroLabelWeight.Bold;
                    lab_tipo_device_palmare.Refresh();
                    lab_tipo_device_ricevitore.Refresh();
                }
                else //  Allora è palmare
                {
                    lab_tipo_device_palmare.Style = MetroColorStyle.Red;
                    lab_tipo_device_ricevitore.Style = MetroColorStyle.Silver;
                    lab_tipo_device_palmare.FontWeight = MetroLabelWeight.Bold;
                    lab_tipo_device_ricevitore.FontWeight = MetroLabelWeight.Regular;
                    lab_tipo_device_palmare.Refresh();
                    lab_tipo_device_ricevitore.Refresh();
                }

                //Gestione firmware - tab_libera
                if (toggle_tipo_firmware.Checked) // FW Custom
                {
                    lab_fw_standard.Style = MetroColorStyle.Silver;
                    lab_fw_custom.Style = MetroColorStyle.Red;
                    lab_fw_standard.FontWeight = MetroLabelWeight.Regular;
                    lab_fw_custom.FontWeight = MetroLabelWeight.Bold;
                    lab_fw_standard.Refresh();
                    lab_fw_custom.Refresh();
                }
                else //  FW Standard
                {
                    lab_fw_standard.Style = MetroColorStyle.Red;
                    lab_fw_custom.Style = MetroColorStyle.Silver;
                    lab_fw_standard.FontWeight = MetroLabelWeight.Bold;
                    lab_fw_custom.FontWeight = MetroLabelWeight.Regular;
                    lab_fw_standard.Refresh();
                    lab_fw_custom.Refresh();
                }

                string filtro_tmp_fw = "";
                if (!toggle_tipo_device_Libera.Checked) { filtro_tmp_fw = "fw_tipodev = 'P' AND "; }// Palmare
                if (toggle_tipo_device_Libera.Checked) { filtro_tmp_fw = "fw_tipodev = 'R' AND "; }// Ricevitore
                if (!toggle_tipo_firmware.Checked) { filtro_tmp_fw = filtro_tmp_fw + "fw_standcust = 'S'"; }// Standard
                if (toggle_tipo_firmware.Checked) { filtro_tmp_fw = filtro_tmp_fw + "fw_standcust = 'C'"; }// Custom
                DataView tmp_fw_view = new DataView(ds_SL.dt_Tmp_Fw);
                tmp_fw_view.RowFilter = filtro_tmp_fw;
                cb_scelta_fw.DataSource = tmp_fw_view;
                cb_scelta_fw.Refresh();

                TableLayoutColumnStyleCollection styles = this.tbl_Label_ID.ColumnStyles;

                foreach (ColumnStyle style in styles)
                {
                    if (style.SizeType == SizeType.Absolute)
                    {
                        style.SizeType = SizeType.AutoSize;
                    }
                    else if (style.SizeType == SizeType.AutoSize)
                    {
                        style.SizeType = SizeType.Percent;

                        // Set the column width to be a percentage
                        // of the TableLayoutPanel control's width.
                        style.Width = 33;
                    }
                    else
                    {
                        // Set the column width to 50 pixels.
                        style.SizeType = SizeType.Absolute;
                        style.Width = 50;
                    }
                }

            }

            if (tab_control_Program.SelectedIndex == 0) //Commessa
            {
                menu_commesse_nas.Checked = false;
                menu_commesse_vis.Checked = true;
                grid_commesse.Refresh();
            }
        }

        private void CaricaTreeView()
        {
            // Clear All Nodes if Already Exists  
            tv_FW.Nodes.Clear();
            if (glob_FW_folder != "" && Directory.Exists(glob_FW_folder))
                LoadDirectory(glob_FW_folder);
            else
                MessageBox.Show("Select Directory!!");
            tv_FW.Nodes[0].Expand();
        }

        private void CaricaArchivi()
        {
            //ds_commander.dt_Tmp_Fw.Clear();
            ds_SL.dt_Tmp_Programma.Clear();
            dg_dt_tmp_programmazione.Refresh();
            AbilitaSchermo();

            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            //Caso - Commessa
            if (tab_control_Program.SelectedTab == tab_commessa)
            {
                // TODO: questa riga di codice carica i dati nella tabella 'ds_commander.dt_Firmware'. È possibile spostarla o rimuoverla se necessario.
                this.sF_DistinteBasiTableAdapter.Fill(this.ds_SL.SF_DistinteBasi);
                // TODO: questa riga di codice carica i dati nella tabella 'ds_commander.dt_Firmware'. È possibile spostarla o rimuoverla se necessario.
                this.firmwareTableAdapter.Fill(this.ds_SL.Firmware);
                // TODO: questa riga di codice carica i dati nella tabella 'ds_commander1.SF_Articoli'. È possibile spostarla o rimuoverla se necessario.
                this.sF_ArticoliTableAdapter.Fill(this.ds_SL.SF_Articoli);
                // TODO: questa riga di codice carica i dati nella tabella 'ds_commander1.SF_ArticoliToXSWR'. È possibile spostarla o rimuoverla se necessario.
                this.sF_ArticoliToXSWRTableAdapter.Fill(this.ds_SL.SF_ArticoliToXSWR);
                // TODO: questa riga di codice carica i dati nella tabella 'ds_commander1.dt_FW_Clienti'. È possibile spostarla o rimuoverla se necessario.
                this.fW_ClientiTableAdapter.Fill(this.ds_SL.FW_Clienti);
                // TODO: questa riga di codice carica i dati nella tabella 'ds_commander1.SF_Commesse_SL'. È possibile spostarla o rimuoverla se necessario.
                this.sF_Commesse_SLTableAdapter.Fill(this.ds_SL.SF_Commesse_SL);
            }

            //Caso - Kit
            if (tab_control_Program.SelectedTab == tab_kit)
            {

            }

            //Caso - Device
            if (tab_control_Program.SelectedTab == tab_item)
            {
                // TODO: questa riga di codice carica i dati nella tabella 'ds_commander.dt_Firmware'. È possibile spostarla o rimuoverla se necessario.
                this.firmwareTableAdapter.Fill(this.ds_SL.Firmware);
                // TODO: questa riga di codice carica i dati nella tabella 'ds_commander2.SF_AnagraficaClienti'. È possibile spostarla o rimuoverla se necessario.
                this.sF_AnagraficaClientiTableAdapter.Fill(this.ds_SL.SF_AnagraficaClienti);
                sFAnagraficaClientiBindingSource.Sort = "Conto ASC, RAGIONESOCIALE ASC";
                int index = sFAnagraficaClientiBindingSource.Find("CODICE_NOMINATIVO", 1);
                if (index >= 0)
                {
                    sFAnagraficaClientiBindingSource.Position = index;
                }

                // TODO: questa riga di codice carica i dati nella tabella 'ds_commander1.SF_Articoli'. È possibile spostarla o rimuoverla se necessario.
                this.sF_ArticoliTableAdapter.Fill(this.ds_SL.SF_Articoli);
                // TODO: questa riga di codice carica i dati nella tabella 'ds_commander1.SF_ItemDevice_FW_Des'. È possibile spostarla o rimuoverla se necessario.
                this.sF_ItemDevice_FW_DesTableAdapter.Fill(this.ds_SL.SF_ItemDevice_FW_Des);
                // TODO: questa riga di codice carica i dati nella tabella 'ds_commander.SF_Distinct_Item_Fam_Functions'. È possibile spostarla o rimuoverla se necessario.
                this.sF_Distinct_Item_Fam_FunctionsTableAdapter.Fill(this.ds_SL.SF_Distinct_Item_Fam_Functions);
                // TODO: questa riga di codice carica i dati nella tabella 'ds_commander1.SF_Distinct_Item_Fam_Prefix'. È possibile spostarla o rimuoverla se necessario.
                this.sF_Distinct_Item_Fam_PrefixTableAdapter.Fill(this.ds_SL.SF_Distinct_Item_Fam_Prefix);
            }

            //Caso - Programmazione libera
            if (tab_control_Program.SelectedTab == tab_libera)
            {
            }

            SplashDB.Close();
        }

        //private void SetupLabelWriterSelection(bool InitCmb)
        //{
        //    // create DYMO COM objects
        //    DymoAddInClass DymoAddIn = new DymoAddInClass();

        //    // get the objects on the label
        //    if (InitCmb)
        //    {
        //        // clear all items first
        //        LabelWriterCmb.Items.Clear();

        //        string PrtNames = DymoAddIn.GetDymoPrinters();

        //        if (PrtNames != null)
        //        {
        //            // parse the result
        //            int i = PrtNames.IndexOf('|');
        //            while (i >= 0)
        //            {
        //                LabelWriterCmb.Items.Add(PrtNames.Substring(0, i));
        //                PrtNames = PrtNames.Remove(0, i + 1);
        //                i = PrtNames.IndexOf('|');
        //            }
        //            if (PrtNames.Length > 0)
        //                LabelWriterCmb.Items.Add(PrtNames);

        //            PrtNames = DymoAddIn.GetCurrentPrinterName();
        //            if (PrtNames != null)
        //            {
        //                LabelWriterCmb.SelectedIndex = LabelWriterCmb.Items.IndexOf(PrtNames);
        //                glob_Printer_Name = LabelWriterCmb.Text;
        //            }
        //            else
        //                LabelWriterCmb.SelectedIndex = 0;
        //        }
        //    }

        //    // check if selected/current printer is a twin turbo printer
        //    TrayCmb.Enabled = DymoAddIn.IsTwinTurboPrinter(LabelWriterCmb.Text);
        //    if (TrayCmb.Enabled)
        //    {
        //        // show the current tray selection if the printer
        //        // is a twin turbo
        //        switch (DymoAddIn.GetCurrentPaperTray())
        //        {
        //            case 0: // left tray
        //                TrayCmb.SelectedIndex = 0;
        //                break;

        //            case 1: // right tray
        //                TrayCmb.SelectedIndex = 1;
        //                break;

        //            case 2: // auto switch
        //                TrayCmb.SelectedIndex = 2;
        //                break;

        //            default: // tray selection not set, so default to auto switch
        //                TrayCmb.SelectedIndex = 2;
        //                break;
        //        }
        //        //glob_Printer_Tray = TrayCmb.text;
        //    }
        //}

        private void SetupLabelWriterSelection()
        {
            // clear all items first
            LabelWriterCmb.Items.Clear();

            foreach (IPrinter printer in Framework.GetPrinters())
                LabelWriterCmb.Items.Add(printer.Name);

            if (LabelWriterCmb.Items.Count > 0)
                LabelWriterCmb.SelectedIndex = 0;

            LabelWriterCmb.Enabled = LabelWriterCmb.Items.Count > 0;
        }

        private void LeggiConfig()
        {
            // Lettura impostazioni
            glob_FW_folder = Properties.Settings.Default.FW_folder;
            glob_IP_printer = Properties.Settings.Default.IP_printer;
            glob_use_printer = Properties.Settings.Default.Use_printer;
            glob_Commander_path = Properties.Settings.Default.Commander_path;

            // Assegna le variabili per lo schermo
            tb_FW_folder.Text = glob_FW_folder;
            tb_IP_Printer.Text = glob_IP_printer;
            tog_Use_printer.Checked = glob_use_printer;
            tb_Commander_path.Text = glob_Commander_path;
        }

        private void SetFilterDevice()
        {
            string filter = "";

            if (cb_scelta_Famiglia.Text != "") { filter = "FamDevice = " + "'" + cb_scelta_Famiglia.Text + "'"; }
            sFDistinctItemFamFunctionsBindingSource.Filter = filter;
            sFItemDeviceFWDesBindingSource.Filter = filter;

            if (cb_scelta_Funzioni.Text != "")
            {
                if (filter != "")
                {
                    filter = filter + " AND NumFunzioni = " + "'" + cb_scelta_Funzioni.Text + "'";
                }
                else
                {
                    filter = filter + "NumFunzioni = " + "'" + cb_scelta_Funzioni.Text + "'";
                }
            }
            sFItemDeviceFWDesBindingSource.Filter = filter;
        }

        public void LoadDirectory(string Dir)
        {
            DirectoryInfo di = new DirectoryInfo(Dir);
            //Setting ProgressBar Maximum Value  
            TreeNode tds = tv_FW.Nodes.Add(di.Name);
            tds.Tag = di.FullName;
            tds.StateImageIndex = 0;
            LoadFiles(Dir, tds);
            LoadSubDirectories(Dir, tds);
        }

        private void LoadFiles(string dir, TreeNode td)
        {
            string[] Files = Directory.GetFiles(dir, "*.*");

            // Loop through them to see files  
            foreach (string file in Files)
            {
                FileInfo fi = new FileInfo(file);
                TreeNode tds = td.Nodes.Add(fi.Name);
                tds.Tag = fi.FullName;
                tds.StateImageIndex = 1;

                //Aggiungi riga
                string ext = Path.GetExtension(fi.Name);
                string name = Path.GetFileNameWithoutExtension(fi.Name);
                if ((ext == ".s37") && (name.Length >= 15))
                {
                    DataRow dr = ds_SL.dt_Tmp_Fw.NewRow();
                    dr["fw_codfw"] = name;
                    dr["fw_pathfw"] = fi.FullName;
                    dr["fw_prefix"] = name.Substring(0, 4);
                    dr["fw_tipodev"] = name.Substring(4, 1);
                    dr["fw_standcust"] = name.Substring(5, 1);
                    dr["fw_versione"] = name.Substring(6, 6);
                    dr["fw_freq"] = name.Substring(12, 1);
                    int lenname = name.Length;
                    int len = lenname - 6;
                    dr["fw_searchvers"] = name.Substring(6, len);
                    ds_SL.dt_Tmp_Fw.Rows.Add(dr);
                }
                ///////////////
            }
        }

        private void LoadSubDirectories(string dir, TreeNode td)
        {
            // Get all subdirectories  
            string[] subdirectoryEntries = Directory.GetDirectories(dir);
            // Loop through them to see if they have any other subdirectories  
            foreach (string subdirectory in subdirectoryEntries)
            {
                DirectoryInfo di = new DirectoryInfo(subdirectory);
                if (di.Name.Length != 15) { continue; }
                string start = di.Name.Substring(0, 5);
                if ((start != "XSWRR") && (start != "XSWRP")) { continue; }

                TreeNode tds = td.Nodes.Add(di.Name);
                tds.StateImageIndex = 0;
                tds.Tag = di.FullName;

                LoadFiles(subdirectory, tds);
                LoadSubDirectories(subdirectory, tds);
            }
        }

        private void sFDistinctItemFamPrefixBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            SetFilterDevice();
        }

        private void sFItemDeviceFWDesBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            DataRowView drview = (DataRowView)sFItemDeviceFWDesBindingSource.Current;

            if (drview != null)
            {
                string famdevice = drview["FamDevice"].ToString();
                string numfunz = drview["NumFunzioni"].ToString();
                if (famdevice == "XSB")
                {
                    famdevice = famdevice + numfunz;
                }
                string coddevice = drview["Articolo_Device"].ToString();

                lab_device_ID.Text = drview["Model"].ToString();
                lab_device_desart.Text = drview["Descrizione_Device"].ToString();
                lab_device_desestart.Text = drview["DescrizioneEstesa_Device"].ToString();
                lab_device_codfw.Text = drview["ArticoloFW"].ToString();
                lab_device_desfw.Text = drview["Des_FW"].ToString();
                lab_device_desestfw.Text = drview["DesEst_FW"].ToString();

                //Carica immagine scheda
                string path = WEB_path_image + famdevice + @"\" + coddevice + @"\" + coddevice + "_Full.png";

                if (!File.Exists(path))
                {
                    MessageBox.Show("Immagine non presente");
                    Device_Image.Image = null;
                }
                else
                {
                    Device_Image.Image = Image.FromFile(path);
                }

                cb_scelta_Famiglia.Refresh();
                cb_scelta_Funzioni.Refresh();
                cb_scelta_Device.Refresh();
            }
        }

        private void grid_commesse_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // controllo se già evasa
            if (e.ColumnIndex == grid_commesse.Columns["grid_commesse_CommessaSelezionata"].Index)
            {
                int qtadaeva = 0;
                int qtaevasa = 0;

                try
                {
                    qtadaeva = Convert.ToInt32(grid_commesse.Rows[e.RowIndex].Cells["grid_commesse_QtaDaEvadere"].Value);
                }
                catch (FormatException)
                {
                    qtadaeva = 0;
                }

                try
                {
                    qtaevasa = Convert.ToInt32(grid_commesse.Rows[e.RowIndex].Cells["grid_commesse_Qta_Evasa"].Value);
                }
                catch (FormatException)
                {
                    qtaevasa = 0;
                }


                if ((qtaevasa != 0) && (qtaevasa >= qtadaeva))
                {
                    MessageBox.Show("Commessa già evasa totalmente!");
                    return;
                }
            }

            //NomiColonne
            //grid_commesse_DataConsegna
            //grid_commesse_NumRiga
            //grid_commesse_CodArticoloCommessa
            //grid_commesse_Device
            //grid_commesse_ViewDevice
            //grid_commesse_QtaDaEvadere
            //grid_commesse_CommessaSelezionata
            //grid_commesse_TipoOrdine
            //grid_commesse_CommessaLong
            //grid_commesse_CommessaShort
            //grid_commesse_DataOrdine
            //grid_commesse_NumeroOrdine
            //grid_commesse_CodAnagrafico
            //grid_commesse_RagioneSociale
            //grid_commesse_UM
            //grid_commesse_QtaOrdinata
            //grid_commesse_StatoCommessa
            //grid_commesse_TipoRiga
            //grid_commesse_IsKit
            //grid_commesse_IsSwrP
            //grid_commesse_IsSWRR
            //grid_commesse_DataFineValidita
            //grid_commesse_SwDevice

            //Setto tipo programmazione
            glob_tipo_progr = "C";

            //Controllo su tipo riga
            DataGridViewRow row = grid_commesse.Rows[e.RowIndex];
            string CommessaLong = row.Cells["grid_commesse_CommessaLong"].Value.ToString().Trim();
            string CommessaShort = row.Cells["grid_commesse_CommessaShort"].Value.ToString().Trim();
            string Kit = row.Cells["grid_commesse_CodArticoloCommessa"].Value.ToString().Trim();
            string Item = row.Cells["grid_commesse_Device"].Value.ToString().Trim();
            string Fw = row.Cells["grid_commesse_SwDevice"].Value.ToString().Trim();
            glob_ID_cli = row.Cells["grid_commesse_CodAnagrafico"].Value.ToString().Trim();

            if ((e.ColumnIndex == grid_commesse.Columns["grid_commesse_ViewDevice"].Index) && (Item != ""))
            {
                using (var form = new UC_ImageDevice(Item, WEB_path_image))
                {
                    if (form.ShowDialog() == DialogResult.OK)
                    {
                        //glob_Form_ID = form.CodiceID;
                        //tb_Id_Hardware.Text = glob_Form_ID;
                    }
                    //glob_Form_ID = form.CodiceID;
                    //tb_Id_Hardware.Text = glob_Form_ID;
                }
            }

            if (e.ColumnIndex == grid_commesse.Columns["grid_commesse_CommessaSelezionata"].Index) // Aggiorna
            {
                if (Item == "") // Solo Software
                {
                    Fw = Kit; //Sovrascrivo il codice software (non ce l'ho) con l'item
                    AggiornaFwCliente(glob_ID_cli, Fw);
                }
                else
                {
                    ds_SL.dt_Tmp_Programma.Clear();
                    ds_SL.dt_TMP_Firmware.Clear();

                    //Ricerca di tutti i device e di tutti i software
                    TrovaFWDeviceCommesse(CommessaShort);
                    TrovaFWDeviceKit(Kit, CommessaLong, CommessaShort, Convert.ToInt32(glob_ID_cli), Kit);

                    //Controllo oggetto per capire che FW mettere
                    ds_SL.dt_TMP_Firmware.DefaultView.Sort = "Livello_FW desc, Cod_FW asc";
                    string tipodevice = Item.Substring(5, 1);
                    string filtro = "";
                    if (tipodevice == "P")
                    {
                        filtro = "Is_SWR_P = '1'";
                    }
                    if (tipodevice == "R")
                    {
                        filtro = "Is_SWR_R = '1'";
                    }
                    foreach (DataRow rows in ds_SL.dt_TMP_Firmware.Select(filtro))
                    {
                        Fw = rows["Cod_FW"].ToString();
                        break;
                    }

                    DataRowView currentRowView = sFCommesseSLSFArticoliBindingSource.Current as DataRowView;
                    string ID = currentRowView["Modello"].ToString();
                    AggiungiRigaProg(CommessaLong, Kit, Item, Fw, 0, ID);
                }
            }

            grid_commesse.Refresh();
        }

        private void grid_commesse_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            if (e.ColumnIndex == grid_commesse.Columns["grid_commesse_ViewDevice"].Index)
            {
                e.Paint(e.CellBounds, DataGridViewPaintParts.All);

                var w = Properties.Resources.Lente.Width;
                var h = Properties.Resources.Lente.Height;
                var x = e.CellBounds.Left + (e.CellBounds.Width - w) / 2;
                var y = e.CellBounds.Top + (e.CellBounds.Height - h) / 2;

                e.Graphics.DrawImage(Properties.Resources.Lente, new Rectangle(x, y, w, h));
                e.Handled = true;
            }

            if (e.ColumnIndex == grid_commesse.Columns["grid_commesse_Device"].Index)
            {
                if (grid_commesse.Rows[e.RowIndex].Cells["grid_commesse_Device"].Value.ToString() == "")
                {
                    // Verifica se il firmware è già associato al cliente
                    bool newrecord = false;

                    string CodAnaCli = grid_commesse.Rows[e.RowIndex].Cells["grid_commesse_CodAnagrafico"].Value.ToString();
                    string Fw = grid_commesse.Rows[e.RowIndex].Cells["grid_commesse_CodArticoloCommessa"].Value.ToString();

                    string sel = "Cod_Nominativo = " + "'" + CodAnaCli + "' AND SW_Code = '" + Fw + "'";
                    DataRow[] result = ds_SL.FW_Clienti.Select(sel);
                    if (result.Count() > 0) { newrecord = false; } else { newrecord = true; }

                    if (!newrecord)
                    {
                        //grid_commesse.Rows[e.RowIndex].DefaultCellStyle.ForeColor = System.Drawing.Color.Blue;
                        grid_commesse.Rows[e.RowIndex].DefaultCellStyle.Font = new Font(grid_commesse.DefaultCellStyle.Font, System.Drawing.FontStyle.Strikeout);
                        if (!glob_show_evasi) { grid_commesse.Rows[e.RowIndex].Visible = false; } else { grid_commesse.Rows[e.RowIndex].Visible = true; }
                    }
                }
            }

            if (e.ColumnIndex == grid_commesse.Columns["grid_commesse_Qta_Evasa"].Index)
            {
                if ((grid_commesse.Rows[e.RowIndex].Cells["grid_commesse_Qta_Evasa"].Value != null) && (grid_commesse.Rows[e.RowIndex].Cells["grid_commesse_Qta_Evasa"].Value.ToString() != ""))
                {
                    int qtadaeva = 0;
                    int qtaevasa = 0;

                    try
                    {
                        qtadaeva = Int32.Parse(grid_commesse.Rows[e.RowIndex].Cells["grid_commesse_QtaDaEvadere"].Value.ToString());
                    }
                    catch (FormatException)
                    {
                        qtadaeva = 0;
                    }

                    try
                    {
                        qtaevasa = Int32.Parse(grid_commesse.Rows[e.RowIndex].Cells["grid_commesse_Qta_Evasa"].Value.ToString());
                    }
                    catch (FormatException)
                    {
                        qtaevasa = 0;
                    }


                    if ((qtaevasa != 0) && (qtaevasa >= qtadaeva))
                    {
                        //grid_commesse.Rows[e.RowIndex].DefaultCellStyle.ForeColor = System.Drawing.Color.Blue;
                        grid_commesse.Rows[e.RowIndex].DefaultCellStyle.Font = new Font(grid_commesse.DefaultCellStyle.Font, System.Drawing.FontStyle.Strikeout);
                        //                        if (!glob_show_evasi) { grid_commesse.Rows[e.RowIndex].Visible = false; } else { grid_commesse.Rows[e.RowIndex].Visible = true; }
                    }
                }
            }
        }

        private void AggiornaFwCliente(string CodAnaCli, string Fw)
        {
            // Verifica se nuovo SN o già esistente
            bool newrecord = false;
            //string sel = "Cod_Nominativo = " + "'" + CodAnaCli + "' AND SW_Code = '" + Fw + "'";
            string sel = "Cod_Nominativo = " + CodAnaCli + " AND SW_Code = '" + Fw + "'";
            DataRow[] result = ds_SL.FW_Clienti.Select(sel);
            if (result.Length > 0)
            { newrecord = false; }
            else
            { newrecord = true; }

            if (newrecord)
            {
                string des_ita = "";
                string des_en = "";
                DataView dv_fw = new DataView(ds_SL.Firmware);
                dv_fw.RowFilter = "SW_Code = " + "'" + Fw + "'";
                if (dv_fw != null)
                {
                    des_ita = dv_fw[0]["SW_Descrizione"].ToString();
                    des_en = dv_fw[0]["SW_Descrizione_EN"].ToString();
                }

                DataRow newrow = ds_SL.FW_Clienti.NewRow();
                newrow["Cod_Nominativo"] = CodAnaCli;
                newrow["SW_Code"] = Fw;
                newrow["SW_Des1"] = des_ita;
                newrow["SW_Des2"] = des_en;

                ds_SL.FW_Clienti.Rows.Add(newrow);

                fW_ClientiTableAdapter.Update(newrow);
            }
        }

        private void TrovaFWDeviceCommesse(string commessashort)
        {
            ds_SL.dt_TMP_Firmware.Clear();

            string filtro = "CommessaShort = " + "'" + commessashort + "'";
            //DataRow[] rows = ds_commander1.SF_Commesse_SL.Select(filtro);

            // Ricerca FW in commesse
            foreach (DataRow rows in ds_SL.SF_Commesse_SL.Select(filtro))
            {
                bool isswrP = Convert.ToBoolean(rows["Is_SWR_P"]);
                bool isswrR = Convert.ToBoolean(rows["Is_SWR_R"]);

                if (isswrP || isswrR)
                {
                    DataRow dr_tmp_fw = ds_SL.dt_TMP_Firmware.NewRow();

                    dr_tmp_fw["CommessaLong"] = rows["CommessaLong"];
                    dr_tmp_fw["CommessaShort"] = rows["CommessaShort"];
                    dr_tmp_fw["CodAnagrafico"] = rows["CodAnagrafico"];
                    dr_tmp_fw["Cod_FW"] = rows["Art_Commessa"];
                    dr_tmp_fw["Is_SWR_P"] = rows["Is_SWR_P"];
                    dr_tmp_fw["Is_SWR_R"] = rows["Is_SWR_R"];
                    dr_tmp_fw["Livello_FW"] = 100; // Firmware da commessa

                    ds_SL.dt_TMP_Firmware.Rows.Add(dr_tmp_fw);
                }
            }
        }

        private void TrovaFWDeviceKit(string kit, string commessalong, string commessashort, int codanacli, string artcommessa)
        {
            string filtro = "ArticoloComposto = " + "'" + kit + "'" + " AND DataFineValidita = '' AND ArticoloComponente like 'XSWR%'";

            // Ricerca FW in commesse
            foreach (DataRow rows in ds_SL.SF_DistinteBasi.Select(filtro))
            {
                string componente = rows["ArticoloComponente"].ToString().Trim();

                bool isswrP = false;
                bool isswrR = false;

                if (componente.StartsWith("XSWRP")) { isswrP = true; }
                if (componente.StartsWith("XSWRR")) { isswrR = true; }

                if (isswrP || isswrR)
                {
                    DataRow dr_tmp_fw = ds_SL.dt_TMP_Firmware.NewRow();

                    dr_tmp_fw["CommessaLong"] = commessalong;
                    dr_tmp_fw["CommessaShort"] = commessashort;
                    dr_tmp_fw["CodAnagrafico"] = codanacli;
                    dr_tmp_fw["Cod_FW"] = componente;
                    dr_tmp_fw["Is_SWR_P"] = isswrP;
                    dr_tmp_fw["Is_SWR_R"] = isswrR;
                    dr_tmp_fw["Livello_FW"] = 200; // Firmware da KIT

                    ds_SL.dt_TMP_Firmware.Rows.Add(dr_tmp_fw);
                }
            }
        }

        private bool AggiungiRigaProg(string Commessa, string Kit, string Item, string cod_fw, int fw_key_id, string ID_Hw)
        {
            DataRow dr = ds_SL.dt_Tmp_Programma.NewRow();
            dr["tmp_prog_commessa"] = Commessa;
            dr["tmp_prog_codart_kit"] = Kit;
            dr["tmp_prog_codart_item"] = Item;
            dr["tmp_prog_codart_fw"] = cod_fw;
            dr["tmp_fw_key_id"] = fw_key_id;
            dr["tmp_ID_Hardware"] = ID_Hw;
            ds_SL.dt_Tmp_Programma.Rows.Add(dr);

            return true;
        }

        private void grid_commesse_menu_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            CaricaArchivi();

            Cursor.Current = Cursors.Default;
        }

        private void grid_commesse_menu_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            var menuText = e.ClickedItem.Text;
            switch (menuText)
            {
                case "Visualizza le commesse evase":
                    glob_show_evasi = true;
                    break;

                case "Nascondi le commesse evase":
                    glob_show_evasi = false;
                    break;
            }

            //filtraggio delle righe
            string filter = "";

            if (!glob_show_evasi)
            {
                filter = "Qta_da_Evadere > Qta_Evasa";
            }
            sFCommesseSLBindingSource.Filter = filter;
        }

        private void grid_commesse_menu_Opened(object sender, EventArgs e)
        {
            if (glob_show_evasi)
            {
                menu_commesse_vis.Checked = true;
                menu_commesse_nas.Checked = false;
            }
            else
            {
                menu_commesse_vis.Checked = false;
                menu_commesse_nas.Checked = true;
            }
        }

    }
}
