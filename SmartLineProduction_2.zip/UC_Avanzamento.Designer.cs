﻿namespace SmartLineProduction
{
    partial class UC_Avanzamento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gv_Commesse = new MetroFramework.Controls.MetroGrid();
            this.sFCommesseAperteCLSLBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.sF_CommesseAperte_CL_SLTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_CommesseAperte_CL_SLTableAdapter();
            this.entitaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tIPOORDINEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dATAORDINEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nUMEROORDINEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nUMERORIGADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codAnagraficoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sortDataConsegnaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RagioneSociale = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nazioneFiscaleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Commessa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cOMMESSASHORTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Articolo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pREZZOUNITARIODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qTAORDINATADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qTASPEDITADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CellaQtaInevasa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iMPORTODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iMPORTOEVASODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iMPORTODAEVADEREDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.meseConsegnaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomeMeseConsegnaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.annoConsegnaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.commessaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CellaProgrammazione = new System.Windows.Forms.DataGridViewImageColumn();
            this.CellaProgrammazione_cmbox = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.CellaProgrammazione_Note = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CellaMontaggio = new System.Windows.Forms.DataGridViewImageColumn();
            this.CellaMontaggio_Note = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CellaCollConf = new System.Windows.Forms.DataGridViewImageColumn();
            this.CellaCollConf_Note = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CellaSpedizione = new System.Windows.Forms.DataGridViewImageColumn();
            this.CellaSpedizione_Note = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CellaVendita = new System.Windows.Forms.DataGridViewImageColumn();
            this.CellaVendita_Note = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.distintaBaseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtamontaggioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtacollaudoconfezionamentoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtavenditaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Commesse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFCommesseAperteCLSLBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            this.SuspendLayout();
            // 
            // gv_Commesse
            // 
            this.gv_Commesse.AllowUserToAddRows = false;
            this.gv_Commesse.AllowUserToDeleteRows = false;
            this.gv_Commesse.AllowUserToOrderColumns = true;
            this.gv_Commesse.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.gv_Commesse.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.gv_Commesse.AutoGenerateColumns = false;
            this.gv_Commesse.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.gv_Commesse.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Commesse.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Commesse.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_Commesse.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Commesse.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gv_Commesse.ColumnHeadersHeight = 40;
            this.gv_Commesse.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.entitaDataGridViewTextBoxColumn,
            this.tIPOORDINEDataGridViewTextBoxColumn,
            this.dATAORDINEDataGridViewTextBoxColumn,
            this.nUMEROORDINEDataGridViewTextBoxColumn,
            this.nUMERORIGADataGridViewTextBoxColumn,
            this.codAnagraficoDataGridViewTextBoxColumn,
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn,
            this.sortDataConsegnaDataGridViewTextBoxColumn,
            this.RagioneSociale,
            this.nazioneFiscaleDataGridViewTextBoxColumn,
            this.Commessa,
            this.cOMMESSASHORTDataGridViewTextBoxColumn,
            this.Articolo,
            this.uMDataGridViewTextBoxColumn,
            this.pREZZOUNITARIODataGridViewTextBoxColumn,
            this.qTAORDINATADataGridViewTextBoxColumn,
            this.qTASPEDITADataGridViewTextBoxColumn,
            this.CellaQtaInevasa,
            this.iMPORTODataGridViewTextBoxColumn,
            this.iMPORTOEVASODataGridViewTextBoxColumn,
            this.iMPORTODAEVADEREDataGridViewTextBoxColumn,
            this.meseConsegnaDataGridViewTextBoxColumn,
            this.nomeMeseConsegnaDataGridViewTextBoxColumn,
            this.annoConsegnaDataGridViewTextBoxColumn,
            this.commessaDataGridViewTextBoxColumn,
            this.CellaProgrammazione,
            this.CellaProgrammazione_cmbox,
            this.CellaProgrammazione_Note,
            this.CellaMontaggio,
            this.CellaMontaggio_Note,
            this.CellaCollConf,
            this.CellaCollConf_Note,
            this.CellaSpedizione,
            this.CellaSpedizione_Note,
            this.CellaVendita,
            this.CellaVendita_Note,
            this.distintaBaseDataGridViewTextBoxColumn,
            this.qtamontaggioDataGridViewTextBoxColumn,
            this.qtacollaudoconfezionamentoDataGridViewTextBoxColumn,
            this.qtavenditaDataGridViewTextBoxColumn});
            this.gv_Commesse.DataSource = this.sFCommesseAperteCLSLBindingSource;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Commesse.DefaultCellStyle = dataGridViewCellStyle10;
            this.gv_Commesse.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Commesse.EnableHeadersVisualStyles = false;
            this.gv_Commesse.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Commesse.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Commesse.Location = new System.Drawing.Point(20, 60);
            this.gv_Commesse.MultiSelect = false;
            this.gv_Commesse.Name = "gv_Commesse";
            this.gv_Commesse.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Commesse.RowHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.gv_Commesse.RowHeadersVisible = false;
            this.gv_Commesse.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Commesse.RowTemplate.DividerHeight = 1;
            this.gv_Commesse.RowTemplate.Height = 60;
            this.gv_Commesse.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Commesse.Size = new System.Drawing.Size(1003, 499);
            this.gv_Commesse.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_Commesse.TabIndex = 0;
            this.gv_Commesse.UseCustomBackColor = true;
            this.gv_Commesse.UseCustomForeColor = true;
            this.gv_Commesse.UseStyleColors = true;
            this.gv_Commesse.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gv_Commesse_CellClick);
            this.gv_Commesse.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.gv_Commesse_CellFormatting);
            this.gv_Commesse.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.gv_Commesse_CellPainting);
            this.gv_Commesse.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.gv_Commesse_DataError);
            // 
            // sFCommesseAperteCLSLBindingSource
            // 
            this.sFCommesseAperteCLSLBindingSource.DataMember = "SF_CommesseAperte_CL_SL";
            this.sFCommesseAperteCLSLBindingSource.DataSource = this.ds_SL;
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sF_CommesseAperte_CL_SLTableAdapter
            // 
            this.sF_CommesseAperte_CL_SLTableAdapter.ClearBeforeFill = true;
            // 
            // entitaDataGridViewTextBoxColumn
            // 
            this.entitaDataGridViewTextBoxColumn.DataPropertyName = "Entita";
            this.entitaDataGridViewTextBoxColumn.HeaderText = "Entita";
            this.entitaDataGridViewTextBoxColumn.Name = "entitaDataGridViewTextBoxColumn";
            this.entitaDataGridViewTextBoxColumn.ReadOnly = true;
            this.entitaDataGridViewTextBoxColumn.Visible = false;
            // 
            // tIPOORDINEDataGridViewTextBoxColumn
            // 
            this.tIPOORDINEDataGridViewTextBoxColumn.DataPropertyName = "TIPO_ORDINE";
            this.tIPOORDINEDataGridViewTextBoxColumn.HeaderText = "TIPO_ORDINE";
            this.tIPOORDINEDataGridViewTextBoxColumn.Name = "tIPOORDINEDataGridViewTextBoxColumn";
            this.tIPOORDINEDataGridViewTextBoxColumn.ReadOnly = true;
            this.tIPOORDINEDataGridViewTextBoxColumn.Visible = false;
            // 
            // dATAORDINEDataGridViewTextBoxColumn
            // 
            this.dATAORDINEDataGridViewTextBoxColumn.DataPropertyName = "DATA_ORDINE";
            this.dATAORDINEDataGridViewTextBoxColumn.HeaderText = "DATA_ORDINE";
            this.dATAORDINEDataGridViewTextBoxColumn.Name = "dATAORDINEDataGridViewTextBoxColumn";
            this.dATAORDINEDataGridViewTextBoxColumn.ReadOnly = true;
            this.dATAORDINEDataGridViewTextBoxColumn.Visible = false;
            // 
            // nUMEROORDINEDataGridViewTextBoxColumn
            // 
            this.nUMEROORDINEDataGridViewTextBoxColumn.DataPropertyName = "NUMERO_ORDINE";
            this.nUMEROORDINEDataGridViewTextBoxColumn.HeaderText = "NUMERO_ORDINE";
            this.nUMEROORDINEDataGridViewTextBoxColumn.Name = "nUMEROORDINEDataGridViewTextBoxColumn";
            this.nUMEROORDINEDataGridViewTextBoxColumn.ReadOnly = true;
            this.nUMEROORDINEDataGridViewTextBoxColumn.Visible = false;
            // 
            // nUMERORIGADataGridViewTextBoxColumn
            // 
            this.nUMERORIGADataGridViewTextBoxColumn.DataPropertyName = "NUMERO_RIGA";
            this.nUMERORIGADataGridViewTextBoxColumn.HeaderText = "NUMERO_RIGA";
            this.nUMERORIGADataGridViewTextBoxColumn.Name = "nUMERORIGADataGridViewTextBoxColumn";
            this.nUMERORIGADataGridViewTextBoxColumn.ReadOnly = true;
            this.nUMERORIGADataGridViewTextBoxColumn.Visible = false;
            // 
            // codAnagraficoDataGridViewTextBoxColumn
            // 
            this.codAnagraficoDataGridViewTextBoxColumn.DataPropertyName = "CodAnagrafico";
            this.codAnagraficoDataGridViewTextBoxColumn.HeaderText = "CodAnagrafico";
            this.codAnagraficoDataGridViewTextBoxColumn.Name = "codAnagraficoDataGridViewTextBoxColumn";
            this.codAnagraficoDataGridViewTextBoxColumn.ReadOnly = true;
            this.codAnagraficoDataGridViewTextBoxColumn.Visible = false;
            // 
            // dATACONFERMACONSEGNADataGridViewTextBoxColumn
            // 
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn.DataPropertyName = "DATA_CONFERMA_CONSEGNA";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.Format = "d";
            dataGridViewCellStyle3.NullValue = null;
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle3;
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn.HeaderText = "Data di Consegna (non usare)";
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn.Name = "dATACONFERMACONSEGNADataGridViewTextBoxColumn";
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn.ReadOnly = true;
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn.Visible = false;
            this.dATACONFERMACONSEGNADataGridViewTextBoxColumn.Width = 139;
            // 
            // sortDataConsegnaDataGridViewTextBoxColumn
            // 
            this.sortDataConsegnaDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.sortDataConsegnaDataGridViewTextBoxColumn.DataPropertyName = "SortDataConsegna";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.Format = "d";
            dataGridViewCellStyle4.NullValue = null;
            this.sortDataConsegnaDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle4;
            this.sortDataConsegnaDataGridViewTextBoxColumn.HeaderText = "Data di Consegna";
            this.sortDataConsegnaDataGridViewTextBoxColumn.Name = "sortDataConsegnaDataGridViewTextBoxColumn";
            this.sortDataConsegnaDataGridViewTextBoxColumn.ReadOnly = true;
            this.sortDataConsegnaDataGridViewTextBoxColumn.Width = 112;
            // 
            // RagioneSociale
            // 
            this.RagioneSociale.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.RagioneSociale.DataPropertyName = "RAGIONE_SOCIALE";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.RagioneSociale.DefaultCellStyle = dataGridViewCellStyle5;
            this.RagioneSociale.HeaderText = "Ragione Sociale";
            this.RagioneSociale.Name = "RagioneSociale";
            this.RagioneSociale.ReadOnly = true;
            // 
            // nazioneFiscaleDataGridViewTextBoxColumn
            // 
            this.nazioneFiscaleDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.nazioneFiscaleDataGridViewTextBoxColumn.DataPropertyName = "NazioneFiscale";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.nazioneFiscaleDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle6;
            this.nazioneFiscaleDataGridViewTextBoxColumn.HeaderText = "Nazione";
            this.nazioneFiscaleDataGridViewTextBoxColumn.Name = "nazioneFiscaleDataGridViewTextBoxColumn";
            this.nazioneFiscaleDataGridViewTextBoxColumn.ReadOnly = true;
            this.nazioneFiscaleDataGridViewTextBoxColumn.Width = 72;
            // 
            // Commessa
            // 
            this.Commessa.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Commessa.DataPropertyName = "COMMESSALONG";
            this.Commessa.HeaderText = "Commessa";
            this.Commessa.Name = "Commessa";
            this.Commessa.ReadOnly = true;
            this.Commessa.Width = 84;
            // 
            // cOMMESSASHORTDataGridViewTextBoxColumn
            // 
            this.cOMMESSASHORTDataGridViewTextBoxColumn.DataPropertyName = "COMMESSASHORT";
            this.cOMMESSASHORTDataGridViewTextBoxColumn.HeaderText = "COMMESSASHORT";
            this.cOMMESSASHORTDataGridViewTextBoxColumn.Name = "cOMMESSASHORTDataGridViewTextBoxColumn";
            this.cOMMESSASHORTDataGridViewTextBoxColumn.ReadOnly = true;
            this.cOMMESSASHORTDataGridViewTextBoxColumn.Visible = false;
            // 
            // Articolo
            // 
            this.Articolo.DataPropertyName = "ARTICOLO";
            this.Articolo.HeaderText = "Articolo";
            this.Articolo.Name = "Articolo";
            this.Articolo.ReadOnly = true;
            // 
            // uMDataGridViewTextBoxColumn
            // 
            this.uMDataGridViewTextBoxColumn.DataPropertyName = "UM";
            this.uMDataGridViewTextBoxColumn.HeaderText = "UM";
            this.uMDataGridViewTextBoxColumn.Name = "uMDataGridViewTextBoxColumn";
            this.uMDataGridViewTextBoxColumn.ReadOnly = true;
            this.uMDataGridViewTextBoxColumn.Visible = false;
            // 
            // pREZZOUNITARIODataGridViewTextBoxColumn
            // 
            this.pREZZOUNITARIODataGridViewTextBoxColumn.DataPropertyName = "PREZZO_UNITARIO";
            this.pREZZOUNITARIODataGridViewTextBoxColumn.HeaderText = "PREZZO_UNITARIO";
            this.pREZZOUNITARIODataGridViewTextBoxColumn.Name = "pREZZOUNITARIODataGridViewTextBoxColumn";
            this.pREZZOUNITARIODataGridViewTextBoxColumn.ReadOnly = true;
            this.pREZZOUNITARIODataGridViewTextBoxColumn.Visible = false;
            // 
            // qTAORDINATADataGridViewTextBoxColumn
            // 
            this.qTAORDINATADataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.qTAORDINATADataGridViewTextBoxColumn.DataPropertyName = "QTA_ORDINATA";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Format = "N0";
            dataGridViewCellStyle7.NullValue = "- - -";
            this.qTAORDINATADataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle7;
            this.qTAORDINATADataGridViewTextBoxColumn.HeaderText = "Q.tà Ordinata";
            this.qTAORDINATADataGridViewTextBoxColumn.Name = "qTAORDINATADataGridViewTextBoxColumn";
            this.qTAORDINATADataGridViewTextBoxColumn.ReadOnly = true;
            this.qTAORDINATADataGridViewTextBoxColumn.Width = 92;
            // 
            // qTASPEDITADataGridViewTextBoxColumn
            // 
            this.qTASPEDITADataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.qTASPEDITADataGridViewTextBoxColumn.DataPropertyName = "QTA_SPEDITA";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.Format = "N0";
            dataGridViewCellStyle8.NullValue = "- - -";
            this.qTASPEDITADataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle8;
            this.qTASPEDITADataGridViewTextBoxColumn.HeaderText = "Q.tà Spedita";
            this.qTASPEDITADataGridViewTextBoxColumn.Name = "qTASPEDITADataGridViewTextBoxColumn";
            this.qTASPEDITADataGridViewTextBoxColumn.ReadOnly = true;
            this.qTASPEDITADataGridViewTextBoxColumn.Width = 85;
            // 
            // CellaQtaInevasa
            // 
            this.CellaQtaInevasa.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.CellaQtaInevasa.DataPropertyName = "QTA_DA_EVADERE";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.Format = "N0";
            dataGridViewCellStyle9.NullValue = "- - -";
            this.CellaQtaInevasa.DefaultCellStyle = dataGridViewCellStyle9;
            this.CellaQtaInevasa.HeaderText = "Q.tà inevasa";
            this.CellaQtaInevasa.Name = "CellaQtaInevasa";
            this.CellaQtaInevasa.ReadOnly = true;
            this.CellaQtaInevasa.Width = 85;
            // 
            // iMPORTODataGridViewTextBoxColumn
            // 
            this.iMPORTODataGridViewTextBoxColumn.DataPropertyName = "IMPORTO";
            this.iMPORTODataGridViewTextBoxColumn.HeaderText = "IMPORTO";
            this.iMPORTODataGridViewTextBoxColumn.Name = "iMPORTODataGridViewTextBoxColumn";
            this.iMPORTODataGridViewTextBoxColumn.ReadOnly = true;
            this.iMPORTODataGridViewTextBoxColumn.Visible = false;
            // 
            // iMPORTOEVASODataGridViewTextBoxColumn
            // 
            this.iMPORTOEVASODataGridViewTextBoxColumn.DataPropertyName = "IMPORTO_EVASO";
            this.iMPORTOEVASODataGridViewTextBoxColumn.HeaderText = "IMPORTO_EVASO";
            this.iMPORTOEVASODataGridViewTextBoxColumn.Name = "iMPORTOEVASODataGridViewTextBoxColumn";
            this.iMPORTOEVASODataGridViewTextBoxColumn.ReadOnly = true;
            this.iMPORTOEVASODataGridViewTextBoxColumn.Visible = false;
            // 
            // iMPORTODAEVADEREDataGridViewTextBoxColumn
            // 
            this.iMPORTODAEVADEREDataGridViewTextBoxColumn.DataPropertyName = "IMPORTO_DA_EVADERE";
            this.iMPORTODAEVADEREDataGridViewTextBoxColumn.HeaderText = "IMPORTO_DA_EVADERE";
            this.iMPORTODAEVADEREDataGridViewTextBoxColumn.Name = "iMPORTODAEVADEREDataGridViewTextBoxColumn";
            this.iMPORTODAEVADEREDataGridViewTextBoxColumn.ReadOnly = true;
            this.iMPORTODAEVADEREDataGridViewTextBoxColumn.Visible = false;
            // 
            // meseConsegnaDataGridViewTextBoxColumn
            // 
            this.meseConsegnaDataGridViewTextBoxColumn.DataPropertyName = "MeseConsegna";
            this.meseConsegnaDataGridViewTextBoxColumn.HeaderText = "MeseConsegna";
            this.meseConsegnaDataGridViewTextBoxColumn.Name = "meseConsegnaDataGridViewTextBoxColumn";
            this.meseConsegnaDataGridViewTextBoxColumn.ReadOnly = true;
            this.meseConsegnaDataGridViewTextBoxColumn.Visible = false;
            // 
            // nomeMeseConsegnaDataGridViewTextBoxColumn
            // 
            this.nomeMeseConsegnaDataGridViewTextBoxColumn.DataPropertyName = "NomeMeseConsegna";
            this.nomeMeseConsegnaDataGridViewTextBoxColumn.HeaderText = "NomeMeseConsegna";
            this.nomeMeseConsegnaDataGridViewTextBoxColumn.Name = "nomeMeseConsegnaDataGridViewTextBoxColumn";
            this.nomeMeseConsegnaDataGridViewTextBoxColumn.ReadOnly = true;
            this.nomeMeseConsegnaDataGridViewTextBoxColumn.Visible = false;
            // 
            // annoConsegnaDataGridViewTextBoxColumn
            // 
            this.annoConsegnaDataGridViewTextBoxColumn.DataPropertyName = "AnnoConsegna";
            this.annoConsegnaDataGridViewTextBoxColumn.HeaderText = "AnnoConsegna";
            this.annoConsegnaDataGridViewTextBoxColumn.Name = "annoConsegnaDataGridViewTextBoxColumn";
            this.annoConsegnaDataGridViewTextBoxColumn.ReadOnly = true;
            this.annoConsegnaDataGridViewTextBoxColumn.Visible = false;
            // 
            // commessaDataGridViewTextBoxColumn
            // 
            this.commessaDataGridViewTextBoxColumn.DataPropertyName = "Commessa";
            this.commessaDataGridViewTextBoxColumn.HeaderText = "Commessa";
            this.commessaDataGridViewTextBoxColumn.Name = "commessaDataGridViewTextBoxColumn";
            this.commessaDataGridViewTextBoxColumn.ReadOnly = true;
            this.commessaDataGridViewTextBoxColumn.Visible = false;
            // 
            // CellaProgrammazione
            // 
            this.CellaProgrammazione.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.CellaProgrammazione.DataPropertyName = "AO_Programmazione";
            this.CellaProgrammazione.HeaderText = "Programmazione";
            this.CellaProgrammazione.Name = "CellaProgrammazione";
            this.CellaProgrammazione.ReadOnly = true;
            this.CellaProgrammazione.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.CellaProgrammazione.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.CellaProgrammazione.Width = 116;
            // 
            // CellaProgrammazione_cmbox
            // 
            this.CellaProgrammazione_cmbox.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.CellaProgrammazione_cmbox.DataPropertyName = "qta_programmazione";
            this.CellaProgrammazione_cmbox.DataSource = this.sFCommesseAperteCLSLBindingSource;
            this.CellaProgrammazione_cmbox.DisplayMember = "qta_programmazione";
            this.CellaProgrammazione_cmbox.HeaderText = "Q.tà Programmazione";
            this.CellaProgrammazione_cmbox.Name = "CellaProgrammazione_cmbox";
            this.CellaProgrammazione_cmbox.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.CellaProgrammazione_cmbox.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.CellaProgrammazione_cmbox.Visible = false;
            this.CellaProgrammazione_cmbox.Width = 128;
            // 
            // CellaProgrammazione_Note
            // 
            this.CellaProgrammazione_Note.DataPropertyName = "AO_Programmazione_Note";
            this.CellaProgrammazione_Note.HeaderText = "AO_Programmazione_Note";
            this.CellaProgrammazione_Note.Name = "CellaProgrammazione_Note";
            this.CellaProgrammazione_Note.Visible = false;
            // 
            // CellaMontaggio
            // 
            this.CellaMontaggio.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.CellaMontaggio.DataPropertyName = "AO_Montaggio";
            this.CellaMontaggio.HeaderText = "Montaggio";
            this.CellaMontaggio.Name = "CellaMontaggio";
            this.CellaMontaggio.ReadOnly = true;
            this.CellaMontaggio.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.CellaMontaggio.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.CellaMontaggio.Width = 88;
            // 
            // CellaMontaggio_Note
            // 
            this.CellaMontaggio_Note.DataPropertyName = "AO_Montaggio_Note";
            this.CellaMontaggio_Note.HeaderText = "AO_Montaggio_Note";
            this.CellaMontaggio_Note.Name = "CellaMontaggio_Note";
            this.CellaMontaggio_Note.Visible = false;
            // 
            // CellaCollConf
            // 
            this.CellaCollConf.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.CellaCollConf.DataPropertyName = "AO_CollaudoConfezionamento";
            this.CellaCollConf.HeaderText = "Coll./Conf.";
            this.CellaCollConf.Name = "CellaCollConf";
            this.CellaCollConf.ReadOnly = true;
            this.CellaCollConf.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.CellaCollConf.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.CellaCollConf.Width = 85;
            // 
            // CellaCollConf_Note
            // 
            this.CellaCollConf_Note.DataPropertyName = "AO_CollaudoConfezionamento_Note";
            this.CellaCollConf_Note.HeaderText = "AO_CollaudoConfezionamento_Note";
            this.CellaCollConf_Note.Name = "CellaCollConf_Note";
            this.CellaCollConf_Note.Visible = false;
            // 
            // CellaSpedizione
            // 
            this.CellaSpedizione.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.CellaSpedizione.DataPropertyName = "AO_Spedizione";
            this.CellaSpedizione.HeaderText = "Spedizione";
            this.CellaSpedizione.Name = "CellaSpedizione";
            this.CellaSpedizione.ReadOnly = true;
            this.CellaSpedizione.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.CellaSpedizione.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.CellaSpedizione.Width = 87;
            // 
            // CellaSpedizione_Note
            // 
            this.CellaSpedizione_Note.DataPropertyName = "AO_Spedizione_Note";
            this.CellaSpedizione_Note.HeaderText = "AO_Spedizione_Note";
            this.CellaSpedizione_Note.Name = "CellaSpedizione_Note";
            this.CellaSpedizione_Note.Visible = false;
            // 
            // CellaVendita
            // 
            this.CellaVendita.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.CellaVendita.DataPropertyName = "AO_Vendita";
            this.CellaVendita.HeaderText = "Vendita";
            this.CellaVendita.Name = "CellaVendita";
            this.CellaVendita.ReadOnly = true;
            this.CellaVendita.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.CellaVendita.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.CellaVendita.Width = 69;
            // 
            // CellaVendita_Note
            // 
            this.CellaVendita_Note.DataPropertyName = "AO_Vendita_Note";
            this.CellaVendita_Note.HeaderText = "AO_Vendita_Note";
            this.CellaVendita_Note.Name = "CellaVendita_Note";
            this.CellaVendita_Note.Visible = false;
            // 
            // distintaBaseDataGridViewTextBoxColumn
            // 
            this.distintaBaseDataGridViewTextBoxColumn.DataPropertyName = "Distinta_Base";
            this.distintaBaseDataGridViewTextBoxColumn.HeaderText = "Distinta_Base";
            this.distintaBaseDataGridViewTextBoxColumn.Name = "distintaBaseDataGridViewTextBoxColumn";
            this.distintaBaseDataGridViewTextBoxColumn.ReadOnly = true;
            this.distintaBaseDataGridViewTextBoxColumn.Visible = false;
            // 
            // qtamontaggioDataGridViewTextBoxColumn
            // 
            this.qtamontaggioDataGridViewTextBoxColumn.DataPropertyName = "qta_montaggio";
            this.qtamontaggioDataGridViewTextBoxColumn.HeaderText = "qta_montaggio";
            this.qtamontaggioDataGridViewTextBoxColumn.Name = "qtamontaggioDataGridViewTextBoxColumn";
            this.qtamontaggioDataGridViewTextBoxColumn.Visible = false;
            // 
            // qtacollaudoconfezionamentoDataGridViewTextBoxColumn
            // 
            this.qtacollaudoconfezionamentoDataGridViewTextBoxColumn.DataPropertyName = "qta_collaudoconfezionamento";
            this.qtacollaudoconfezionamentoDataGridViewTextBoxColumn.HeaderText = "qta_collaudoconfezionamento";
            this.qtacollaudoconfezionamentoDataGridViewTextBoxColumn.Name = "qtacollaudoconfezionamentoDataGridViewTextBoxColumn";
            this.qtacollaudoconfezionamentoDataGridViewTextBoxColumn.Visible = false;
            // 
            // qtavenditaDataGridViewTextBoxColumn
            // 
            this.qtavenditaDataGridViewTextBoxColumn.DataPropertyName = "qta_vendita";
            this.qtavenditaDataGridViewTextBoxColumn.HeaderText = "qta_vendita";
            this.qtavenditaDataGridViewTextBoxColumn.Name = "qtavenditaDataGridViewTextBoxColumn";
            this.qtavenditaDataGridViewTextBoxColumn.Visible = false;
            // 
            // UC_Avanzamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1043, 579);
            this.Controls.Add(this.gv_Commesse);
            this.Name = "UC_Avanzamento";
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "Sistematica - Avanzamento Commesse";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.UC_Avanzamento_FormClosing);
            this.Load += new System.EventHandler(this.UC_Avanzamento_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gv_Commesse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFCommesseAperteCLSLBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroGrid gv_Commesse;
        private ds_SL ds_SL;
        private System.Windows.Forms.BindingSource sFCommesseAperteCLSLBindingSource;
        private ds_SLTableAdapters.SF_CommesseAperte_CL_SLTableAdapter sF_CommesseAperte_CL_SLTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn entitaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tIPOORDINEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dATAORDINEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nUMEROORDINEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nUMERORIGADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn codAnagraficoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dATACONFERMACONSEGNADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sortDataConsegnaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn RagioneSociale;
        private System.Windows.Forms.DataGridViewTextBoxColumn nazioneFiscaleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Commessa;
        private System.Windows.Forms.DataGridViewTextBoxColumn cOMMESSASHORTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Articolo;
        private System.Windows.Forms.DataGridViewTextBoxColumn uMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pREZZOUNITARIODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qTAORDINATADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qTASPEDITADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn CellaQtaInevasa;
        private System.Windows.Forms.DataGridViewTextBoxColumn iMPORTODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iMPORTOEVASODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iMPORTODAEVADEREDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn meseConsegnaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomeMeseConsegnaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn annoConsegnaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn commessaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewImageColumn CellaProgrammazione;
        private System.Windows.Forms.DataGridViewComboBoxColumn CellaProgrammazione_cmbox;
        private System.Windows.Forms.DataGridViewTextBoxColumn CellaProgrammazione_Note;
        private System.Windows.Forms.DataGridViewImageColumn CellaMontaggio;
        private System.Windows.Forms.DataGridViewTextBoxColumn CellaMontaggio_Note;
        private System.Windows.Forms.DataGridViewImageColumn CellaCollConf;
        private System.Windows.Forms.DataGridViewTextBoxColumn CellaCollConf_Note;
        private System.Windows.Forms.DataGridViewImageColumn CellaSpedizione;
        private System.Windows.Forms.DataGridViewTextBoxColumn CellaSpedizione_Note;
        private System.Windows.Forms.DataGridViewImageColumn CellaVendita;
        private System.Windows.Forms.DataGridViewTextBoxColumn CellaVendita_Note;
        private System.Windows.Forms.DataGridViewTextBoxColumn distintaBaseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtamontaggioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtacollaudoconfezionamentoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtavenditaDataGridViewTextBoxColumn;
    }
}