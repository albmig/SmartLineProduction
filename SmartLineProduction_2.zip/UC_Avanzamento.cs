﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using SmartLineProduction.Properties;
using System.Data.SqlTypes;
using MetroFramework;

namespace SmartLineProduction
{
    public partial class UC_Avanzamento : MetroFramework.Forms.MetroForm
    {
        public UC_Avanzamento()
        {
            InitializeComponent();
        }

        private void UC_Avanzamento_Load(object sender, EventArgs e)
        {
            GVar.formclosing = false;

            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_CommesseAperte_CL_SL'. È possibile spostarla o rimuoverla se necessario.
            this.sF_CommesseAperte_CL_SLTableAdapter.Fill(this.ds_SL.SF_CommesseAperte_CL_SL);

            gv_Commesse.Sort(sortDataConsegnaDataGridViewTextBoxColumn, ListSortDirection.Ascending);

        }

        private void gv_Commesse_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value == null) { return; }
            if (GVar.formclosing) { return; }

            DataGridViewCell cell = this.gv_Commesse.Rows[e.RowIndex].Cells[e.ColumnIndex];
            DataGridViewRow gridRow = gv_Commesse.Rows[e.RowIndex];
            //Disegno cella Programmazione
            if ((gv_Commesse.Columns[e.ColumnIndex].Name == "CellaProgrammazione") && (e.Value != null))
            {
                int valore = (int)e.Value;

                cell.ToolTipText = gridRow.Cells["CellaProgrammazione_Note"].Value.ToString();
                if ((cell.ToolTipText != "") && (cell.ToolTipText != null))
                {
                    //presenti note
                    if (valore == 0)
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Programma_Enable_nota");
                    }
                    else
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Programma_Disable_nota");
                    }
                }
                else
                {
                    if (valore == 0)
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Programma_Enable");
                    }
                    else
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Programma_Disable");
                    }
                }

            }
            //Disegno cella Montaggio
            if ((gv_Commesse.Columns[e.ColumnIndex].Name == "CellaMontaggio") && (e.Value != null))
            {
                int valore = (int)e.Value;

                cell.ToolTipText = gridRow.Cells["CellaMontaggio_Note"].Value.ToString();
                if ((cell.ToolTipText != "") && (cell.ToolTipText != null))
                {
                    //presenti note
                    if (valore == 0)
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Montaggio_Enable_nota");
                    }
                    else
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Montaggio_Disable_nota");
                    }
                }
                else
                {
                    if (valore == 0)
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Montaggio_Enable");
                    }
                    else
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Montaggio_Disable");
                    }
                }

            }
            //Disegno cella CollaudoConfezionamento
            if ((gv_Commesse.Columns[e.ColumnIndex].Name == "CellaCollConf") && (e.Value != null))
            {
                int valore = (int)e.Value;

                cell.ToolTipText = gridRow.Cells["CellaCollConf_Note"].Value.ToString();
                if ((cell.ToolTipText != "") && (cell.ToolTipText != null))
                {
                    //presenti note
                    if (valore == 0)
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Pack_Enable_nota");
                    }
                    else
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Pack_Disable_nota");
                    }
                }
                else
                {
                    if (valore == 0)
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Pack_Enable");
                    }
                    else
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Pack_Disable");
                    }
                }

            }
            //Disegno cella Spedizione
            if ((gv_Commesse.Columns[e.ColumnIndex].Name == "CellaSpedizione") && (e.Value != null))
            {
                int valore = (int)e.Value;

                cell.ToolTipText = gridRow.Cells["CellaSpedizione_Note"].Value.ToString();
                if ((cell.ToolTipText != "") && (cell.ToolTipText != null))
                {
                    //presenti note
                    if (valore == 0)
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Ship_Enable_nota");
                    }
                    else
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Ship_Disable_nota");
                    }
                }
                else
                {
                    if (valore == 0)
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Ship_Enable");
                    }
                    else
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Ship_Disable");
                    }
                }

            }
            //Disegno cella Vendita
            if ((gv_Commesse.Columns[e.ColumnIndex].Name == "CellaVendita") && (e.Value != null))
            {
                int valore = (int)e.Value;

                cell.ToolTipText = gridRow.Cells["CellaVendita_Note"].Value.ToString();
                if ((cell.ToolTipText != "") && (cell.ToolTipText != null))
                {
                    //presenti note
                    if (valore == 0)
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Doc_Enable_nota");
                    }
                    else
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Doc_Disable_nota");
                    }
                }
                else
                {
                    if (valore == 0)
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Doc_Enable");
                    }
                    else
                    {
                        e.Value = Resources.ResourceManager.GetObject("Icona_AV_Doc_Disable");
                    }
                }

            }
        }

        private void gv_Commesse_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (GVar.formclosing) { return; }

            foreach (DataGridViewRow x in gv_Commesse.Rows)
            {
                x.MinimumHeight = 50;
            }
        }

        private void UC_Avanzamento_FormClosing(object sender, FormClosingEventArgs e)
        {
            GVar.formclosing = true;
        }

        private void gv_Commesse_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            //Tenere così
        }

        private void gv_Commesse_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            //DataGridViewRow gridRow = gv_Commesse.Rows[e.RowIndex];

            //DataGridViewComboBoxCell comboProgramma = (DataGridViewComboBoxCell)gridRow.Cells["QtaProgramma"];

            //if (comboProgramma!= null)
            //{
            //    int qtadaev = Convert.ToInt32(gridRow.Cells["CellaQtaInevasa"].Value);
            //    comboProgramma.Items.Clear();
            //    for (int i = 0; i <= qtadaev; i++)
            //    {
            //        comboProgramma.Items.Add(i);
            //    }
            //}
        }

        private void gv_Commesse_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            var senderGrid = (DataGridView)sender;
            DataGridViewRow gridRow = gv_Commesse.Rows[e.RowIndex];
            GVar.gl_commessa = gridRow.Cells["Commessa"].Value.ToString();
            GVar.gl_ragsoc = gridRow.Cells["RagioneSociale"].Value.ToString();
            GVar.gl_articolo = gridRow.Cells["Articolo"].Value.ToString();
            GVar.gl_qtaevadere = Convert.ToInt32(gridRow.Cells["CellaQtaInevasa"].Value);

            if (senderGrid.Columns[e.ColumnIndex] is DataGridViewImageColumn && e.RowIndex >= 0)
            {
                if (e.ColumnIndex == gv_Commesse.Columns["CellaProgrammazione"].Index && e.RowIndex >= 0)
                {
                    if ((int)gridRow.Cells["CellaProgrammazione"].Value == 0)
                    {
                        GVar.gl_note = gridRow.Cells["CellaProgrammazione_Note"].Value.ToString();
                        UC_AV_Programmazione uC_AV_Programmazione = new UC_AV_Programmazione();
                        uC_AV_Programmazione.Show();
                    }
                }

                if (e.ColumnIndex == gv_Commesse.Columns["CellaMontaggio"].Index && e.RowIndex >= 0)
                {
                    if ((int)gridRow.Cells["CellaMontaggio"].Value == 0)
                    {
                        GVar.gl_note = gridRow.Cells["CellaMontaggio_Note"].Value.ToString();
                        UC_AV_Montaggio uC_AV_Montaggio = new UC_AV_Montaggio();
                        uC_AV_Montaggio.Show();
                    }
                }

                if (e.ColumnIndex == gv_Commesse.Columns["CellaCollConf"].Index && e.RowIndex >= 0)
                {
                    if ((int)gridRow.Cells["CellaCollConf"].Value == 0)
                    {
                        GVar.gl_note = gridRow.Cells["CellaCollConf_Note"].Value.ToString();
                        UC_AV_CollConf uC_AV_CollConf = new UC_AV_CollConf();
                        uC_AV_CollConf.Show();
                    }
                }
                if (e.ColumnIndex == gv_Commesse.Columns["CellaSpedizione"].Index && e.RowIndex >= 0)
                {
                    if ((int)gridRow.Cells["CellaSpedizione"].Value == 0)
                    {
                        GVar.gl_note = gridRow.Cells["CellaCollConf_Note"].Value.ToString();
                        UC_AV_Spedizioni uC_AV_Spedizioni = new UC_AV_Spedizioni();
                        uC_AV_Spedizioni.Show();
                    }
                }
                if (e.ColumnIndex == gv_Commesse.Columns["CellaVendita"].Index && e.RowIndex >= 0)
                {
                    if ((int)gridRow.Cells["CellaVendita"].Value == 0)
                    {
                        GVar.gl_note = gridRow.Cells["CellaVendita_Note"].Value.ToString();
                        UC_AV_Vendite uC_AV_Vendite = new UC_AV_Vendite();
                        uC_AV_Vendite.Show();
                    }
                }
            }
        }
    }
}
