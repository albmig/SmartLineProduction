﻿namespace SmartLineProduction
{
    partial class UC_Quality
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Quality));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.layout_orizz_menu = new System.Windows.Forms.TableLayoutPanel();
            this.pan_Menu_salva = new System.Windows.Forms.MenuStrip();
            this.menu_sw_salva = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_sw_div12 = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_sw_annulla = new System.Windows.Forms.ToolStripMenuItem();
            this.pan_Menu_comandi = new System.Windows.Forms.MenuStrip();
            this.menu_new = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_div01 = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_edit = new System.Windows.Forms.ToolStripMenuItem();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.panel_fattibilita = new MetroFramework.Controls.MetroPanel();
            this.layout_Schede = new System.Windows.Forms.TableLayoutPanel();
            this.tb_rev = new MetroFramework.Controls.MetroTextBox();
            this.dtQualityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.tb_vers = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.tb_folder = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.lab_Codice = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.lab_class = new MetroFramework.Controls.MetroLabel();
            this.dtQualityClassificationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cb_class = new System.Windows.Forms.ComboBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.lab_MyIp = new MetroFramework.Controls.MetroLabel();
            this.lab_type = new MetroFramework.Controls.MetroLabel();
            this.dtQualityTipoDocBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lab_org = new MetroFramework.Controls.MetroLabel();
            this.dtQualityCompanyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lab_projprodarea = new MetroFramework.Controls.MetroLabel();
            this.dtQualityProjProdAreaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.cb_org = new System.Windows.Forms.ComboBox();
            this.cb_projprodarea = new System.Windows.Forms.ComboBox();
            this.cb_User = new System.Windows.Forms.ComboBox();
            this.usersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.tb_desClass = new MetroFramework.Controls.MetroTextBox();
            this.panel_grid = new MetroFramework.Controls.MetroPanel();
            this.gv_Quality = new MetroFramework.Controls.MetroGrid();
            this.codiceQualityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qualDesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qualProjProdAreaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qualOrgDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qualTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qualClassDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qualProgDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qualVerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qualRevDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qualPathDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qualRichiedenteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qualDateRequestDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qualIPRequestDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tb_Des = new MetroFramework.Controls.MetroTextBox();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colQual_ProjProdArea = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colQual_Org = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colQual_Type = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colQual_Class = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colQual_Prog = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colQual_Ver = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colQual_Rev = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colQual_Des = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colQual_Path = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colQual_Richiedente = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colQual_DateRequest = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colQual_IPRequest = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCodice_Quality = new DevExpress.XtraGrid.Columns.GridColumn();
            this.dt_Quality_ProjProdAreaTableAdapter = new SmartLineProduction.ds_SLTableAdapters.dt_Quality_ProjProdAreaTableAdapter();
            this.dt_Quality_CompanyTableAdapter = new SmartLineProduction.ds_SLTableAdapters.dt_Quality_CompanyTableAdapter();
            this.dt_Quality_TipoDocTableAdapter = new SmartLineProduction.ds_SLTableAdapters.dt_Quality_TipoDocTableAdapter();
            this.usersTableAdapter = new SmartLineProduction.ds_SLTableAdapters.UsersTableAdapter();
            this.dt_Quality_ClassificationTableAdapter = new SmartLineProduction.ds_SLTableAdapters.dt_Quality_ClassificationTableAdapter();
            this.dt_QualityTableAdapter = new SmartLineProduction.ds_SLTableAdapters.dt_QualityTableAdapter();
            this.layout_orizz_menu.SuspendLayout();
            this.pan_Menu_salva.SuspendLayout();
            this.pan_Menu_comandi.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            this.panel_fattibilita.SuspendLayout();
            this.layout_Schede.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtQualityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtQualityClassificationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtQualityTipoDocBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtQualityCompanyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtQualityProjProdAreaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).BeginInit();
            this.panel_grid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Quality)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // layout_orizz_menu
            // 
            this.layout_orizz_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.ColumnCount = 10;
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_salva, 6, 0);
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_comandi, 0, 0);
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_exit, 10, 0);
            this.layout_orizz_menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_orizz_menu.Location = new System.Drawing.Point(20, 30);
            this.layout_orizz_menu.Name = "layout_orizz_menu";
            this.layout_orizz_menu.RowCount = 1;
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_orizz_menu.Size = new System.Drawing.Size(960, 25);
            this.layout_orizz_menu.TabIndex = 125;
            // 
            // pan_Menu_salva
            // 
            this.pan_Menu_salva.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pan_Menu_salva.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.SetColumnSpan(this.pan_Menu_salva, 2);
            this.pan_Menu_salva.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_salva.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_salva,
            this.menu_sw_div12,
            this.menu_sw_annulla});
            this.pan_Menu_salva.Location = new System.Drawing.Point(588, 0);
            this.pan_Menu_salva.Name = "pan_Menu_salva";
            this.pan_Menu_salva.Size = new System.Drawing.Size(168, 24);
            this.pan_Menu_salva.TabIndex = 86;
            this.pan_Menu_salva.Text = "menuStrip1";
            // 
            // menu_sw_salva
            // 
            this.menu_sw_salva.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_salva.Image")));
            this.menu_sw_salva.Name = "menu_sw_salva";
            this.menu_sw_salva.Size = new System.Drawing.Size(62, 20);
            this.menu_sw_salva.Text = "Salva";
            this.menu_sw_salva.Click += new System.EventHandler(this.menu_sw_salva_Click);
            // 
            // menu_sw_div12
            // 
            this.menu_sw_div12.Enabled = false;
            this.menu_sw_div12.Name = "menu_sw_div12";
            this.menu_sw_div12.ShowShortcutKeys = false;
            this.menu_sw_div12.Size = new System.Drawing.Size(22, 20);
            this.menu_sw_div12.Text = "|";
            // 
            // menu_sw_annulla
            // 
            this.menu_sw_annulla.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_annulla.Image")));
            this.menu_sw_annulla.Name = "menu_sw_annulla";
            this.menu_sw_annulla.Size = new System.Drawing.Size(76, 20);
            this.menu_sw_annulla.Text = "Annulla";
            this.menu_sw_annulla.Click += new System.EventHandler(this.menu_sw_annulla_Click);
            // 
            // pan_Menu_comandi
            // 
            this.pan_Menu_comandi.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.SetColumnSpan(this.pan_Menu_comandi, 5);
            this.pan_Menu_comandi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_Menu_comandi.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_new,
            this.menu_div01,
            this.menu_edit});
            this.pan_Menu_comandi.Location = new System.Drawing.Point(0, 0);
            this.pan_Menu_comandi.Name = "pan_Menu_comandi";
            this.pan_Menu_comandi.Size = new System.Drawing.Size(480, 25);
            this.pan_Menu_comandi.TabIndex = 85;
            this.pan_Menu_comandi.Text = "menuStrip1";
            // 
            // menu_new
            // 
            this.menu_new.Image = ((System.Drawing.Image)(resources.GetObject("menu_new.Image")));
            this.menu_new.Name = "menu_new";
            this.menu_new.Size = new System.Drawing.Size(111, 21);
            this.menu_new.Text = "Nuovo Codice";
            this.menu_new.Click += new System.EventHandler(this.menu_new_Click);
            // 
            // menu_div01
            // 
            this.menu_div01.Enabled = false;
            this.menu_div01.Name = "menu_div01";
            this.menu_div01.Size = new System.Drawing.Size(22, 21);
            this.menu_div01.Text = "|";
            // 
            // menu_edit
            // 
            this.menu_edit.Image = ((System.Drawing.Image)(resources.GetObject("menu_edit.Image")));
            this.menu_edit.Name = "menu_edit";
            this.menu_edit.Size = new System.Drawing.Size(122, 21);
            this.menu_edit.Text = "Modifica Codice";
            this.menu_edit.Click += new System.EventHandler(this.menu_edit_Click);
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Gainsboro;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(885, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(75, 24);
            this.pan_Menu_exit.TabIndex = 82;
            this.pan_Menu_exit.Text = "menuStrip1";
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            this.menu_sw_exit.Click += new System.EventHandler(this.menu_sw_exit_Click);
            // 
            // panel_fattibilita
            // 
            this.panel_fattibilita.Controls.Add(this.layout_Schede);
            this.panel_fattibilita.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_fattibilita.HorizontalScrollbarBarColor = true;
            this.panel_fattibilita.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_fattibilita.HorizontalScrollbarSize = 10;
            this.panel_fattibilita.Location = new System.Drawing.Point(20, 55);
            this.panel_fattibilita.Name = "panel_fattibilita";
            this.panel_fattibilita.Size = new System.Drawing.Size(960, 425);
            this.panel_fattibilita.TabIndex = 126;
            this.panel_fattibilita.VerticalScrollbarBarColor = true;
            this.panel_fattibilita.VerticalScrollbarHighlightOnWheel = false;
            this.panel_fattibilita.VerticalScrollbarSize = 10;
            // 
            // layout_Schede
            // 
            this.layout_Schede.ColumnCount = 8;
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.Controls.Add(this.tb_rev, 1, 15);
            this.layout_Schede.Controls.Add(this.metroLabel14, 0, 15);
            this.layout_Schede.Controls.Add(this.tb_vers, 1, 14);
            this.layout_Schede.Controls.Add(this.metroLabel13, 0, 14);
            this.layout_Schede.Controls.Add(this.tb_folder, 1, 13);
            this.layout_Schede.Controls.Add(this.metroLabel12, 0, 13);
            this.layout_Schede.Controls.Add(this.lab_Codice, 1, 11);
            this.layout_Schede.Controls.Add(this.metroLabel11, 0, 11);
            this.layout_Schede.Controls.Add(this.metroLabel10, 0, 12);
            this.layout_Schede.Controls.Add(this.lab_class, 7, 4);
            this.layout_Schede.Controls.Add(this.cb_class, 5, 4);
            this.layout_Schede.Controls.Add(this.metroLabel5, 4, 4);
            this.layout_Schede.Controls.Add(this.lab_MyIp, 7, 0);
            this.layout_Schede.Controls.Add(this.lab_type, 7, 3);
            this.layout_Schede.Controls.Add(this.lab_org, 7, 2);
            this.layout_Schede.Controls.Add(this.lab_projprodarea, 7, 1);
            this.layout_Schede.Controls.Add(this.cb_type, 5, 3);
            this.layout_Schede.Controls.Add(this.cb_org, 5, 2);
            this.layout_Schede.Controls.Add(this.cb_projprodarea, 5, 1);
            this.layout_Schede.Controls.Add(this.cb_User, 5, 0);
            this.layout_Schede.Controls.Add(this.metroLabel4, 4, 3);
            this.layout_Schede.Controls.Add(this.metroLabel3, 4, 2);
            this.layout_Schede.Controls.Add(this.metroLabel1, 4, 1);
            this.layout_Schede.Controls.Add(this.metroLabel2, 4, 0);
            this.layout_Schede.Controls.Add(this.tb_desClass, 5, 5);
            this.layout_Schede.Controls.Add(this.panel_grid, 0, 0);
            this.layout_Schede.Controls.Add(this.tb_Des, 1, 12);
            this.layout_Schede.Controls.Add(this.gridControl1, 3, 14);
            this.layout_Schede.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Schede.Location = new System.Drawing.Point(0, 0);
            this.layout_Schede.Name = "layout_Schede";
            this.layout_Schede.RowCount = 20;
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.Size = new System.Drawing.Size(960, 425);
            this.layout_Schede.TabIndex = 123;
            // 
            // tb_rev
            // 
            this.tb_rev.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            // 
            // 
            // 
            this.tb_rev.CustomButton.Image = null;
            this.tb_rev.CustomButton.Location = new System.Drawing.Point(100, 1);
            this.tb_rev.CustomButton.Name = "";
            this.tb_rev.CustomButton.Size = new System.Drawing.Size(13, 13);
            this.tb_rev.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_rev.CustomButton.TabIndex = 1;
            this.tb_rev.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_rev.CustomButton.UseSelectable = true;
            this.tb_rev.CustomButton.Visible = false;
            this.tb_rev.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dtQualityBindingSource, "Qual_Rev", true));
            this.tb_rev.Lines = new string[] {
        "tb_rev"};
            this.tb_rev.Location = new System.Drawing.Point(123, 318);
            this.tb_rev.MaxLength = 32767;
            this.tb_rev.Name = "tb_rev";
            this.tb_rev.PasswordChar = '\0';
            this.tb_rev.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_rev.SelectedText = "";
            this.tb_rev.SelectionLength = 0;
            this.tb_rev.SelectionStart = 0;
            this.tb_rev.ShortcutsEnabled = true;
            this.tb_rev.Size = new System.Drawing.Size(114, 15);
            this.tb_rev.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_rev.TabIndex = 8;
            this.tb_rev.Text = "tb_rev";
            this.tb_rev.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tb_rev.UseSelectable = true;
            this.tb_rev.UseStyleColors = true;
            this.tb_rev.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_rev.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tb_rev.Leave += new System.EventHandler(this.tb_rev_Leave);
            // 
            // dtQualityBindingSource
            // 
            this.dtQualityBindingSource.DataMember = "dt_Quality";
            this.dtQualityBindingSource.DataSource = this.ds_SL;
            this.dtQualityBindingSource.Sort = "Qual_ProjProdArea asc, Qual_Org asc, Qual_Type asc";
            this.dtQualityBindingSource.CurrentChanged += new System.EventHandler(this.dtQualityBindingSource_CurrentChanged);
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // metroLabel14
            // 
            this.metroLabel14.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel14.Location = new System.Drawing.Point(3, 316);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(73, 19);
            this.metroLabel14.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel14.TabIndex = 31;
            this.metroLabel14.Text = "Revisione :";
            this.metroLabel14.UseStyleColors = true;
            // 
            // tb_vers
            // 
            this.tb_vers.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            // 
            // 
            // 
            this.tb_vers.CustomButton.Image = null;
            this.tb_vers.CustomButton.Location = new System.Drawing.Point(100, 1);
            this.tb_vers.CustomButton.Name = "";
            this.tb_vers.CustomButton.Size = new System.Drawing.Size(13, 13);
            this.tb_vers.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_vers.CustomButton.TabIndex = 1;
            this.tb_vers.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_vers.CustomButton.UseSelectable = true;
            this.tb_vers.CustomButton.Visible = false;
            this.tb_vers.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dtQualityBindingSource, "Qual_Ver", true));
            this.tb_vers.Lines = new string[] {
        "tb_vers"};
            this.tb_vers.Location = new System.Drawing.Point(123, 297);
            this.tb_vers.MaxLength = 32767;
            this.tb_vers.Name = "tb_vers";
            this.tb_vers.PasswordChar = '\0';
            this.tb_vers.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_vers.SelectedText = "";
            this.tb_vers.SelectionLength = 0;
            this.tb_vers.SelectionStart = 0;
            this.tb_vers.ShortcutsEnabled = true;
            this.tb_vers.Size = new System.Drawing.Size(114, 15);
            this.tb_vers.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_vers.TabIndex = 7;
            this.tb_vers.Text = "tb_vers";
            this.tb_vers.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tb_vers.UseSelectable = true;
            this.tb_vers.UseStyleColors = true;
            this.tb_vers.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_vers.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tb_vers.Leave += new System.EventHandler(this.tb_vers_Leave);
            // 
            // metroLabel13
            // 
            this.metroLabel13.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel13.Location = new System.Drawing.Point(3, 295);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(68, 19);
            this.metroLabel13.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel13.TabIndex = 29;
            this.metroLabel13.Text = "Versione :";
            this.metroLabel13.UseStyleColors = true;
            // 
            // tb_folder
            // 
            this.layout_Schede.SetColumnSpan(this.tb_folder, 7);
            // 
            // 
            // 
            this.tb_folder.CustomButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tb_folder.CustomButton.Image = global::SmartLineProduction.Properties.Resources.Lente;
            this.tb_folder.CustomButton.Location = new System.Drawing.Point(820, 1);
            this.tb_folder.CustomButton.Name = "";
            this.tb_folder.CustomButton.Size = new System.Drawing.Size(13, 13);
            this.tb_folder.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_folder.CustomButton.TabIndex = 1;
            this.tb_folder.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_folder.CustomButton.UseSelectable = true;
            this.tb_folder.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dtQualityBindingSource, "Qual_Path", true));
            this.tb_folder.DisplayIcon = true;
            this.tb_folder.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_folder.Lines = new string[] {
        "metroTextBox2"};
            this.tb_folder.Location = new System.Drawing.Point(123, 276);
            this.tb_folder.MaxLength = 32767;
            this.tb_folder.Name = "tb_folder";
            this.tb_folder.PasswordChar = '\0';
            this.tb_folder.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_folder.SelectedText = "";
            this.tb_folder.SelectionLength = 0;
            this.tb_folder.SelectionStart = 0;
            this.tb_folder.ShortcutsEnabled = true;
            this.tb_folder.ShowButton = true;
            this.tb_folder.Size = new System.Drawing.Size(834, 15);
            this.tb_folder.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_folder.TabIndex = 6;
            this.tb_folder.Text = "metroTextBox2";
            this.tb_folder.UseSelectable = true;
            this.tb_folder.UseStyleColors = true;
            this.tb_folder.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_folder.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tb_folder.ButtonClick += new MetroFramework.Controls.MetroTextBox.ButClick(this.tb_folder_ButtonClick);
            // 
            // metroLabel12
            // 
            this.metroLabel12.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel12.Location = new System.Drawing.Point(3, 274);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(114, 19);
            this.metroLabel12.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel12.TabIndex = 27;
            this.metroLabel12.Text = "Cartella di riferimento :";
            this.metroLabel12.UseStyleColors = true;
            // 
            // lab_Codice
            // 
            this.lab_Codice.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lab_Codice.AutoSize = true;
            this.layout_Schede.SetColumnSpan(this.lab_Codice, 2);
            this.lab_Codice.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dtQualityBindingSource, "Codice_Quality", true));
            this.lab_Codice.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_Codice.Location = new System.Drawing.Point(123, 232);
            this.lab_Codice.Name = "lab_Codice";
            this.lab_Codice.Size = new System.Drawing.Size(115, 19);
            this.lab_Codice.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_Codice.TabIndex = 26;
            this.lab_Codice.Text = "Codice Qualità :";
            this.lab_Codice.UseStyleColors = true;
            // 
            // metroLabel11
            // 
            this.metroLabel11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel11.Location = new System.Drawing.Point(3, 232);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(105, 19);
            this.metroLabel11.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel11.TabIndex = 24;
            this.metroLabel11.Text = "Codice Qualità :";
            this.metroLabel11.UseStyleColors = true;
            // 
            // metroLabel10
            // 
            this.metroLabel10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel10.Location = new System.Drawing.Point(3, 253);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(85, 19);
            this.metroLabel10.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel10.TabIndex = 22;
            this.metroLabel10.Text = "Descrizione :";
            this.metroLabel10.UseStyleColors = true;
            // 
            // lab_class
            // 
            this.lab_class.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab_class.AutoSize = true;
            this.lab_class.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dtQualityClassificationBindingSource, "Qual_Codice", true));
            this.lab_class.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_class.Location = new System.Drawing.Point(873, 85);
            this.lab_class.Name = "lab_class";
            this.lab_class.Size = new System.Drawing.Size(54, 19);
            this.lab_class.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_class.TabIndex = 21;
            this.lab_class.Text = "Utente:";
            this.lab_class.UseStyleColors = true;
            // 
            // dtQualityClassificationBindingSource
            // 
            this.dtQualityClassificationBindingSource.DataMember = "dt_Quality_Classification";
            this.dtQualityClassificationBindingSource.DataSource = this.ds_SL;
            this.dtQualityClassificationBindingSource.CurrentChanged += new System.EventHandler(this.dtQualityClassificationBindingSource_CurrentChanged);
            // 
            // cb_class
            // 
            this.cb_class.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.layout_Schede.SetColumnSpan(this.cb_class, 2);
            this.cb_class.DataSource = this.dtQualityClassificationBindingSource;
            this.cb_class.DisplayMember = "Qual_Des";
            this.cb_class.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cb_class.FormattingEnabled = true;
            this.cb_class.Location = new System.Drawing.Point(603, 87);
            this.cb_class.Name = "cb_class";
            this.cb_class.Size = new System.Drawing.Size(234, 23);
            this.cb_class.TabIndex = 4;
            // 
            // metroLabel5
            // 
            this.metroLabel5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel5.Location = new System.Drawing.Point(483, 85);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(94, 19);
            this.metroLabel5.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel5.TabIndex = 18;
            this.metroLabel5.Text = "Classification :";
            this.metroLabel5.UseStyleColors = true;
            // 
            // lab_MyIp
            // 
            this.lab_MyIp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab_MyIp.AutoSize = true;
            this.lab_MyIp.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_MyIp.Location = new System.Drawing.Point(873, 1);
            this.lab_MyIp.Name = "lab_MyIp";
            this.lab_MyIp.Size = new System.Drawing.Size(54, 19);
            this.lab_MyIp.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_MyIp.TabIndex = 16;
            this.lab_MyIp.Text = "Utente:";
            this.lab_MyIp.UseStyleColors = true;
            this.lab_MyIp.Visible = false;
            // 
            // lab_type
            // 
            this.lab_type.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab_type.AutoSize = true;
            this.lab_type.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dtQualityTipoDocBindingSource, "Qual_Codice", true));
            this.lab_type.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_type.Location = new System.Drawing.Point(873, 64);
            this.lab_type.Name = "lab_type";
            this.lab_type.Size = new System.Drawing.Size(54, 19);
            this.lab_type.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_type.TabIndex = 15;
            this.lab_type.Text = "Utente:";
            this.lab_type.UseStyleColors = true;
            // 
            // dtQualityTipoDocBindingSource
            // 
            this.dtQualityTipoDocBindingSource.DataMember = "dt_Quality_TipoDoc";
            this.dtQualityTipoDocBindingSource.DataSource = this.ds_SL;
            this.dtQualityTipoDocBindingSource.CurrentChanged += new System.EventHandler(this.dtQualityTipoDocBindingSource_CurrentChanged);
            // 
            // lab_org
            // 
            this.lab_org.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab_org.AutoSize = true;
            this.lab_org.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dtQualityCompanyBindingSource, "Qual_Codice", true));
            this.lab_org.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_org.Location = new System.Drawing.Point(873, 43);
            this.lab_org.Name = "lab_org";
            this.lab_org.Size = new System.Drawing.Size(54, 19);
            this.lab_org.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_org.TabIndex = 14;
            this.lab_org.Text = "Utente:";
            this.lab_org.UseStyleColors = true;
            // 
            // dtQualityCompanyBindingSource
            // 
            this.dtQualityCompanyBindingSource.DataMember = "dt_Quality_Company";
            this.dtQualityCompanyBindingSource.DataSource = this.ds_SL;
            this.dtQualityCompanyBindingSource.CurrentChanged += new System.EventHandler(this.dtQualityCompanyBindingSource_CurrentChanged);
            // 
            // lab_projprodarea
            // 
            this.lab_projprodarea.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab_projprodarea.AutoSize = true;
            this.lab_projprodarea.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dtQualityProjProdAreaBindingSource, "Qual_Codice", true));
            this.lab_projprodarea.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_projprodarea.Location = new System.Drawing.Point(873, 22);
            this.lab_projprodarea.Name = "lab_projprodarea";
            this.lab_projprodarea.Size = new System.Drawing.Size(54, 19);
            this.lab_projprodarea.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_projprodarea.TabIndex = 13;
            this.lab_projprodarea.Text = "Utente:";
            this.lab_projprodarea.UseStyleColors = true;
            // 
            // dtQualityProjProdAreaBindingSource
            // 
            this.dtQualityProjProdAreaBindingSource.DataMember = "dt_Quality_ProjProdArea";
            this.dtQualityProjProdAreaBindingSource.DataSource = this.ds_SL;
            this.dtQualityProjProdAreaBindingSource.CurrentChanged += new System.EventHandler(this.dtQualityProjProdAreaBindingSource_CurrentChanged);
            // 
            // cb_type
            // 
            this.cb_type.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.layout_Schede.SetColumnSpan(this.cb_type, 2);
            this.cb_type.DataSource = this.dtQualityTipoDocBindingSource;
            this.cb_type.DisplayMember = "Qual_Des";
            this.cb_type.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Location = new System.Drawing.Point(603, 66);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(234, 23);
            this.cb_type.TabIndex = 3;
            // 
            // cb_org
            // 
            this.cb_org.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.layout_Schede.SetColumnSpan(this.cb_org, 2);
            this.cb_org.DataSource = this.dtQualityCompanyBindingSource;
            this.cb_org.DisplayMember = "Qual_Des";
            this.cb_org.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cb_org.FormattingEnabled = true;
            this.cb_org.Location = new System.Drawing.Point(603, 45);
            this.cb_org.Name = "cb_org";
            this.cb_org.Size = new System.Drawing.Size(234, 23);
            this.cb_org.TabIndex = 2;
            // 
            // cb_projprodarea
            // 
            this.cb_projprodarea.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.layout_Schede.SetColumnSpan(this.cb_projprodarea, 2);
            this.cb_projprodarea.DataSource = this.dtQualityProjProdAreaBindingSource;
            this.cb_projprodarea.DisplayMember = "Qual_Des";
            this.cb_projprodarea.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cb_projprodarea.FormattingEnabled = true;
            this.cb_projprodarea.Location = new System.Drawing.Point(603, 24);
            this.cb_projprodarea.Name = "cb_projprodarea";
            this.cb_projprodarea.Size = new System.Drawing.Size(234, 23);
            this.cb_projprodarea.TabIndex = 1;
            // 
            // cb_User
            // 
            this.cb_User.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.layout_Schede.SetColumnSpan(this.cb_User, 2);
            this.cb_User.DataSource = this.usersBindingSource;
            this.cb_User.DisplayMember = "UTENTE";
            this.cb_User.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_User.FormattingEnabled = true;
            this.cb_User.Location = new System.Drawing.Point(603, 3);
            this.cb_User.Name = "cb_User";
            this.cb_User.Size = new System.Drawing.Size(234, 23);
            this.cb_User.TabIndex = 0;
            // 
            // usersBindingSource
            // 
            this.usersBindingSource.DataMember = "Users";
            this.usersBindingSource.DataSource = this.ds_SL;
            this.usersBindingSource.CurrentChanged += new System.EventHandler(this.usersBindingSource_CurrentChanged);
            // 
            // metroLabel4
            // 
            this.metroLabel4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(483, 64);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(114, 19);
            this.metroLabel4.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel4.TabIndex = 7;
            this.metroLabel4.Text = "Type of document :";
            this.metroLabel4.UseStyleColors = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Location = new System.Drawing.Point(483, 43);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(95, 19);
            this.metroLabel3.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel3.TabIndex = 6;
            this.metroLabel3.Text = "Organization :";
            this.metroLabel3.UseStyleColors = true;
            // 
            // metroLabel1
            // 
            this.metroLabel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(483, 22);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(114, 19);
            this.metroLabel1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel1.TabIndex = 5;
            this.metroLabel1.Text = "Project / Product / Area :";
            this.metroLabel1.UseStyleColors = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Location = new System.Drawing.Point(483, 1);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(54, 19);
            this.metroLabel2.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel2.TabIndex = 4;
            this.metroLabel2.Text = "Utente:";
            this.metroLabel2.UseStyleColors = true;
            // 
            // tb_desClass
            // 
            this.layout_Schede.SetColumnSpan(this.tb_desClass, 3);
            // 
            // 
            // 
            this.tb_desClass.CustomButton.Image = null;
            this.tb_desClass.CustomButton.Location = new System.Drawing.Point(236, 2);
            this.tb_desClass.CustomButton.Name = "";
            this.tb_desClass.CustomButton.Size = new System.Drawing.Size(115, 115);
            this.tb_desClass.CustomButton.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_desClass.CustomButton.TabIndex = 1;
            this.tb_desClass.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_desClass.CustomButton.UseSelectable = true;
            this.tb_desClass.CustomButton.Visible = false;
            this.tb_desClass.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dtQualityClassificationBindingSource, "Qual_Note", true));
            this.tb_desClass.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_desClass.Enabled = false;
            this.tb_desClass.Lines = new string[] {
        "metroTextBox1"};
            this.tb_desClass.Location = new System.Drawing.Point(603, 108);
            this.tb_desClass.MaxLength = 32767;
            this.tb_desClass.Multiline = true;
            this.tb_desClass.Name = "tb_desClass";
            this.tb_desClass.PasswordChar = '\0';
            this.tb_desClass.ReadOnly = true;
            this.layout_Schede.SetRowSpan(this.tb_desClass, 6);
            this.tb_desClass.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tb_desClass.SelectedText = "";
            this.tb_desClass.SelectionLength = 0;
            this.tb_desClass.SelectionStart = 0;
            this.tb_desClass.ShortcutsEnabled = true;
            this.tb_desClass.Size = new System.Drawing.Size(354, 120);
            this.tb_desClass.TabIndex = 20;
            this.tb_desClass.Text = "metroTextBox1";
            this.tb_desClass.UseSelectable = true;
            this.tb_desClass.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_desClass.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // panel_grid
            // 
            this.layout_Schede.SetColumnSpan(this.panel_grid, 4);
            this.panel_grid.Controls.Add(this.gv_Quality);
            this.panel_grid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_grid.HorizontalScrollbarBarColor = true;
            this.panel_grid.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_grid.HorizontalScrollbarSize = 10;
            this.panel_grid.Location = new System.Drawing.Point(3, 3);
            this.panel_grid.Name = "panel_grid";
            this.layout_Schede.SetRowSpan(this.panel_grid, 11);
            this.panel_grid.Size = new System.Drawing.Size(474, 225);
            this.panel_grid.TabIndex = 17;
            this.panel_grid.VerticalScrollbarBarColor = true;
            this.panel_grid.VerticalScrollbarHighlightOnWheel = false;
            this.panel_grid.VerticalScrollbarSize = 10;
            // 
            // gv_Quality
            // 
            this.gv_Quality.AllowUserToAddRows = false;
            this.gv_Quality.AllowUserToDeleteRows = false;
            this.gv_Quality.AllowUserToResizeRows = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_Quality.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.gv_Quality.AutoGenerateColumns = false;
            this.gv_Quality.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Quality.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Quality.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_Quality.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Quality.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.gv_Quality.ColumnHeadersHeight = 40;
            this.gv_Quality.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.codiceQualityDataGridViewTextBoxColumn,
            this.qualDesDataGridViewTextBoxColumn,
            this.idDataGridViewTextBoxColumn,
            this.qualProjProdAreaDataGridViewTextBoxColumn,
            this.qualOrgDataGridViewTextBoxColumn,
            this.qualTypeDataGridViewTextBoxColumn,
            this.qualClassDataGridViewTextBoxColumn,
            this.qualProgDataGridViewTextBoxColumn,
            this.qualVerDataGridViewTextBoxColumn,
            this.qualRevDataGridViewTextBoxColumn,
            this.qualPathDataGridViewTextBoxColumn,
            this.qualRichiedenteDataGridViewTextBoxColumn,
            this.qualDateRequestDataGridViewTextBoxColumn,
            this.qualIPRequestDataGridViewTextBoxColumn});
            this.gv_Quality.DataSource = this.dtQualityBindingSource;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Quality.DefaultCellStyle = dataGridViewCellStyle7;
            this.gv_Quality.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Quality.EnableHeadersVisualStyles = false;
            this.gv_Quality.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Quality.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Quality.Location = new System.Drawing.Point(0, 0);
            this.gv_Quality.MultiSelect = false;
            this.gv_Quality.Name = "gv_Quality";
            this.gv_Quality.ReadOnly = true;
            this.gv_Quality.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Quality.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.gv_Quality.RowHeadersVisible = false;
            this.gv_Quality.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Quality.RowTemplate.Height = 30;
            this.gv_Quality.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Quality.Size = new System.Drawing.Size(474, 225);
            this.gv_Quality.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_Quality.TabIndex = 2;
            this.gv_Quality.UseStyleColors = true;
            // 
            // codiceQualityDataGridViewTextBoxColumn
            // 
            this.codiceQualityDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.codiceQualityDataGridViewTextBoxColumn.DataPropertyName = "Codice_Quality";
            this.codiceQualityDataGridViewTextBoxColumn.HeaderText = "Codice";
            this.codiceQualityDataGridViewTextBoxColumn.Name = "codiceQualityDataGridViewTextBoxColumn";
            this.codiceQualityDataGridViewTextBoxColumn.ReadOnly = true;
            this.codiceQualityDataGridViewTextBoxColumn.Width = 65;
            // 
            // qualDesDataGridViewTextBoxColumn
            // 
            this.qualDesDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.qualDesDataGridViewTextBoxColumn.DataPropertyName = "Qual_Des";
            this.qualDesDataGridViewTextBoxColumn.HeaderText = "Descrizione";
            this.qualDesDataGridViewTextBoxColumn.Name = "qualDesDataGridViewTextBoxColumn";
            this.qualDesDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Visible = false;
            // 
            // qualProjProdAreaDataGridViewTextBoxColumn
            // 
            this.qualProjProdAreaDataGridViewTextBoxColumn.DataPropertyName = "Qual_ProjProdArea";
            this.qualProjProdAreaDataGridViewTextBoxColumn.HeaderText = "Qual_ProjProdArea";
            this.qualProjProdAreaDataGridViewTextBoxColumn.Name = "qualProjProdAreaDataGridViewTextBoxColumn";
            this.qualProjProdAreaDataGridViewTextBoxColumn.ReadOnly = true;
            this.qualProjProdAreaDataGridViewTextBoxColumn.Visible = false;
            // 
            // qualOrgDataGridViewTextBoxColumn
            // 
            this.qualOrgDataGridViewTextBoxColumn.DataPropertyName = "Qual_Org";
            this.qualOrgDataGridViewTextBoxColumn.HeaderText = "Qual_Org";
            this.qualOrgDataGridViewTextBoxColumn.Name = "qualOrgDataGridViewTextBoxColumn";
            this.qualOrgDataGridViewTextBoxColumn.ReadOnly = true;
            this.qualOrgDataGridViewTextBoxColumn.Visible = false;
            // 
            // qualTypeDataGridViewTextBoxColumn
            // 
            this.qualTypeDataGridViewTextBoxColumn.DataPropertyName = "Qual_Type";
            this.qualTypeDataGridViewTextBoxColumn.HeaderText = "Qual_Type";
            this.qualTypeDataGridViewTextBoxColumn.Name = "qualTypeDataGridViewTextBoxColumn";
            this.qualTypeDataGridViewTextBoxColumn.ReadOnly = true;
            this.qualTypeDataGridViewTextBoxColumn.Visible = false;
            // 
            // qualClassDataGridViewTextBoxColumn
            // 
            this.qualClassDataGridViewTextBoxColumn.DataPropertyName = "Qual_Class";
            this.qualClassDataGridViewTextBoxColumn.HeaderText = "Qual_Class";
            this.qualClassDataGridViewTextBoxColumn.Name = "qualClassDataGridViewTextBoxColumn";
            this.qualClassDataGridViewTextBoxColumn.ReadOnly = true;
            this.qualClassDataGridViewTextBoxColumn.Visible = false;
            // 
            // qualProgDataGridViewTextBoxColumn
            // 
            this.qualProgDataGridViewTextBoxColumn.DataPropertyName = "Qual_Prog";
            this.qualProgDataGridViewTextBoxColumn.HeaderText = "Qual_Prog";
            this.qualProgDataGridViewTextBoxColumn.Name = "qualProgDataGridViewTextBoxColumn";
            this.qualProgDataGridViewTextBoxColumn.ReadOnly = true;
            this.qualProgDataGridViewTextBoxColumn.Visible = false;
            // 
            // qualVerDataGridViewTextBoxColumn
            // 
            this.qualVerDataGridViewTextBoxColumn.DataPropertyName = "Qual_Ver";
            this.qualVerDataGridViewTextBoxColumn.HeaderText = "Qual_Ver";
            this.qualVerDataGridViewTextBoxColumn.Name = "qualVerDataGridViewTextBoxColumn";
            this.qualVerDataGridViewTextBoxColumn.ReadOnly = true;
            this.qualVerDataGridViewTextBoxColumn.Visible = false;
            // 
            // qualRevDataGridViewTextBoxColumn
            // 
            this.qualRevDataGridViewTextBoxColumn.DataPropertyName = "Qual_Rev";
            this.qualRevDataGridViewTextBoxColumn.HeaderText = "Qual_Rev";
            this.qualRevDataGridViewTextBoxColumn.Name = "qualRevDataGridViewTextBoxColumn";
            this.qualRevDataGridViewTextBoxColumn.ReadOnly = true;
            this.qualRevDataGridViewTextBoxColumn.Visible = false;
            // 
            // qualPathDataGridViewTextBoxColumn
            // 
            this.qualPathDataGridViewTextBoxColumn.DataPropertyName = "Qual_Path";
            this.qualPathDataGridViewTextBoxColumn.HeaderText = "Qual_Path";
            this.qualPathDataGridViewTextBoxColumn.Name = "qualPathDataGridViewTextBoxColumn";
            this.qualPathDataGridViewTextBoxColumn.ReadOnly = true;
            this.qualPathDataGridViewTextBoxColumn.Visible = false;
            // 
            // qualRichiedenteDataGridViewTextBoxColumn
            // 
            this.qualRichiedenteDataGridViewTextBoxColumn.DataPropertyName = "Qual_Richiedente";
            this.qualRichiedenteDataGridViewTextBoxColumn.HeaderText = "Qual_Richiedente";
            this.qualRichiedenteDataGridViewTextBoxColumn.Name = "qualRichiedenteDataGridViewTextBoxColumn";
            this.qualRichiedenteDataGridViewTextBoxColumn.ReadOnly = true;
            this.qualRichiedenteDataGridViewTextBoxColumn.Visible = false;
            // 
            // qualDateRequestDataGridViewTextBoxColumn
            // 
            this.qualDateRequestDataGridViewTextBoxColumn.DataPropertyName = "Qual_DateRequest";
            this.qualDateRequestDataGridViewTextBoxColumn.HeaderText = "Qual_DateRequest";
            this.qualDateRequestDataGridViewTextBoxColumn.Name = "qualDateRequestDataGridViewTextBoxColumn";
            this.qualDateRequestDataGridViewTextBoxColumn.ReadOnly = true;
            this.qualDateRequestDataGridViewTextBoxColumn.Visible = false;
            // 
            // qualIPRequestDataGridViewTextBoxColumn
            // 
            this.qualIPRequestDataGridViewTextBoxColumn.DataPropertyName = "Qual_IPRequest";
            this.qualIPRequestDataGridViewTextBoxColumn.HeaderText = "Qual_IPRequest";
            this.qualIPRequestDataGridViewTextBoxColumn.Name = "qualIPRequestDataGridViewTextBoxColumn";
            this.qualIPRequestDataGridViewTextBoxColumn.ReadOnly = true;
            this.qualIPRequestDataGridViewTextBoxColumn.Visible = false;
            // 
            // tb_Des
            // 
            this.layout_Schede.SetColumnSpan(this.tb_Des, 7);
            // 
            // 
            // 
            this.tb_Des.CustomButton.Image = null;
            this.tb_Des.CustomButton.Location = new System.Drawing.Point(820, 1);
            this.tb_Des.CustomButton.Name = "";
            this.tb_Des.CustomButton.Size = new System.Drawing.Size(13, 13);
            this.tb_Des.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_Des.CustomButton.TabIndex = 1;
            this.tb_Des.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_Des.CustomButton.UseSelectable = true;
            this.tb_Des.CustomButton.Visible = false;
            this.tb_Des.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dtQualityBindingSource, "Qual_Des", true));
            this.tb_Des.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_Des.Lines = new string[] {
        "tb_Des"};
            this.tb_Des.Location = new System.Drawing.Point(123, 255);
            this.tb_Des.MaxLength = 32767;
            this.tb_Des.Name = "tb_Des";
            this.tb_Des.PasswordChar = '\0';
            this.tb_Des.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_Des.SelectedText = "";
            this.tb_Des.SelectionLength = 0;
            this.tb_Des.SelectionStart = 0;
            this.tb_Des.ShortcutsEnabled = true;
            this.tb_Des.Size = new System.Drawing.Size(834, 15);
            this.tb_Des.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_Des.TabIndex = 5;
            this.tb_Des.Text = "tb_Des";
            this.tb_Des.UseSelectable = true;
            this.tb_Des.UseStyleColors = true;
            this.tb_Des.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_Des.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // gridControl1
            // 
            this.layout_Schede.SetColumnSpan(this.gridControl1, 5);
            this.gridControl1.DataSource = this.dtQualityBindingSource;
            this.gridControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControl1.Location = new System.Drawing.Point(363, 297);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Name = "gridControl1";
            this.layout_Schede.SetRowSpan(this.gridControl1, 5);
            this.gridControl1.Size = new System.Drawing.Size(594, 99);
            this.gridControl1.TabIndex = 32;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colId,
            this.colQual_ProjProdArea,
            this.colQual_Org,
            this.colQual_Type,
            this.colQual_Class,
            this.colQual_Prog,
            this.colQual_Ver,
            this.colQual_Rev,
            this.colQual_Des,
            this.colQual_Path,
            this.colQual_Richiedente,
            this.colQual_DateRequest,
            this.colQual_IPRequest,
            this.colCodice_Quality});
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.GroupCount = 3;
            this.gridView1.Name = "gridView1";
            this.gridView1.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colQual_ProjProdArea, DevExpress.Data.ColumnSortOrder.Descending),
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colQual_Org, DevExpress.Data.ColumnSortOrder.Descending),
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colQual_Type, DevExpress.Data.ColumnSortOrder.Descending)});
            // 
            // colId
            // 
            this.colId.FieldName = "Id";
            this.colId.Name = "colId";
            this.colId.Visible = true;
            this.colId.VisibleIndex = 0;
            // 
            // colQual_ProjProdArea
            // 
            this.colQual_ProjProdArea.FieldName = "Qual_ProjProdArea";
            this.colQual_ProjProdArea.Name = "colQual_ProjProdArea";
            this.colQual_ProjProdArea.Visible = true;
            this.colQual_ProjProdArea.VisibleIndex = 1;
            // 
            // colQual_Org
            // 
            this.colQual_Org.FieldName = "Qual_Org";
            this.colQual_Org.Name = "colQual_Org";
            this.colQual_Org.Visible = true;
            this.colQual_Org.VisibleIndex = 1;
            // 
            // colQual_Type
            // 
            this.colQual_Type.FieldName = "Qual_Type";
            this.colQual_Type.Name = "colQual_Type";
            this.colQual_Type.Visible = true;
            this.colQual_Type.VisibleIndex = 1;
            // 
            // colQual_Class
            // 
            this.colQual_Class.FieldName = "Qual_Class";
            this.colQual_Class.Name = "colQual_Class";
            this.colQual_Class.Visible = true;
            this.colQual_Class.VisibleIndex = 1;
            // 
            // colQual_Prog
            // 
            this.colQual_Prog.FieldName = "Qual_Prog";
            this.colQual_Prog.Name = "colQual_Prog";
            this.colQual_Prog.Visible = true;
            this.colQual_Prog.VisibleIndex = 2;
            // 
            // colQual_Ver
            // 
            this.colQual_Ver.FieldName = "Qual_Ver";
            this.colQual_Ver.Name = "colQual_Ver";
            this.colQual_Ver.Visible = true;
            this.colQual_Ver.VisibleIndex = 3;
            // 
            // colQual_Rev
            // 
            this.colQual_Rev.FieldName = "Qual_Rev";
            this.colQual_Rev.Name = "colQual_Rev";
            this.colQual_Rev.Visible = true;
            this.colQual_Rev.VisibleIndex = 4;
            // 
            // colQual_Des
            // 
            this.colQual_Des.FieldName = "Qual_Des";
            this.colQual_Des.Name = "colQual_Des";
            this.colQual_Des.Visible = true;
            this.colQual_Des.VisibleIndex = 5;
            // 
            // colQual_Path
            // 
            this.colQual_Path.FieldName = "Qual_Path";
            this.colQual_Path.Name = "colQual_Path";
            this.colQual_Path.Visible = true;
            this.colQual_Path.VisibleIndex = 6;
            // 
            // colQual_Richiedente
            // 
            this.colQual_Richiedente.FieldName = "Qual_Richiedente";
            this.colQual_Richiedente.Name = "colQual_Richiedente";
            this.colQual_Richiedente.Visible = true;
            this.colQual_Richiedente.VisibleIndex = 7;
            // 
            // colQual_DateRequest
            // 
            this.colQual_DateRequest.FieldName = "Qual_DateRequest";
            this.colQual_DateRequest.Name = "colQual_DateRequest";
            this.colQual_DateRequest.Visible = true;
            this.colQual_DateRequest.VisibleIndex = 8;
            // 
            // colQual_IPRequest
            // 
            this.colQual_IPRequest.FieldName = "Qual_IPRequest";
            this.colQual_IPRequest.Name = "colQual_IPRequest";
            this.colQual_IPRequest.Visible = true;
            this.colQual_IPRequest.VisibleIndex = 9;
            // 
            // colCodice_Quality
            // 
            this.colCodice_Quality.FieldName = "Codice_Quality";
            this.colCodice_Quality.Name = "colCodice_Quality";
            this.colCodice_Quality.Visible = true;
            this.colCodice_Quality.VisibleIndex = 10;
            // 
            // dt_Quality_ProjProdAreaTableAdapter
            // 
            this.dt_Quality_ProjProdAreaTableAdapter.ClearBeforeFill = true;
            // 
            // dt_Quality_CompanyTableAdapter
            // 
            this.dt_Quality_CompanyTableAdapter.ClearBeforeFill = true;
            // 
            // dt_Quality_TipoDocTableAdapter
            // 
            this.dt_Quality_TipoDocTableAdapter.ClearBeforeFill = true;
            // 
            // usersTableAdapter
            // 
            this.usersTableAdapter.ClearBeforeFill = true;
            // 
            // dt_Quality_ClassificationTableAdapter
            // 
            this.dt_Quality_ClassificationTableAdapter.ClearBeforeFill = true;
            // 
            // dt_QualityTableAdapter
            // 
            this.dt_QualityTableAdapter.ClearBeforeFill = true;
            // 
            // UC_Quality
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 500);
            this.ControlBox = false;
            this.Controls.Add(this.panel_fattibilita);
            this.Controls.Add(this.layout_orizz_menu);
            this.DisplayHeader = false;
            this.Name = "UC_Quality";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UC_Quality_Load);
            this.layout_orizz_menu.ResumeLayout(false);
            this.layout_orizz_menu.PerformLayout();
            this.pan_Menu_salva.ResumeLayout(false);
            this.pan_Menu_salva.PerformLayout();
            this.pan_Menu_comandi.ResumeLayout(false);
            this.pan_Menu_comandi.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            this.panel_fattibilita.ResumeLayout(false);
            this.layout_Schede.ResumeLayout(false);
            this.layout_Schede.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtQualityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtQualityClassificationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtQualityTipoDocBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtQualityCompanyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtQualityProjProdAreaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).EndInit();
            this.panel_grid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_Quality)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel layout_orizz_menu;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
        private MetroFramework.Controls.MetroPanel panel_fattibilita;
        private System.Windows.Forms.TableLayoutPanel layout_Schede;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloCompostoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloComponenteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Explode_Mag;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.ComboBox cb_org;
        private System.Windows.Forms.ComboBox cb_projprodarea;
        private System.Windows.Forms.ComboBox cb_User;
        private ds_SL ds_SL;
        private System.Windows.Forms.BindingSource dtQualityProjProdAreaBindingSource;
        private ds_SLTableAdapters.dt_Quality_ProjProdAreaTableAdapter dt_Quality_ProjProdAreaTableAdapter;
        private System.Windows.Forms.BindingSource dtQualityCompanyBindingSource;
        private ds_SLTableAdapters.dt_Quality_CompanyTableAdapter dt_Quality_CompanyTableAdapter;
        private System.Windows.Forms.BindingSource dtQualityTipoDocBindingSource;
        private ds_SLTableAdapters.dt_Quality_TipoDocTableAdapter dt_Quality_TipoDocTableAdapter;
        private MetroFramework.Controls.MetroLabel lab_type;
        private MetroFramework.Controls.MetroLabel lab_org;
        private MetroFramework.Controls.MetroLabel lab_projprodarea;
        private System.Windows.Forms.BindingSource usersBindingSource;
        private ds_SLTableAdapters.UsersTableAdapter usersTableAdapter;
        private MetroFramework.Controls.MetroLabel lab_MyIp;
        private MetroFramework.Controls.MetroPanel panel_grid;
        private MetroFramework.Controls.MetroGrid gv_Quality;
        private System.Windows.Forms.ComboBox cb_class;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroTextBox tb_desClass;
        private System.Windows.Forms.BindingSource dtQualityClassificationBindingSource;
        private ds_SLTableAdapters.dt_Quality_ClassificationTableAdapter dt_Quality_ClassificationTableAdapter;
        private MetroFramework.Controls.MetroLabel lab_class;
        private System.Windows.Forms.DataGridViewTextBoxColumn qualProg1DataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource dtQualityBindingSource;
        private ds_SLTableAdapters.dt_QualityTableAdapter dt_QualityTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroTextBox tb_Des;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel lab_Codice;
        private System.Windows.Forms.MenuStrip pan_Menu_salva;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_salva;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_div12;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_annulla;
        private System.Windows.Forms.MenuStrip pan_Menu_comandi;
        private System.Windows.Forms.ToolStripMenuItem menu_new;
        private System.Windows.Forms.ToolStripMenuItem menu_div01;
        private System.Windows.Forms.ToolStripMenuItem menu_edit;
        private System.Windows.Forms.DataGridViewTextBoxColumn codiceQualityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qualDesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qualProjProdAreaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qualOrgDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qualTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qualClassDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qualProgDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qualVerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qualRevDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qualPathDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qualRichiedenteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qualDateRequestDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qualIPRequestDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroTextBox tb_folder;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private MetroFramework.Controls.MetroTextBox tb_rev;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroTextBox tb_vers;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn colId;
        private DevExpress.XtraGrid.Columns.GridColumn colQual_ProjProdArea;
        private DevExpress.XtraGrid.Columns.GridColumn colQual_Org;
        private DevExpress.XtraGrid.Columns.GridColumn colQual_Type;
        private DevExpress.XtraGrid.Columns.GridColumn colQual_Class;
        private DevExpress.XtraGrid.Columns.GridColumn colQual_Prog;
        private DevExpress.XtraGrid.Columns.GridColumn colQual_Ver;
        private DevExpress.XtraGrid.Columns.GridColumn colQual_Rev;
        private DevExpress.XtraGrid.Columns.GridColumn colQual_Des;
        private DevExpress.XtraGrid.Columns.GridColumn colQual_Path;
        private DevExpress.XtraGrid.Columns.GridColumn colQual_Richiedente;
        private DevExpress.XtraGrid.Columns.GridColumn colQual_DateRequest;
        private DevExpress.XtraGrid.Columns.GridColumn colQual_IPRequest;
        private DevExpress.XtraGrid.Columns.GridColumn colCodice_Quality;
    }
}