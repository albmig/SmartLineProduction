﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using Syncfusion.Windows.Forms.Grid.Grouping;

namespace SmartLineProduction
{
    public partial class UC_Quality : MetroFramework.Forms.MetroForm
    {
        private string displayform = "V"; // V-View/I-Insert/E-Edit
        private string sel_ProjProdArea = "";
        private string sel_Org = "";
        private string sel_Type = "";
        private string sel_Class = "";
        private string sel_User = "";

        private int ultcodice = 0;

        public UC_Quality()
        {
            InitializeComponent();
        }

        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UC_Quality_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.dt_Quality'. È possibile spostarla o rimuoverla se necessario.
            //this.dt_QualityTableAdapter.Fill(this.ds_SL.dt_Quality);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.dt_Quality_Classification'. È possibile spostarla o rimuoverla se necessario.
            this.dt_Quality_ClassificationTableAdapter.Fill(this.ds_SL.dt_Quality_Classification);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.Users'. È possibile spostarla o rimuoverla se necessario.
            this.usersTableAdapter.Fill(this.ds_SL.Users);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.dt_Quality_TipoDoc'. È possibile spostarla o rimuoverla se necessario.
            this.dt_Quality_TipoDocTableAdapter.Fill(this.ds_SL.dt_Quality_TipoDoc);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.dt_Quality_Company'. È possibile spostarla o rimuoverla se necessario.
            this.dt_Quality_CompanyTableAdapter.Fill(this.ds_SL.dt_Quality_Company);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.dt_Quality_ProjProdArea'. È possibile spostarla o rimuoverla se necessario.
            this.dt_Quality_ProjProdAreaTableAdapter.Fill(this.ds_SL.dt_Quality_ProjProdArea);

            lab_MyIp.Text = FindIP();
            PreparaForm();
        }

        private string FindIP()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            throw new Exception("No network adapters with an IPv4 address in the system!");
        }

        private void dtQualityBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (displayform == "V")
            {
                DataRowView drview = (DataRowView)dtQualityBindingSource.Current;
                if (drview != null)
                {
                    string filtro = "UTENTE = " + "'" + drview["Qual_Richiedente"].ToString() + "'";
                    usersBindingSource.Filter = filtro;

                    filtro = "Qual_Codice = " + "'" + drview["Qual_ProjProdArea"].ToString() + "'";
                    dtQualityProjProdAreaBindingSource.Filter = filtro;

                    filtro = "Qual_Codice = " + "'" + drview["Qual_Org"].ToString() + "'";
                    dtQualityCompanyBindingSource.Filter = filtro;

                    filtro = "Qual_Codice = " + "'" + drview["Qual_Type"].ToString() + "'";
                    dtQualityTipoDocBindingSource.Filter = filtro;

                    filtro = "Qual_Codice = " + "'" + drview["Qual_Class"].ToString() + "'";
                    dtQualityClassificationBindingSource.Filter = filtro;
                }
            }
        }

        private void PreparaForm()
        {
            switch (displayform)
            {
                case "V":
                    this.dt_QualityTableAdapter.FillBy_CodiceQuality(this.ds_SL.dt_Quality);

                    dtQualityBindingSource.ResumeBinding();
                    gv_Quality.Enabled = true;
                    tb_Des.Enabled = false;
                    tb_folder.Enabled = false;
                    tb_rev.Enabled = false;
                    tb_vers.Enabled = false;

                    pan_Menu_comandi.Enabled = true;
                    pan_Menu_salva.Enabled = false;
                    pan_Menu_exit.Enabled = true;

                    dtQualityBindingSource.RemoveFilter();
                    dtQualityBindingSource.MoveFirst();
                    break;
                case "I":
                    dtQualityBindingSource.SuspendBinding();
                    tb_Des.Enabled = true;
                    tb_Des.Text = "";
                    tb_folder.Enabled = true;
                    tb_rev.Enabled = true;
                    tb_vers.Enabled = true;

                    usersBindingSource.RemoveFilter();
                    dtQualityProjProdAreaBindingSource.RemoveFilter();
                    dtQualityCompanyBindingSource.RemoveFilter();
                    dtQualityTipoDocBindingSource.RemoveFilter();
                    dtQualityClassificationBindingSource.RemoveFilter();

                    usersBindingSource.RemoveFilter();
                    dtQualityProjProdAreaBindingSource.Sort = "Qual_Des asc";
                    dtQualityCompanyBindingSource.Sort = "Qual_Des asc";
                    dtQualityTipoDocBindingSource.Sort = "Qual_Des asc";
                    dtQualityClassificationBindingSource.Sort = "Qual_Des asc";

                    gv_Quality.Enabled = false;

                    pan_Menu_comandi.Enabled = false;
                    pan_Menu_salva.Enabled = true;
                    pan_Menu_exit.Enabled = false;

                    break;
                case "E":
                    //dtQualityBindingSource.SuspendBinding();

                    cb_User.Enabled = false;
                    cb_projprodarea.Enabled = false;
                    cb_org.Enabled = false;
                    cb_type.Enabled = false;
                    cb_class.Enabled = false;
                    tb_Des.Enabled = true;
                    tb_folder.Enabled = true;
                    tb_rev.Enabled = false;
                    tb_vers.Enabled = false;

                    pan_Menu_comandi.Enabled = false;
                    pan_Menu_salva.Enabled = true;
                    pan_Menu_exit.Enabled = false;

                    break;
            }
        }

        private void menu_new_Click(object sender, EventArgs e)
        {
            displayform = "I";
            Application.UseWaitCursor = true;
            PreparaForm();
            Application.UseWaitCursor = false;
        }

        private void FiltraQuality()
        {
            if (displayform == "I")
            {
                string filtro = "";
                bool firstfilter = false;

                if (sel_ProjProdArea != "___")
                {
                    filtro = filtro + "(Qual_ProjProdArea like " + "'" + sel_ProjProdArea + "')";
                    firstfilter = true;
                }
                if (sel_Org != "___")
                {
                    if (firstfilter) { filtro = filtro + " AND "; }
                    filtro = filtro + "(Qual_Org like " + "'" + sel_Org + "')";
                    firstfilter = true;
                }
                if (sel_Type != "___")
                {
                    if (firstfilter) { filtro = filtro + " AND "; }
                    filtro = filtro + "(Qual_Type like " + "'" + sel_Type + "')";
                    firstfilter = true;
                }

                dtQualityBindingSource.Filter = filtro;

                CreaCodice();
            }
        }

        private void dtQualityProjProdAreaBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            DataRowView drview = (DataRowView)dtQualityProjProdAreaBindingSource.Current;
            if (drview != null && displayform == "I") { sel_ProjProdArea = drview["Qual_Codice"].ToString(); FiltraQuality(); }
        }

        private void dtQualityCompanyBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            DataRowView drview = (DataRowView)dtQualityCompanyBindingSource.Current;
            if (drview != null && displayform == "I") { sel_Org = drview["Qual_Codice"].ToString(); FiltraQuality(); }
        }

        private void dtQualityTipoDocBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            DataRowView drview = (DataRowView)dtQualityTipoDocBindingSource.Current;
            if (drview != null && displayform == "I") { sel_Type = drview["Qual_Codice"].ToString(); FiltraQuality(); }
        }

        private void dtQualityClassificationBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            DataRowView drview = (DataRowView)dtQualityClassificationBindingSource.Current;
            if (drview != null && displayform == "I") { sel_Class = drview["Qual_Codice"].ToString(); FiltraQuality(); }
        }

        private void menu_sw_annulla_Click(object sender, EventArgs e)
        {
            displayform = "V";
            PreparaForm();
        }

        private void CreaCodice()
        {
            //Trova ultimo codice
            ultcodice = 0;

            DataView view = new DataView(ds_SL.dt_Quality);
            view.RowFilter = dtQualityBindingSource.Filter;
            int contarec = view.Count;
            if (contarec > 0)
            {
                DataTable result = view.ToTable();
                ultcodice = Convert.ToInt32(result.Compute("max(Qual_Prog)", ""));
            }

            ultcodice++;

            string codvers = "";
            string codrev = "";
            if (tb_vers.Text != "") { codvers = tb_vers.Text; } else { codvers = "__" ; }
            if (tb_rev.Text != "") { codrev = tb_rev.Text; } else { codrev = "__"; }

            //,CONCAT(Quality.Qual_ProjProdArea, '-', Quality.Qual_Org, '-', Quality.Qual_Type, '-', Quality.Qual_Class, '-', FORMAT(Quality.Qual_Prog, '0000'), '-', Quality.Qual_Ver, '.', Quality.Qual_Rev) AS Codice_Quality
            string codice = sel_ProjProdArea + "-" + sel_Org + "-" + sel_Type + "-" + sel_Class + "-" + ultcodice.ToString("0000") + "-" + codvers + "."+ codrev;
            lab_Codice.Text = codice;
        }

        private void tb_vers_Leave(object sender, EventArgs e)
        {
            CreaCodice();
        }

        private void tb_rev_Leave(object sender, EventArgs e)
        {
            CreaCodice();
        }

        private void tb_folder_ButtonClick(object sender, EventArgs e)
        {
            FolderBrowserDialog folderDlg = new FolderBrowserDialog();
            folderDlg.SelectedPath = @"\\192.168.0.8\sistematica";
            folderDlg.ShowNewFolderButton = true;
            // Show the FolderBrowserDialog.  
            DialogResult result = folderDlg.ShowDialog();
            if (result == DialogResult.OK)
            {
                tb_folder.Text = folderDlg.SelectedPath;
            }
        }

        private void menu_sw_salva_Click(object sender, EventArgs e)
        {
            //Verifica che tutti i campi siano stati compilati correttamente
            if (lab_projprodarea.Text == "___")
            {
                MessageBox.Show("Si prega di compilare correttamente il campo Project / Product / Area. \nNon può essere vuoto!");
                cb_projprodarea.Focus();
                return;
            }
            if (lab_org.Text == "___")
            {
                MessageBox.Show("Si prega di compilare correttamente il campo Organization. \nNon può essere vuoto!");
                cb_org.Focus();
                return;
            }
            if (lab_type.Text == "___")
            {
                MessageBox.Show("Si prega di compilare correttamente il campo Type Document. \nNon può essere vuoto!");
                cb_type.Focus();
                return;
            }
            if (lab_class.Text == "___")
            {
                MessageBox.Show("Si prega di compilare correttamente il campo Classification. \nNon può essere vuoto!");
                cb_class.Focus();
                return;
            }
            if (tb_Des.Text =="")
            {
                MessageBox.Show("Si prega di compilare correttamente il campo Descrizione. \nNon può essere vuoto!");
                tb_Des.Focus();
                return;
            }
            if (tb_vers.Text == "")
            {
                MessageBox.Show("Si prega di compilare correttamente il campo Versione. \nNon può essere vuoto!");
                tb_vers.Focus();
                return;
            }
            if (tb_rev.Text == "")
            {
                MessageBox.Show("Si prega di compilare correttamente il campo Revisione. \nNon può essere vuoto!");
                tb_rev.Focus();
                return;
            }

            //Verifica che non esista già il codice
            if(displayform=="I")
            {
                DataView view = new DataView(ds_SL.dt_Quality);
                view.RowFilter = "Codice_Quality = " + "'" + lab_Codice.Text + "'";
                int contarec = view.Count;
                if (contarec > 0)
                {
                    MessageBox.Show("Attenzione! Il codice richiesto esiste già! \nRivedere le selezioni!");
                    tb_rev.Focus();
                    return;
                }
            }

            Riga2Db();
            displayform = "V";
            PreparaForm();
        }

        private void Riga2Db()
        {
            if (displayform=="I")
            {
                var newrow = ds_SL.dt_Quality.NewRow();
                newrow["Qual_ProjProdArea"] = lab_projprodarea.Text;
                newrow["Qual_Org"] = lab_org.Text;
                newrow["Qual_Type"] = lab_type.Text;
                newrow["Qual_Class"] = lab_class.Text;
                newrow["Qual_Prog"] = ultcodice.ToString();
                newrow["Qual_Ver"] = tb_vers.Text;
                newrow["Qual_Rev"] = tb_rev.Text;
                newrow["Qual_Des"] = tb_Des.Text;
                newrow["Qual_Path"] = tb_folder.Text;
                newrow["Qual_Richiedente"] = sel_User;
                newrow["Qual_DateRequest"] = DateTime.Now;
                newrow["Qual_IPRequest"] = FindIP();
                ds_SL.dt_Quality.Rows.Add(newrow);
                dt_QualityTableAdapter.Update(newrow);
            }
            if (displayform=="E")
            {
                DataRowView findrowview = this.dtQualityBindingSource.Current as DataRowView;
                DataRow findrow = (DataRow)findrowview.Row;

                DataRow editrow = ds_SL.dt_Quality.Rows.Find(findrow["Id"]);
                editrow.BeginEdit();
                editrow["Qual_ProjProdArea"] = lab_projprodarea.Text;
                editrow["Qual_Org"] = lab_org.Text;
                editrow["Qual_Type"] = lab_type.Text;
                editrow["Qual_Class"] = lab_class.Text;
                editrow["Qual_Prog"] = ultcodice.ToString();
                editrow["Qual_Ver"] = tb_vers.Text;
                editrow["Qual_Rev"] = tb_rev.Text;
                editrow["Qual_Des"] = tb_Des.Text;
                editrow["Qual_Path"] = tb_folder.Text;
                editrow["Qual_Richiedente"] = sel_User;
                editrow["Qual_DateRequest"] = DateTime.Now;
                editrow["Qual_IPRequest"] = FindIP();
                //editrow.EndEdit();

                try
                {
                    this.Validate();
                    this.dtQualityBindingSource.EndEdit();
                    this.dt_QualityTableAdapter.Update(editrow);
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show("Update failed");
                }
                //dt_QualityTableAdapter. Update(editrow);
            }
        }

        private void usersBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            DataRowView drview = (DataRowView)usersBindingSource.Current;
            if (drview != null && displayform == "I") { sel_User = drview["UTENTE"].ToString(); }
        }

        private void menu_edit_Click(object sender, EventArgs e)
        {
            displayform = "E";
            Application.UseWaitCursor = true;
            PreparaForm();
            Application.UseWaitCursor = false;
        }
    }
}
