﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;


namespace SmartLineProduction
{
    public partial class UC_SL_FirmwareClienti : MetroFramework.Forms.MetroForm
    {
        public UC_SL_FirmwareClienti()
        {
            InitializeComponent();
        }

        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UC_SL_FirmwareClientiLabel_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_FwClienti.Bouquet_RicCust'. È possibile spostarla o rimuoverla se necessario.
            this.bouquet_RicCustTableAdapter.Fill(this.ds_FwClienti.Bouquet_RicCust);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_FwClienti.Bouquet_RicStand'. È possibile spostarla o rimuoverla se necessario.
            this.bouquet_RicStandTableAdapter.Fill(this.ds_FwClienti.Bouquet_RicStand);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_FwClienti.Bouquet_PalmCust'. È possibile spostarla o rimuoverla se necessario.
            this.bouquet_PalmCustTableAdapter.Fill(this.ds_FwClienti.Bouquet_PalmCust);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_FwClienti.Bouquet_PalmStand'. È possibile spostarla o rimuoverla se necessario.
            this.bouquet_PalmStandTableAdapter.Fill(this.ds_FwClienti.Bouquet_PalmStand);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_FwClienti.FW_Clienti'. È possibile spostarla o rimuoverla se necessario.
            this.fW_ClientiTableAdapter.Fill(this.ds_FwClienti.FW_Clienti);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL_History.SF_Clienti_SerialNumbers'. È possibile spostarla o rimuoverla se necessario.
            this.sF_Clienti_SerialNumbersTableAdapter.Fill(this.ds_FwClienti.SF_Clienti_SerialNumbers);

            this.WindowState = FormWindowState.Maximized;
        }

        private void gv_PalmStand_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value == null) { return; }

            DataGridViewCell cell = this.gv_PalmStand.Rows[e.RowIndex].Cells[e.ColumnIndex];
            DataGridViewCell cellbutton = this.gv_PalmStand.Rows[e.RowIndex].Cells["gv_PalmStand_Present"];

            DataGridViewRow gridRow = gv_PalmStand.Rows[e.RowIndex];

            if ((gv_PalmStand.Columns[e.ColumnIndex].Name == "gv_PalmStand_Code") && (e.Value != null))
            {
                cell.Style.Font = new Font(cell.InheritedStyle.Font, FontStyle.Bold);
            }

            if ((gv_PalmStand.Columns[e.ColumnIndex].Name == "gv_PalmStand_Present") && (e.Value != null))
            {
                bool presente = Convert.ToBoolean(e.Value);
                if (presente)
                {
                    e.Value = "Elimina";
                    gridRow.DefaultCellStyle.ForeColor = Color.LightGray;
                    gridRow.DefaultCellStyle.SelectionForeColor = Color.LightGray;
                }
                else
                {
                    e.Value = "Aggiungi";
                    gridRow.DefaultCellStyle.ForeColor = Color.DarkGreen;
                    gridRow.DefaultCellStyle.SelectionForeColor = Color.DarkGreen;
                }
            }

        }

        private void gv_PalmCust_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value == null) { return; }

            DataGridViewCell cell = this.gv_PalmCust.Rows[e.RowIndex].Cells[e.ColumnIndex];
            DataGridViewRow gridRow = gv_PalmCust.Rows[e.RowIndex];
            if ((gv_PalmCust.Columns[e.ColumnIndex].Name == "gv_PalmCust_Code") && (e.Value != null))
            {
                cell.Style.Font = new Font(cell.InheritedStyle.Font, FontStyle.Bold);
            }

            if ((gv_PalmCust.Columns[e.ColumnIndex].Name == "gv_PalmCust_Present") && (e.Value != null))
            {
                bool presente = Convert.ToBoolean(e.Value);
                if (presente)
                {
                    e.Value = "Elimina";
                    gridRow.DefaultCellStyle.ForeColor = Color.LightGray;
                    gridRow.DefaultCellStyle.SelectionForeColor = Color.LightGray;
                }
                else
                {
                    e.Value = "Aggiungi";
                    gridRow.DefaultCellStyle.ForeColor = Color.DarkGreen;
                    gridRow.DefaultCellStyle.SelectionForeColor = Color.DarkGreen;
                }
            }

        }

        private void gv_RicStand_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value == null) { return; }

            DataGridViewCell cell = this.gv_RicStand.Rows[e.RowIndex].Cells[e.ColumnIndex];
            DataGridViewRow gridRow = gv_RicStand.Rows[e.RowIndex];
            if ((gv_RicStand.Columns[e.ColumnIndex].Name == "gv_RicStand_Code") && (e.Value != null))
            {
                cell.Style.Font = new Font(cell.InheritedStyle.Font, FontStyle.Bold);
            }

            if ((gv_RicStand.Columns[e.ColumnIndex].Name == "gv_RicStand_Present") && (e.Value != null))
            {
                bool presente = Convert.ToBoolean(e.Value);
                if (presente)
                {
                    e.Value = "Elimina";
                    gridRow.DefaultCellStyle.ForeColor = Color.LightGray;
                    gridRow.DefaultCellStyle.SelectionForeColor = Color.LightGray;
                }
                else
                {
                    e.Value = "Aggiungi";
                    gridRow.DefaultCellStyle.ForeColor = Color.DarkGreen;
                    gridRow.DefaultCellStyle.SelectionForeColor = Color.DarkGreen;
                }
            }

        }

        private void gv_RicCust_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value == null) { return; }

            DataGridViewCell cell = this.gv_RicCust.Rows[e.RowIndex].Cells[e.ColumnIndex];
            DataGridViewRow gridRow = gv_RicCust.Rows[e.RowIndex];
            if ((gv_RicCust.Columns[e.ColumnIndex].Name == "gv_RicCust_Code") && (e.Value != null))
            {
                cell.Style.Font = new Font(cell.InheritedStyle.Font, FontStyle.Bold);
            }

            if ((gv_RicCust.Columns[e.ColumnIndex].Name == "gv_RicCust_Present") && (e.Value != null))
            {
                bool presente = Convert.ToBoolean(e.Value);
                if (presente)
                {
                    e.Value = "Elimina";
                    gridRow.DefaultCellStyle.ForeColor = Color.LightGray;
                    gridRow.DefaultCellStyle.SelectionForeColor = Color.LightGray;
                }
                else
                {
                    e.Value = "Aggiungi";
                    gridRow.DefaultCellStyle.ForeColor = Color.DarkGreen;
                    gridRow.DefaultCellStyle.SelectionForeColor = Color.DarkGreen;
                }
            }

        }

        private void gv_FWCliente_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value == null) { return; }

            DataGridViewCell cell = this.gv_FWCliente.Rows[e.RowIndex].Cells[e.ColumnIndex];
            DataGridViewRow gridRow = gv_FWCliente.Rows[e.RowIndex];
            if ((gv_FWCliente.Columns[e.ColumnIndex].Name == "gv_FWCliente_SWCode") && (e.Value != null))
            {
                cell.Style.Font = new Font(cell.InheritedStyle.Font, FontStyle.Bold);
            }
        }
    }
}
