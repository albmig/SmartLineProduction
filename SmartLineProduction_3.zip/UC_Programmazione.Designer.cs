﻿namespace SmartLineProduction
{
    partial class UC_Programmazione
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Programmazione));
            this.MainMenu = new System.Windows.Forms.MenuStrip();
            this.uscitaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nascondiVisualizzaFirmwareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aggiornaArchiviToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.commandPanel = new MetroFramework.Controls.MetroPanel();
            this.panel_dt_tmp_programmazione = new MetroFramework.Controls.MetroPanel();
            this.panel_programmazione_output = new MetroFramework.Controls.MetroPanel();
            this.tbl_Label_ID = new System.Windows.Forms.TableLayoutPanel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.lab_IDNumber_write = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.lab_SN = new MetroFramework.Controls.MetroLabel();
            this.lab_PartNumber = new MetroFramework.Controls.MetroLabel();
            this.lab_IDNumber_read = new MetroFramework.Controls.MetroLabel();
            this.panel_programmazione_result = new MetroFramework.Controls.MetroPanel();
            this.panel_programmazione_grid = new MetroFramework.Controls.MetroPanel();
            this.dg_dt_tmp_programmazione = new MetroFramework.Controls.MetroGrid();
            this.dg_dt_tmp_progr_Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dg_dt_tmp_progr_Commessa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dg_dt_tmp_progr_Kit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dg_dt_tmp_progr_Device = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dg_dt_tmp_progr_Fw = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dg_dt_tmp_progr_FwKeyId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dg_dt_tmp_progr_ID_Hardware = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Programma = new System.Windows.Forms.DataGridViewButtonColumn();
            this.tmpfwkeyidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tmpIDHardwareDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtTmpProgrammaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.pan_tipoprogramma = new MetroFramework.Controls.MetroPanel();
            this.tab_control_Program = new MetroFramework.Controls.MetroTabControl();
            this.tab_commessa = new MetroFramework.Controls.MetroTabPage();
            this.grid_commesse = new MetroFramework.Controls.MetroGrid();
            this.grid_commesse_CommessaShort = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_DataConsegna = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_RagioneSociale = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_NumRiga = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_CodArticoloCommessa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_Device = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_QtaDaEvadere = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_Qta_Evasa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_TipoOrdine = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_CommessaLong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_DataOrdine = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_NumeroOrdine = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_UM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_TipoRiga = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_IsSwrP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_IsSwrR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_SwDevice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_CodAnagrafico = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_QtaOrdinata = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_StatoCommessa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_IsKit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_DataFineValidita = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_ViewDevice = new System.Windows.Forms.DataGridViewButtonColumn();
            this.grid_commesse_CommessaSelezionata = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dataConfermaConsegnaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numeroRigaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.artCommessaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtadaEvadereDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.deviceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grid_commesse_menu = new MetroFramework.Controls.MetroContextMenu(this.components);
            this.menu_commesse_vis = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_commesse_nas = new System.Windows.Forms.ToolStripMenuItem();
            this.sFCommesseSLBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tab_kit = new MetroFramework.Controls.MetroTabPage();
            this.grid_Componenti = new MetroFramework.Controls.MetroGrid();
            this.grid_Kit = new MetroFramework.Controls.MetroGrid();
            this.tab_item = new MetroFramework.Controls.MetroTabPage();
            this.cb_sceltaCliente = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.lab_device_ID = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.panel_device_image = new MetroFramework.Controls.MetroPanel();
            this.Device_Image = new System.Windows.Forms.PictureBox();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.cb_scelta_Device = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.cb_scelta_Famiglia = new MetroFramework.Controls.MetroComboBox();
            this.but_seleziona_device = new MetroFramework.Controls.MetroButton();
            this.lab_device_desestfw = new MetroFramework.Controls.MetroLabel();
            this.lab_device_desfw = new MetroFramework.Controls.MetroLabel();
            this.lab_device_codfw = new MetroFramework.Controls.MetroLabel();
            this.lab_device_desestart = new MetroFramework.Controls.MetroLabel();
            this.lab_device_desart = new MetroFramework.Controls.MetroLabel();
            this.cb_scelta_Funzioni = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.tab_libera = new MetroFramework.Controls.MetroTabPage();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.tb_Id_Hardware = new MetroFramework.Controls.MetroTextBox();
            this.but_seleziona_fw = new MetroFramework.Controls.MetroButton();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.lab_fw_custom = new MetroFramework.Controls.MetroLabel();
            this.lab_fw_standard = new MetroFramework.Controls.MetroLabel();
            this.toggle_tipo_firmware = new MetroFramework.Controls.MetroToggle();
            this.cb_scelta_fw = new MetroFramework.Controls.MetroComboBox();
            this.lab_tipo_device_ricevitore = new MetroFramework.Controls.MetroLabel();
            this.lab_tipo_device_palmare = new MetroFramework.Controls.MetroLabel();
            this.toggle_tipo_device_Libera = new MetroFramework.Controls.MetroToggle();
            this.pan_titolo = new MetroFramework.Controls.MetroPanel();
            this.lab_command = new MetroFramework.Controls.MetroLabel();
            this.tv_FW = new System.Windows.Forms.TreeView();
            this.outputPanel = new MetroFramework.Controls.MetroPanel();
            this.dos_box = new System.Windows.Forms.TextBox();
            this.configPanel = new MetroFramework.Controls.MetroPanel();
            this.TrayCmb = new System.Windows.Forms.ComboBox();
            this.LabelWriterCmb = new System.Windows.Forms.ComboBox();
            this.lab_Configurazione = new MetroFramework.Controls.MetroLabel();
            this.lab_FW_folder = new MetroFramework.Controls.MetroLabel();
            this.tb_FW_folder = new MetroFramework.Controls.MetroTextBox();
            this.lab_IP_printer = new MetroFramework.Controls.MetroLabel();
            this.tb_IP_Printer = new MetroFramework.Controls.MetroTextBox();
            this.lab_use_printer = new MetroFramework.Controls.MetroLabel();
            this.tog_Use_printer = new MetroFramework.Controls.MetroToggle();
            this.lab_Commander = new MetroFramework.Controls.MetroLabel();
            this.tb_Commander_path = new MetroFramework.Controls.MetroTextBox();
            this.Panel_Config_buttons = new System.Windows.Forms.TableLayoutPanel();
            this.but_Edit_Config = new System.Windows.Forms.Button();
            this.but_Save_Config = new System.Windows.Forms.Button();
            this.but_Abort_Config = new System.Windows.Forms.Button();
            this.sFCommesseSLSFArticoliBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sFDistinctItemFamPrefixBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sFAnagraficaClientiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.firmwareBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.serialNumbersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.serialNumbersTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SerialNumbersTableAdapter();
            this.sFDistinteBasiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_DistinteBasiTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_DistinteBasiTableAdapter();
            this.firmwareTableAdapter = new SmartLineProduction.ds_SLTableAdapters.FirmwareTableAdapter();
            this.sFArticoliBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_ArticoliTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_ArticoliTableAdapter();
            this.sFArticoliToXSWRBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_ArticoliToXSWRTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_ArticoliToXSWRTableAdapter();
            this.fWClientiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fW_ClientiTableAdapter = new SmartLineProduction.ds_SLTableAdapters.FW_ClientiTableAdapter();
            this.sF_Commesse_SLTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_Commesse_SLTableAdapter();
            this.sF_AnagraficaClientiTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_AnagraficaClientiTableAdapter();
            this.sFItemDeviceFWDesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_ItemDevice_FW_DesTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_ItemDevice_FW_DesTableAdapter();
            this.sFDistinctItemFamFunctionsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_Distinct_Item_Fam_FunctionsTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_Distinct_Item_Fam_FunctionsTableAdapter();
            this.sF_Distinct_Item_Fam_PrefixTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_Distinct_Item_Fam_PrefixTableAdapter();
            this.dtFirmwarelookupCommesseSLBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dt_Firmware_lookupCommesseSLTableAdapter = new SmartLineProduction.ds_SLTableAdapters.dt_Firmware_lookupCommesseSLTableAdapter();
            this.dtTmpProgrammadtFirmwareBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.MainMenu.SuspendLayout();
            this.commandPanel.SuspendLayout();
            this.panel_dt_tmp_programmazione.SuspendLayout();
            this.panel_programmazione_output.SuspendLayout();
            this.tbl_Label_ID.SuspendLayout();
            this.panel_programmazione_grid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_dt_tmp_programmazione)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtTmpProgrammaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            this.pan_tipoprogramma.SuspendLayout();
            this.tab_control_Program.SuspendLayout();
            this.tab_commessa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_commesse)).BeginInit();
            this.grid_commesse_menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sFCommesseSLBindingSource)).BeginInit();
            this.tab_kit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid_Componenti)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grid_Kit)).BeginInit();
            this.tab_item.SuspendLayout();
            this.panel_device_image.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Device_Image)).BeginInit();
            this.tab_libera.SuspendLayout();
            this.pan_titolo.SuspendLayout();
            this.outputPanel.SuspendLayout();
            this.configPanel.SuspendLayout();
            this.Panel_Config_buttons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sFCommesseSLSFArticoliBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFDistinctItemFamPrefixBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFAnagraficaClientiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.firmwareBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.serialNumbersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFDistinteBasiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFArticoliBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFArticoliToXSWRBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fWClientiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFItemDeviceFWDesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFDistinctItemFamFunctionsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtFirmwarelookupCommesseSLBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtTmpProgrammadtFirmwareBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // MainMenu
            // 
            this.MainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uscitaToolStripMenuItem,
            this.nascondiVisualizzaFirmwareToolStripMenuItem,
            this.aggiornaArchiviToolStripMenuItem});
            this.MainMenu.Location = new System.Drawing.Point(20, 60);
            this.MainMenu.Name = "MainMenu";
            this.MainMenu.Size = new System.Drawing.Size(1346, 24);
            this.MainMenu.TabIndex = 70;
            this.MainMenu.Text = "menuStrip1";
            // 
            // uscitaToolStripMenuItem
            // 
            this.uscitaToolStripMenuItem.Name = "uscitaToolStripMenuItem";
            this.uscitaToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.uscitaToolStripMenuItem.Text = "Uscita";
            this.uscitaToolStripMenuItem.Click += new System.EventHandler(this.uscitaToolStripMenuItem_Click);
            // 
            // nascondiVisualizzaFirmwareToolStripMenuItem
            // 
            this.nascondiVisualizzaFirmwareToolStripMenuItem.Name = "nascondiVisualizzaFirmwareToolStripMenuItem";
            this.nascondiVisualizzaFirmwareToolStripMenuItem.Size = new System.Drawing.Size(176, 20);
            this.nascondiVisualizzaFirmwareToolStripMenuItem.Text = "Nascondi/Visualizza Firmware";
            this.nascondiVisualizzaFirmwareToolStripMenuItem.Click += new System.EventHandler(this.nascondiVisualizzaFirmwareToolStripMenuItem_Click);
            // 
            // aggiornaArchiviToolStripMenuItem
            // 
            this.aggiornaArchiviToolStripMenuItem.Name = "aggiornaArchiviToolStripMenuItem";
            this.aggiornaArchiviToolStripMenuItem.Size = new System.Drawing.Size(108, 20);
            this.aggiornaArchiviToolStripMenuItem.Text = "Aggiorna Archivi";
            // 
            // commandPanel
            // 
            this.commandPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.commandPanel.Controls.Add(this.panel_dt_tmp_programmazione);
            this.commandPanel.Controls.Add(this.pan_tipoprogramma);
            this.commandPanel.Controls.Add(this.pan_titolo);
            this.commandPanel.Controls.Add(this.tv_FW);
            this.commandPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.commandPanel.HorizontalScrollbarBarColor = true;
            this.commandPanel.HorizontalScrollbarHighlightOnWheel = false;
            this.commandPanel.HorizontalScrollbarSize = 10;
            this.commandPanel.Location = new System.Drawing.Point(20, 84);
            this.commandPanel.Name = "commandPanel";
            this.commandPanel.Size = new System.Drawing.Size(946, 534);
            this.commandPanel.TabIndex = 71;
            this.commandPanel.VerticalScrollbarBarColor = true;
            this.commandPanel.VerticalScrollbarHighlightOnWheel = false;
            this.commandPanel.VerticalScrollbarSize = 10;
            // 
            // panel_dt_tmp_programmazione
            // 
            this.panel_dt_tmp_programmazione.AutoSize = true;
            this.panel_dt_tmp_programmazione.BackColor = System.Drawing.Color.White;
            this.panel_dt_tmp_programmazione.Controls.Add(this.panel_programmazione_output);
            this.panel_dt_tmp_programmazione.Controls.Add(this.panel_programmazione_result);
            this.panel_dt_tmp_programmazione.Controls.Add(this.panel_programmazione_grid);
            this.panel_dt_tmp_programmazione.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_dt_tmp_programmazione.HorizontalScrollbarBarColor = true;
            this.panel_dt_tmp_programmazione.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_dt_tmp_programmazione.HorizontalScrollbarSize = 10;
            this.panel_dt_tmp_programmazione.Location = new System.Drawing.Point(250, 400);
            this.panel_dt_tmp_programmazione.Name = "panel_dt_tmp_programmazione";
            this.panel_dt_tmp_programmazione.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.panel_dt_tmp_programmazione.Size = new System.Drawing.Size(692, 130);
            this.panel_dt_tmp_programmazione.TabIndex = 7;
            this.panel_dt_tmp_programmazione.UseCustomBackColor = true;
            this.panel_dt_tmp_programmazione.VerticalScrollbarBarColor = true;
            this.panel_dt_tmp_programmazione.VerticalScrollbarHighlightOnWheel = false;
            this.panel_dt_tmp_programmazione.VerticalScrollbarSize = 10;
            // 
            // panel_programmazione_output
            // 
            this.panel_programmazione_output.BackColor = System.Drawing.Color.Gold;
            this.panel_programmazione_output.Controls.Add(this.tbl_Label_ID);
            this.panel_programmazione_output.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_programmazione_output.HorizontalScrollbarBarColor = true;
            this.panel_programmazione_output.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_programmazione_output.HorizontalScrollbarSize = 10;
            this.panel_programmazione_output.Location = new System.Drawing.Point(0, 100);
            this.panel_programmazione_output.Name = "panel_programmazione_output";
            this.panel_programmazione_output.Size = new System.Drawing.Size(692, 30);
            this.panel_programmazione_output.TabIndex = 8;
            this.panel_programmazione_output.VerticalScrollbarBarColor = true;
            this.panel_programmazione_output.VerticalScrollbarHighlightOnWheel = false;
            this.panel_programmazione_output.VerticalScrollbarSize = 10;
            // 
            // tbl_Label_ID
            // 
            this.tbl_Label_ID.ColumnCount = 8;
            this.tbl_Label_ID.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tbl_Label_ID.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tbl_Label_ID.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tbl_Label_ID.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tbl_Label_ID.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tbl_Label_ID.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tbl_Label_ID.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tbl_Label_ID.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tbl_Label_ID.Controls.Add(this.metroLabel6, 5, 0);
            this.tbl_Label_ID.Controls.Add(this.metroLabel5, 4, 0);
            this.tbl_Label_ID.Controls.Add(this.lab_IDNumber_write, 3, 0);
            this.tbl_Label_ID.Controls.Add(this.metroLabel4, 2, 0);
            this.tbl_Label_ID.Controls.Add(this.metroLabel3, 0, 0);
            this.tbl_Label_ID.Controls.Add(this.lab_SN, 7, 0);
            this.tbl_Label_ID.Controls.Add(this.lab_PartNumber, 5, 0);
            this.tbl_Label_ID.Controls.Add(this.lab_IDNumber_read, 1, 0);
            this.tbl_Label_ID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbl_Label_ID.Location = new System.Drawing.Point(0, 0);
            this.tbl_Label_ID.Name = "tbl_Label_ID";
            this.tbl_Label_ID.RowCount = 1;
            this.tbl_Label_ID.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tbl_Label_ID.Size = new System.Drawing.Size(692, 30);
            this.tbl_Label_ID.TabIndex = 5;
            // 
            // metroLabel6
            // 
            this.metroLabel6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel6.Location = new System.Drawing.Point(589, 7);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(83, 15);
            this.metroLabel6.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel6.TabIndex = 15;
            this.metroLabel6.Text = "Serial number:";
            this.metroLabel6.UseCustomBackColor = true;
            this.metroLabel6.UseStyleColors = true;
            // 
            // metroLabel5
            // 
            this.metroLabel5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel5.Location = new System.Drawing.Point(409, 7);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(78, 15);
            this.metroLabel5.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel5.TabIndex = 14;
            this.metroLabel5.Text = "Part Number:";
            this.metroLabel5.UseCustomBackColor = true;
            this.metroLabel5.UseStyleColors = true;
            // 
            // lab_IDNumber_write
            // 
            this.lab_IDNumber_write.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab_IDNumber_write.AutoSize = true;
            this.lab_IDNumber_write.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lab_IDNumber_write.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_IDNumber_write.Location = new System.Drawing.Point(281, 7);
            this.lab_IDNumber_write.Name = "lab_IDNumber_write";
            this.lab_IDNumber_write.Size = new System.Drawing.Size(122, 15);
            this.lab_IDNumber_write.Style = MetroFramework.MetroColorStyle.Blue;
            this.lab_IDNumber_write.TabIndex = 13;
            this.lab_IDNumber_write.Text = "lab_IDNumber_write";
            this.lab_IDNumber_write.UseCustomBackColor = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(198, 7);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(77, 15);
            this.metroLabel4.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel4.TabIndex = 12;
            this.metroLabel4.Text = "ID codificato:";
            this.metroLabel4.UseCustomBackColor = true;
            this.metroLabel4.UseStyleColors = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Location = new System.Drawing.Point(3, 7);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(66, 15);
            this.metroLabel3.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel3.TabIndex = 11;
            this.metroLabel3.Text = "ID del chip:";
            this.metroLabel3.UseCustomBackColor = true;
            this.metroLabel3.UseStyleColors = true;
            // 
            // lab_SN
            // 
            this.lab_SN.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab_SN.AutoSize = true;
            this.lab_SN.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lab_SN.Location = new System.Drawing.Point(678, 7);
            this.lab_SN.Name = "lab_SN";
            this.lab_SN.Size = new System.Drawing.Size(42, 15);
            this.lab_SN.TabIndex = 4;
            this.lab_SN.Text = "lab_SN";
            this.lab_SN.UseCustomBackColor = true;
            // 
            // lab_PartNumber
            // 
            this.lab_PartNumber.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab_PartNumber.AutoSize = true;
            this.lab_PartNumber.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lab_PartNumber.Location = new System.Drawing.Point(493, 7);
            this.lab_PartNumber.Name = "lab_PartNumber";
            this.lab_PartNumber.Size = new System.Drawing.Size(90, 15);
            this.lab_PartNumber.TabIndex = 3;
            this.lab_PartNumber.Text = "lab_PartNumber";
            this.lab_PartNumber.UseCustomBackColor = true;
            // 
            // lab_IDNumber_read
            // 
            this.lab_IDNumber_read.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lab_IDNumber_read.AutoSize = true;
            this.lab_IDNumber_read.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lab_IDNumber_read.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_IDNumber_read.Location = new System.Drawing.Point(75, 7);
            this.lab_IDNumber_read.Name = "lab_IDNumber_read";
            this.lab_IDNumber_read.Size = new System.Drawing.Size(117, 15);
            this.lab_IDNumber_read.Style = MetroFramework.MetroColorStyle.Blue;
            this.lab_IDNumber_read.TabIndex = 2;
            this.lab_IDNumber_read.Text = "lab_IDNumber_read";
            this.lab_IDNumber_read.UseCustomBackColor = true;
            // 
            // panel_programmazione_result
            // 
            this.panel_programmazione_result.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_programmazione_result.HorizontalScrollbarBarColor = true;
            this.panel_programmazione_result.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_programmazione_result.HorizontalScrollbarSize = 10;
            this.panel_programmazione_result.Location = new System.Drawing.Point(0, 100);
            this.panel_programmazione_result.Name = "panel_programmazione_result";
            this.panel_programmazione_result.Size = new System.Drawing.Size(692, 30);
            this.panel_programmazione_result.TabIndex = 7;
            this.panel_programmazione_result.UseCustomBackColor = true;
            this.panel_programmazione_result.VerticalScrollbarBarColor = true;
            this.panel_programmazione_result.VerticalScrollbarHighlightOnWheel = false;
            this.panel_programmazione_result.VerticalScrollbarSize = 10;
            // 
            // panel_programmazione_grid
            // 
            this.panel_programmazione_grid.Controls.Add(this.dg_dt_tmp_programmazione);
            this.panel_programmazione_grid.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_programmazione_grid.HorizontalScrollbarBarColor = true;
            this.panel_programmazione_grid.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_programmazione_grid.HorizontalScrollbarSize = 10;
            this.panel_programmazione_grid.Location = new System.Drawing.Point(0, 10);
            this.panel_programmazione_grid.Name = "panel_programmazione_grid";
            this.panel_programmazione_grid.Size = new System.Drawing.Size(692, 90);
            this.panel_programmazione_grid.TabIndex = 7;
            this.panel_programmazione_grid.VerticalScrollbarBarColor = true;
            this.panel_programmazione_grid.VerticalScrollbarHighlightOnWheel = false;
            this.panel_programmazione_grid.VerticalScrollbarSize = 10;
            // 
            // dg_dt_tmp_programmazione
            // 
            this.dg_dt_tmp_programmazione.AllowUserToAddRows = false;
            this.dg_dt_tmp_programmazione.AllowUserToDeleteRows = false;
            this.dg_dt_tmp_programmazione.AllowUserToResizeRows = false;
            this.dg_dt_tmp_programmazione.AutoGenerateColumns = false;
            this.dg_dt_tmp_programmazione.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dg_dt_tmp_programmazione.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dg_dt_tmp_programmazione.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dg_dt_tmp_programmazione.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(177)))), ((int)(((byte)(89)))));
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(191)))), ((int)(((byte)(96)))));
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dg_dt_tmp_programmazione.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.dg_dt_tmp_programmazione.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_dt_tmp_programmazione.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dg_dt_tmp_progr_Id,
            this.dg_dt_tmp_progr_Commessa,
            this.dg_dt_tmp_progr_Kit,
            this.dg_dt_tmp_progr_Device,
            this.dg_dt_tmp_progr_Fw,
            this.dg_dt_tmp_progr_FwKeyId,
            this.dg_dt_tmp_progr_ID_Hardware,
            this.Programma,
            this.tmpfwkeyidDataGridViewTextBoxColumn,
            this.tmpIDHardwareDataGridViewTextBoxColumn});
            this.dg_dt_tmp_programmazione.DataSource = this.dtTmpProgrammaBindingSource;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(191)))), ((int)(((byte)(96)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dg_dt_tmp_programmazione.DefaultCellStyle = dataGridViewCellStyle18;
            this.dg_dt_tmp_programmazione.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dg_dt_tmp_programmazione.EnableHeadersVisualStyles = false;
            this.dg_dt_tmp_programmazione.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dg_dt_tmp_programmazione.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dg_dt_tmp_programmazione.HighLightPercentage = 0.1F;
            this.dg_dt_tmp_programmazione.Location = new System.Drawing.Point(0, 0);
            this.dg_dt_tmp_programmazione.MultiSelect = false;
            this.dg_dt_tmp_programmazione.Name = "dg_dt_tmp_programmazione";
            this.dg_dt_tmp_programmazione.ReadOnly = true;
            this.dg_dt_tmp_programmazione.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(177)))), ((int)(((byte)(89)))));
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(191)))), ((int)(((byte)(96)))));
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dg_dt_tmp_programmazione.RowHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.dg_dt_tmp_programmazione.RowHeadersVisible = false;
            this.dg_dt_tmp_programmazione.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dg_dt_tmp_programmazione.RowTemplate.Height = 32;
            this.dg_dt_tmp_programmazione.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg_dt_tmp_programmazione.Size = new System.Drawing.Size(692, 90);
            this.dg_dt_tmp_programmazione.Style = MetroFramework.MetroColorStyle.Green;
            this.dg_dt_tmp_programmazione.TabIndex = 6;
            this.dg_dt_tmp_programmazione.UseCustomBackColor = true;
            this.dg_dt_tmp_programmazione.UseCustomForeColor = true;
            this.dg_dt_tmp_programmazione.UseStyleColors = true;
            this.dg_dt_tmp_programmazione.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_dt_tmp_programmazione_CellContentClick);
            // 
            // dg_dt_tmp_progr_Id
            // 
            this.dg_dt_tmp_progr_Id.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dg_dt_tmp_progr_Id.DataPropertyName = "tmp_prog_id";
            this.dg_dt_tmp_progr_Id.HeaderText = "tmp_prog_id";
            this.dg_dt_tmp_progr_Id.Name = "dg_dt_tmp_progr_Id";
            this.dg_dt_tmp_progr_Id.ReadOnly = true;
            this.dg_dt_tmp_progr_Id.Visible = false;
            // 
            // dg_dt_tmp_progr_Commessa
            // 
            this.dg_dt_tmp_progr_Commessa.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dg_dt_tmp_progr_Commessa.DataPropertyName = "tmp_prog_commessa";
            this.dg_dt_tmp_progr_Commessa.HeaderText = "Commessa";
            this.dg_dt_tmp_progr_Commessa.Name = "dg_dt_tmp_progr_Commessa";
            this.dg_dt_tmp_progr_Commessa.ReadOnly = true;
            this.dg_dt_tmp_progr_Commessa.Width = 84;
            // 
            // dg_dt_tmp_progr_Kit
            // 
            this.dg_dt_tmp_progr_Kit.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dg_dt_tmp_progr_Kit.DataPropertyName = "tmp_prog_codart_kit";
            this.dg_dt_tmp_progr_Kit.HeaderText = "Codice Kit";
            this.dg_dt_tmp_progr_Kit.Name = "dg_dt_tmp_progr_Kit";
            this.dg_dt_tmp_progr_Kit.ReadOnly = true;
            this.dg_dt_tmp_progr_Kit.Width = 75;
            // 
            // dg_dt_tmp_progr_Device
            // 
            this.dg_dt_tmp_progr_Device.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dg_dt_tmp_progr_Device.DataPropertyName = "tmp_prog_codart_item";
            this.dg_dt_tmp_progr_Device.HeaderText = "Codice Device";
            this.dg_dt_tmp_progr_Device.Name = "dg_dt_tmp_progr_Device";
            this.dg_dt_tmp_progr_Device.ReadOnly = true;
            this.dg_dt_tmp_progr_Device.Width = 93;
            // 
            // dg_dt_tmp_progr_Fw
            // 
            this.dg_dt_tmp_progr_Fw.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dg_dt_tmp_progr_Fw.DataPropertyName = "tmp_prog_codart_fw";
            this.dg_dt_tmp_progr_Fw.HeaderText = "Firmware";
            this.dg_dt_tmp_progr_Fw.Name = "dg_dt_tmp_progr_Fw";
            this.dg_dt_tmp_progr_Fw.ReadOnly = true;
            this.dg_dt_tmp_progr_Fw.Width = 77;
            // 
            // dg_dt_tmp_progr_FwKeyId
            // 
            this.dg_dt_tmp_progr_FwKeyId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dg_dt_tmp_progr_FwKeyId.DataPropertyName = "tmp_fw_key_id";
            this.dg_dt_tmp_progr_FwKeyId.HeaderText = "tmp_fw_key_id";
            this.dg_dt_tmp_progr_FwKeyId.Name = "dg_dt_tmp_progr_FwKeyId";
            this.dg_dt_tmp_progr_FwKeyId.ReadOnly = true;
            this.dg_dt_tmp_progr_FwKeyId.Visible = false;
            // 
            // dg_dt_tmp_progr_ID_Hardware
            // 
            this.dg_dt_tmp_progr_ID_Hardware.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dg_dt_tmp_progr_ID_Hardware.DataPropertyName = "tmp_ID_Hardware";
            this.dg_dt_tmp_progr_ID_Hardware.HeaderText = "ID Hardware";
            this.dg_dt_tmp_progr_ID_Hardware.Name = "dg_dt_tmp_progr_ID_Hardware";
            this.dg_dt_tmp_progr_ID_Hardware.ReadOnly = true;
            this.dg_dt_tmp_progr_ID_Hardware.Width = 86;
            // 
            // Programma
            // 
            this.Programma.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Programma.HeaderText = "Esegui Programmazione";
            this.Programma.Name = "Programma";
            this.Programma.ReadOnly = true;
            this.Programma.Text = "Programma ->";
            this.Programma.UseColumnTextForButtonValue = true;
            // 
            // tmpfwkeyidDataGridViewTextBoxColumn
            // 
            this.tmpfwkeyidDataGridViewTextBoxColumn.DataPropertyName = "tmp_fw_key_id";
            this.tmpfwkeyidDataGridViewTextBoxColumn.HeaderText = "tmp_fw_key_id";
            this.tmpfwkeyidDataGridViewTextBoxColumn.Name = "tmpfwkeyidDataGridViewTextBoxColumn";
            this.tmpfwkeyidDataGridViewTextBoxColumn.ReadOnly = true;
            this.tmpfwkeyidDataGridViewTextBoxColumn.Visible = false;
            // 
            // tmpIDHardwareDataGridViewTextBoxColumn
            // 
            this.tmpIDHardwareDataGridViewTextBoxColumn.DataPropertyName = "tmp_ID_Hardware";
            this.tmpIDHardwareDataGridViewTextBoxColumn.HeaderText = "tmp_ID_Hardware";
            this.tmpIDHardwareDataGridViewTextBoxColumn.Name = "tmpIDHardwareDataGridViewTextBoxColumn";
            this.tmpIDHardwareDataGridViewTextBoxColumn.ReadOnly = true;
            this.tmpIDHardwareDataGridViewTextBoxColumn.Visible = false;
            // 
            // dtTmpProgrammaBindingSource
            // 
            this.dtTmpProgrammaBindingSource.DataMember = "dt_Tmp_Programma";
            this.dtTmpProgrammaBindingSource.DataSource = this.ds_SL;
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pan_tipoprogramma
            // 
            this.pan_tipoprogramma.Controls.Add(this.tab_control_Program);
            this.pan_tipoprogramma.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_tipoprogramma.HorizontalScrollbarBarColor = true;
            this.pan_tipoprogramma.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_tipoprogramma.HorizontalScrollbarSize = 10;
            this.pan_tipoprogramma.Location = new System.Drawing.Point(250, 30);
            this.pan_tipoprogramma.Name = "pan_tipoprogramma";
            this.pan_tipoprogramma.Size = new System.Drawing.Size(692, 500);
            this.pan_tipoprogramma.TabIndex = 6;
            this.pan_tipoprogramma.VerticalScrollbarBarColor = true;
            this.pan_tipoprogramma.VerticalScrollbarHighlightOnWheel = false;
            this.pan_tipoprogramma.VerticalScrollbarSize = 10;
            // 
            // tab_control_Program
            // 
            this.tab_control_Program.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tab_control_Program.Controls.Add(this.tab_commessa);
            this.tab_control_Program.Controls.Add(this.tab_kit);
            this.tab_control_Program.Controls.Add(this.tab_item);
            this.tab_control_Program.Controls.Add(this.tab_libera);
            this.tab_control_Program.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab_control_Program.Location = new System.Drawing.Point(0, 0);
            this.tab_control_Program.Name = "tab_control_Program";
            this.tab_control_Program.SelectedIndex = 2;
            this.tab_control_Program.Size = new System.Drawing.Size(692, 500);
            this.tab_control_Program.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tab_control_Program.Style = MetroFramework.MetroColorStyle.Red;
            this.tab_control_Program.TabIndex = 2;
            this.tab_control_Program.UseSelectable = true;
            this.tab_control_Program.UseStyleColors = true;
            this.tab_control_Program.Selected += new System.Windows.Forms.TabControlEventHandler(this.tab_control_Program_Selected);
            // 
            // tab_commessa
            // 
            this.tab_commessa.BackColor = System.Drawing.Color.AliceBlue;
            this.tab_commessa.Controls.Add(this.grid_commesse);
            this.tab_commessa.HorizontalScrollbarBarColor = true;
            this.tab_commessa.HorizontalScrollbarHighlightOnWheel = false;
            this.tab_commessa.HorizontalScrollbarSize = 10;
            this.tab_commessa.Location = new System.Drawing.Point(4, 41);
            this.tab_commessa.Name = "tab_commessa";
            this.tab_commessa.Padding = new System.Windows.Forms.Padding(5);
            this.tab_commessa.Size = new System.Drawing.Size(684, 455);
            this.tab_commessa.Style = MetroFramework.MetroColorStyle.Red;
            this.tab_commessa.TabIndex = 0;
            this.tab_commessa.Text = "Commessa";
            this.tab_commessa.UseCustomBackColor = true;
            this.tab_commessa.UseStyleColors = true;
            this.tab_commessa.VerticalScrollbarBarColor = true;
            this.tab_commessa.VerticalScrollbarHighlightOnWheel = false;
            this.tab_commessa.VerticalScrollbarSize = 10;
            // 
            // grid_commesse
            // 
            this.grid_commesse.AllowUserToAddRows = false;
            this.grid_commesse.AllowUserToDeleteRows = false;
            this.grid_commesse.AllowUserToResizeRows = false;
            this.grid_commesse.AutoGenerateColumns = false;
            this.grid_commesse.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_commesse.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.grid_commesse.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.grid_commesse.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_commesse.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle20;
            this.grid_commesse.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid_commesse.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.grid_commesse_CommessaShort,
            this.grid_commesse_DataConsegna,
            this.grid_commesse_RagioneSociale,
            this.grid_commesse_NumRiga,
            this.grid_commesse_CodArticoloCommessa,
            this.grid_commesse_Device,
            this.grid_commesse_QtaDaEvadere,
            this.grid_commesse_Qta_Evasa,
            this.grid_commesse_TipoOrdine,
            this.grid_commesse_CommessaLong,
            this.grid_commesse_DataOrdine,
            this.grid_commesse_NumeroOrdine,
            this.grid_commesse_UM,
            this.grid_commesse_TipoRiga,
            this.grid_commesse_IsSwrP,
            this.grid_commesse_IsSwrR,
            this.grid_commesse_SwDevice,
            this.grid_commesse_CodAnagrafico,
            this.grid_commesse_QtaOrdinata,
            this.grid_commesse_StatoCommessa,
            this.grid_commesse_IsKit,
            this.grid_commesse_DataFineValidita,
            this.grid_commesse_ViewDevice,
            this.grid_commesse_CommessaSelezionata,
            this.dataConfermaConsegnaDataGridViewTextBoxColumn,
            this.numeroRigaDataGridViewTextBoxColumn,
            this.artCommessaDataGridViewTextBoxColumn,
            this.qtadaEvadereDataGridViewTextBoxColumn,
            this.deviceDataGridViewTextBoxColumn});
            this.grid_commesse.ContextMenuStrip = this.grid_commesse_menu;
            this.grid_commesse.DataSource = this.sFCommesseSLBindingSource;
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grid_commesse.DefaultCellStyle = dataGridViewCellStyle25;
            this.grid_commesse.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid_commesse.EnableHeadersVisualStyles = false;
            this.grid_commesse.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.grid_commesse.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_commesse.Location = new System.Drawing.Point(5, 5);
            this.grid_commesse.MultiSelect = false;
            this.grid_commesse.Name = "grid_commesse";
            this.grid_commesse.ReadOnly = true;
            this.grid_commesse.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_commesse.RowHeadersDefaultCellStyle = dataGridViewCellStyle26;
            this.grid_commesse.RowHeadersVisible = false;
            this.grid_commesse.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.grid_commesse.RowTemplate.Height = 25;
            this.grid_commesse.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid_commesse.Size = new System.Drawing.Size(674, 445);
            this.grid_commesse.Style = MetroFramework.MetroColorStyle.Red;
            this.grid_commesse.TabIndex = 2;
            this.grid_commesse.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grid_commesse_CellContentClick);
            this.grid_commesse.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.grid_commesse_CellPainting);
            // 
            // grid_commesse_CommessaShort
            // 
            this.grid_commesse_CommessaShort.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.grid_commesse_CommessaShort.DataPropertyName = "CommessaShort";
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.grid_commesse_CommessaShort.DefaultCellStyle = dataGridViewCellStyle21;
            this.grid_commesse_CommessaShort.HeaderText = "Commessa";
            this.grid_commesse_CommessaShort.Name = "grid_commesse_CommessaShort";
            this.grid_commesse_CommessaShort.ReadOnly = true;
            this.grid_commesse_CommessaShort.Width = 84;
            // 
            // grid_commesse_DataConsegna
            // 
            this.grid_commesse_DataConsegna.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.grid_commesse_DataConsegna.DataPropertyName = "Data_Conferma_Consegna";
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.grid_commesse_DataConsegna.DefaultCellStyle = dataGridViewCellStyle22;
            this.grid_commesse_DataConsegna.HeaderText = "Data Consegna";
            this.grid_commesse_DataConsegna.Name = "grid_commesse_DataConsegna";
            this.grid_commesse_DataConsegna.ReadOnly = true;
            // 
            // grid_commesse_RagioneSociale
            // 
            this.grid_commesse_RagioneSociale.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.grid_commesse_RagioneSociale.DataPropertyName = "Ragione_Sociale";
            this.grid_commesse_RagioneSociale.HeaderText = "Ragione Sociale";
            this.grid_commesse_RagioneSociale.Name = "grid_commesse_RagioneSociale";
            this.grid_commesse_RagioneSociale.ReadOnly = true;
            // 
            // grid_commesse_NumRiga
            // 
            this.grid_commesse_NumRiga.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.grid_commesse_NumRiga.DataPropertyName = "Numero_Riga";
            this.grid_commesse_NumRiga.HeaderText = "Riga n.";
            this.grid_commesse_NumRiga.Name = "grid_commesse_NumRiga";
            this.grid_commesse_NumRiga.ReadOnly = true;
            this.grid_commesse_NumRiga.Visible = false;
            // 
            // grid_commesse_CodArticoloCommessa
            // 
            this.grid_commesse_CodArticoloCommessa.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.grid_commesse_CodArticoloCommessa.DataPropertyName = "Art_Commessa";
            this.grid_commesse_CodArticoloCommessa.HeaderText = "Codice Articolo";
            this.grid_commesse_CodArticoloCommessa.Name = "grid_commesse_CodArticoloCommessa";
            this.grid_commesse_CodArticoloCommessa.ReadOnly = true;
            this.grid_commesse_CodArticoloCommessa.Width = 99;
            // 
            // grid_commesse_Device
            // 
            this.grid_commesse_Device.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.grid_commesse_Device.DataPropertyName = "Device";
            this.grid_commesse_Device.HeaderText = "Device";
            this.grid_commesse_Device.Name = "grid_commesse_Device";
            this.grid_commesse_Device.ReadOnly = true;
            this.grid_commesse_Device.Width = 63;
            // 
            // grid_commesse_QtaDaEvadere
            // 
            this.grid_commesse_QtaDaEvadere.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.grid_commesse_QtaDaEvadere.DataPropertyName = "Qta_da_Evadere";
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle23.Format = "N0";
            dataGridViewCellStyle23.NullValue = null;
            this.grid_commesse_QtaDaEvadere.DefaultCellStyle = dataGridViewCellStyle23;
            this.grid_commesse_QtaDaEvadere.HeaderText = "Q.tà da evadere";
            this.grid_commesse_QtaDaEvadere.Name = "grid_commesse_QtaDaEvadere";
            this.grid_commesse_QtaDaEvadere.ReadOnly = true;
            this.grid_commesse_QtaDaEvadere.Width = 101;
            // 
            // grid_commesse_Qta_Evasa
            // 
            this.grid_commesse_Qta_Evasa.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.grid_commesse_Qta_Evasa.DataPropertyName = "Qta_Evasa";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.grid_commesse_Qta_Evasa.DefaultCellStyle = dataGridViewCellStyle24;
            this.grid_commesse_Qta_Evasa.HeaderText = "Q.tà Evasa";
            this.grid_commesse_Qta_Evasa.Name = "grid_commesse_Qta_Evasa";
            this.grid_commesse_Qta_Evasa.ReadOnly = true;
            this.grid_commesse_Qta_Evasa.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_commesse_Qta_Evasa.Width = 76;
            // 
            // grid_commesse_TipoOrdine
            // 
            this.grid_commesse_TipoOrdine.DataPropertyName = "TipoOrdine";
            this.grid_commesse_TipoOrdine.HeaderText = "TipoOrdine";
            this.grid_commesse_TipoOrdine.Name = "grid_commesse_TipoOrdine";
            this.grid_commesse_TipoOrdine.ReadOnly = true;
            this.grid_commesse_TipoOrdine.Visible = false;
            // 
            // grid_commesse_CommessaLong
            // 
            this.grid_commesse_CommessaLong.DataPropertyName = "CommessaLong";
            this.grid_commesse_CommessaLong.HeaderText = "CommessaLong";
            this.grid_commesse_CommessaLong.Name = "grid_commesse_CommessaLong";
            this.grid_commesse_CommessaLong.ReadOnly = true;
            this.grid_commesse_CommessaLong.Visible = false;
            // 
            // grid_commesse_DataOrdine
            // 
            this.grid_commesse_DataOrdine.DataPropertyName = "Data_Ordine";
            this.grid_commesse_DataOrdine.HeaderText = "Data_Ordine";
            this.grid_commesse_DataOrdine.Name = "grid_commesse_DataOrdine";
            this.grid_commesse_DataOrdine.ReadOnly = true;
            this.grid_commesse_DataOrdine.Visible = false;
            // 
            // grid_commesse_NumeroOrdine
            // 
            this.grid_commesse_NumeroOrdine.DataPropertyName = "Numero_Ordine";
            this.grid_commesse_NumeroOrdine.HeaderText = "Numero_Ordine";
            this.grid_commesse_NumeroOrdine.Name = "grid_commesse_NumeroOrdine";
            this.grid_commesse_NumeroOrdine.ReadOnly = true;
            this.grid_commesse_NumeroOrdine.Visible = false;
            // 
            // grid_commesse_UM
            // 
            this.grid_commesse_UM.DataPropertyName = "UM";
            this.grid_commesse_UM.HeaderText = "UM";
            this.grid_commesse_UM.Name = "grid_commesse_UM";
            this.grid_commesse_UM.ReadOnly = true;
            this.grid_commesse_UM.Visible = false;
            // 
            // grid_commesse_TipoRiga
            // 
            this.grid_commesse_TipoRiga.DataPropertyName = "TipoRiga";
            this.grid_commesse_TipoRiga.HeaderText = "TipoRiga";
            this.grid_commesse_TipoRiga.Name = "grid_commesse_TipoRiga";
            this.grid_commesse_TipoRiga.ReadOnly = true;
            this.grid_commesse_TipoRiga.Visible = false;
            // 
            // grid_commesse_IsSwrP
            // 
            this.grid_commesse_IsSwrP.DataPropertyName = "Is_SWR_P";
            this.grid_commesse_IsSwrP.HeaderText = "Is_SWR_P";
            this.grid_commesse_IsSwrP.Name = "grid_commesse_IsSwrP";
            this.grid_commesse_IsSwrP.ReadOnly = true;
            this.grid_commesse_IsSwrP.Visible = false;
            // 
            // grid_commesse_IsSwrR
            // 
            this.grid_commesse_IsSwrR.DataPropertyName = "Is_SWR_R";
            this.grid_commesse_IsSwrR.HeaderText = "Is_SWR_R";
            this.grid_commesse_IsSwrR.Name = "grid_commesse_IsSwrR";
            this.grid_commesse_IsSwrR.ReadOnly = true;
            this.grid_commesse_IsSwrR.Visible = false;
            // 
            // grid_commesse_SwDevice
            // 
            this.grid_commesse_SwDevice.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.grid_commesse_SwDevice.DataPropertyName = "SW_Device";
            this.grid_commesse_SwDevice.HeaderText = "Fw Device";
            this.grid_commesse_SwDevice.Name = "grid_commesse_SwDevice";
            this.grid_commesse_SwDevice.ReadOnly = true;
            this.grid_commesse_SwDevice.Visible = false;
            // 
            // grid_commesse_CodAnagrafico
            // 
            this.grid_commesse_CodAnagrafico.DataPropertyName = "CodAnagrafico";
            this.grid_commesse_CodAnagrafico.HeaderText = "CodAnagrafico";
            this.grid_commesse_CodAnagrafico.Name = "grid_commesse_CodAnagrafico";
            this.grid_commesse_CodAnagrafico.ReadOnly = true;
            this.grid_commesse_CodAnagrafico.Visible = false;
            // 
            // grid_commesse_QtaOrdinata
            // 
            this.grid_commesse_QtaOrdinata.DataPropertyName = "Qta_Ordinata";
            this.grid_commesse_QtaOrdinata.HeaderText = "Qta_Ordinata";
            this.grid_commesse_QtaOrdinata.Name = "grid_commesse_QtaOrdinata";
            this.grid_commesse_QtaOrdinata.ReadOnly = true;
            this.grid_commesse_QtaOrdinata.Visible = false;
            // 
            // grid_commesse_StatoCommessa
            // 
            this.grid_commesse_StatoCommessa.DataPropertyName = "StatoCommessa";
            this.grid_commesse_StatoCommessa.HeaderText = "StatoCommessa";
            this.grid_commesse_StatoCommessa.Name = "grid_commesse_StatoCommessa";
            this.grid_commesse_StatoCommessa.ReadOnly = true;
            this.grid_commesse_StatoCommessa.Visible = false;
            // 
            // grid_commesse_IsKit
            // 
            this.grid_commesse_IsKit.DataPropertyName = "Is_Kit";
            this.grid_commesse_IsKit.HeaderText = "Is_Kit";
            this.grid_commesse_IsKit.Name = "grid_commesse_IsKit";
            this.grid_commesse_IsKit.ReadOnly = true;
            this.grid_commesse_IsKit.Visible = false;
            // 
            // grid_commesse_DataFineValidita
            // 
            this.grid_commesse_DataFineValidita.DataPropertyName = "DataFineValidita";
            this.grid_commesse_DataFineValidita.HeaderText = "DataFineValidita";
            this.grid_commesse_DataFineValidita.Name = "grid_commesse_DataFineValidita";
            this.grid_commesse_DataFineValidita.ReadOnly = true;
            this.grid_commesse_DataFineValidita.Visible = false;
            // 
            // grid_commesse_ViewDevice
            // 
            this.grid_commesse_ViewDevice.HeaderText = "Vedi";
            this.grid_commesse_ViewDevice.Name = "grid_commesse_ViewDevice";
            this.grid_commesse_ViewDevice.ReadOnly = true;
            this.grid_commesse_ViewDevice.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_commesse_ViewDevice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.grid_commesse_ViewDevice.Width = 30;
            // 
            // grid_commesse_CommessaSelezionata
            // 
            this.grid_commesse_CommessaSelezionata.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.grid_commesse_CommessaSelezionata.HeaderText = "Seleziona";
            this.grid_commesse_CommessaSelezionata.Name = "grid_commesse_CommessaSelezionata";
            this.grid_commesse_CommessaSelezionata.ReadOnly = true;
            this.grid_commesse_CommessaSelezionata.Text = "Evadi  ->";
            this.grid_commesse_CommessaSelezionata.UseColumnTextForButtonValue = true;
            this.grid_commesse_CommessaSelezionata.Width = 60;
            // 
            // dataConfermaConsegnaDataGridViewTextBoxColumn
            // 
            this.dataConfermaConsegnaDataGridViewTextBoxColumn.DataPropertyName = "Data_Conferma_Consegna";
            this.dataConfermaConsegnaDataGridViewTextBoxColumn.HeaderText = "Data_Conferma_Consegna";
            this.dataConfermaConsegnaDataGridViewTextBoxColumn.Name = "dataConfermaConsegnaDataGridViewTextBoxColumn";
            this.dataConfermaConsegnaDataGridViewTextBoxColumn.ReadOnly = true;
            this.dataConfermaConsegnaDataGridViewTextBoxColumn.Visible = false;
            // 
            // numeroRigaDataGridViewTextBoxColumn
            // 
            this.numeroRigaDataGridViewTextBoxColumn.DataPropertyName = "Numero_Riga";
            this.numeroRigaDataGridViewTextBoxColumn.HeaderText = "Numero_Riga";
            this.numeroRigaDataGridViewTextBoxColumn.Name = "numeroRigaDataGridViewTextBoxColumn";
            this.numeroRigaDataGridViewTextBoxColumn.ReadOnly = true;
            this.numeroRigaDataGridViewTextBoxColumn.Visible = false;
            // 
            // artCommessaDataGridViewTextBoxColumn
            // 
            this.artCommessaDataGridViewTextBoxColumn.DataPropertyName = "Art_Commessa";
            this.artCommessaDataGridViewTextBoxColumn.HeaderText = "Art_Commessa";
            this.artCommessaDataGridViewTextBoxColumn.Name = "artCommessaDataGridViewTextBoxColumn";
            this.artCommessaDataGridViewTextBoxColumn.ReadOnly = true;
            this.artCommessaDataGridViewTextBoxColumn.Visible = false;
            // 
            // qtadaEvadereDataGridViewTextBoxColumn
            // 
            this.qtadaEvadereDataGridViewTextBoxColumn.DataPropertyName = "Qta_da_Evadere";
            this.qtadaEvadereDataGridViewTextBoxColumn.HeaderText = "Qta_da_Evadere";
            this.qtadaEvadereDataGridViewTextBoxColumn.Name = "qtadaEvadereDataGridViewTextBoxColumn";
            this.qtadaEvadereDataGridViewTextBoxColumn.ReadOnly = true;
            this.qtadaEvadereDataGridViewTextBoxColumn.Visible = false;
            // 
            // deviceDataGridViewTextBoxColumn
            // 
            this.deviceDataGridViewTextBoxColumn.DataPropertyName = "Device";
            this.deviceDataGridViewTextBoxColumn.HeaderText = "Device";
            this.deviceDataGridViewTextBoxColumn.Name = "deviceDataGridViewTextBoxColumn";
            this.deviceDataGridViewTextBoxColumn.ReadOnly = true;
            this.deviceDataGridViewTextBoxColumn.Visible = false;
            // 
            // grid_commesse_menu
            // 
            this.grid_commesse_menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_commesse_vis,
            this.menu_commesse_nas});
            this.grid_commesse_menu.Name = "grid_commesse_menu";
            this.grid_commesse_menu.Size = new System.Drawing.Size(229, 48);
            this.grid_commesse_menu.Style = MetroFramework.MetroColorStyle.Red;
            this.grid_commesse_menu.Opened += new System.EventHandler(this.grid_commesse_menu_Opened);
            this.grid_commesse_menu.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.grid_commesse_menu_ItemClicked);
            this.grid_commesse_menu.Click += new System.EventHandler(this.grid_commesse_menu_Click);
            // 
            // menu_commesse_vis
            // 
            this.menu_commesse_vis.Name = "menu_commesse_vis";
            this.menu_commesse_vis.Size = new System.Drawing.Size(228, 22);
            this.menu_commesse_vis.Text = "Visualizza le commesse evase";
            // 
            // menu_commesse_nas
            // 
            this.menu_commesse_nas.Name = "menu_commesse_nas";
            this.menu_commesse_nas.Size = new System.Drawing.Size(228, 22);
            this.menu_commesse_nas.Text = "Nascondi le commesse evase";
            // 
            // sFCommesseSLBindingSource
            // 
            this.sFCommesseSLBindingSource.DataMember = "SF_Commesse_SL";
            this.sFCommesseSLBindingSource.DataSource = this.ds_SL;
            // 
            // tab_kit
            // 
            this.tab_kit.AutoScroll = true;
            this.tab_kit.BackColor = System.Drawing.Color.AntiqueWhite;
            this.tab_kit.Controls.Add(this.grid_Componenti);
            this.tab_kit.Controls.Add(this.grid_Kit);
            this.tab_kit.HorizontalScrollbar = true;
            this.tab_kit.HorizontalScrollbarBarColor = true;
            this.tab_kit.HorizontalScrollbarHighlightOnWheel = false;
            this.tab_kit.HorizontalScrollbarSize = 10;
            this.tab_kit.Location = new System.Drawing.Point(4, 41);
            this.tab_kit.Name = "tab_kit";
            this.tab_kit.Size = new System.Drawing.Size(684, 455);
            this.tab_kit.TabIndex = 1;
            this.tab_kit.Text = "Kit";
            this.tab_kit.UseCustomBackColor = true;
            this.tab_kit.VerticalScrollbar = true;
            this.tab_kit.VerticalScrollbarBarColor = true;
            this.tab_kit.VerticalScrollbarHighlightOnWheel = false;
            this.tab_kit.VerticalScrollbarSize = 10;
            // 
            // grid_Componenti
            // 
            this.grid_Componenti.AllowUserToAddRows = false;
            this.grid_Componenti.AllowUserToDeleteRows = false;
            this.grid_Componenti.AllowUserToResizeRows = false;
            this.grid_Componenti.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_Componenti.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.grid_Componenti.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.grid_Componenti.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_Componenti.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.grid_Componenti.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grid_Componenti.DefaultCellStyle = dataGridViewCellStyle9;
            this.grid_Componenti.Dock = System.Windows.Forms.DockStyle.Left;
            this.grid_Componenti.EnableHeadersVisualStyles = false;
            this.grid_Componenti.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.grid_Componenti.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_Componenti.Location = new System.Drawing.Point(240, 0);
            this.grid_Componenti.Name = "grid_Componenti";
            this.grid_Componenti.ReadOnly = true;
            this.grid_Componenti.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_Componenti.RowHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.grid_Componenti.RowHeadersVisible = false;
            this.grid_Componenti.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.grid_Componenti.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid_Componenti.Size = new System.Drawing.Size(240, 455);
            this.grid_Componenti.Style = MetroFramework.MetroColorStyle.Orange;
            this.grid_Componenti.TabIndex = 4;
            this.grid_Componenti.UseStyleColors = true;
            // 
            // grid_Kit
            // 
            this.grid_Kit.AllowUserToAddRows = false;
            this.grid_Kit.AllowUserToDeleteRows = false;
            this.grid_Kit.AllowUserToResizeRows = false;
            this.grid_Kit.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_Kit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.grid_Kit.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.grid_Kit.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_Kit.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.grid_Kit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grid_Kit.DefaultCellStyle = dataGridViewCellStyle28;
            this.grid_Kit.Dock = System.Windows.Forms.DockStyle.Left;
            this.grid_Kit.EnableHeadersVisualStyles = false;
            this.grid_Kit.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.grid_Kit.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grid_Kit.Location = new System.Drawing.Point(0, 0);
            this.grid_Kit.MultiSelect = false;
            this.grid_Kit.Name = "grid_Kit";
            this.grid_Kit.ReadOnly = true;
            this.grid_Kit.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grid_Kit.RowHeadersDefaultCellStyle = dataGridViewCellStyle29;
            this.grid_Kit.RowHeadersVisible = false;
            this.grid_Kit.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.grid_Kit.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grid_Kit.Size = new System.Drawing.Size(240, 455);
            this.grid_Kit.Style = MetroFramework.MetroColorStyle.Red;
            this.grid_Kit.TabIndex = 3;
            this.grid_Kit.UseStyleColors = true;
            // 
            // tab_item
            // 
            this.tab_item.AutoScroll = true;
            this.tab_item.BackColor = System.Drawing.Color.LemonChiffon;
            this.tab_item.Controls.Add(this.cb_sceltaCliente);
            this.tab_item.Controls.Add(this.metroLabel11);
            this.tab_item.Controls.Add(this.lab_device_ID);
            this.tab_item.Controls.Add(this.metroLabel10);
            this.tab_item.Controls.Add(this.panel_device_image);
            this.tab_item.Controls.Add(this.metroLabel9);
            this.tab_item.Controls.Add(this.cb_scelta_Device);
            this.tab_item.Controls.Add(this.metroLabel8);
            this.tab_item.Controls.Add(this.cb_scelta_Famiglia);
            this.tab_item.Controls.Add(this.but_seleziona_device);
            this.tab_item.Controls.Add(this.lab_device_desestfw);
            this.tab_item.Controls.Add(this.lab_device_desfw);
            this.tab_item.Controls.Add(this.lab_device_codfw);
            this.tab_item.Controls.Add(this.lab_device_desestart);
            this.tab_item.Controls.Add(this.lab_device_desart);
            this.tab_item.Controls.Add(this.cb_scelta_Funzioni);
            this.tab_item.Controls.Add(this.metroLabel7);
            this.tab_item.HorizontalScrollbar = true;
            this.tab_item.HorizontalScrollbarBarColor = true;
            this.tab_item.HorizontalScrollbarHighlightOnWheel = false;
            this.tab_item.HorizontalScrollbarSize = 10;
            this.tab_item.Location = new System.Drawing.Point(4, 41);
            this.tab_item.Name = "tab_item";
            this.tab_item.Size = new System.Drawing.Size(684, 455);
            this.tab_item.Style = MetroFramework.MetroColorStyle.Red;
            this.tab_item.TabIndex = 2;
            this.tab_item.Text = "Device";
            this.tab_item.UseCustomBackColor = true;
            this.tab_item.VerticalScrollbar = true;
            this.tab_item.VerticalScrollbarBarColor = true;
            this.tab_item.VerticalScrollbarHighlightOnWheel = false;
            this.tab_item.VerticalScrollbarSize = 10;
            // 
            // cb_sceltaCliente
            // 
            this.cb_sceltaCliente.DisplayFocus = true;
            this.cb_sceltaCliente.DisplayMember = "RAGIONESOCIALE";
            this.cb_sceltaCliente.FontSize = MetroFramework.MetroComboBoxSize.Small;
            this.cb_sceltaCliente.FormattingEnabled = true;
            this.cb_sceltaCliente.ItemHeight = 19;
            this.cb_sceltaCliente.Location = new System.Drawing.Point(334, 96);
            this.cb_sceltaCliente.Name = "cb_sceltaCliente";
            this.cb_sceltaCliente.Size = new System.Drawing.Size(209, 25);
            this.cb_sceltaCliente.Style = MetroFramework.MetroColorStyle.Red;
            this.cb_sceltaCliente.TabIndex = 46;
            this.cb_sceltaCliente.UseSelectable = true;
            this.cb_sceltaCliente.ValueMember = "CODICE_NOMINATIVO";
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel11.Location = new System.Drawing.Point(205, 96);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(54, 19);
            this.metroLabel11.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel11.TabIndex = 45;
            this.metroLabel11.Text = "Cliente:";
            this.metroLabel11.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.metroLabel11.UseCustomBackColor = true;
            this.metroLabel11.UseStyleColors = true;
            // 
            // lab_device_ID
            // 
            this.lab_device_ID.AutoSize = true;
            this.lab_device_ID.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_device_ID.Location = new System.Drawing.Point(231, 141);
            this.lab_device_ID.Name = "lab_device_ID";
            this.lab_device_ID.Size = new System.Drawing.Size(26, 19);
            this.lab_device_ID.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_device_ID.TabIndex = 43;
            this.lab_device_ID.Text = "ID:";
            this.lab_device_ID.UseCustomBackColor = true;
            this.lab_device_ID.UseStyleColors = true;
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel10.Location = new System.Drawing.Point(206, 141);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(26, 19);
            this.metroLabel10.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel10.TabIndex = 42;
            this.metroLabel10.Text = "ID:";
            this.metroLabel10.UseCustomBackColor = true;
            this.metroLabel10.UseStyleColors = true;
            // 
            // panel_device_image
            // 
            this.panel_device_image.Controls.Add(this.Device_Image);
            this.panel_device_image.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_device_image.HorizontalScrollbarBarColor = true;
            this.panel_device_image.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_device_image.HorizontalScrollbarSize = 10;
            this.panel_device_image.Location = new System.Drawing.Point(0, 0);
            this.panel_device_image.Name = "panel_device_image";
            this.panel_device_image.Size = new System.Drawing.Size(200, 455);
            this.panel_device_image.TabIndex = 41;
            this.panel_device_image.VerticalScrollbarBarColor = true;
            this.panel_device_image.VerticalScrollbarHighlightOnWheel = false;
            this.panel_device_image.VerticalScrollbarSize = 10;
            // 
            // Device_Image
            // 
            this.Device_Image.BackColor = System.Drawing.Color.White;
            this.Device_Image.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Device_Image.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Device_Image.Location = new System.Drawing.Point(0, 0);
            this.Device_Image.Name = "Device_Image";
            this.Device_Image.Size = new System.Drawing.Size(200, 455);
            this.Device_Image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Device_Image.TabIndex = 40;
            this.Device_Image.TabStop = false;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel9.Location = new System.Drawing.Point(205, 65);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(52, 19);
            this.metroLabel9.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel9.TabIndex = 29;
            this.metroLabel9.Text = "Device:";
            this.metroLabel9.UseCustomBackColor = true;
            this.metroLabel9.UseStyleColors = true;
            // 
            // cb_scelta_Device
            // 
            this.cb_scelta_Device.DisplayFocus = true;
            this.cb_scelta_Device.DisplayMember = "Articolo_Device";
            this.cb_scelta_Device.FontSize = MetroFramework.MetroComboBoxSize.Small;
            this.cb_scelta_Device.FormattingEnabled = true;
            this.cb_scelta_Device.ItemHeight = 19;
            this.cb_scelta_Device.Location = new System.Drawing.Point(334, 65);
            this.cb_scelta_Device.Name = "cb_scelta_Device";
            this.cb_scelta_Device.Size = new System.Drawing.Size(209, 25);
            this.cb_scelta_Device.Style = MetroFramework.MetroColorStyle.Red;
            this.cb_scelta_Device.TabIndex = 28;
            this.cb_scelta_Device.UseSelectable = true;
            this.cb_scelta_Device.ValueMember = "Articolo";
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel8.Location = new System.Drawing.Point(205, 3);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(119, 19);
            this.metroLabel8.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel8.TabIndex = 27;
            this.metroLabel8.Text = "Famiglia di device:";
            this.metroLabel8.UseCustomBackColor = true;
            this.metroLabel8.UseStyleColors = true;
            // 
            // cb_scelta_Famiglia
            // 
            this.cb_scelta_Famiglia.DisplayMember = "FamDevice";
            this.cb_scelta_Famiglia.FontSize = MetroFramework.MetroComboBoxSize.Small;
            this.cb_scelta_Famiglia.FormattingEnabled = true;
            this.cb_scelta_Famiglia.ItemHeight = 19;
            this.cb_scelta_Famiglia.Location = new System.Drawing.Point(334, 3);
            this.cb_scelta_Famiglia.Name = "cb_scelta_Famiglia";
            this.cb_scelta_Famiglia.Size = new System.Drawing.Size(209, 25);
            this.cb_scelta_Famiglia.TabIndex = 26;
            this.cb_scelta_Famiglia.UseSelectable = true;
            this.cb_scelta_Famiglia.ValueMember = "FamDevice";
            this.cb_scelta_Famiglia.SelectedIndexChanged += new System.EventHandler(this.cb_scelta_Famiglia_SelectedIndexChanged);
            // 
            // but_seleziona_device
            // 
            this.but_seleziona_device.Location = new System.Drawing.Point(334, 270);
            this.but_seleziona_device.Name = "but_seleziona_device";
            this.but_seleziona_device.Size = new System.Drawing.Size(75, 25);
            this.but_seleziona_device.Style = MetroFramework.MetroColorStyle.Red;
            this.but_seleziona_device.TabIndex = 24;
            this.but_seleziona_device.Text = "Seleziona";
            this.but_seleziona_device.UseSelectable = true;
            // 
            // lab_device_desestfw
            // 
            this.lab_device_desestfw.AutoSize = true;
            this.lab_device_desestfw.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lab_device_desestfw.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_device_desestfw.Location = new System.Drawing.Point(334, 235);
            this.lab_device_desestfw.Name = "lab_device_desestfw";
            this.lab_device_desestfw.Size = new System.Drawing.Size(113, 15);
            this.lab_device_desestfw.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_device_desestfw.TabIndex = 23;
            this.lab_device_desestfw.Text = "lab_device_desestfw";
            this.lab_device_desestfw.UseCustomBackColor = true;
            this.lab_device_desestfw.UseStyleColors = true;
            // 
            // lab_device_desfw
            // 
            this.lab_device_desfw.AutoSize = true;
            this.lab_device_desfw.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lab_device_desfw.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_device_desfw.Location = new System.Drawing.Point(334, 215);
            this.lab_device_desfw.Name = "lab_device_desfw";
            this.lab_device_desfw.Size = new System.Drawing.Size(98, 15);
            this.lab_device_desfw.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_device_desfw.TabIndex = 22;
            this.lab_device_desfw.Text = "lab_device_desfw";
            this.lab_device_desfw.UseCustomBackColor = true;
            this.lab_device_desfw.UseStyleColors = true;
            // 
            // lab_device_codfw
            // 
            this.lab_device_codfw.AutoSize = true;
            this.lab_device_codfw.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lab_device_codfw.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_device_codfw.Location = new System.Drawing.Point(334, 195);
            this.lab_device_codfw.Name = "lab_device_codfw";
            this.lab_device_codfw.Size = new System.Drawing.Size(105, 15);
            this.lab_device_codfw.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_device_codfw.TabIndex = 21;
            this.lab_device_codfw.Text = "lab_device_codfw";
            this.lab_device_codfw.UseCustomBackColor = true;
            this.lab_device_codfw.UseStyleColors = true;
            // 
            // lab_device_desestart
            // 
            this.lab_device_desestart.AutoSize = true;
            this.lab_device_desestart.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lab_device_desestart.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_device_desestart.Location = new System.Drawing.Point(334, 165);
            this.lab_device_desestart.Name = "lab_device_desestart";
            this.lab_device_desestart.Size = new System.Drawing.Size(114, 15);
            this.lab_device_desestart.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_device_desestart.TabIndex = 20;
            this.lab_device_desestart.Text = "lab_device_desestart";
            this.lab_device_desestart.UseCustomBackColor = true;
            this.lab_device_desestart.UseStyleColors = true;
            // 
            // lab_device_desart
            // 
            this.lab_device_desart.AutoSize = true;
            this.lab_device_desart.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lab_device_desart.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_device_desart.Location = new System.Drawing.Point(334, 145);
            this.lab_device_desart.Name = "lab_device_desart";
            this.lab_device_desart.Size = new System.Drawing.Size(99, 15);
            this.lab_device_desart.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_device_desart.TabIndex = 19;
            this.lab_device_desart.Text = "lab_device_desart";
            this.lab_device_desart.UseCustomBackColor = true;
            this.lab_device_desart.UseStyleColors = true;
            // 
            // cb_scelta_Funzioni
            // 
            this.cb_scelta_Funzioni.DisplayFocus = true;
            this.cb_scelta_Funzioni.DisplayMember = "NumFunzioni";
            this.cb_scelta_Funzioni.FontSize = MetroFramework.MetroComboBoxSize.Small;
            this.cb_scelta_Funzioni.FormattingEnabled = true;
            this.cb_scelta_Funzioni.ItemHeight = 19;
            this.cb_scelta_Funzioni.Location = new System.Drawing.Point(334, 34);
            this.cb_scelta_Funzioni.Name = "cb_scelta_Funzioni";
            this.cb_scelta_Funzioni.Size = new System.Drawing.Size(209, 25);
            this.cb_scelta_Funzioni.Style = MetroFramework.MetroColorStyle.Red;
            this.cb_scelta_Funzioni.TabIndex = 18;
            this.cb_scelta_Funzioni.UseSelectable = true;
            this.cb_scelta_Funzioni.ValueMember = "NumFunzioni";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel7.Location = new System.Drawing.Point(205, 34);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(63, 19);
            this.metroLabel7.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel7.TabIndex = 17;
            this.metroLabel7.Text = "Funzioni:";
            this.metroLabel7.UseCustomBackColor = true;
            this.metroLabel7.UseStyleColors = true;
            // 
            // tab_libera
            // 
            this.tab_libera.BackColor = System.Drawing.Color.Cornsilk;
            this.tab_libera.Controls.Add(this.metroLabel2);
            this.tab_libera.Controls.Add(this.tb_Id_Hardware);
            this.tab_libera.Controls.Add(this.but_seleziona_fw);
            this.tab_libera.Controls.Add(this.metroLabel1);
            this.tab_libera.Controls.Add(this.lab_fw_custom);
            this.tab_libera.Controls.Add(this.lab_fw_standard);
            this.tab_libera.Controls.Add(this.toggle_tipo_firmware);
            this.tab_libera.Controls.Add(this.cb_scelta_fw);
            this.tab_libera.Controls.Add(this.lab_tipo_device_ricevitore);
            this.tab_libera.Controls.Add(this.lab_tipo_device_palmare);
            this.tab_libera.Controls.Add(this.toggle_tipo_device_Libera);
            this.tab_libera.HorizontalScrollbarBarColor = true;
            this.tab_libera.HorizontalScrollbarHighlightOnWheel = false;
            this.tab_libera.HorizontalScrollbarSize = 10;
            this.tab_libera.Location = new System.Drawing.Point(4, 41);
            this.tab_libera.Name = "tab_libera";
            this.tab_libera.Size = new System.Drawing.Size(684, 455);
            this.tab_libera.TabIndex = 3;
            this.tab_libera.Text = "Progr. libera";
            this.tab_libera.UseCustomBackColor = true;
            this.tab_libera.VerticalScrollbarBarColor = true;
            this.tab_libera.VerticalScrollbarHighlightOnWheel = false;
            this.tab_libera.VerticalScrollbarSize = 10;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Location = new System.Drawing.Point(251, 82);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(89, 19);
            this.metroLabel2.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel2.TabIndex = 19;
            this.metroLabel2.Text = "ID Hardware:";
            this.metroLabel2.UseCustomBackColor = true;
            this.metroLabel2.UseStyleColors = true;
            // 
            // tb_Id_Hardware
            // 
            this.tb_Id_Hardware.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            // 
            // 
            // 
            this.tb_Id_Hardware.CustomButton.Image = null;
            this.tb_Id_Hardware.CustomButton.Location = new System.Drawing.Point(206, 1);
            this.tb_Id_Hardware.CustomButton.Name = "";
            this.tb_Id_Hardware.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_Id_Hardware.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_Id_Hardware.CustomButton.TabIndex = 1;
            this.tb_Id_Hardware.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_Id_Hardware.CustomButton.UseSelectable = true;
            this.tb_Id_Hardware.Lines = new string[0];
            this.tb_Id_Hardware.Location = new System.Drawing.Point(251, 104);
            this.tb_Id_Hardware.MaxLength = 32767;
            this.tb_Id_Hardware.Name = "tb_Id_Hardware";
            this.tb_Id_Hardware.PasswordChar = '\0';
            this.tb_Id_Hardware.PromptText = "Inserire o ricercare l\'ID hardware";
            this.tb_Id_Hardware.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_Id_Hardware.SelectedText = "";
            this.tb_Id_Hardware.SelectionLength = 0;
            this.tb_Id_Hardware.SelectionStart = 0;
            this.tb_Id_Hardware.ShortcutsEnabled = true;
            this.tb_Id_Hardware.ShowButton = true;
            this.tb_Id_Hardware.Size = new System.Drawing.Size(228, 23);
            this.tb_Id_Hardware.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_Id_Hardware.TabIndex = 18;
            this.tb_Id_Hardware.UseSelectable = true;
            this.tb_Id_Hardware.WaterMark = "Inserire o ricercare l\'ID hardware";
            this.tb_Id_Hardware.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_Id_Hardware.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tb_Id_Hardware.ButtonClick += new MetroFramework.Controls.MetroTextBox.ButClick(this.tb_Id_Hardware_ButtonClick);
            // 
            // but_seleziona_fw
            // 
            this.but_seleziona_fw.Location = new System.Drawing.Point(498, 102);
            this.but_seleziona_fw.Name = "but_seleziona_fw";
            this.but_seleziona_fw.Size = new System.Drawing.Size(75, 25);
            this.but_seleziona_fw.Style = MetroFramework.MetroColorStyle.Red;
            this.but_seleziona_fw.TabIndex = 17;
            this.but_seleziona_fw.Text = "Seleziona";
            this.but_seleziona_fw.UseSelectable = true;
            this.but_seleziona_fw.Visible = false;
            this.but_seleziona_fw.Click += new System.EventHandler(this.but_seleziona_fw_Click);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(5, 82);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(128, 19);
            this.metroLabel1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel1.TabIndex = 16;
            this.metroLabel1.Text = "Seleziona Firmware:";
            this.metroLabel1.UseCustomBackColor = true;
            this.metroLabel1.UseStyleColors = true;
            // 
            // lab_fw_custom
            // 
            this.lab_fw_custom.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_fw_custom.Location = new System.Drawing.Point(135, 46);
            this.lab_fw_custom.Name = "lab_fw_custom";
            this.lab_fw_custom.Size = new System.Drawing.Size(98, 19);
            this.lab_fw_custom.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_fw_custom.TabIndex = 13;
            this.lab_fw_custom.Text = "Custom";
            this.lab_fw_custom.UseCustomBackColor = true;
            this.lab_fw_custom.UseStyleColors = true;
            // 
            // lab_fw_standard
            // 
            this.lab_fw_standard.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_fw_standard.Location = new System.Drawing.Point(5, 44);
            this.lab_fw_standard.Name = "lab_fw_standard";
            this.lab_fw_standard.Size = new System.Drawing.Size(72, 19);
            this.lab_fw_standard.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_fw_standard.TabIndex = 12;
            this.lab_fw_standard.Text = "Standard";
            this.lab_fw_standard.UseCustomBackColor = true;
            this.lab_fw_standard.UseStyleColors = true;
            // 
            // toggle_tipo_firmware
            // 
            this.toggle_tipo_firmware.AutoSize = true;
            this.toggle_tipo_firmware.DisplayStatus = false;
            this.toggle_tipo_firmware.Location = new System.Drawing.Point(74, 46);
            this.toggle_tipo_firmware.Name = "toggle_tipo_firmware";
            this.toggle_tipo_firmware.Size = new System.Drawing.Size(50, 17);
            this.toggle_tipo_firmware.Style = MetroFramework.MetroColorStyle.Red;
            this.toggle_tipo_firmware.TabIndex = 11;
            this.toggle_tipo_firmware.Text = "Off";
            this.toggle_tipo_firmware.UseSelectable = true;
            this.toggle_tipo_firmware.UseStyleColors = true;
            this.toggle_tipo_firmware.CheckedChanged += new System.EventHandler(this.toggle_tipo_firmware_CheckedChanged);
            // 
            // cb_scelta_fw
            // 
            this.cb_scelta_fw.DisplayMember = "fw_codfw";
            this.cb_scelta_fw.FontSize = MetroFramework.MetroComboBoxSize.Small;
            this.cb_scelta_fw.FormattingEnabled = true;
            this.cb_scelta_fw.ItemHeight = 19;
            this.cb_scelta_fw.Location = new System.Drawing.Point(5, 104);
            this.cb_scelta_fw.Name = "cb_scelta_fw";
            this.cb_scelta_fw.Size = new System.Drawing.Size(228, 25);
            this.cb_scelta_fw.Style = MetroFramework.MetroColorStyle.Red;
            this.cb_scelta_fw.TabIndex = 10;
            this.cb_scelta_fw.UseSelectable = true;
            this.cb_scelta_fw.ValueMember = "fw_id";
            this.cb_scelta_fw.SelectedIndexChanged += new System.EventHandler(this.cb_scelta_fw_SelectedIndexChanged);
            this.cb_scelta_fw.Click += new System.EventHandler(this.cb_scelta_fw_Click);
            // 
            // lab_tipo_device_ricevitore
            // 
            this.lab_tipo_device_ricevitore.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_tipo_device_ricevitore.Location = new System.Drawing.Point(135, 10);
            this.lab_tipo_device_ricevitore.Name = "lab_tipo_device_ricevitore";
            this.lab_tipo_device_ricevitore.Size = new System.Drawing.Size(98, 19);
            this.lab_tipo_device_ricevitore.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_tipo_device_ricevitore.TabIndex = 8;
            this.lab_tipo_device_ricevitore.Text = "Ricevitore";
            this.lab_tipo_device_ricevitore.UseCustomBackColor = true;
            this.lab_tipo_device_ricevitore.UseStyleColors = true;
            // 
            // lab_tipo_device_palmare
            // 
            this.lab_tipo_device_palmare.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_tipo_device_palmare.Location = new System.Drawing.Point(5, 8);
            this.lab_tipo_device_palmare.Name = "lab_tipo_device_palmare";
            this.lab_tipo_device_palmare.Size = new System.Drawing.Size(72, 19);
            this.lab_tipo_device_palmare.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_tipo_device_palmare.TabIndex = 7;
            this.lab_tipo_device_palmare.Text = "Palmare";
            this.lab_tipo_device_palmare.UseCustomBackColor = true;
            this.lab_tipo_device_palmare.UseStyleColors = true;
            // 
            // toggle_tipo_device_Libera
            // 
            this.toggle_tipo_device_Libera.AutoSize = true;
            this.toggle_tipo_device_Libera.DisplayStatus = false;
            this.toggle_tipo_device_Libera.Location = new System.Drawing.Point(74, 10);
            this.toggle_tipo_device_Libera.Name = "toggle_tipo_device_Libera";
            this.toggle_tipo_device_Libera.Size = new System.Drawing.Size(50, 17);
            this.toggle_tipo_device_Libera.Style = MetroFramework.MetroColorStyle.Red;
            this.toggle_tipo_device_Libera.TabIndex = 6;
            this.toggle_tipo_device_Libera.Text = "Off";
            this.toggle_tipo_device_Libera.UseSelectable = true;
            this.toggle_tipo_device_Libera.UseStyleColors = true;
            this.toggle_tipo_device_Libera.CheckedChanged += new System.EventHandler(this.toggle_tipo_device_Libera_CheckedChanged);
            // 
            // pan_titolo
            // 
            this.pan_titolo.Controls.Add(this.lab_command);
            this.pan_titolo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pan_titolo.HorizontalScrollbarBarColor = true;
            this.pan_titolo.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_titolo.HorizontalScrollbarSize = 10;
            this.pan_titolo.Location = new System.Drawing.Point(250, 0);
            this.pan_titolo.Name = "pan_titolo";
            this.pan_titolo.Size = new System.Drawing.Size(692, 30);
            this.pan_titolo.TabIndex = 5;
            this.pan_titolo.VerticalScrollbarBarColor = true;
            this.pan_titolo.VerticalScrollbarHighlightOnWheel = false;
            this.pan_titolo.VerticalScrollbarSize = 10;
            // 
            // lab_command
            // 
            this.lab_command.AutoSize = true;
            this.lab_command.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.lab_command.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_command.Location = new System.Drawing.Point(6, 2);
            this.lab_command.Name = "lab_command";
            this.lab_command.Size = new System.Drawing.Size(231, 25);
            this.lab_command.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_command.TabIndex = 5;
            this.lab_command.Text = "Programmazione SmartLine";
            this.lab_command.UseCustomBackColor = true;
            this.lab_command.UseStyleColors = true;
            // 
            // tv_FW
            // 
            this.tv_FW.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tv_FW.Dock = System.Windows.Forms.DockStyle.Left;
            this.tv_FW.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tv_FW.Location = new System.Drawing.Point(0, 0);
            this.tv_FW.Name = "tv_FW";
            this.tv_FW.Size = new System.Drawing.Size(250, 530);
            this.tv_FW.TabIndex = 3;
            this.tv_FW.Visible = false;
            // 
            // outputPanel
            // 
            this.outputPanel.Controls.Add(this.dos_box);
            this.outputPanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.outputPanel.HorizontalScrollbarBarColor = true;
            this.outputPanel.HorizontalScrollbarHighlightOnWheel = false;
            this.outputPanel.HorizontalScrollbarSize = 10;
            this.outputPanel.Location = new System.Drawing.Point(966, 84);
            this.outputPanel.Name = "outputPanel";
            this.outputPanel.Size = new System.Drawing.Size(400, 534);
            this.outputPanel.TabIndex = 72;
            this.outputPanel.VerticalScrollbarBarColor = true;
            this.outputPanel.VerticalScrollbarHighlightOnWheel = false;
            this.outputPanel.VerticalScrollbarSize = 10;
            // 
            // dos_box
            // 
            this.dos_box.BackColor = System.Drawing.Color.White;
            this.dos_box.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dos_box.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dos_box.ForeColor = System.Drawing.Color.Black;
            this.dos_box.Location = new System.Drawing.Point(0, 0);
            this.dos_box.Multiline = true;
            this.dos_box.Name = "dos_box";
            this.dos_box.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dos_box.Size = new System.Drawing.Size(400, 534);
            this.dos_box.TabIndex = 68;
            // 
            // configPanel
            // 
            this.configPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.configPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.configPanel.Controls.Add(this.TrayCmb);
            this.configPanel.Controls.Add(this.LabelWriterCmb);
            this.configPanel.Controls.Add(this.lab_Configurazione);
            this.configPanel.Controls.Add(this.lab_FW_folder);
            this.configPanel.Controls.Add(this.tb_FW_folder);
            this.configPanel.Controls.Add(this.lab_IP_printer);
            this.configPanel.Controls.Add(this.tb_IP_Printer);
            this.configPanel.Controls.Add(this.lab_use_printer);
            this.configPanel.Controls.Add(this.tog_Use_printer);
            this.configPanel.Controls.Add(this.lab_Commander);
            this.configPanel.Controls.Add(this.tb_Commander_path);
            this.configPanel.Controls.Add(this.Panel_Config_buttons);
            this.configPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.configPanel.HorizontalScrollbarBarColor = true;
            this.configPanel.HorizontalScrollbarHighlightOnWheel = false;
            this.configPanel.HorizontalScrollbarSize = 10;
            this.configPanel.Location = new System.Drawing.Point(20, 618);
            this.configPanel.Name = "configPanel";
            this.configPanel.Size = new System.Drawing.Size(1346, 150);
            this.configPanel.TabIndex = 73;
            this.configPanel.UseCustomBackColor = true;
            this.configPanel.VerticalScrollbarBarColor = true;
            this.configPanel.VerticalScrollbarHighlightOnWheel = false;
            this.configPanel.VerticalScrollbarSize = 10;
            // 
            // TrayCmb
            // 
            this.TrayCmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TrayCmb.Items.AddRange(new object[] {
            "Left Tray",
            "Right Tray",
            "Auto Switch"});
            this.TrayCmb.Location = new System.Drawing.Point(1045, 15);
            this.TrayCmb.Name = "TrayCmb";
            this.TrayCmb.Size = new System.Drawing.Size(128, 21);
            this.TrayCmb.TabIndex = 14;
            // 
            // LabelWriterCmb
            // 
            this.LabelWriterCmb.Location = new System.Drawing.Point(741, 15);
            this.LabelWriterCmb.Name = "LabelWriterCmb";
            this.LabelWriterCmb.Size = new System.Drawing.Size(280, 21);
            this.LabelWriterCmb.TabIndex = 13;
            // 
            // lab_Configurazione
            // 
            this.lab_Configurazione.AutoSize = true;
            this.lab_Configurazione.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_Configurazione.Location = new System.Drawing.Point(3, 3);
            this.lab_Configurazione.Name = "lab_Configurazione";
            this.lab_Configurazione.Size = new System.Drawing.Size(173, 19);
            this.lab_Configurazione.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_Configurazione.TabIndex = 2;
            this.lab_Configurazione.Text = "Configurazione del sistema";
            this.lab_Configurazione.UseCustomBackColor = true;
            this.lab_Configurazione.UseStyleColors = true;
            // 
            // lab_FW_folder
            // 
            this.lab_FW_folder.AutoSize = true;
            this.lab_FW_folder.Location = new System.Drawing.Point(5, 32);
            this.lab_FW_folder.Name = "lab_FW_folder";
            this.lab_FW_folder.Size = new System.Drawing.Size(171, 19);
            this.lab_FW_folder.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_FW_folder.TabIndex = 3;
            this.lab_FW_folder.Text = "Folder iniziale del firmware:";
            this.lab_FW_folder.UseCustomBackColor = true;
            this.lab_FW_folder.UseStyleColors = true;
            // 
            // tb_FW_folder
            // 
            // 
            // 
            // 
            this.tb_FW_folder.CustomButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("resource.BackgroundImage")));
            this.tb_FW_folder.CustomButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tb_FW_folder.CustomButton.Image = null;
            this.tb_FW_folder.CustomButton.Location = new System.Drawing.Point(453, 1);
            this.tb_FW_folder.CustomButton.Name = "";
            this.tb_FW_folder.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_FW_folder.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_FW_folder.CustomButton.TabIndex = 1;
            this.tb_FW_folder.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_FW_folder.CustomButton.UseSelectable = true;
            this.tb_FW_folder.DisplayIcon = true;
            this.tb_FW_folder.Icon = ((System.Drawing.Image)(resources.GetObject("tb_FW_folder.Icon")));
            this.tb_FW_folder.Lines = new string[] {
        "tb_FW_folder"};
            this.tb_FW_folder.Location = new System.Drawing.Point(193, 32);
            this.tb_FW_folder.MaxLength = 32767;
            this.tb_FW_folder.Name = "tb_FW_folder";
            this.tb_FW_folder.PasswordChar = '\0';
            this.tb_FW_folder.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_FW_folder.SelectedText = "";
            this.tb_FW_folder.SelectionLength = 0;
            this.tb_FW_folder.SelectionStart = 0;
            this.tb_FW_folder.ShortcutsEnabled = true;
            this.tb_FW_folder.ShowButton = true;
            this.tb_FW_folder.Size = new System.Drawing.Size(475, 23);
            this.tb_FW_folder.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_FW_folder.TabIndex = 4;
            this.tb_FW_folder.Text = "tb_FW_folder";
            this.tb_FW_folder.UseSelectable = true;
            this.tb_FW_folder.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_FW_folder.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // lab_IP_printer
            // 
            this.lab_IP_printer.AutoSize = true;
            this.lab_IP_printer.Location = new System.Drawing.Point(5, 69);
            this.lab_IP_printer.Name = "lab_IP_printer";
            this.lab_IP_printer.Size = new System.Drawing.Size(173, 19);
            this.lab_IP_printer.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_IP_printer.TabIndex = 7;
            this.lab_IP_printer.Text = "Indirizzo IP della stampante:";
            this.lab_IP_printer.UseCustomBackColor = true;
            this.lab_IP_printer.UseStyleColors = true;
            // 
            // tb_IP_Printer
            // 
            // 
            // 
            // 
            this.tb_IP_Printer.CustomButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("resource.BackgroundImage1")));
            this.tb_IP_Printer.CustomButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tb_IP_Printer.CustomButton.Image = null;
            this.tb_IP_Printer.CustomButton.Location = new System.Drawing.Point(453, 1);
            this.tb_IP_Printer.CustomButton.Name = "";
            this.tb_IP_Printer.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_IP_Printer.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_IP_Printer.CustomButton.TabIndex = 1;
            this.tb_IP_Printer.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_IP_Printer.CustomButton.UseSelectable = true;
            this.tb_IP_Printer.CustomButton.Visible = false;
            this.tb_IP_Printer.Lines = new string[] {
        "tb_IP_Printer"};
            this.tb_IP_Printer.Location = new System.Drawing.Point(193, 69);
            this.tb_IP_Printer.MaxLength = 32767;
            this.tb_IP_Printer.Name = "tb_IP_Printer";
            this.tb_IP_Printer.PasswordChar = '\0';
            this.tb_IP_Printer.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_IP_Printer.SelectedText = "";
            this.tb_IP_Printer.SelectionLength = 0;
            this.tb_IP_Printer.SelectionStart = 0;
            this.tb_IP_Printer.ShortcutsEnabled = true;
            this.tb_IP_Printer.Size = new System.Drawing.Size(475, 23);
            this.tb_IP_Printer.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_IP_Printer.TabIndex = 8;
            this.tb_IP_Printer.Text = "tb_IP_Printer";
            this.tb_IP_Printer.UseSelectable = true;
            this.tb_IP_Printer.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_IP_Printer.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // lab_use_printer
            // 
            this.lab_use_printer.AutoSize = true;
            this.lab_use_printer.Location = new System.Drawing.Point(673, 71);
            this.lab_use_printer.Name = "lab_use_printer";
            this.lab_use_printer.Size = new System.Drawing.Size(110, 19);
            this.lab_use_printer.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_use_printer.TabIndex = 10;
            this.lab_use_printer.Text = "Stampante attiva:";
            this.lab_use_printer.UseCustomBackColor = true;
            this.lab_use_printer.UseStyleColors = true;
            // 
            // tog_Use_printer
            // 
            this.tog_Use_printer.AutoSize = true;
            this.tog_Use_printer.Location = new System.Drawing.Point(789, 73);
            this.tog_Use_printer.Name = "tog_Use_printer";
            this.tog_Use_printer.Size = new System.Drawing.Size(80, 17);
            this.tog_Use_printer.Style = MetroFramework.MetroColorStyle.Red;
            this.tog_Use_printer.TabIndex = 9;
            this.tog_Use_printer.Text = "Off";
            this.tog_Use_printer.UseSelectable = true;
            // 
            // lab_Commander
            // 
            this.lab_Commander.AutoSize = true;
            this.lab_Commander.Location = new System.Drawing.Point(5, 106);
            this.lab_Commander.Name = "lab_Commander";
            this.lab_Commander.Size = new System.Drawing.Size(182, 19);
            this.lab_Commander.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_Commander.TabIndex = 11;
            this.lab_Commander.Text = "Folder del file \"Commander\":";
            this.lab_Commander.UseCustomBackColor = true;
            this.lab_Commander.UseStyleColors = true;
            // 
            // tb_Commander_path
            // 
            // 
            // 
            // 
            this.tb_Commander_path.CustomButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("resource.BackgroundImage2")));
            this.tb_Commander_path.CustomButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tb_Commander_path.CustomButton.Image = null;
            this.tb_Commander_path.CustomButton.Location = new System.Drawing.Point(453, 1);
            this.tb_Commander_path.CustomButton.Name = "";
            this.tb_Commander_path.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_Commander_path.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_Commander_path.CustomButton.TabIndex = 1;
            this.tb_Commander_path.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_Commander_path.CustomButton.UseSelectable = true;
            this.tb_Commander_path.DisplayIcon = true;
            this.tb_Commander_path.Icon = ((System.Drawing.Image)(resources.GetObject("tb_Commander_path.Icon")));
            this.tb_Commander_path.Lines = new string[] {
        "metroTextBox1"};
            this.tb_Commander_path.Location = new System.Drawing.Point(193, 106);
            this.tb_Commander_path.MaxLength = 32767;
            this.tb_Commander_path.Name = "tb_Commander_path";
            this.tb_Commander_path.PasswordChar = '\0';
            this.tb_Commander_path.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_Commander_path.SelectedText = "";
            this.tb_Commander_path.SelectionLength = 0;
            this.tb_Commander_path.SelectionStart = 0;
            this.tb_Commander_path.ShortcutsEnabled = true;
            this.tb_Commander_path.ShowButton = true;
            this.tb_Commander_path.Size = new System.Drawing.Size(475, 23);
            this.tb_Commander_path.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_Commander_path.TabIndex = 12;
            this.tb_Commander_path.Text = "metroTextBox1";
            this.tb_Commander_path.UseSelectable = true;
            this.tb_Commander_path.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_Commander_path.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Panel_Config_buttons
            // 
            this.Panel_Config_buttons.ColumnCount = 1;
            this.Panel_Config_buttons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.Panel_Config_buttons.Controls.Add(this.but_Edit_Config, 0, 0);
            this.Panel_Config_buttons.Controls.Add(this.but_Save_Config, 0, 1);
            this.Panel_Config_buttons.Controls.Add(this.but_Abort_Config, 0, 2);
            this.Panel_Config_buttons.Dock = System.Windows.Forms.DockStyle.Right;
            this.Panel_Config_buttons.Location = new System.Drawing.Point(1244, 0);
            this.Panel_Config_buttons.Name = "Panel_Config_buttons";
            this.Panel_Config_buttons.RowCount = 3;
            this.Panel_Config_buttons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.Panel_Config_buttons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.Panel_Config_buttons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.Panel_Config_buttons.Size = new System.Drawing.Size(100, 148);
            this.Panel_Config_buttons.TabIndex = 6;
            // 
            // but_Edit_Config
            // 
            this.but_Edit_Config.Dock = System.Windows.Forms.DockStyle.Fill;
            this.but_Edit_Config.Image = ((System.Drawing.Image)(resources.GetObject("but_Edit_Config.Image")));
            this.but_Edit_Config.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.but_Edit_Config.Location = new System.Drawing.Point(3, 3);
            this.but_Edit_Config.Name = "but_Edit_Config";
            this.but_Edit_Config.Size = new System.Drawing.Size(94, 43);
            this.but_Edit_Config.TabIndex = 9;
            this.but_Edit_Config.Text = "Modifica";
            this.but_Edit_Config.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.but_Edit_Config.UseVisualStyleBackColor = true;
            this.but_Edit_Config.Click += new System.EventHandler(this.but_Edit_Config_Click);
            // 
            // but_Save_Config
            // 
            this.but_Save_Config.Dock = System.Windows.Forms.DockStyle.Fill;
            this.but_Save_Config.Image = ((System.Drawing.Image)(resources.GetObject("but_Save_Config.Image")));
            this.but_Save_Config.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.but_Save_Config.Location = new System.Drawing.Point(3, 52);
            this.but_Save_Config.Name = "but_Save_Config";
            this.but_Save_Config.Size = new System.Drawing.Size(94, 43);
            this.but_Save_Config.TabIndex = 7;
            this.but_Save_Config.Text = "Salva";
            this.but_Save_Config.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.but_Save_Config.UseVisualStyleBackColor = true;
            this.but_Save_Config.Click += new System.EventHandler(this.but_Save_Config_Click);
            // 
            // but_Abort_Config
            // 
            this.but_Abort_Config.Dock = System.Windows.Forms.DockStyle.Fill;
            this.but_Abort_Config.Image = ((System.Drawing.Image)(resources.GetObject("but_Abort_Config.Image")));
            this.but_Abort_Config.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.but_Abort_Config.Location = new System.Drawing.Point(3, 101);
            this.but_Abort_Config.Name = "but_Abort_Config";
            this.but_Abort_Config.Size = new System.Drawing.Size(94, 44);
            this.but_Abort_Config.TabIndex = 8;
            this.but_Abort_Config.Text = "Annulla";
            this.but_Abort_Config.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.but_Abort_Config.UseVisualStyleBackColor = true;
            this.but_Abort_Config.Click += new System.EventHandler(this.but_Abort_Config_Click);
            // 
            // sFCommesseSLSFArticoliBindingSource
            // 
            this.sFCommesseSLSFArticoliBindingSource.DataMember = "SF_Commesse_SL_SF_Articoli";
            this.sFCommesseSLSFArticoliBindingSource.DataSource = this.sFCommesseSLBindingSource;
            // 
            // sFDistinctItemFamPrefixBindingSource
            // 
            this.sFDistinctItemFamPrefixBindingSource.DataSource = this.ds_SL;
            this.sFDistinctItemFamPrefixBindingSource.Position = 0;
            this.sFDistinctItemFamPrefixBindingSource.CurrentChanged += new System.EventHandler(this.sFDistinctItemFamPrefixBindingSource_CurrentChanged);
            // 
            // sFAnagraficaClientiBindingSource
            // 
            this.sFAnagraficaClientiBindingSource.DataMember = "SF_AnagraficaClienti";
            this.sFAnagraficaClientiBindingSource.DataSource = this.ds_SL;
            // 
            // firmwareBindingSource
            // 
            this.firmwareBindingSource.DataMember = "Firmware";
            this.firmwareBindingSource.DataSource = this.ds_SL;
            // 
            // serialNumbersBindingSource
            // 
            this.serialNumbersBindingSource.DataMember = "SerialNumbers";
            this.serialNumbersBindingSource.DataSource = this.ds_SL;
            // 
            // serialNumbersTableAdapter
            // 
            this.serialNumbersTableAdapter.ClearBeforeFill = true;
            // 
            // sFDistinteBasiBindingSource
            // 
            this.sFDistinteBasiBindingSource.DataMember = "SF_DistinteBasi";
            this.sFDistinteBasiBindingSource.DataSource = this.ds_SL;
            // 
            // sF_DistinteBasiTableAdapter
            // 
            this.sF_DistinteBasiTableAdapter.ClearBeforeFill = true;
            // 
            // firmwareTableAdapter
            // 
            this.firmwareTableAdapter.ClearBeforeFill = true;
            // 
            // sFArticoliBindingSource
            // 
            this.sFArticoliBindingSource.DataMember = "SF_Articoli";
            this.sFArticoliBindingSource.DataSource = this.ds_SL;
            // 
            // sF_ArticoliTableAdapter
            // 
            this.sF_ArticoliTableAdapter.ClearBeforeFill = true;
            // 
            // sFArticoliToXSWRBindingSource
            // 
            this.sFArticoliToXSWRBindingSource.DataMember = "SF_ArticoliToXSWR";
            this.sFArticoliToXSWRBindingSource.DataSource = this.ds_SL;
            // 
            // sF_ArticoliToXSWRTableAdapter
            // 
            this.sF_ArticoliToXSWRTableAdapter.ClearBeforeFill = true;
            // 
            // fWClientiBindingSource
            // 
            this.fWClientiBindingSource.DataMember = "FW_Clienti";
            this.fWClientiBindingSource.DataSource = this.ds_SL;
            // 
            // fW_ClientiTableAdapter
            // 
            this.fW_ClientiTableAdapter.ClearBeforeFill = true;
            // 
            // sF_Commesse_SLTableAdapter
            // 
            this.sF_Commesse_SLTableAdapter.ClearBeforeFill = true;
            // 
            // sF_AnagraficaClientiTableAdapter
            // 
            this.sF_AnagraficaClientiTableAdapter.ClearBeforeFill = true;
            // 
            // sFItemDeviceFWDesBindingSource
            // 
            this.sFItemDeviceFWDesBindingSource.DataMember = "SF_ItemDevice_FW_Des";
            this.sFItemDeviceFWDesBindingSource.DataSource = this.ds_SL;
            this.sFItemDeviceFWDesBindingSource.CurrentChanged += new System.EventHandler(this.sFItemDeviceFWDesBindingSource_CurrentChanged);
            // 
            // sF_ItemDevice_FW_DesTableAdapter
            // 
            this.sF_ItemDevice_FW_DesTableAdapter.ClearBeforeFill = true;
            // 
            // sFDistinctItemFamFunctionsBindingSource
            // 
            this.sFDistinctItemFamFunctionsBindingSource.DataSource = this.ds_SL;
            this.sFDistinctItemFamFunctionsBindingSource.Position = 0;
            // 
            // sF_Distinct_Item_Fam_FunctionsTableAdapter
            // 
            this.sF_Distinct_Item_Fam_FunctionsTableAdapter.ClearBeforeFill = true;
            // 
            // sF_Distinct_Item_Fam_PrefixTableAdapter
            // 
            this.sF_Distinct_Item_Fam_PrefixTableAdapter.ClearBeforeFill = true;
            // 
            // dtFirmwarelookupCommesseSLBindingSource
            // 
            this.dtFirmwarelookupCommesseSLBindingSource.DataSource = this.ds_SL;
            this.dtFirmwarelookupCommesseSLBindingSource.Position = 0;
            // 
            // dt_Firmware_lookupCommesseSLTableAdapter
            // 
            this.dt_Firmware_lookupCommesseSLTableAdapter.ClearBeforeFill = true;
            // 
            // dtTmpProgrammadtFirmwareBindingSource
            // 
            this.dtTmpProgrammadtFirmwareBindingSource.DataMember = "dt_Tmp_Programma_dt_Firmware";
            this.dtTmpProgrammadtFirmwareBindingSource.DataSource = this.dtTmpProgrammaBindingSource;
            // 
            // UC_Programmazione
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1386, 788);
            this.Controls.Add(this.commandPanel);
            this.Controls.Add(this.outputPanel);
            this.Controls.Add(this.configPanel);
            this.Controls.Add(this.MainMenu);
            this.Name = "UC_Programmazione";
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "Programmazione SmartLine";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UC_Programmazione_Load);
            this.MainMenu.ResumeLayout(false);
            this.MainMenu.PerformLayout();
            this.commandPanel.ResumeLayout(false);
            this.commandPanel.PerformLayout();
            this.panel_dt_tmp_programmazione.ResumeLayout(false);
            this.panel_programmazione_output.ResumeLayout(false);
            this.tbl_Label_ID.ResumeLayout(false);
            this.tbl_Label_ID.PerformLayout();
            this.panel_programmazione_grid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dg_dt_tmp_programmazione)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtTmpProgrammaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            this.pan_tipoprogramma.ResumeLayout(false);
            this.tab_control_Program.ResumeLayout(false);
            this.tab_commessa.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid_commesse)).EndInit();
            this.grid_commesse_menu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sFCommesseSLBindingSource)).EndInit();
            this.tab_kit.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid_Componenti)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grid_Kit)).EndInit();
            this.tab_item.ResumeLayout(false);
            this.tab_item.PerformLayout();
            this.panel_device_image.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Device_Image)).EndInit();
            this.tab_libera.ResumeLayout(false);
            this.tab_libera.PerformLayout();
            this.pan_titolo.ResumeLayout(false);
            this.pan_titolo.PerformLayout();
            this.outputPanel.ResumeLayout(false);
            this.outputPanel.PerformLayout();
            this.configPanel.ResumeLayout(false);
            this.configPanel.PerformLayout();
            this.Panel_Config_buttons.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sFCommesseSLSFArticoliBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFDistinctItemFamPrefixBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFAnagraficaClientiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.firmwareBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.serialNumbersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFDistinteBasiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFArticoliBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFArticoliToXSWRBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fWClientiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFItemDeviceFWDesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFDistinctItemFamFunctionsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtFirmwarelookupCommesseSLBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtTmpProgrammadtFirmwareBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MainMenu;
        private System.Windows.Forms.ToolStripMenuItem uscitaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nascondiVisualizzaFirmwareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aggiornaArchiviToolStripMenuItem;
        private MetroFramework.Controls.MetroPanel commandPanel;
        private MetroFramework.Controls.MetroPanel panel_dt_tmp_programmazione;
        private MetroFramework.Controls.MetroPanel panel_programmazione_output;
        private System.Windows.Forms.TableLayoutPanel tbl_Label_ID;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel lab_IDNumber_write;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel lab_SN;
        private MetroFramework.Controls.MetroLabel lab_PartNumber;
        private MetroFramework.Controls.MetroLabel lab_IDNumber_read;
        private MetroFramework.Controls.MetroPanel panel_programmazione_result;
        private MetroFramework.Controls.MetroPanel panel_programmazione_grid;
        private MetroFramework.Controls.MetroGrid dg_dt_tmp_programmazione;
        private MetroFramework.Controls.MetroPanel pan_tipoprogramma;
        private MetroFramework.Controls.MetroTabControl tab_control_Program;
        private MetroFramework.Controls.MetroTabPage tab_commessa;
        private MetroFramework.Controls.MetroGrid grid_commesse;
        private MetroFramework.Controls.MetroTabPage tab_kit;
        private MetroFramework.Controls.MetroGrid grid_Componenti;
        private MetroFramework.Controls.MetroGrid grid_Kit;
        private MetroFramework.Controls.MetroTabPage tab_item;
        private MetroFramework.Controls.MetroComboBox cb_sceltaCliente;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel lab_device_ID;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroPanel panel_device_image;
        private System.Windows.Forms.PictureBox Device_Image;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroComboBox cb_scelta_Device;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroComboBox cb_scelta_Famiglia;
        private MetroFramework.Controls.MetroButton but_seleziona_device;
        private MetroFramework.Controls.MetroLabel lab_device_desestfw;
        private MetroFramework.Controls.MetroLabel lab_device_desfw;
        private MetroFramework.Controls.MetroLabel lab_device_codfw;
        private MetroFramework.Controls.MetroLabel lab_device_desestart;
        private MetroFramework.Controls.MetroLabel lab_device_desart;
        private MetroFramework.Controls.MetroComboBox cb_scelta_Funzioni;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroTabPage tab_libera;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroTextBox tb_Id_Hardware;
        private MetroFramework.Controls.MetroButton but_seleziona_fw;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel lab_fw_custom;
        private MetroFramework.Controls.MetroLabel lab_fw_standard;
        private MetroFramework.Controls.MetroToggle toggle_tipo_firmware;
        private MetroFramework.Controls.MetroComboBox cb_scelta_fw;
        private MetroFramework.Controls.MetroLabel lab_tipo_device_ricevitore;
        private MetroFramework.Controls.MetroLabel lab_tipo_device_palmare;
        private MetroFramework.Controls.MetroToggle toggle_tipo_device_Libera;
        private MetroFramework.Controls.MetroPanel pan_titolo;
        private MetroFramework.Controls.MetroLabel lab_command;
        private System.Windows.Forms.TreeView tv_FW;
        private MetroFramework.Controls.MetroPanel outputPanel;
        private System.Windows.Forms.TextBox dos_box;
        private MetroFramework.Controls.MetroPanel configPanel;
        private System.Windows.Forms.ComboBox TrayCmb;
        private System.Windows.Forms.ComboBox LabelWriterCmb;
        private MetroFramework.Controls.MetroLabel lab_Configurazione;
        private MetroFramework.Controls.MetroLabel lab_FW_folder;
        private MetroFramework.Controls.MetroTextBox tb_FW_folder;
        private MetroFramework.Controls.MetroLabel lab_IP_printer;
        private MetroFramework.Controls.MetroTextBox tb_IP_Printer;
        private MetroFramework.Controls.MetroLabel lab_use_printer;
        private MetroFramework.Controls.MetroToggle tog_Use_printer;
        private MetroFramework.Controls.MetroLabel lab_Commander;
        private MetroFramework.Controls.MetroTextBox tb_Commander_path;
        private System.Windows.Forms.TableLayoutPanel Panel_Config_buttons;
        private System.Windows.Forms.Button but_Edit_Config;
        private System.Windows.Forms.Button but_Save_Config;
        private System.Windows.Forms.Button but_Abort_Config;
        private ds_SL ds_SL;
        private System.Windows.Forms.BindingSource serialNumbersBindingSource;
        private ds_SLTableAdapters.SerialNumbersTableAdapter serialNumbersTableAdapter;
        private System.Windows.Forms.BindingSource sFDistinteBasiBindingSource;
        private ds_SLTableAdapters.SF_DistinteBasiTableAdapter sF_DistinteBasiTableAdapter;
        private System.Windows.Forms.BindingSource firmwareBindingSource;
        private ds_SLTableAdapters.FirmwareTableAdapter firmwareTableAdapter;
        private System.Windows.Forms.BindingSource sFArticoliBindingSource;
        private ds_SLTableAdapters.SF_ArticoliTableAdapter sF_ArticoliTableAdapter;
        private System.Windows.Forms.BindingSource sFArticoliToXSWRBindingSource;
        private ds_SLTableAdapters.SF_ArticoliToXSWRTableAdapter sF_ArticoliToXSWRTableAdapter;
        private System.Windows.Forms.BindingSource fWClientiBindingSource;
        private ds_SLTableAdapters.FW_ClientiTableAdapter fW_ClientiTableAdapter;
        private System.Windows.Forms.BindingSource sFCommesseSLBindingSource;
        private ds_SLTableAdapters.SF_Commesse_SLTableAdapter sF_Commesse_SLTableAdapter;
        private System.Windows.Forms.BindingSource sFAnagraficaClientiBindingSource;
        private ds_SLTableAdapters.SF_AnagraficaClientiTableAdapter sF_AnagraficaClientiTableAdapter;
        private System.Windows.Forms.BindingSource sFItemDeviceFWDesBindingSource;
        private ds_SLTableAdapters.SF_ItemDevice_FW_DesTableAdapter sF_ItemDevice_FW_DesTableAdapter;
        private System.Windows.Forms.BindingSource sFDistinctItemFamFunctionsBindingSource;
        private ds_SLTableAdapters.SF_Distinct_Item_Fam_FunctionsTableAdapter sF_Distinct_Item_Fam_FunctionsTableAdapter;
        private System.Windows.Forms.BindingSource sFDistinctItemFamPrefixBindingSource;
        private ds_SLTableAdapters.SF_Distinct_Item_Fam_PrefixTableAdapter sF_Distinct_Item_Fam_PrefixTableAdapter;
        private MetroFramework.Controls.MetroContextMenu grid_commesse_menu;
        private System.Windows.Forms.ToolStripMenuItem menu_commesse_vis;
        private System.Windows.Forms.ToolStripMenuItem menu_commesse_nas;
        private System.Windows.Forms.BindingSource sFCommesseSLSFArticoliBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_CommessaShort;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_DataConsegna;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_RagioneSociale;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_NumRiga;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_CodArticoloCommessa;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_Device;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_QtaDaEvadere;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_Qta_Evasa;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_TipoOrdine;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_CommessaLong;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_DataOrdine;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_NumeroOrdine;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_UM;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_TipoRiga;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_IsSwrP;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_IsSwrR;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_SwDevice;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_CodAnagrafico;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_QtaOrdinata;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_StatoCommessa;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_IsKit;
        private System.Windows.Forms.DataGridViewTextBoxColumn grid_commesse_DataFineValidita;
        private System.Windows.Forms.DataGridViewButtonColumn grid_commesse_ViewDevice;
        private System.Windows.Forms.DataGridViewButtonColumn grid_commesse_CommessaSelezionata;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataConfermaConsegnaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeroRigaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn artCommessaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtadaEvadereDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn deviceDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource dtTmpProgrammaBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn dg_dt_tmp_progr_Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn dg_dt_tmp_progr_Commessa;
        private System.Windows.Forms.DataGridViewTextBoxColumn dg_dt_tmp_progr_Kit;
        private System.Windows.Forms.DataGridViewTextBoxColumn dg_dt_tmp_progr_Device;
        private System.Windows.Forms.DataGridViewTextBoxColumn dg_dt_tmp_progr_Fw;
        private System.Windows.Forms.DataGridViewTextBoxColumn dg_dt_tmp_progr_FwKeyId;
        private System.Windows.Forms.DataGridViewTextBoxColumn dg_dt_tmp_progr_ID_Hardware;
        private System.Windows.Forms.DataGridViewButtonColumn Programma;
        private System.Windows.Forms.DataGridViewTextBoxColumn tmpfwkeyidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tmpIDHardwareDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource dtFirmwarelookupCommesseSLBindingSource;
        private ds_SLTableAdapters.dt_Firmware_lookupCommesseSLTableAdapter dt_Firmware_lookupCommesseSLTableAdapter;
        private System.Windows.Forms.BindingSource dtTmpProgrammadtFirmwareBindingSource;
    }
}