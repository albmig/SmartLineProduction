﻿namespace SmartLineProduction
{
    partial class MainMenu
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenu));
            this.tile_Programmazione = new MetroFramework.Controls.MetroTile();
            this.layout_Menu = new System.Windows.Forms.TableLayoutPanel();
            this.tile_Avanzamento = new MetroFramework.Controls.MetroTile();
            this.tile_Spedizione = new MetroFramework.Controls.MetroTile();
            this.panel_Logo = new MetroFramework.Controls.MetroPanel();
            this.tile_Exit = new MetroFramework.Controls.MetroTile();
            this.layout_Menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // tile_Programmazione
            // 
            this.tile_Programmazione.ActiveControl = null;
            this.layout_Menu.SetColumnSpan(this.tile_Programmazione, 2);
            this.tile_Programmazione.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tile_Programmazione.Location = new System.Drawing.Point(3, 188);
            this.tile_Programmazione.Name = "tile_Programmazione";
            this.tile_Programmazione.Size = new System.Drawing.Size(146, 31);
            this.tile_Programmazione.Style = MetroFramework.MetroColorStyle.Red;
            this.tile_Programmazione.TabIndex = 0;
            this.tile_Programmazione.Text = "Programmazione";
            this.tile_Programmazione.TileImage = ((System.Drawing.Image)(resources.GetObject("tile_Programmazione.TileImage")));
            this.tile_Programmazione.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.tile_Programmazione.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile_Programmazione.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tile_Programmazione.UseSelectable = true;
            this.tile_Programmazione.UseTileImage = true;
            this.tile_Programmazione.Click += new System.EventHandler(this.tile_Programmazione_Click);
            // 
            // layout_Menu
            // 
            this.layout_Menu.ColumnCount = 10;
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.Controls.Add(this.tile_Exit, 8, 9);
            this.layout_Menu.Controls.Add(this.tile_Avanzamento, 3, 5);
            this.layout_Menu.Controls.Add(this.tile_Spedizione, 0, 7);
            this.layout_Menu.Controls.Add(this.tile_Programmazione, 0, 5);
            this.layout_Menu.Controls.Add(this.panel_Logo, 0, 0);
            this.layout_Menu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Menu.Location = new System.Drawing.Point(20, 60);
            this.layout_Menu.Name = "layout_Menu";
            this.layout_Menu.RowCount = 10;
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.Size = new System.Drawing.Size(760, 370);
            this.layout_Menu.TabIndex = 1;
            // 
            // tile_Avanzamento
            // 
            this.tile_Avanzamento.ActiveControl = null;
            this.layout_Menu.SetColumnSpan(this.tile_Avanzamento, 2);
            this.tile_Avanzamento.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tile_Avanzamento.Location = new System.Drawing.Point(231, 188);
            this.tile_Avanzamento.Name = "tile_Avanzamento";
            this.tile_Avanzamento.Size = new System.Drawing.Size(146, 31);
            this.tile_Avanzamento.Style = MetroFramework.MetroColorStyle.Blue;
            this.tile_Avanzamento.TabIndex = 3;
            this.tile_Avanzamento.Text = "Avanzamento Commesse";
            this.tile_Avanzamento.TileImage = ((System.Drawing.Image)(resources.GetObject("tile_Avanzamento.TileImage")));
            this.tile_Avanzamento.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.tile_Avanzamento.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile_Avanzamento.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tile_Avanzamento.UseSelectable = true;
            this.tile_Avanzamento.UseStyleColors = true;
            this.tile_Avanzamento.UseTileImage = true;
            this.tile_Avanzamento.Click += new System.EventHandler(this.tile_Avanzamento_Click);
            // 
            // tile_Spedizione
            // 
            this.tile_Spedizione.ActiveControl = null;
            this.layout_Menu.SetColumnSpan(this.tile_Spedizione, 2);
            this.tile_Spedizione.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tile_Spedizione.Location = new System.Drawing.Point(3, 262);
            this.tile_Spedizione.Name = "tile_Spedizione";
            this.tile_Spedizione.Size = new System.Drawing.Size(146, 31);
            this.tile_Spedizione.Style = MetroFramework.MetroColorStyle.Red;
            this.tile_Spedizione.TabIndex = 1;
            this.tile_Spedizione.Text = "Spedizione";
            this.tile_Spedizione.TileImage = ((System.Drawing.Image)(resources.GetObject("tile_Spedizione.TileImage")));
            this.tile_Spedizione.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.tile_Spedizione.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile_Spedizione.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tile_Spedizione.UseSelectable = true;
            this.tile_Spedizione.UseTileImage = true;
            this.tile_Spedizione.Click += new System.EventHandler(this.tile_Spedizione_Click);
            // 
            // panel_Logo
            // 
            this.panel_Logo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_Logo.BackgroundImage")));
            this.panel_Logo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.layout_Menu.SetColumnSpan(this.panel_Logo, 2);
            this.panel_Logo.HorizontalScrollbarBarColor = true;
            this.panel_Logo.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_Logo.HorizontalScrollbarSize = 10;
            this.panel_Logo.Location = new System.Drawing.Point(3, 3);
            this.panel_Logo.Name = "panel_Logo";
            this.layout_Menu.SetRowSpan(this.panel_Logo, 4);
            this.panel_Logo.Size = new System.Drawing.Size(146, 142);
            this.panel_Logo.TabIndex = 2;
            this.panel_Logo.VerticalScrollbarBarColor = true;
            this.panel_Logo.VerticalScrollbarHighlightOnWheel = false;
            this.panel_Logo.VerticalScrollbarSize = 10;
            // 
            // tile_Exit
            // 
            this.tile_Exit.ActiveControl = null;
            this.layout_Menu.SetColumnSpan(this.tile_Exit, 2);
            this.tile_Exit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tile_Exit.Location = new System.Drawing.Point(611, 336);
            this.tile_Exit.Name = "tile_Exit";
            this.tile_Exit.Size = new System.Drawing.Size(146, 31);
            this.tile_Exit.Style = MetroFramework.MetroColorStyle.Silver;
            this.tile_Exit.TabIndex = 4;
            this.tile_Exit.Text = "Uscita";
            this.tile_Exit.TileImage = ((System.Drawing.Image)(resources.GetObject("tile_Exit.TileImage")));
            this.tile_Exit.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.tile_Exit.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile_Exit.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tile_Exit.UseSelectable = true;
            this.tile_Exit.UseStyleColors = true;
            this.tile_Exit.UseTileImage = true;
            this.tile_Exit.Click += new System.EventHandler(this.tile_Exit_Click);
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.layout_Menu);
            this.Name = "MainMenu";
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "Sistematica - SmartLine";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.layout_Menu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTile tile_Programmazione;
        private System.Windows.Forms.TableLayoutPanel layout_Menu;
        private MetroFramework.Controls.MetroTile tile_Spedizione;
        private MetroFramework.Controls.MetroPanel panel_Logo;
        private MetroFramework.Controls.MetroTile tile_Avanzamento;
        private MetroFramework.Controls.MetroTile tile_Exit;
    }
}

