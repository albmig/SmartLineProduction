﻿namespace SmartLineProduction
{
    partial class UC_Spedizione
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Spedizione));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lab_Etichetta = new MetroFramework.Controls.MetroLabel();
            this.tbx_ReadLabel_Device = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.lab_read_FW = new MetroFramework.Controls.MetroLabel();
            this.lab_read_Device = new MetroFramework.Controls.MetroLabel();
            this.lab_read_SN = new MetroFramework.Controls.MetroLabel();
            this.but_AttivaProc = new MetroFramework.Controls.MetroButton();
            this.but_AssegnaLottoVuoto = new MetroFramework.Controls.MetroButton();
            this.layout_orizz_menu = new System.Windows.Forms.TableLayoutPanel();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.layout_spedizioni = new System.Windows.Forms.TableLayoutPanel();
            this.panel_ric_commessa = new MetroFramework.Controls.MetroPanel();
            this.tb_ric_Commessa = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.panel_grid_avanzamento = new MetroFramework.Controls.MetroPanel();
            this.gv_Avanzamento = new MetroFramework.Controls.MetroGrid();
            this.commessaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COMMESSALONG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RAGIONE_SOCIALE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NazioneFiscale = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ARTICOLO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtaordineDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOProgrammazioneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOProgrammazioneNoteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtaprogrammazioneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOMontaggioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOMontaggioNoteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtamontaggioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOCollaudoConfezionamentoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOCollaudoConfezionamentoNoteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtacollaudoconfezionamentoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOVenditaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOVenditaNoteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtavenditaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOImballoNoteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOSpedizioneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aOSpedizioneNoteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.distintaBaseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtaspedizioneprogressivaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.spedizioniBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.ds_Programmazione = new SmartLineProduction.ds_Programmazione();
            this.panel_SN = new MetroFramework.Controls.MetroPanel();
            this.btn_conf_serial = new MetroFramework.Controls.MetroButton();
            this.lab_articolo_todo = new MetroFramework.Controls.MetroLabel();
            this.lab_SN_todo = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.tbx_ReadLabel_NFC = new MetroFramework.Controls.MetroTextBox();
            this.lab_read_ID = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.panel_attiva_proc = new System.Windows.Forms.TableLayoutPanel();
            this.but_TerminaProc = new MetroFramework.Controls.MetroButton();
            this.but_ChiusuraCollConf = new MetroFramework.Controls.MetroButton();
            this.pan_note_programmazione = new MetroFramework.Controls.MetroPanel();
            this.pic_note_programmazione = new System.Windows.Forms.PictureBox();
            this.lab_note_programmazione = new MetroFramework.Controls.MetroLabel();
            this.tb_note_programmazione = new MetroFramework.Controls.MetroTextBox();
            this.pan_note_montaggio = new MetroFramework.Controls.MetroPanel();
            this.pic_note_montaggio = new System.Windows.Forms.PictureBox();
            this.lab_note_montaggio = new MetroFramework.Controls.MetroLabel();
            this.tb_note_montaggio = new MetroFramework.Controls.MetroTextBox();
            this.pan_note_collconf = new MetroFramework.Controls.MetroPanel();
            this.pic_note_collconf = new System.Windows.Forms.PictureBox();
            this.lab_note_collconf = new MetroFramework.Controls.MetroLabel();
            this.tb_note_collconf = new MetroFramework.Controls.MetroTextBox();
            this.pan_note_vendita = new MetroFramework.Controls.MetroPanel();
            this.pic_note_vendita = new System.Windows.Forms.PictureBox();
            this.lab_note_vendita = new MetroFramework.Controls.MetroLabel();
            this.tb_note_vendita = new MetroFramework.Controls.MetroTextBox();
            this.pan_note_spedizione = new MetroFramework.Controls.MetroPanel();
            this.pic_note_spedizione = new System.Windows.Forms.PictureBox();
            this.lab_note_spedizione = new MetroFramework.Controls.MetroLabel();
            this.tb_note_spedizione = new MetroFramework.Controls.MetroTextBox();
            this.panel_SN_label = new MetroFramework.Controls.MetroPanel();
            this.gv_SerialNumber = new MetroFramework.Controls.MetroGrid();
            this.spedizioniSNBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.spedizioniSNSpedizioniLottiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.spedizioniSNSpedizioniIDSerialNumbersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.serialNumbersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.serialNumbersTableAdapter = new SmartLineProduction.ds_ProgrammazioneTableAdapters.SerialNumbersTableAdapter();
            this.sFAnagraficaClientiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_AnagraficaClientiTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SF_AnagraficaClientiTableAdapter();
            this.spedizioniTableAdapter = new SmartLineProduction.ds_SLTableAdapters.SpedizioniTableAdapter();
            this.spedizioni_SNTableAdapter = new SmartLineProduction.ds_SLTableAdapters.Spedizioni_SNTableAdapter();
            this.spedizioni_LottiTableAdapter = new SmartLineProduction.ds_SLTableAdapters.Spedizioni_LottiTableAdapter();
            this.spedizioni_IDSerialNumbersTableAdapter = new SmartLineProduction.ds_SLTableAdapters.Spedizioni_IDSerialNumbersTableAdapter();
            this.HasLotti = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.gv_SerialNumber_SerialNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_SerialNumber_Articolo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_SerialNumber_RagioneSociale = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_SerialNumber_Descrizione = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_SerialNumber_Commessa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_SerialNumber_OfficialID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_SerialNumber_QRCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.layout_orizz_menu.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            this.layout_spedizioni.SuspendLayout();
            this.panel_ric_commessa.SuspendLayout();
            this.panel_grid_avanzamento.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Avanzamento)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spedizioniBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            this.panel_SN.SuspendLayout();
            this.panel_attiva_proc.SuspendLayout();
            this.pan_note_programmazione.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_note_programmazione)).BeginInit();
            this.pan_note_montaggio.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_note_montaggio)).BeginInit();
            this.pan_note_collconf.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_note_collconf)).BeginInit();
            this.pan_note_vendita.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_note_vendita)).BeginInit();
            this.pan_note_spedizione.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_note_spedizione)).BeginInit();
            this.panel_SN_label.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_SerialNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spedizioniSNBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spedizioniSNSpedizioniLottiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spedizioniSNSpedizioniIDSerialNumbersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.serialNumbersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFAnagraficaClientiBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // lab_Etichetta
            // 
            this.lab_Etichetta.AutoSize = true;
            this.lab_Etichetta.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_Etichetta.Location = new System.Drawing.Point(0, 44);
            this.lab_Etichetta.Name = "lab_Etichetta";
            this.lab_Etichetta.Size = new System.Drawing.Size(257, 19);
            this.lab_Etichetta.TabIndex = 0;
            this.lab_Etichetta.Text = "Lettura dell\'etichetta presente sul device:";
            // 
            // tbx_ReadLabel_Device
            // 
            // 
            // 
            // 
            this.tbx_ReadLabel_Device.CustomButton.Image = null;
            this.tbx_ReadLabel_Device.CustomButton.Location = new System.Drawing.Point(254, 1);
            this.tbx_ReadLabel_Device.CustomButton.Name = "";
            this.tbx_ReadLabel_Device.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tbx_ReadLabel_Device.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbx_ReadLabel_Device.CustomButton.TabIndex = 1;
            this.tbx_ReadLabel_Device.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbx_ReadLabel_Device.CustomButton.UseSelectable = true;
            this.tbx_ReadLabel_Device.CustomButton.Visible = false;
            this.tbx_ReadLabel_Device.Lines = new string[0];
            this.tbx_ReadLabel_Device.Location = new System.Drawing.Point(0, 66);
            this.tbx_ReadLabel_Device.MaxLength = 32767;
            this.tbx_ReadLabel_Device.Multiline = true;
            this.tbx_ReadLabel_Device.Name = "tbx_ReadLabel_Device";
            this.tbx_ReadLabel_Device.PasswordChar = '\0';
            this.tbx_ReadLabel_Device.PromptText = "Lettura del QR-Code";
            this.tbx_ReadLabel_Device.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbx_ReadLabel_Device.SelectedText = "";
            this.tbx_ReadLabel_Device.SelectionLength = 0;
            this.tbx_ReadLabel_Device.SelectionStart = 0;
            this.tbx_ReadLabel_Device.ShortcutsEnabled = true;
            this.tbx_ReadLabel_Device.Size = new System.Drawing.Size(276, 23);
            this.tbx_ReadLabel_Device.TabIndex = 0;
            this.tbx_ReadLabel_Device.UseSelectable = true;
            this.tbx_ReadLabel_Device.WaterMark = "Lettura del QR-Code";
            this.tbx_ReadLabel_Device.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tbx_ReadLabel_Device.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tbx_ReadLabel_Device.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbx_ReadLabel_Device_KeyPress);
            this.tbx_ReadLabel_Device.Leave += new System.EventHandler(this.tbx_ReadLabel_Device_Leave);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(0, 94);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(107, 19);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "Numero di serie:";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(0, 134);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(50, 19);
            this.metroLabel2.TabIndex = 3;
            this.metroLabel2.Text = "Device:";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(0, 154);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(122, 19);
            this.metroLabel3.TabIndex = 4;
            this.metroLabel3.Text = "Firmware installato:";
            // 
            // lab_read_FW
            // 
            this.lab_read_FW.AutoSize = true;
            this.lab_read_FW.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_read_FW.Location = new System.Drawing.Point(130, 154);
            this.lab_read_FW.Name = "lab_read_FW";
            this.lab_read_FW.Size = new System.Drawing.Size(86, 19);
            this.lab_read_FW.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_read_FW.TabIndex = 7;
            this.lab_read_FW.Text = "lab_read_FW";
            this.lab_read_FW.UseStyleColors = true;
            // 
            // lab_read_Device
            // 
            this.lab_read_Device.AutoSize = true;
            this.lab_read_Device.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_read_Device.Location = new System.Drawing.Point(130, 134);
            this.lab_read_Device.Name = "lab_read_Device";
            this.lab_read_Device.Size = new System.Drawing.Size(106, 19);
            this.lab_read_Device.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_read_Device.TabIndex = 6;
            this.lab_read_Device.Text = "lab_read_Device";
            this.lab_read_Device.UseStyleColors = true;
            // 
            // lab_read_SN
            // 
            this.lab_read_SN.AutoSize = true;
            this.lab_read_SN.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_read_SN.Location = new System.Drawing.Point(130, 94);
            this.lab_read_SN.Name = "lab_read_SN";
            this.lab_read_SN.Size = new System.Drawing.Size(83, 19);
            this.lab_read_SN.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_read_SN.TabIndex = 5;
            this.lab_read_SN.Text = "lab_read_SN";
            this.lab_read_SN.UseStyleColors = true;
            // 
            // but_AttivaProc
            // 
            this.but_AttivaProc.BackColor = System.Drawing.Color.White;
            this.but_AttivaProc.Dock = System.Windows.Forms.DockStyle.Top;
            this.but_AttivaProc.Location = new System.Drawing.Point(3, 3);
            this.but_AttivaProc.Name = "but_AttivaProc";
            this.but_AttivaProc.Size = new System.Drawing.Size(276, 23);
            this.but_AttivaProc.Style = MetroFramework.MetroColorStyle.Green;
            this.but_AttivaProc.TabIndex = 0;
            this.but_AttivaProc.Text = "Inizia Procedura";
            this.but_AttivaProc.UseSelectable = true;
            this.but_AttivaProc.UseStyleColors = true;
            this.but_AttivaProc.Click += new System.EventHandler(this.but_Associa_Click);
            // 
            // but_AssegnaLottoVuoto
            // 
            this.but_AssegnaLottoVuoto.BackColor = System.Drawing.Color.White;
            this.but_AssegnaLottoVuoto.Dock = System.Windows.Forms.DockStyle.Top;
            this.but_AssegnaLottoVuoto.Location = new System.Drawing.Point(3, 61);
            this.but_AssegnaLottoVuoto.Name = "but_AssegnaLottoVuoto";
            this.but_AssegnaLottoVuoto.Size = new System.Drawing.Size(276, 23);
            this.but_AssegnaLottoVuoto.Style = MetroFramework.MetroColorStyle.Magenta;
            this.but_AssegnaLottoVuoto.TabIndex = 2;
            this.but_AssegnaLottoVuoto.Text = "Assegna lotto -UNDEFINED-";
            this.but_AssegnaLottoVuoto.UseSelectable = true;
            this.but_AssegnaLottoVuoto.UseStyleColors = true;
            this.but_AssegnaLottoVuoto.Click += new System.EventHandler(this.but_AssegnaLottoVuoto_Click);
            // 
            // layout_orizz_menu
            // 
            this.layout_orizz_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.ColumnCount = 10;
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_exit, 10, 0);
            this.layout_orizz_menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_orizz_menu.Location = new System.Drawing.Point(20, 30);
            this.layout_orizz_menu.Name = "layout_orizz_menu";
            this.layout_orizz_menu.RowCount = 1;
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_orizz_menu.Size = new System.Drawing.Size(1003, 25);
            this.layout_orizz_menu.TabIndex = 121;
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Gainsboro;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(928, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(75, 24);
            this.pan_Menu_exit.TabIndex = 82;
            this.pan_Menu_exit.Text = "menuStrip1";
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            this.menu_sw_exit.Click += new System.EventHandler(this.menu_sw_exit_Click);
            // 
            // layout_spedizioni
            // 
            this.layout_spedizioni.ColumnCount = 8;
            this.layout_spedizioni.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_spedizioni.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_spedizioni.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_spedizioni.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_spedizioni.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_spedizioni.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_spedizioni.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_spedizioni.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_spedizioni.Controls.Add(this.panel_ric_commessa, 0, 0);
            this.layout_spedizioni.Controls.Add(this.panel_grid_avanzamento, 0, 1);
            this.layout_spedizioni.Controls.Add(this.panel_SN, 6, 2);
            this.layout_spedizioni.Controls.Add(this.panel_attiva_proc, 6, 1);
            this.layout_spedizioni.Controls.Add(this.pan_note_programmazione, 3, 2);
            this.layout_spedizioni.Controls.Add(this.tb_note_programmazione, 4, 2);
            this.layout_spedizioni.Controls.Add(this.pan_note_montaggio, 3, 3);
            this.layout_spedizioni.Controls.Add(this.tb_note_montaggio, 4, 3);
            this.layout_spedizioni.Controls.Add(this.pan_note_collconf, 3, 4);
            this.layout_spedizioni.Controls.Add(this.tb_note_collconf, 4, 4);
            this.layout_spedizioni.Controls.Add(this.pan_note_vendita, 3, 5);
            this.layout_spedizioni.Controls.Add(this.tb_note_vendita, 4, 5);
            this.layout_spedizioni.Controls.Add(this.pan_note_spedizione, 3, 6);
            this.layout_spedizioni.Controls.Add(this.tb_note_spedizione, 4, 6);
            this.layout_spedizioni.Controls.Add(this.panel_SN_label, 0, 2);
            this.layout_spedizioni.Controls.Add(this.metroButton2, 3, 7);
            this.layout_spedizioni.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_spedizioni.Location = new System.Drawing.Point(20, 55);
            this.layout_spedizioni.Name = "layout_spedizioni";
            this.layout_spedizioni.RowCount = 8;
            this.layout_spedizioni.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_spedizioni.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_spedizioni.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_spedizioni.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_spedizioni.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_spedizioni.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_spedizioni.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_spedizioni.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_spedizioni.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_spedizioni.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_spedizioni.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_spedizioni.Size = new System.Drawing.Size(1003, 725);
            this.layout_spedizioni.TabIndex = 122;
            // 
            // panel_ric_commessa
            // 
            this.layout_spedizioni.SetColumnSpan(this.panel_ric_commessa, 3);
            this.panel_ric_commessa.Controls.Add(this.tb_ric_Commessa);
            this.panel_ric_commessa.Controls.Add(this.metroLabel9);
            this.panel_ric_commessa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_ric_commessa.HorizontalScrollbarBarColor = true;
            this.panel_ric_commessa.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_ric_commessa.HorizontalScrollbarSize = 10;
            this.panel_ric_commessa.Location = new System.Drawing.Point(3, 3);
            this.panel_ric_commessa.Name = "panel_ric_commessa";
            this.panel_ric_commessa.Size = new System.Drawing.Size(369, 50);
            this.panel_ric_commessa.TabIndex = 126;
            this.panel_ric_commessa.VerticalScrollbarBarColor = true;
            this.panel_ric_commessa.VerticalScrollbarHighlightOnWheel = false;
            this.panel_ric_commessa.VerticalScrollbarSize = 10;
            // 
            // tb_ric_Commessa
            // 
            this.tb_ric_Commessa.BackColor = System.Drawing.Color.LightYellow;
            // 
            // 
            // 
            this.tb_ric_Commessa.CustomButton.Image = null;
            this.tb_ric_Commessa.CustomButton.Location = new System.Drawing.Point(178, 1);
            this.tb_ric_Commessa.CustomButton.Name = "";
            this.tb_ric_Commessa.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_ric_Commessa.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_ric_Commessa.CustomButton.TabIndex = 1;
            this.tb_ric_Commessa.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_ric_Commessa.CustomButton.UseSelectable = true;
            this.tb_ric_Commessa.CustomButton.Visible = false;
            this.tb_ric_Commessa.Lines = new string[0];
            this.tb_ric_Commessa.Location = new System.Drawing.Point(0, 22);
            this.tb_ric_Commessa.MaxLength = 32767;
            this.tb_ric_Commessa.Multiline = true;
            this.tb_ric_Commessa.Name = "tb_ric_Commessa";
            this.tb_ric_Commessa.PasswordChar = '\0';
            this.tb_ric_Commessa.PromptText = "Codice commessa";
            this.tb_ric_Commessa.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_ric_Commessa.SelectedText = "";
            this.tb_ric_Commessa.SelectionLength = 0;
            this.tb_ric_Commessa.SelectionStart = 0;
            this.tb_ric_Commessa.ShortcutsEnabled = true;
            this.tb_ric_Commessa.Size = new System.Drawing.Size(200, 23);
            this.tb_ric_Commessa.TabIndex = 10;
            this.tb_ric_Commessa.UseCustomBackColor = true;
            this.tb_ric_Commessa.UseSelectable = true;
            this.tb_ric_Commessa.WaterMark = "Codice commessa";
            this.tb_ric_Commessa.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_ric_Commessa.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tb_ric_Commessa.TextChanged += new System.EventHandler(this.tb_ric_Commessa_TextChanged);
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel9.Location = new System.Drawing.Point(0, 0);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(196, 19);
            this.metroLabel9.TabIndex = 9;
            this.metroLabel9.Text = "Ricerca rapida della commessa:";
            // 
            // panel_grid_avanzamento
            // 
            this.panel_grid_avanzamento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.layout_spedizioni.SetColumnSpan(this.panel_grid_avanzamento, 6);
            this.panel_grid_avanzamento.Controls.Add(this.gv_Avanzamento);
            this.panel_grid_avanzamento.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_grid_avanzamento.HorizontalScrollbarBarColor = true;
            this.panel_grid_avanzamento.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_grid_avanzamento.HorizontalScrollbarSize = 10;
            this.panel_grid_avanzamento.Location = new System.Drawing.Point(3, 59);
            this.panel_grid_avanzamento.Name = "panel_grid_avanzamento";
            this.panel_grid_avanzamento.Size = new System.Drawing.Size(744, 238);
            this.panel_grid_avanzamento.TabIndex = 127;
            this.panel_grid_avanzamento.VerticalScrollbarBarColor = true;
            this.panel_grid_avanzamento.VerticalScrollbarHighlightOnWheel = false;
            this.panel_grid_avanzamento.VerticalScrollbarSize = 10;
            // 
            // gv_Avanzamento
            // 
            this.gv_Avanzamento.AllowUserToAddRows = false;
            this.gv_Avanzamento.AllowUserToDeleteRows = false;
            this.gv_Avanzamento.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_Avanzamento.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.gv_Avanzamento.AutoGenerateColumns = false;
            this.gv_Avanzamento.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Avanzamento.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Avanzamento.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_Avanzamento.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Avanzamento.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gv_Avanzamento.ColumnHeadersHeight = 40;
            this.gv_Avanzamento.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.commessaDataGridViewTextBoxColumn,
            this.COMMESSALONG,
            this.RAGIONE_SOCIALE,
            this.NazioneFiscale,
            this.ARTICOLO,
            this.qtaordineDataGridViewTextBoxColumn,
            this.aOProgrammazioneDataGridViewTextBoxColumn,
            this.aOProgrammazioneNoteDataGridViewTextBoxColumn,
            this.qtaprogrammazioneDataGridViewTextBoxColumn,
            this.aOMontaggioDataGridViewTextBoxColumn,
            this.aOMontaggioNoteDataGridViewTextBoxColumn,
            this.qtamontaggioDataGridViewTextBoxColumn,
            this.aOCollaudoConfezionamentoDataGridViewTextBoxColumn,
            this.aOCollaudoConfezionamentoNoteDataGridViewTextBoxColumn,
            this.qtacollaudoconfezionamentoDataGridViewTextBoxColumn,
            this.aOVenditaDataGridViewTextBoxColumn,
            this.aOVenditaNoteDataGridViewTextBoxColumn,
            this.qtavenditaDataGridViewTextBoxColumn,
            this.aOImballoNoteDataGridViewTextBoxColumn,
            this.aOSpedizioneDataGridViewTextBoxColumn,
            this.aOSpedizioneNoteDataGridViewTextBoxColumn,
            this.distintaBaseDataGridViewTextBoxColumn,
            this.qtaspedizioneprogressivaDataGridViewTextBoxColumn});
            this.gv_Avanzamento.DataSource = this.spedizioniBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Avanzamento.DefaultCellStyle = dataGridViewCellStyle3;
            this.gv_Avanzamento.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Avanzamento.EnableHeadersVisualStyles = false;
            this.gv_Avanzamento.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Avanzamento.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Avanzamento.Location = new System.Drawing.Point(0, 0);
            this.gv_Avanzamento.MultiSelect = false;
            this.gv_Avanzamento.Name = "gv_Avanzamento";
            this.gv_Avanzamento.ReadOnly = true;
            this.gv_Avanzamento.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Avanzamento.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.gv_Avanzamento.RowHeadersVisible = false;
            this.gv_Avanzamento.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Avanzamento.RowTemplate.Height = 30;
            this.gv_Avanzamento.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Avanzamento.Size = new System.Drawing.Size(742, 236);
            this.gv_Avanzamento.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_Avanzamento.TabIndex = 50;
            this.gv_Avanzamento.UseStyleColors = true;
            // 
            // commessaDataGridViewTextBoxColumn
            // 
            this.commessaDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.commessaDataGridViewTextBoxColumn.DataPropertyName = "Commessa";
            this.commessaDataGridViewTextBoxColumn.HeaderText = "Commessa";
            this.commessaDataGridViewTextBoxColumn.Name = "commessaDataGridViewTextBoxColumn";
            this.commessaDataGridViewTextBoxColumn.ReadOnly = true;
            this.commessaDataGridViewTextBoxColumn.Width = 84;
            // 
            // COMMESSALONG
            // 
            this.COMMESSALONG.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.COMMESSALONG.DataPropertyName = "COMMESSALONG";
            this.COMMESSALONG.HeaderText = "Commessa";
            this.COMMESSALONG.Name = "COMMESSALONG";
            this.COMMESSALONG.ReadOnly = true;
            this.COMMESSALONG.Width = 84;
            // 
            // RAGIONE_SOCIALE
            // 
            this.RAGIONE_SOCIALE.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.RAGIONE_SOCIALE.DataPropertyName = "RAGIONE_SOCIALE";
            this.RAGIONE_SOCIALE.HeaderText = "Ragione Sociale";
            this.RAGIONE_SOCIALE.Name = "RAGIONE_SOCIALE";
            this.RAGIONE_SOCIALE.ReadOnly = true;
            // 
            // NazioneFiscale
            // 
            this.NazioneFiscale.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.NazioneFiscale.DataPropertyName = "NazioneFiscale";
            this.NazioneFiscale.HeaderText = "Nazione Fiscale";
            this.NazioneFiscale.Name = "NazioneFiscale";
            this.NazioneFiscale.ReadOnly = true;
            // 
            // ARTICOLO
            // 
            this.ARTICOLO.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.ARTICOLO.DataPropertyName = "ARTICOLO";
            this.ARTICOLO.HeaderText = "Articolo";
            this.ARTICOLO.Name = "ARTICOLO";
            this.ARTICOLO.ReadOnly = true;
            this.ARTICOLO.Width = 70;
            // 
            // qtaordineDataGridViewTextBoxColumn
            // 
            this.qtaordineDataGridViewTextBoxColumn.DataPropertyName = "qta_ordine";
            this.qtaordineDataGridViewTextBoxColumn.HeaderText = "Q.tà Ordine";
            this.qtaordineDataGridViewTextBoxColumn.Name = "qtaordineDataGridViewTextBoxColumn";
            this.qtaordineDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // aOProgrammazioneDataGridViewTextBoxColumn
            // 
            this.aOProgrammazioneDataGridViewTextBoxColumn.DataPropertyName = "AO_Programmazione";
            this.aOProgrammazioneDataGridViewTextBoxColumn.HeaderText = "AO_Programmazione";
            this.aOProgrammazioneDataGridViewTextBoxColumn.Name = "aOProgrammazioneDataGridViewTextBoxColumn";
            this.aOProgrammazioneDataGridViewTextBoxColumn.ReadOnly = true;
            this.aOProgrammazioneDataGridViewTextBoxColumn.Visible = false;
            // 
            // aOProgrammazioneNoteDataGridViewTextBoxColumn
            // 
            this.aOProgrammazioneNoteDataGridViewTextBoxColumn.DataPropertyName = "AO_Programmazione_Note";
            this.aOProgrammazioneNoteDataGridViewTextBoxColumn.HeaderText = "AO_Programmazione_Note";
            this.aOProgrammazioneNoteDataGridViewTextBoxColumn.Name = "aOProgrammazioneNoteDataGridViewTextBoxColumn";
            this.aOProgrammazioneNoteDataGridViewTextBoxColumn.ReadOnly = true;
            this.aOProgrammazioneNoteDataGridViewTextBoxColumn.Visible = false;
            // 
            // qtaprogrammazioneDataGridViewTextBoxColumn
            // 
            this.qtaprogrammazioneDataGridViewTextBoxColumn.DataPropertyName = "qta_programmazione";
            this.qtaprogrammazioneDataGridViewTextBoxColumn.HeaderText = "qta_programmazione";
            this.qtaprogrammazioneDataGridViewTextBoxColumn.Name = "qtaprogrammazioneDataGridViewTextBoxColumn";
            this.qtaprogrammazioneDataGridViewTextBoxColumn.ReadOnly = true;
            this.qtaprogrammazioneDataGridViewTextBoxColumn.Visible = false;
            // 
            // aOMontaggioDataGridViewTextBoxColumn
            // 
            this.aOMontaggioDataGridViewTextBoxColumn.DataPropertyName = "AO_Montaggio";
            this.aOMontaggioDataGridViewTextBoxColumn.HeaderText = "AO_Montaggio";
            this.aOMontaggioDataGridViewTextBoxColumn.Name = "aOMontaggioDataGridViewTextBoxColumn";
            this.aOMontaggioDataGridViewTextBoxColumn.ReadOnly = true;
            this.aOMontaggioDataGridViewTextBoxColumn.Visible = false;
            // 
            // aOMontaggioNoteDataGridViewTextBoxColumn
            // 
            this.aOMontaggioNoteDataGridViewTextBoxColumn.DataPropertyName = "AO_Montaggio_Note";
            this.aOMontaggioNoteDataGridViewTextBoxColumn.HeaderText = "AO_Montaggio_Note";
            this.aOMontaggioNoteDataGridViewTextBoxColumn.Name = "aOMontaggioNoteDataGridViewTextBoxColumn";
            this.aOMontaggioNoteDataGridViewTextBoxColumn.ReadOnly = true;
            this.aOMontaggioNoteDataGridViewTextBoxColumn.Visible = false;
            // 
            // qtamontaggioDataGridViewTextBoxColumn
            // 
            this.qtamontaggioDataGridViewTextBoxColumn.DataPropertyName = "qta_montaggio";
            this.qtamontaggioDataGridViewTextBoxColumn.HeaderText = "qta_montaggio";
            this.qtamontaggioDataGridViewTextBoxColumn.Name = "qtamontaggioDataGridViewTextBoxColumn";
            this.qtamontaggioDataGridViewTextBoxColumn.ReadOnly = true;
            this.qtamontaggioDataGridViewTextBoxColumn.Visible = false;
            // 
            // aOCollaudoConfezionamentoDataGridViewTextBoxColumn
            // 
            this.aOCollaudoConfezionamentoDataGridViewTextBoxColumn.DataPropertyName = "AO_CollaudoConfezionamento";
            this.aOCollaudoConfezionamentoDataGridViewTextBoxColumn.HeaderText = "AO_CollaudoConfezionamento";
            this.aOCollaudoConfezionamentoDataGridViewTextBoxColumn.Name = "aOCollaudoConfezionamentoDataGridViewTextBoxColumn";
            this.aOCollaudoConfezionamentoDataGridViewTextBoxColumn.ReadOnly = true;
            this.aOCollaudoConfezionamentoDataGridViewTextBoxColumn.Visible = false;
            // 
            // aOCollaudoConfezionamentoNoteDataGridViewTextBoxColumn
            // 
            this.aOCollaudoConfezionamentoNoteDataGridViewTextBoxColumn.DataPropertyName = "AO_CollaudoConfezionamento_Note";
            this.aOCollaudoConfezionamentoNoteDataGridViewTextBoxColumn.HeaderText = "AO_CollaudoConfezionamento_Note";
            this.aOCollaudoConfezionamentoNoteDataGridViewTextBoxColumn.Name = "aOCollaudoConfezionamentoNoteDataGridViewTextBoxColumn";
            this.aOCollaudoConfezionamentoNoteDataGridViewTextBoxColumn.ReadOnly = true;
            this.aOCollaudoConfezionamentoNoteDataGridViewTextBoxColumn.Visible = false;
            // 
            // qtacollaudoconfezionamentoDataGridViewTextBoxColumn
            // 
            this.qtacollaudoconfezionamentoDataGridViewTextBoxColumn.DataPropertyName = "qta_collaudoconfezionamento";
            this.qtacollaudoconfezionamentoDataGridViewTextBoxColumn.HeaderText = "qta_collaudoconfezionamento";
            this.qtacollaudoconfezionamentoDataGridViewTextBoxColumn.Name = "qtacollaudoconfezionamentoDataGridViewTextBoxColumn";
            this.qtacollaudoconfezionamentoDataGridViewTextBoxColumn.ReadOnly = true;
            this.qtacollaudoconfezionamentoDataGridViewTextBoxColumn.Visible = false;
            // 
            // aOVenditaDataGridViewTextBoxColumn
            // 
            this.aOVenditaDataGridViewTextBoxColumn.DataPropertyName = "AO_Vendita";
            this.aOVenditaDataGridViewTextBoxColumn.HeaderText = "AO_Vendita";
            this.aOVenditaDataGridViewTextBoxColumn.Name = "aOVenditaDataGridViewTextBoxColumn";
            this.aOVenditaDataGridViewTextBoxColumn.ReadOnly = true;
            this.aOVenditaDataGridViewTextBoxColumn.Visible = false;
            // 
            // aOVenditaNoteDataGridViewTextBoxColumn
            // 
            this.aOVenditaNoteDataGridViewTextBoxColumn.DataPropertyName = "AO_Vendita_Note";
            this.aOVenditaNoteDataGridViewTextBoxColumn.HeaderText = "AO_Vendita_Note";
            this.aOVenditaNoteDataGridViewTextBoxColumn.Name = "aOVenditaNoteDataGridViewTextBoxColumn";
            this.aOVenditaNoteDataGridViewTextBoxColumn.ReadOnly = true;
            this.aOVenditaNoteDataGridViewTextBoxColumn.Visible = false;
            // 
            // qtavenditaDataGridViewTextBoxColumn
            // 
            this.qtavenditaDataGridViewTextBoxColumn.DataPropertyName = "qta_vendita";
            this.qtavenditaDataGridViewTextBoxColumn.HeaderText = "qta_vendita";
            this.qtavenditaDataGridViewTextBoxColumn.Name = "qtavenditaDataGridViewTextBoxColumn";
            this.qtavenditaDataGridViewTextBoxColumn.ReadOnly = true;
            this.qtavenditaDataGridViewTextBoxColumn.Visible = false;
            // 
            // aOImballoNoteDataGridViewTextBoxColumn
            // 
            this.aOImballoNoteDataGridViewTextBoxColumn.DataPropertyName = "AO_Imballo_Note";
            this.aOImballoNoteDataGridViewTextBoxColumn.HeaderText = "AO_Imballo_Note";
            this.aOImballoNoteDataGridViewTextBoxColumn.Name = "aOImballoNoteDataGridViewTextBoxColumn";
            this.aOImballoNoteDataGridViewTextBoxColumn.ReadOnly = true;
            this.aOImballoNoteDataGridViewTextBoxColumn.Visible = false;
            // 
            // aOSpedizioneDataGridViewTextBoxColumn
            // 
            this.aOSpedizioneDataGridViewTextBoxColumn.DataPropertyName = "AO_Spedizione";
            this.aOSpedizioneDataGridViewTextBoxColumn.HeaderText = "AO_Spedizione";
            this.aOSpedizioneDataGridViewTextBoxColumn.Name = "aOSpedizioneDataGridViewTextBoxColumn";
            this.aOSpedizioneDataGridViewTextBoxColumn.ReadOnly = true;
            this.aOSpedizioneDataGridViewTextBoxColumn.Visible = false;
            // 
            // aOSpedizioneNoteDataGridViewTextBoxColumn
            // 
            this.aOSpedizioneNoteDataGridViewTextBoxColumn.DataPropertyName = "AO_Spedizione_Note";
            this.aOSpedizioneNoteDataGridViewTextBoxColumn.HeaderText = "AO_Spedizione_Note";
            this.aOSpedizioneNoteDataGridViewTextBoxColumn.Name = "aOSpedizioneNoteDataGridViewTextBoxColumn";
            this.aOSpedizioneNoteDataGridViewTextBoxColumn.ReadOnly = true;
            this.aOSpedizioneNoteDataGridViewTextBoxColumn.Visible = false;
            // 
            // distintaBaseDataGridViewTextBoxColumn
            // 
            this.distintaBaseDataGridViewTextBoxColumn.DataPropertyName = "Distinta_Base";
            this.distintaBaseDataGridViewTextBoxColumn.HeaderText = "Distinta_Base";
            this.distintaBaseDataGridViewTextBoxColumn.Name = "distintaBaseDataGridViewTextBoxColumn";
            this.distintaBaseDataGridViewTextBoxColumn.ReadOnly = true;
            this.distintaBaseDataGridViewTextBoxColumn.Visible = false;
            // 
            // qtaspedizioneprogressivaDataGridViewTextBoxColumn
            // 
            this.qtaspedizioneprogressivaDataGridViewTextBoxColumn.DataPropertyName = "qta_spedizione_progressiva";
            this.qtaspedizioneprogressivaDataGridViewTextBoxColumn.HeaderText = "qta_spedizione_progressiva";
            this.qtaspedizioneprogressivaDataGridViewTextBoxColumn.Name = "qtaspedizioneprogressivaDataGridViewTextBoxColumn";
            this.qtaspedizioneprogressivaDataGridViewTextBoxColumn.ReadOnly = true;
            this.qtaspedizioneprogressivaDataGridViewTextBoxColumn.Visible = false;
            // 
            // spedizioniBindingSource
            // 
            this.spedizioniBindingSource.DataMember = "Spedizioni";
            this.spedizioniBindingSource.DataSource = this.ds_SL;
            this.spedizioniBindingSource.CurrentChanged += new System.EventHandler(this.spedizioniBindingSource_CurrentChanged);
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ds_Programmazione
            // 
            this.ds_Programmazione.DataSetName = "ds_Programmazione";
            this.ds_Programmazione.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel_SN
            // 
            this.layout_spedizioni.SetColumnSpan(this.panel_SN, 2);
            this.panel_SN.Controls.Add(this.btn_conf_serial);
            this.panel_SN.Controls.Add(this.lab_articolo_todo);
            this.panel_SN.Controls.Add(this.lab_SN_todo);
            this.panel_SN.Controls.Add(this.metroLabel5);
            this.panel_SN.Controls.Add(this.metroLabel4);
            this.panel_SN.Controls.Add(this.tbx_ReadLabel_NFC);
            this.panel_SN.Controls.Add(this.lab_read_ID);
            this.panel_SN.Controls.Add(this.metroLabel7);
            this.panel_SN.Controls.Add(this.metroLabel1);
            this.panel_SN.Controls.Add(this.metroLabel2);
            this.panel_SN.Controls.Add(this.lab_read_FW);
            this.panel_SN.Controls.Add(this.metroLabel3);
            this.panel_SN.Controls.Add(this.lab_read_Device);
            this.panel_SN.Controls.Add(this.lab_read_SN);
            this.panel_SN.Controls.Add(this.lab_Etichetta);
            this.panel_SN.Controls.Add(this.tbx_ReadLabel_Device);
            this.panel_SN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_SN.Enabled = false;
            this.panel_SN.HorizontalScrollbarBarColor = true;
            this.panel_SN.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_SN.HorizontalScrollbarSize = 10;
            this.panel_SN.Location = new System.Drawing.Point(753, 303);
            this.panel_SN.Name = "panel_SN";
            this.layout_spedizioni.SetRowSpan(this.panel_SN, 5);
            this.panel_SN.Size = new System.Drawing.Size(247, 274);
            this.panel_SN.TabIndex = 123;
            this.panel_SN.VerticalScrollbarBarColor = true;
            this.panel_SN.VerticalScrollbarHighlightOnWheel = false;
            this.panel_SN.VerticalScrollbarSize = 10;
            // 
            // btn_conf_serial
            // 
            this.btn_conf_serial.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btn_conf_serial.Location = new System.Drawing.Point(0, 251);
            this.btn_conf_serial.Name = "btn_conf_serial";
            this.btn_conf_serial.Size = new System.Drawing.Size(247, 23);
            this.btn_conf_serial.TabIndex = 2;
            this.btn_conf_serial.Text = "Conferma";
            this.btn_conf_serial.UseSelectable = true;
            this.btn_conf_serial.Click += new System.EventHandler(this.btn_conf_serial_Click);
            // 
            // lab_articolo_todo
            // 
            this.lab_articolo_todo.AutoSize = true;
            this.lab_articolo_todo.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_articolo_todo.Location = new System.Drawing.Point(130, 19);
            this.lab_articolo_todo.Name = "lab_articolo_todo";
            this.lab_articolo_todo.Size = new System.Drawing.Size(113, 19);
            this.lab_articolo_todo.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_articolo_todo.TabIndex = 14;
            this.lab_articolo_todo.Text = "lab_articolo_todo";
            this.lab_articolo_todo.UseStyleColors = true;
            // 
            // lab_SN_todo
            // 
            this.lab_SN_todo.AutoSize = true;
            this.lab_SN_todo.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lab_SN_todo.Location = new System.Drawing.Point(130, 0);
            this.lab_SN_todo.Name = "lab_SN_todo";
            this.lab_SN_todo.Size = new System.Drawing.Size(93, 19);
            this.lab_SN_todo.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_SN_todo.TabIndex = 13;
            this.lab_SN_todo.Text = "lab_SN_todo";
            this.lab_SN_todo.UseStyleColors = true;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(0, 0);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(100, 19);
            this.metroLabel5.TabIndex = 12;
            this.metroLabel5.Text = "SN da lavorare:";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(0, 188);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(119, 19);
            this.metroLabel4.TabIndex = 11;
            this.metroLabel4.Text = "Lettura NFC lotto:";
            // 
            // tbx_ReadLabel_NFC
            // 
            // 
            // 
            // 
            this.tbx_ReadLabel_NFC.CustomButton.Image = null;
            this.tbx_ReadLabel_NFC.CustomButton.Location = new System.Drawing.Point(254, 1);
            this.tbx_ReadLabel_NFC.CustomButton.Name = "";
            this.tbx_ReadLabel_NFC.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tbx_ReadLabel_NFC.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbx_ReadLabel_NFC.CustomButton.TabIndex = 1;
            this.tbx_ReadLabel_NFC.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbx_ReadLabel_NFC.CustomButton.UseSelectable = true;
            this.tbx_ReadLabel_NFC.CustomButton.Visible = false;
            this.tbx_ReadLabel_NFC.Lines = new string[0];
            this.tbx_ReadLabel_NFC.Location = new System.Drawing.Point(0, 210);
            this.tbx_ReadLabel_NFC.MaxLength = 32767;
            this.tbx_ReadLabel_NFC.Multiline = true;
            this.tbx_ReadLabel_NFC.Name = "tbx_ReadLabel_NFC";
            this.tbx_ReadLabel_NFC.PasswordChar = '\0';
            this.tbx_ReadLabel_NFC.PromptText = "Lettura NFC";
            this.tbx_ReadLabel_NFC.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbx_ReadLabel_NFC.SelectedText = "";
            this.tbx_ReadLabel_NFC.SelectionLength = 0;
            this.tbx_ReadLabel_NFC.SelectionStart = 0;
            this.tbx_ReadLabel_NFC.ShortcutsEnabled = true;
            this.tbx_ReadLabel_NFC.Size = new System.Drawing.Size(276, 23);
            this.tbx_ReadLabel_NFC.TabIndex = 1;
            this.tbx_ReadLabel_NFC.UseSelectable = true;
            this.tbx_ReadLabel_NFC.WaterMark = "Lettura NFC";
            this.tbx_ReadLabel_NFC.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tbx_ReadLabel_NFC.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tbx_ReadLabel_NFC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbx_ReadLabel_NFC_KeyPress);
            this.tbx_ReadLabel_NFC.Leave += new System.EventHandler(this.tbx_ReadLabel_NFC_Leave);
            // 
            // lab_read_ID
            // 
            this.lab_read_ID.AutoSize = true;
            this.lab_read_ID.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_read_ID.Location = new System.Drawing.Point(130, 114);
            this.lab_read_ID.Name = "lab_read_ID";
            this.lab_read_ID.Size = new System.Drawing.Size(80, 19);
            this.lab_read_ID.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_read_ID.TabIndex = 9;
            this.lab_read_ID.Text = "lab_read_ID";
            this.lab_read_ID.UseStyleColors = true;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(0, 114);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(24, 19);
            this.metroLabel7.TabIndex = 8;
            this.metroLabel7.Text = "ID:";
            // 
            // panel_attiva_proc
            // 
            this.panel_attiva_proc.ColumnCount = 1;
            this.layout_spedizioni.SetColumnSpan(this.panel_attiva_proc, 2);
            this.panel_attiva_proc.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.panel_attiva_proc.Controls.Add(this.but_TerminaProc, 0, 1);
            this.panel_attiva_proc.Controls.Add(this.but_ChiusuraCollConf, 0, 3);
            this.panel_attiva_proc.Controls.Add(this.but_AttivaProc, 0, 0);
            this.panel_attiva_proc.Controls.Add(this.but_AssegnaLottoVuoto, 0, 2);
            this.panel_attiva_proc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_attiva_proc.Location = new System.Drawing.Point(753, 59);
            this.panel_attiva_proc.Name = "panel_attiva_proc";
            this.panel_attiva_proc.RowCount = 4;
            this.panel_attiva_proc.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.panel_attiva_proc.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.panel_attiva_proc.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.panel_attiva_proc.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.panel_attiva_proc.Size = new System.Drawing.Size(247, 238);
            this.panel_attiva_proc.TabIndex = 125;
            // 
            // but_TerminaProc
            // 
            this.but_TerminaProc.BackColor = System.Drawing.Color.White;
            this.but_TerminaProc.Dock = System.Windows.Forms.DockStyle.Top;
            this.but_TerminaProc.Location = new System.Drawing.Point(3, 32);
            this.but_TerminaProc.Name = "but_TerminaProc";
            this.but_TerminaProc.Size = new System.Drawing.Size(276, 23);
            this.but_TerminaProc.Style = MetroFramework.MetroColorStyle.Red;
            this.but_TerminaProc.TabIndex = 1;
            this.but_TerminaProc.Text = "Termina Procedura";
            this.but_TerminaProc.UseSelectable = true;
            this.but_TerminaProc.UseStyleColors = true;
            this.but_TerminaProc.Click += new System.EventHandler(this.but_TerminaProc_Click);
            // 
            // but_ChiusuraCollConf
            // 
            this.but_ChiusuraCollConf.BackColor = System.Drawing.Color.White;
            this.but_ChiusuraCollConf.Dock = System.Windows.Forms.DockStyle.Top;
            this.but_ChiusuraCollConf.Location = new System.Drawing.Point(3, 90);
            this.but_ChiusuraCollConf.Name = "but_ChiusuraCollConf";
            this.but_ChiusuraCollConf.Size = new System.Drawing.Size(276, 23);
            this.but_ChiusuraCollConf.Style = MetroFramework.MetroColorStyle.Blue;
            this.but_ChiusuraCollConf.TabIndex = 3;
            this.but_ChiusuraCollConf.Text = "CHIUSURA COLLAUDO/CONFEZIONAMENTO";
            this.but_ChiusuraCollConf.UseSelectable = true;
            this.but_ChiusuraCollConf.UseStyleColors = true;
            this.but_ChiusuraCollConf.Visible = false;
            this.but_ChiusuraCollConf.Click += new System.EventHandler(this.but_ChiusuraSpedizione_Click);
            // 
            // pan_note_programmazione
            // 
            this.pan_note_programmazione.Controls.Add(this.pic_note_programmazione);
            this.pan_note_programmazione.Controls.Add(this.lab_note_programmazione);
            this.pan_note_programmazione.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_note_programmazione.HorizontalScrollbarBarColor = true;
            this.pan_note_programmazione.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_note_programmazione.HorizontalScrollbarSize = 10;
            this.pan_note_programmazione.Location = new System.Drawing.Point(378, 303);
            this.pan_note_programmazione.Name = "pan_note_programmazione";
            this.pan_note_programmazione.Size = new System.Drawing.Size(119, 50);
            this.pan_note_programmazione.TabIndex = 128;
            this.pan_note_programmazione.VerticalScrollbarBarColor = true;
            this.pan_note_programmazione.VerticalScrollbarHighlightOnWheel = false;
            this.pan_note_programmazione.VerticalScrollbarSize = 10;
            // 
            // pic_note_programmazione
            // 
            this.pic_note_programmazione.Image = global::SmartLineProduction.Properties.Resources.Icona_AV_Programma_Enable;
            this.pic_note_programmazione.Location = new System.Drawing.Point(0, 0);
            this.pic_note_programmazione.Name = "pic_note_programmazione";
            this.pic_note_programmazione.Size = new System.Drawing.Size(32, 32);
            this.pic_note_programmazione.TabIndex = 11;
            this.pic_note_programmazione.TabStop = false;
            // 
            // lab_note_programmazione
            // 
            this.lab_note_programmazione.AutoSize = true;
            this.lab_note_programmazione.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_note_programmazione.Location = new System.Drawing.Point(35, 8);
            this.lab_note_programmazione.Name = "lab_note_programmazione";
            this.lab_note_programmazione.Size = new System.Drawing.Size(165, 19);
            this.lab_note_programmazione.TabIndex = 10;
            this.lab_note_programmazione.Text = "Note di programmazione:";
            // 
            // tb_note_programmazione
            // 
            this.layout_spedizioni.SetColumnSpan(this.tb_note_programmazione, 2);
            // 
            // 
            // 
            this.tb_note_programmazione.CustomButton.Image = null;
            this.tb_note_programmazione.CustomButton.Location = new System.Drawing.Point(196, 2);
            this.tb_note_programmazione.CustomButton.Name = "";
            this.tb_note_programmazione.CustomButton.Size = new System.Drawing.Size(45, 45);
            this.tb_note_programmazione.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_note_programmazione.CustomButton.TabIndex = 1;
            this.tb_note_programmazione.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_note_programmazione.CustomButton.UseSelectable = true;
            this.tb_note_programmazione.CustomButton.Visible = false;
            this.tb_note_programmazione.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.spedizioniBindingSource, "AO_Programmazione_Note", true));
            this.tb_note_programmazione.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_note_programmazione.Lines = new string[] {
        "tb_note_programmazione"};
            this.tb_note_programmazione.Location = new System.Drawing.Point(503, 303);
            this.tb_note_programmazione.MaxLength = 32767;
            this.tb_note_programmazione.Multiline = true;
            this.tb_note_programmazione.Name = "tb_note_programmazione";
            this.tb_note_programmazione.PasswordChar = '\0';
            this.tb_note_programmazione.ReadOnly = true;
            this.tb_note_programmazione.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tb_note_programmazione.SelectedText = "";
            this.tb_note_programmazione.SelectionLength = 0;
            this.tb_note_programmazione.SelectionStart = 0;
            this.tb_note_programmazione.ShortcutsEnabled = true;
            this.tb_note_programmazione.Size = new System.Drawing.Size(244, 50);
            this.tb_note_programmazione.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_note_programmazione.TabIndex = 0;
            this.tb_note_programmazione.Text = "tb_note_programmazione";
            this.tb_note_programmazione.UseSelectable = true;
            this.tb_note_programmazione.UseStyleColors = true;
            this.tb_note_programmazione.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_note_programmazione.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // pan_note_montaggio
            // 
            this.pan_note_montaggio.Controls.Add(this.pic_note_montaggio);
            this.pan_note_montaggio.Controls.Add(this.lab_note_montaggio);
            this.pan_note_montaggio.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_note_montaggio.HorizontalScrollbarBarColor = true;
            this.pan_note_montaggio.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_note_montaggio.HorizontalScrollbarSize = 10;
            this.pan_note_montaggio.Location = new System.Drawing.Point(378, 359);
            this.pan_note_montaggio.Name = "pan_note_montaggio";
            this.pan_note_montaggio.Size = new System.Drawing.Size(119, 50);
            this.pan_note_montaggio.TabIndex = 129;
            this.pan_note_montaggio.VerticalScrollbarBarColor = true;
            this.pan_note_montaggio.VerticalScrollbarHighlightOnWheel = false;
            this.pan_note_montaggio.VerticalScrollbarSize = 10;
            // 
            // pic_note_montaggio
            // 
            this.pic_note_montaggio.Image = global::SmartLineProduction.Properties.Resources.Icona_AV_Montaggio_Enable;
            this.pic_note_montaggio.Location = new System.Drawing.Point(0, 0);
            this.pic_note_montaggio.Name = "pic_note_montaggio";
            this.pic_note_montaggio.Size = new System.Drawing.Size(32, 32);
            this.pic_note_montaggio.TabIndex = 11;
            this.pic_note_montaggio.TabStop = false;
            // 
            // lab_note_montaggio
            // 
            this.lab_note_montaggio.AutoSize = true;
            this.lab_note_montaggio.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_note_montaggio.Location = new System.Drawing.Point(35, 8);
            this.lab_note_montaggio.Name = "lab_note_montaggio";
            this.lab_note_montaggio.Size = new System.Drawing.Size(128, 19);
            this.lab_note_montaggio.TabIndex = 10;
            this.lab_note_montaggio.Text = "Note di montaggio:";
            // 
            // tb_note_montaggio
            // 
            this.layout_spedizioni.SetColumnSpan(this.tb_note_montaggio, 2);
            // 
            // 
            // 
            this.tb_note_montaggio.CustomButton.Image = null;
            this.tb_note_montaggio.CustomButton.Location = new System.Drawing.Point(196, 2);
            this.tb_note_montaggio.CustomButton.Name = "";
            this.tb_note_montaggio.CustomButton.Size = new System.Drawing.Size(45, 45);
            this.tb_note_montaggio.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_note_montaggio.CustomButton.TabIndex = 1;
            this.tb_note_montaggio.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_note_montaggio.CustomButton.UseSelectable = true;
            this.tb_note_montaggio.CustomButton.Visible = false;
            this.tb_note_montaggio.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.spedizioniBindingSource, "AO_Montaggio_Note", true));
            this.tb_note_montaggio.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_note_montaggio.Lines = new string[] {
        "tb_note_montaggio"};
            this.tb_note_montaggio.Location = new System.Drawing.Point(503, 359);
            this.tb_note_montaggio.MaxLength = 32767;
            this.tb_note_montaggio.Multiline = true;
            this.tb_note_montaggio.Name = "tb_note_montaggio";
            this.tb_note_montaggio.PasswordChar = '\0';
            this.tb_note_montaggio.ReadOnly = true;
            this.tb_note_montaggio.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tb_note_montaggio.SelectedText = "";
            this.tb_note_montaggio.SelectionLength = 0;
            this.tb_note_montaggio.SelectionStart = 0;
            this.tb_note_montaggio.ShortcutsEnabled = true;
            this.tb_note_montaggio.Size = new System.Drawing.Size(244, 50);
            this.tb_note_montaggio.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_note_montaggio.TabIndex = 1;
            this.tb_note_montaggio.Text = "tb_note_montaggio";
            this.tb_note_montaggio.UseSelectable = true;
            this.tb_note_montaggio.UseStyleColors = true;
            this.tb_note_montaggio.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_note_montaggio.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // pan_note_collconf
            // 
            this.pan_note_collconf.Controls.Add(this.pic_note_collconf);
            this.pan_note_collconf.Controls.Add(this.lab_note_collconf);
            this.pan_note_collconf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_note_collconf.HorizontalScrollbarBarColor = true;
            this.pan_note_collconf.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_note_collconf.HorizontalScrollbarSize = 10;
            this.pan_note_collconf.Location = new System.Drawing.Point(378, 415);
            this.pan_note_collconf.Name = "pan_note_collconf";
            this.pan_note_collconf.Size = new System.Drawing.Size(119, 50);
            this.pan_note_collconf.TabIndex = 131;
            this.pan_note_collconf.VerticalScrollbarBarColor = true;
            this.pan_note_collconf.VerticalScrollbarHighlightOnWheel = false;
            this.pan_note_collconf.VerticalScrollbarSize = 10;
            // 
            // pic_note_collconf
            // 
            this.pic_note_collconf.Image = global::SmartLineProduction.Properties.Resources.Icona_AV_Pack_Enable;
            this.pic_note_collconf.Location = new System.Drawing.Point(0, 0);
            this.pic_note_collconf.Name = "pic_note_collconf";
            this.pic_note_collconf.Size = new System.Drawing.Size(32, 32);
            this.pic_note_collconf.TabIndex = 11;
            this.pic_note_collconf.TabStop = false;
            // 
            // lab_note_collconf
            // 
            this.lab_note_collconf.AutoSize = true;
            this.lab_note_collconf.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_note_collconf.Location = new System.Drawing.Point(35, 8);
            this.lab_note_collconf.Name = "lab_note_collconf";
            this.lab_note_collconf.Size = new System.Drawing.Size(131, 19);
            this.lab_note_collconf.TabIndex = 10;
            this.lab_note_collconf.Text = "Note di coll./confez.:";
            // 
            // tb_note_collconf
            // 
            this.layout_spedizioni.SetColumnSpan(this.tb_note_collconf, 2);
            // 
            // 
            // 
            this.tb_note_collconf.CustomButton.Image = null;
            this.tb_note_collconf.CustomButton.Location = new System.Drawing.Point(196, 2);
            this.tb_note_collconf.CustomButton.Name = "";
            this.tb_note_collconf.CustomButton.Size = new System.Drawing.Size(45, 45);
            this.tb_note_collconf.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_note_collconf.CustomButton.TabIndex = 1;
            this.tb_note_collconf.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_note_collconf.CustomButton.UseSelectable = true;
            this.tb_note_collconf.CustomButton.Visible = false;
            this.tb_note_collconf.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.spedizioniBindingSource, "AO_CollaudoConfezionamento_Note", true));
            this.tb_note_collconf.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_note_collconf.Lines = new string[] {
        "tb_note_collconf"};
            this.tb_note_collconf.Location = new System.Drawing.Point(503, 415);
            this.tb_note_collconf.MaxLength = 32767;
            this.tb_note_collconf.Multiline = true;
            this.tb_note_collconf.Name = "tb_note_collconf";
            this.tb_note_collconf.PasswordChar = '\0';
            this.tb_note_collconf.ReadOnly = true;
            this.tb_note_collconf.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tb_note_collconf.SelectedText = "";
            this.tb_note_collconf.SelectionLength = 0;
            this.tb_note_collconf.SelectionStart = 0;
            this.tb_note_collconf.ShortcutsEnabled = true;
            this.tb_note_collconf.Size = new System.Drawing.Size(244, 50);
            this.tb_note_collconf.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_note_collconf.TabIndex = 2;
            this.tb_note_collconf.Text = "tb_note_collconf";
            this.tb_note_collconf.UseSelectable = true;
            this.tb_note_collconf.UseStyleColors = true;
            this.tb_note_collconf.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_note_collconf.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // pan_note_vendita
            // 
            this.pan_note_vendita.Controls.Add(this.pic_note_vendita);
            this.pan_note_vendita.Controls.Add(this.lab_note_vendita);
            this.pan_note_vendita.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_note_vendita.HorizontalScrollbarBarColor = true;
            this.pan_note_vendita.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_note_vendita.HorizontalScrollbarSize = 10;
            this.pan_note_vendita.Location = new System.Drawing.Point(378, 471);
            this.pan_note_vendita.Name = "pan_note_vendita";
            this.pan_note_vendita.Size = new System.Drawing.Size(119, 50);
            this.pan_note_vendita.TabIndex = 132;
            this.pan_note_vendita.VerticalScrollbarBarColor = true;
            this.pan_note_vendita.VerticalScrollbarHighlightOnWheel = false;
            this.pan_note_vendita.VerticalScrollbarSize = 10;
            // 
            // pic_note_vendita
            // 
            this.pic_note_vendita.Image = global::SmartLineProduction.Properties.Resources.Icona_AV_Doc_Enable;
            this.pic_note_vendita.Location = new System.Drawing.Point(0, 0);
            this.pic_note_vendita.Name = "pic_note_vendita";
            this.pic_note_vendita.Size = new System.Drawing.Size(32, 32);
            this.pic_note_vendita.TabIndex = 11;
            this.pic_note_vendita.TabStop = false;
            // 
            // lab_note_vendita
            // 
            this.lab_note_vendita.AutoSize = true;
            this.lab_note_vendita.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_note_vendita.Location = new System.Drawing.Point(35, 8);
            this.lab_note_vendita.Name = "lab_note_vendita";
            this.lab_note_vendita.Size = new System.Drawing.Size(106, 19);
            this.lab_note_vendita.TabIndex = 10;
            this.lab_note_vendita.Text = "Note di vendita:";
            // 
            // tb_note_vendita
            // 
            this.layout_spedizioni.SetColumnSpan(this.tb_note_vendita, 2);
            // 
            // 
            // 
            this.tb_note_vendita.CustomButton.Image = null;
            this.tb_note_vendita.CustomButton.Location = new System.Drawing.Point(196, 2);
            this.tb_note_vendita.CustomButton.Name = "";
            this.tb_note_vendita.CustomButton.Size = new System.Drawing.Size(45, 45);
            this.tb_note_vendita.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_note_vendita.CustomButton.TabIndex = 1;
            this.tb_note_vendita.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_note_vendita.CustomButton.UseSelectable = true;
            this.tb_note_vendita.CustomButton.Visible = false;
            this.tb_note_vendita.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.spedizioniBindingSource, "AO_Vendita_Note", true));
            this.tb_note_vendita.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_note_vendita.Lines = new string[] {
        "tb_note_vendita"};
            this.tb_note_vendita.Location = new System.Drawing.Point(503, 471);
            this.tb_note_vendita.MaxLength = 32767;
            this.tb_note_vendita.Multiline = true;
            this.tb_note_vendita.Name = "tb_note_vendita";
            this.tb_note_vendita.PasswordChar = '\0';
            this.tb_note_vendita.ReadOnly = true;
            this.tb_note_vendita.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tb_note_vendita.SelectedText = "";
            this.tb_note_vendita.SelectionLength = 0;
            this.tb_note_vendita.SelectionStart = 0;
            this.tb_note_vendita.ShortcutsEnabled = true;
            this.tb_note_vendita.Size = new System.Drawing.Size(244, 50);
            this.tb_note_vendita.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_note_vendita.TabIndex = 3;
            this.tb_note_vendita.Text = "tb_note_vendita";
            this.tb_note_vendita.UseSelectable = true;
            this.tb_note_vendita.UseStyleColors = true;
            this.tb_note_vendita.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_note_vendita.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // pan_note_spedizione
            // 
            this.pan_note_spedizione.Controls.Add(this.pic_note_spedizione);
            this.pan_note_spedizione.Controls.Add(this.lab_note_spedizione);
            this.pan_note_spedizione.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_note_spedizione.HorizontalScrollbarBarColor = true;
            this.pan_note_spedizione.HorizontalScrollbarHighlightOnWheel = false;
            this.pan_note_spedizione.HorizontalScrollbarSize = 10;
            this.pan_note_spedizione.Location = new System.Drawing.Point(378, 527);
            this.pan_note_spedizione.Name = "pan_note_spedizione";
            this.pan_note_spedizione.Size = new System.Drawing.Size(119, 50);
            this.pan_note_spedizione.TabIndex = 133;
            this.pan_note_spedizione.VerticalScrollbarBarColor = true;
            this.pan_note_spedizione.VerticalScrollbarHighlightOnWheel = false;
            this.pan_note_spedizione.VerticalScrollbarSize = 10;
            // 
            // pic_note_spedizione
            // 
            this.pic_note_spedizione.Image = global::SmartLineProduction.Properties.Resources.Icona_AV_Ship_Enable;
            this.pic_note_spedizione.Location = new System.Drawing.Point(0, 0);
            this.pic_note_spedizione.Name = "pic_note_spedizione";
            this.pic_note_spedizione.Size = new System.Drawing.Size(32, 32);
            this.pic_note_spedizione.TabIndex = 11;
            this.pic_note_spedizione.TabStop = false;
            // 
            // lab_note_spedizione
            // 
            this.lab_note_spedizione.AutoSize = true;
            this.lab_note_spedizione.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_note_spedizione.Location = new System.Drawing.Point(35, 8);
            this.lab_note_spedizione.Name = "lab_note_spedizione";
            this.lab_note_spedizione.Size = new System.Drawing.Size(125, 19);
            this.lab_note_spedizione.TabIndex = 10;
            this.lab_note_spedizione.Text = "Note di spedizione:";
            // 
            // tb_note_spedizione
            // 
            this.layout_spedizioni.SetColumnSpan(this.tb_note_spedizione, 2);
            // 
            // 
            // 
            this.tb_note_spedizione.CustomButton.Image = null;
            this.tb_note_spedizione.CustomButton.Location = new System.Drawing.Point(196, 2);
            this.tb_note_spedizione.CustomButton.Name = "";
            this.tb_note_spedizione.CustomButton.Size = new System.Drawing.Size(45, 45);
            this.tb_note_spedizione.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_note_spedizione.CustomButton.TabIndex = 1;
            this.tb_note_spedizione.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_note_spedizione.CustomButton.UseSelectable = true;
            this.tb_note_spedizione.CustomButton.Visible = false;
            this.tb_note_spedizione.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.spedizioniBindingSource, "AO_Spedizione_Note", true));
            this.tb_note_spedizione.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_note_spedizione.Lines = new string[] {
        "tb_note_spedizione"};
            this.tb_note_spedizione.Location = new System.Drawing.Point(503, 527);
            this.tb_note_spedizione.MaxLength = 32767;
            this.tb_note_spedizione.Multiline = true;
            this.tb_note_spedizione.Name = "tb_note_spedizione";
            this.tb_note_spedizione.PasswordChar = '\0';
            this.tb_note_spedizione.ReadOnly = true;
            this.tb_note_spedizione.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tb_note_spedizione.SelectedText = "";
            this.tb_note_spedizione.SelectionLength = 0;
            this.tb_note_spedizione.SelectionStart = 0;
            this.tb_note_spedizione.ShortcutsEnabled = true;
            this.tb_note_spedizione.Size = new System.Drawing.Size(244, 50);
            this.tb_note_spedizione.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_note_spedizione.TabIndex = 4;
            this.tb_note_spedizione.Text = "tb_note_spedizione";
            this.tb_note_spedizione.UseSelectable = true;
            this.tb_note_spedizione.UseStyleColors = true;
            this.tb_note_spedizione.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_note_spedizione.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // panel_SN_label
            // 
            this.panel_SN_label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.layout_spedizioni.SetColumnSpan(this.panel_SN_label, 3);
            this.panel_SN_label.Controls.Add(this.gv_SerialNumber);
            this.panel_SN_label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_SN_label.HorizontalScrollbarBarColor = true;
            this.panel_SN_label.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_SN_label.HorizontalScrollbarSize = 10;
            this.panel_SN_label.Location = new System.Drawing.Point(3, 303);
            this.panel_SN_label.Name = "panel_SN_label";
            this.layout_spedizioni.SetRowSpan(this.panel_SN_label, 5);
            this.panel_SN_label.Size = new System.Drawing.Size(369, 274);
            this.panel_SN_label.TabIndex = 135;
            this.panel_SN_label.VerticalScrollbarBarColor = true;
            this.panel_SN_label.VerticalScrollbarHighlightOnWheel = false;
            this.panel_SN_label.VerticalScrollbarSize = 10;
            // 
            // gv_SerialNumber
            // 
            this.gv_SerialNumber.AllowUserToAddRows = false;
            this.gv_SerialNumber.AllowUserToDeleteRows = false;
            this.gv_SerialNumber.AllowUserToResizeRows = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_SerialNumber.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.gv_SerialNumber.AutoGenerateColumns = false;
            this.gv_SerialNumber.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_SerialNumber.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_SerialNumber.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_SerialNumber.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_SerialNumber.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.gv_SerialNumber.ColumnHeadersHeight = 40;
            this.gv_SerialNumber.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.HasLotti,
            this.gv_SerialNumber_SerialNumber,
            this.gv_SerialNumber_Articolo,
            this.gv_SerialNumber_RagioneSociale,
            this.gv_SerialNumber_Descrizione,
            this.gv_SerialNumber_Commessa,
            this.gv_SerialNumber_OfficialID,
            this.gv_SerialNumber_QRCode});
            this.gv_SerialNumber.DataSource = this.spedizioniSNBindingSource;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_SerialNumber.DefaultCellStyle = dataGridViewCellStyle7;
            this.gv_SerialNumber.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_SerialNumber.EnableHeadersVisualStyles = false;
            this.gv_SerialNumber.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_SerialNumber.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_SerialNumber.Location = new System.Drawing.Point(0, 0);
            this.gv_SerialNumber.MultiSelect = false;
            this.gv_SerialNumber.Name = "gv_SerialNumber";
            this.gv_SerialNumber.ReadOnly = true;
            this.gv_SerialNumber.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_SerialNumber.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.gv_SerialNumber.RowHeadersVisible = false;
            this.gv_SerialNumber.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_SerialNumber.RowTemplate.Height = 20;
            this.gv_SerialNumber.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_SerialNumber.Size = new System.Drawing.Size(367, 272);
            this.gv_SerialNumber.Style = MetroFramework.MetroColorStyle.Orange;
            this.gv_SerialNumber.TabIndex = 134;
            this.gv_SerialNumber.UseStyleColors = true;
            // 
            // spedizioniSNBindingSource
            // 
            this.spedizioniSNBindingSource.DataMember = "Spedizioni_SN";
            this.spedizioniSNBindingSource.DataSource = this.ds_SL;
            this.spedizioniSNBindingSource.CurrentChanged += new System.EventHandler(this.spedizioniSNBindingSource_CurrentChanged);
            // 
            // metroButton2
            // 
            this.metroButton2.Location = new System.Drawing.Point(378, 583);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(75, 23);
            this.metroButton2.TabIndex = 136;
            this.metroButton2.Text = "metroButton2";
            this.metroButton2.UseSelectable = true;
            // 
            // spedizioniSNSpedizioniLottiBindingSource
            // 
            this.spedizioniSNSpedizioniLottiBindingSource.DataMember = "Spedizioni_SN_Spedizioni_Lotti";
            this.spedizioniSNSpedizioniLottiBindingSource.DataSource = this.spedizioniSNBindingSource;
            // 
            // spedizioniSNSpedizioniIDSerialNumbersBindingSource
            // 
            this.spedizioniSNSpedizioniIDSerialNumbersBindingSource.DataMember = "Spedizioni_SN_Spedizioni_IDSerialNumbers";
            this.spedizioniSNSpedizioniIDSerialNumbersBindingSource.DataSource = this.spedizioniSNBindingSource;
            // 
            // serialNumbersBindingSource
            // 
            this.serialNumbersBindingSource.DataMember = "SerialNumbers";
            this.serialNumbersBindingSource.DataSource = this.ds_Programmazione;
            // 
            // serialNumbersTableAdapter
            // 
            this.serialNumbersTableAdapter.ClearBeforeFill = true;
            // 
            // sFAnagraficaClientiBindingSource
            // 
            this.sFAnagraficaClientiBindingSource.DataMember = "SF_AnagraficaClienti";
            this.sFAnagraficaClientiBindingSource.DataSource = this.ds_SL;
            // 
            // sF_AnagraficaClientiTableAdapter
            // 
            this.sF_AnagraficaClientiTableAdapter.ClearBeforeFill = true;
            // 
            // spedizioniTableAdapter
            // 
            this.spedizioniTableAdapter.ClearBeforeFill = true;
            // 
            // spedizioni_SNTableAdapter
            // 
            this.spedizioni_SNTableAdapter.ClearBeforeFill = true;
            // 
            // spedizioni_LottiTableAdapter
            // 
            this.spedizioni_LottiTableAdapter.ClearBeforeFill = true;
            // 
            // spedizioni_IDSerialNumbersTableAdapter
            // 
            this.spedizioni_IDSerialNumbersTableAdapter.ClearBeforeFill = true;
            // 
            // HasLotti
            // 
            this.HasLotti.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.HasLotti.DataPropertyName = "HasLotti";
            this.HasLotti.HeaderText = "Associato";
            this.HasLotti.Name = "HasLotti";
            this.HasLotti.ReadOnly = true;
            this.HasLotti.Width = 60;
            // 
            // gv_SerialNumber_SerialNumber
            // 
            this.gv_SerialNumber_SerialNumber.DataPropertyName = "SerialNumber";
            this.gv_SerialNumber_SerialNumber.HeaderText = "Serial Number";
            this.gv_SerialNumber_SerialNumber.Name = "gv_SerialNumber_SerialNumber";
            this.gv_SerialNumber_SerialNumber.ReadOnly = true;
            // 
            // gv_SerialNumber_Articolo
            // 
            this.gv_SerialNumber_Articolo.DataPropertyName = "ARTICOLO";
            this.gv_SerialNumber_Articolo.HeaderText = "Articolo";
            this.gv_SerialNumber_Articolo.Name = "gv_SerialNumber_Articolo";
            this.gv_SerialNumber_Articolo.ReadOnly = true;
            // 
            // gv_SerialNumber_RagioneSociale
            // 
            this.gv_SerialNumber_RagioneSociale.DataPropertyName = "RAGIONE_SOCIALE";
            this.gv_SerialNumber_RagioneSociale.HeaderText = "RAGIONE_SOCIALE";
            this.gv_SerialNumber_RagioneSociale.Name = "gv_SerialNumber_RagioneSociale";
            this.gv_SerialNumber_RagioneSociale.ReadOnly = true;
            this.gv_SerialNumber_RagioneSociale.Visible = false;
            // 
            // gv_SerialNumber_Descrizione
            // 
            this.gv_SerialNumber_Descrizione.DataPropertyName = "Descrizione";
            this.gv_SerialNumber_Descrizione.HeaderText = "Descrizione";
            this.gv_SerialNumber_Descrizione.Name = "gv_SerialNumber_Descrizione";
            this.gv_SerialNumber_Descrizione.ReadOnly = true;
            this.gv_SerialNumber_Descrizione.Visible = false;
            // 
            // gv_SerialNumber_Commessa
            // 
            this.gv_SerialNumber_Commessa.DataPropertyName = "Commessa";
            this.gv_SerialNumber_Commessa.HeaderText = "Commessa";
            this.gv_SerialNumber_Commessa.Name = "gv_SerialNumber_Commessa";
            this.gv_SerialNumber_Commessa.ReadOnly = true;
            this.gv_SerialNumber_Commessa.Visible = false;
            // 
            // gv_SerialNumber_OfficialID
            // 
            this.gv_SerialNumber_OfficialID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_SerialNumber_OfficialID.DataPropertyName = "Ser_OfficialSerial";
            this.gv_SerialNumber_OfficialID.HeaderText = "ID SmartLine";
            this.gv_SerialNumber_OfficialID.Name = "gv_SerialNumber_OfficialID";
            this.gv_SerialNumber_OfficialID.ReadOnly = true;
            this.gv_SerialNumber_OfficialID.Width = 86;
            // 
            // gv_SerialNumber_QRCode
            // 
            this.gv_SerialNumber_QRCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_SerialNumber_QRCode.DataPropertyName = "QR_CODE";
            this.gv_SerialNumber_QRCode.HeaderText = "QR Code";
            this.gv_SerialNumber_QRCode.Name = "gv_SerialNumber_QRCode";
            this.gv_SerialNumber_QRCode.ReadOnly = true;
            // 
            // UC_Spedizione
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1043, 800);
            this.ControlBox = false;
            this.Controls.Add(this.layout_spedizioni);
            this.Controls.Add(this.layout_orizz_menu);
            this.DisplayHeader = false;
            this.Name = "UC_Spedizione";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Resizable = false;
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UC_Spedizione_Load);
            this.layout_orizz_menu.ResumeLayout(false);
            this.layout_orizz_menu.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            this.layout_spedizioni.ResumeLayout(false);
            this.panel_ric_commessa.ResumeLayout(false);
            this.panel_ric_commessa.PerformLayout();
            this.panel_grid_avanzamento.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_Avanzamento)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spedizioniBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            this.panel_SN.ResumeLayout(false);
            this.panel_SN.PerformLayout();
            this.panel_attiva_proc.ResumeLayout(false);
            this.pan_note_programmazione.ResumeLayout(false);
            this.pan_note_programmazione.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_note_programmazione)).EndInit();
            this.pan_note_montaggio.ResumeLayout(false);
            this.pan_note_montaggio.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_note_montaggio)).EndInit();
            this.pan_note_collconf.ResumeLayout(false);
            this.pan_note_collconf.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_note_collconf)).EndInit();
            this.pan_note_vendita.ResumeLayout(false);
            this.pan_note_vendita.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_note_vendita)).EndInit();
            this.pan_note_spedizione.ResumeLayout(false);
            this.pan_note_spedizione.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_note_spedizione)).EndInit();
            this.panel_SN_label.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_SerialNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spedizioniSNBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spedizioniSNSpedizioniLottiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spedizioniSNSpedizioniIDSerialNumbersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.serialNumbersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFAnagraficaClientiBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroLabel lab_Etichetta;
        private MetroFramework.Controls.MetroTextBox tbx_ReadLabel_Device;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel lab_read_FW;
        private MetroFramework.Controls.MetroLabel lab_read_Device;
        private MetroFramework.Controls.MetroLabel lab_read_SN;
        private ds_SL ds_SL;
        private ds_Programmazione ds_Programmazione;
        private System.Windows.Forms.BindingSource serialNumbersBindingSource;
        private ds_ProgrammazioneTableAdapters.SerialNumbersTableAdapter serialNumbersTableAdapter;
        private System.Windows.Forms.BindingSource sFAnagraficaClientiBindingSource;
        private ds_SLTableAdapters.SF_AnagraficaClientiTableAdapter sF_AnagraficaClientiTableAdapter;
        private MetroFramework.Controls.MetroButton but_AttivaProc;
        private MetroFramework.Controls.MetroButton but_AssegnaLottoVuoto;
        private System.Windows.Forms.TableLayoutPanel layout_orizz_menu;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
        private System.Windows.Forms.TableLayoutPanel layout_spedizioni;
        private MetroFramework.Controls.MetroPanel panel_SN;
        private System.Windows.Forms.TableLayoutPanel panel_attiva_proc;
        private MetroFramework.Controls.MetroLabel lab_read_ID;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroPanel panel_ric_commessa;
        private MetroFramework.Controls.MetroTextBox tb_ric_Commessa;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroPanel panel_grid_avanzamento;
        private MetroFramework.Controls.MetroGrid gv_Avanzamento;
        private System.Windows.Forms.BindingSource spedizioniBindingSource;
        private ds_SLTableAdapters.SpedizioniTableAdapter spedizioniTableAdapter;
        private MetroFramework.Controls.MetroPanel pan_note_programmazione;
        private System.Windows.Forms.PictureBox pic_note_programmazione;
        private MetroFramework.Controls.MetroLabel lab_note_programmazione;
        private MetroFramework.Controls.MetroTextBox tb_note_programmazione;
        private MetroFramework.Controls.MetroPanel pan_note_montaggio;
        private System.Windows.Forms.PictureBox pic_note_montaggio;
        private MetroFramework.Controls.MetroLabel lab_note_montaggio;
        private MetroFramework.Controls.MetroTextBox tb_note_montaggio;
        private MetroFramework.Controls.MetroPanel pan_note_collconf;
        private System.Windows.Forms.PictureBox pic_note_collconf;
        private MetroFramework.Controls.MetroLabel lab_note_collconf;
        private MetroFramework.Controls.MetroTextBox tb_note_collconf;
        private MetroFramework.Controls.MetroPanel pan_note_vendita;
        private System.Windows.Forms.PictureBox pic_note_vendita;
        private MetroFramework.Controls.MetroLabel lab_note_vendita;
        private MetroFramework.Controls.MetroTextBox tb_note_vendita;
        private MetroFramework.Controls.MetroPanel pan_note_spedizione;
        private System.Windows.Forms.PictureBox pic_note_spedizione;
        private MetroFramework.Controls.MetroLabel lab_note_spedizione;
        private MetroFramework.Controls.MetroTextBox tb_note_spedizione;
        private MetroFramework.Controls.MetroGrid gv_SerialNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn fIRMWAREDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fAMIGLIADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn modelloDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn alimentazioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fccIDCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn e8E24ApprovalNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn e8E24ImmagineDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn temperaturaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoIPDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn famigliaModelloDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoEtichettaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fWSLCUSTOMDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroPanel panel_SN_label;
        private System.Windows.Forms.BindingSource spedizioniSNBindingSource;
        private ds_SLTableAdapters.Spedizioni_SNTableAdapter spedizioni_SNTableAdapter;
        private System.Windows.Forms.BindingSource spedizioniSNSpedizioniLottiBindingSource;
        private ds_SLTableAdapters.Spedizioni_LottiTableAdapter spedizioni_LottiTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn ltKitDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource spedizioniSNSpedizioniIDSerialNumbersBindingSource;
        private ds_SLTableAdapters.Spedizioni_IDSerialNumbersTableAdapter spedizioni_IDSerialNumbersTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn kITDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aRTICOLODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aRTICOLOCLIENTEDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroButton but_ChiusuraCollConf;
        private MetroFramework.Controls.MetroButton but_TerminaProc;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroTextBox tbx_ReadLabel_NFC;
        private MetroFramework.Controls.MetroLabel lab_SN_todo;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel lab_articolo_todo;
        private MetroFramework.Controls.MetroButton btn_conf_serial;
        private System.Windows.Forms.DataGridViewTextBoxColumn commessaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn COMMESSALONG;
        private System.Windows.Forms.DataGridViewTextBoxColumn RAGIONE_SOCIALE;
        private System.Windows.Forms.DataGridViewTextBoxColumn NazioneFiscale;
        private System.Windows.Forms.DataGridViewTextBoxColumn ARTICOLO;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtaordineDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOProgrammazioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOProgrammazioneNoteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtaprogrammazioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOMontaggioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOMontaggioNoteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtamontaggioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOCollaudoConfezionamentoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOCollaudoConfezionamentoNoteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtacollaudoconfezionamentoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOVenditaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOVenditaNoteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtavenditaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOImballoNoteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOSpedizioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aOSpedizioneNoteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn distintaBaseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtaspedizioneprogressivaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn HasLotti;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_SerialNumber_SerialNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_SerialNumber_Articolo;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_SerialNumber_RagioneSociale;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_SerialNumber_Descrizione;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_SerialNumber_Commessa;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_SerialNumber_OfficialID;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_SerialNumber_QRCode;
    }
}