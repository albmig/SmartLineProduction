﻿namespace SmartLineProduction
{


    public partial class ds_SL_History
    {
    }
}
namespace SmartLineProduction {
    
    
    public partial class ds_SL_History {
    }
}
