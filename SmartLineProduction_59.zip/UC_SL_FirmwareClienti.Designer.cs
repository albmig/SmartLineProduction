﻿namespace SmartLineProduction
{
    partial class UC_SL_FirmwareClienti
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_SL_FirmwareClienti));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            this.layout_orizz_menu = new System.Windows.Forms.TableLayoutPanel();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.panel_SN = new MetroFramework.Controls.MetroPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.gv_PalmStand = new MetroFramework.Controls.MetroGrid();
            this.gv_PalmStand_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_PalmStand_DesIt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_PalmStand_DesEn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_PalmStand_Present = new System.Windows.Forms.DataGridViewButtonColumn();
            this.fWClientiBouquetPalmStandBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sFClientiSerialNumbersFWClientiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sFClientiSerialNumbersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_FwClienti = new SmartLineProduction.ds_FwClienti();
            this.gv_PalmCust = new MetroFramework.Controls.MetroGrid();
            this.gv_PalmCust_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_PalmCust_DesIt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_PalmCust_DesEn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_PalmCust_Present = new System.Windows.Forms.DataGridViewButtonColumn();
            this.fWClientiBouquetPalmCustBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gv_RicStand = new MetroFramework.Controls.MetroGrid();
            this.gv_RicStand_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_RicStand_DesIt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_RicStand_DesEn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_RicStand_Present = new System.Windows.Forms.DataGridViewButtonColumn();
            this.fWClientiBouquetRicStandBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gv_RicCust = new MetroFramework.Controls.MetroGrid();
            this.gv_RicCust_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_RicCust_DesIT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_RicCust_DesEn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_RicCust_Present = new System.Windows.Forms.DataGridViewButtonColumn();
            this.fWClientiBouquetRicCustBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gv_FWCliente = new MetroFramework.Controls.MetroGrid();
            this.gv_FWCliente_CodNominativo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_FWCliente_SWCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_FWCliente_DesIT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_FWCliente_DesEN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cb_clienti = new System.Windows.Forms.ComboBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.sF_Clienti_SerialNumbersTableAdapter = new SmartLineProduction.ds_FwClientiTableAdapters.SF_Clienti_SerialNumbersTableAdapter();
            this.fW_ClientiTableAdapter = new SmartLineProduction.ds_FwClientiTableAdapters.FW_ClientiTableAdapter();
            this.bouquet_PalmStandTableAdapter = new SmartLineProduction.ds_FwClientiTableAdapters.Bouquet_PalmStandTableAdapter();
            this.bouquet_PalmCustTableAdapter = new SmartLineProduction.ds_FwClientiTableAdapters.Bouquet_PalmCustTableAdapter();
            this.bouquet_RicStandTableAdapter = new SmartLineProduction.ds_FwClientiTableAdapters.Bouquet_RicStandTableAdapter();
            this.bouquet_RicCustTableAdapter = new SmartLineProduction.ds_FwClientiTableAdapters.Bouquet_RicCustTableAdapter();
            this.fWClientiDBBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fW_Clienti_DBTableAdapter = new SmartLineProduction.ds_FwClientiTableAdapters.FW_Clienti_DBTableAdapter();
            this.sFClientiSNBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sF_Clienti_SNTableAdapter = new SmartLineProduction.ds_FwClientiTableAdapters.SF_Clienti_SNTableAdapter();
            this.firmwareDBBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.firmware_DBTableAdapter = new SmartLineProduction.ds_FwClientiTableAdapters.Firmware_DBTableAdapter();
            this.layout_orizz_menu.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            this.panel_SN.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_PalmStand)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fWClientiBouquetPalmStandBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFClientiSerialNumbersFWClientiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFClientiSerialNumbersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_FwClienti)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_PalmCust)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fWClientiBouquetPalmCustBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_RicStand)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fWClientiBouquetRicStandBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_RicCust)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fWClientiBouquetRicCustBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_FWCliente)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fWClientiDBBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFClientiSNBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.firmwareDBBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // layout_orizz_menu
            // 
            this.layout_orizz_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.ColumnCount = 10;
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_exit, 10, 0);
            this.layout_orizz_menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_orizz_menu.Location = new System.Drawing.Point(20, 30);
            this.layout_orizz_menu.Name = "layout_orizz_menu";
            this.layout_orizz_menu.RowCount = 1;
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_orizz_menu.Size = new System.Drawing.Size(1175, 25);
            this.layout_orizz_menu.TabIndex = 120;
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Gainsboro;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(1100, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(75, 24);
            this.pan_Menu_exit.TabIndex = 82;
            this.pan_Menu_exit.Text = "menuStrip1";
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            this.menu_sw_exit.Click += new System.EventHandler(this.menu_sw_exit_Click);
            // 
            // panel_SN
            // 
            this.panel_SN.Controls.Add(this.tableLayoutPanel1);
            this.panel_SN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_SN.HorizontalScrollbarBarColor = true;
            this.panel_SN.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_SN.HorizontalScrollbarSize = 10;
            this.panel_SN.Location = new System.Drawing.Point(20, 55);
            this.panel_SN.Name = "panel_SN";
            this.panel_SN.Size = new System.Drawing.Size(1175, 371);
            this.panel_SN.TabIndex = 0;
            this.panel_SN.VerticalScrollbarBarColor = true;
            this.panel_SN.VerticalScrollbarHighlightOnWheel = false;
            this.panel_SN.VerticalScrollbarSize = 10;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 10;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Controls.Add(this.metroLabel5, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.metroLabel4, 7, 5);
            this.tableLayoutPanel1.Controls.Add(this.metroLabel3, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.metroLabel2, 7, 1);
            this.tableLayoutPanel1.Controls.Add(this.gv_PalmStand, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.gv_PalmCust, 7, 2);
            this.tableLayoutPanel1.Controls.Add(this.gv_RicStand, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.gv_RicCust, 7, 6);
            this.tableLayoutPanel1.Controls.Add(this.gv_FWCliente, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.cb_clienti, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.metroLabel1, 4, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1175, 371);
            this.tableLayoutPanel1.TabIndex = 122;
            // 
            // metroLabel5
            // 
            this.metroLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel5.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.metroLabel5, 3);
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel5.Location = new System.Drawing.Point(3, 41);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(345, 19);
            this.metroLabel5.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel5.TabIndex = 133;
            this.metroLabel5.Text = "Elenco Firmware del cliente selezionato:";
            this.metroLabel5.UseStyleColors = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel4.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.metroLabel4, 3);
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel4.Location = new System.Drawing.Point(822, 183);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(350, 19);
            this.metroLabel4.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel4.TabIndex = 132;
            this.metroLabel4.Text = "Firmware Ricevitori - Custom:";
            this.metroLabel4.UseStyleColors = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel3.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.metroLabel3, 3);
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.Location = new System.Drawing.Point(471, 183);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(345, 19);
            this.metroLabel3.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel3.TabIndex = 131;
            this.metroLabel3.Text = "Firmware Ricevitori - Standard:";
            this.metroLabel3.UseStyleColors = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel2.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.metroLabel2, 3);
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.Location = new System.Drawing.Point(822, 41);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(350, 19);
            this.metroLabel2.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel2.TabIndex = 130;
            this.metroLabel2.Text = "Firmware Palmari - Custom:";
            this.metroLabel2.UseStyleColors = true;
            // 
            // gv_PalmStand
            // 
            this.gv_PalmStand.AllowUserToAddRows = false;
            this.gv_PalmStand.AllowUserToDeleteRows = false;
            this.gv_PalmStand.AllowUserToResizeRows = false;
            this.gv_PalmStand.AutoGenerateColumns = false;
            this.gv_PalmStand.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_PalmStand.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_PalmStand.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_PalmStand.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_PalmStand.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.gv_PalmStand.ColumnHeadersHeight = 40;
            this.gv_PalmStand.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gv_PalmStand_Code,
            this.gv_PalmStand_DesIt,
            this.gv_PalmStand_DesEn,
            this.gv_PalmStand_Present});
            this.tableLayoutPanel1.SetColumnSpan(this.gv_PalmStand, 3);
            this.gv_PalmStand.DataSource = this.fWClientiBouquetPalmStandBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_PalmStand.DefaultCellStyle = dataGridViewCellStyle3;
            this.gv_PalmStand.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_PalmStand.EnableHeadersVisualStyles = false;
            this.gv_PalmStand.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_PalmStand.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_PalmStand.Location = new System.Drawing.Point(471, 63);
            this.gv_PalmStand.MultiSelect = false;
            this.gv_PalmStand.Name = "gv_PalmStand";
            this.gv_PalmStand.ReadOnly = true;
            this.gv_PalmStand.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_PalmStand.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.gv_PalmStand.RowHeadersVisible = false;
            this.gv_PalmStand.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.tableLayoutPanel1.SetRowSpan(this.gv_PalmStand, 3);
            this.gv_PalmStand.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Wheat;
            this.gv_PalmStand.RowTemplate.Height = 30;
            this.gv_PalmStand.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_PalmStand.Size = new System.Drawing.Size(345, 117);
            this.gv_PalmStand.Style = MetroFramework.MetroColorStyle.Orange;
            this.gv_PalmStand.TabIndex = 125;
            this.gv_PalmStand.UseStyleColors = true;
            this.gv_PalmStand.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gv_PalmStand_CellContentClick);
            this.gv_PalmStand.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.gv_PalmStand_CellFormatting);
            // 
            // gv_PalmStand_Code
            // 
            this.gv_PalmStand_Code.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_PalmStand_Code.DataPropertyName = "SW_Code";
            this.gv_PalmStand_Code.HeaderText = "Firmware";
            this.gv_PalmStand_Code.Name = "gv_PalmStand_Code";
            this.gv_PalmStand_Code.ReadOnly = true;
            this.gv_PalmStand_Code.Width = 77;
            // 
            // gv_PalmStand_DesIt
            // 
            this.gv_PalmStand_DesIt.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_PalmStand_DesIt.DataPropertyName = "SW_Descrizione";
            this.gv_PalmStand_DesIt.HeaderText = "Descrizione IT";
            this.gv_PalmStand_DesIt.Name = "gv_PalmStand_DesIt";
            this.gv_PalmStand_DesIt.ReadOnly = true;
            // 
            // gv_PalmStand_DesEn
            // 
            this.gv_PalmStand_DesEn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_PalmStand_DesEn.DataPropertyName = "SW_Descrizione_EN";
            this.gv_PalmStand_DesEn.HeaderText = "Descrizione EN";
            this.gv_PalmStand_DesEn.Name = "gv_PalmStand_DesEn";
            this.gv_PalmStand_DesEn.ReadOnly = true;
            // 
            // gv_PalmStand_Present
            // 
            this.gv_PalmStand_Present.DataPropertyName = "SW_Present";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(3);
            this.gv_PalmStand_Present.DefaultCellStyle = dataGridViewCellStyle2;
            this.gv_PalmStand_Present.HeaderText = "Azione";
            this.gv_PalmStand_Present.Name = "gv_PalmStand_Present";
            this.gv_PalmStand_Present.ReadOnly = true;
            this.gv_PalmStand_Present.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_PalmStand_Present.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.gv_PalmStand_Present.Text = "";
            this.gv_PalmStand_Present.Width = 70;
            // 
            // fWClientiBouquetPalmStandBindingSource
            // 
            this.fWClientiBouquetPalmStandBindingSource.DataMember = "FW_Clienti_Bouquet_PalmStand";
            this.fWClientiBouquetPalmStandBindingSource.DataSource = this.sFClientiSerialNumbersFWClientiBindingSource;
            this.fWClientiBouquetPalmStandBindingSource.Sort = "SW_SortCode asc";
            // 
            // sFClientiSerialNumbersFWClientiBindingSource
            // 
            this.sFClientiSerialNumbersFWClientiBindingSource.DataMember = "SF_Clienti_SerialNumbers_FW_Clienti";
            this.sFClientiSerialNumbersFWClientiBindingSource.DataSource = this.sFClientiSerialNumbersBindingSource;
            this.sFClientiSerialNumbersFWClientiBindingSource.Sort = "SW_SortCode asc";
            // 
            // sFClientiSerialNumbersBindingSource
            // 
            this.sFClientiSerialNumbersBindingSource.DataMember = "SF_Clienti_SerialNumbers";
            this.sFClientiSerialNumbersBindingSource.DataSource = this.ds_FwClienti;
            this.sFClientiSerialNumbersBindingSource.Sort = "RagSocCognome";
            this.sFClientiSerialNumbersBindingSource.CurrentChanged += new System.EventHandler(this.sFClientiSerialNumbersBindingSource_CurrentChanged);
            // 
            // ds_FwClienti
            // 
            this.ds_FwClienti.DataSetName = "ds_FwClienti";
            this.ds_FwClienti.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gv_PalmCust
            // 
            this.gv_PalmCust.AllowUserToAddRows = false;
            this.gv_PalmCust.AllowUserToDeleteRows = false;
            this.gv_PalmCust.AllowUserToResizeRows = false;
            this.gv_PalmCust.AutoGenerateColumns = false;
            this.gv_PalmCust.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_PalmCust.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_PalmCust.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_PalmCust.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_PalmCust.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.gv_PalmCust.ColumnHeadersHeight = 40;
            this.gv_PalmCust.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gv_PalmCust_Code,
            this.gv_PalmCust_DesIt,
            this.gv_PalmCust_DesEn,
            this.gv_PalmCust_Present});
            this.tableLayoutPanel1.SetColumnSpan(this.gv_PalmCust, 3);
            this.gv_PalmCust.DataSource = this.fWClientiBouquetPalmCustBindingSource;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_PalmCust.DefaultCellStyle = dataGridViewCellStyle7;
            this.gv_PalmCust.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_PalmCust.EnableHeadersVisualStyles = false;
            this.gv_PalmCust.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_PalmCust.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_PalmCust.Location = new System.Drawing.Point(822, 63);
            this.gv_PalmCust.MultiSelect = false;
            this.gv_PalmCust.Name = "gv_PalmCust";
            this.gv_PalmCust.ReadOnly = true;
            this.gv_PalmCust.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_PalmCust.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.gv_PalmCust.RowHeadersVisible = false;
            this.gv_PalmCust.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.tableLayoutPanel1.SetRowSpan(this.gv_PalmCust, 3);
            this.gv_PalmCust.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Wheat;
            this.gv_PalmCust.RowTemplate.Height = 30;
            this.gv_PalmCust.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_PalmCust.Size = new System.Drawing.Size(350, 117);
            this.gv_PalmCust.Style = MetroFramework.MetroColorStyle.Orange;
            this.gv_PalmCust.TabIndex = 126;
            this.gv_PalmCust.UseStyleColors = true;
            this.gv_PalmCust.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gv_PalmCust_CellContentClick);
            this.gv_PalmCust.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.gv_PalmCust_CellFormatting);
            // 
            // gv_PalmCust_Code
            // 
            this.gv_PalmCust_Code.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_PalmCust_Code.DataPropertyName = "SW_Code";
            this.gv_PalmCust_Code.HeaderText = "Firmware";
            this.gv_PalmCust_Code.Name = "gv_PalmCust_Code";
            this.gv_PalmCust_Code.ReadOnly = true;
            this.gv_PalmCust_Code.Width = 77;
            // 
            // gv_PalmCust_DesIt
            // 
            this.gv_PalmCust_DesIt.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_PalmCust_DesIt.DataPropertyName = "SW_Descrizione";
            this.gv_PalmCust_DesIt.HeaderText = "Descrizione IT";
            this.gv_PalmCust_DesIt.Name = "gv_PalmCust_DesIt";
            this.gv_PalmCust_DesIt.ReadOnly = true;
            // 
            // gv_PalmCust_DesEn
            // 
            this.gv_PalmCust_DesEn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_PalmCust_DesEn.DataPropertyName = "SW_Descrizione_EN";
            this.gv_PalmCust_DesEn.HeaderText = "Descrizione EN";
            this.gv_PalmCust_DesEn.Name = "gv_PalmCust_DesEn";
            this.gv_PalmCust_DesEn.ReadOnly = true;
            // 
            // gv_PalmCust_Present
            // 
            this.gv_PalmCust_Present.DataPropertyName = "SW_Present";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.Padding = new System.Windows.Forms.Padding(3);
            this.gv_PalmCust_Present.DefaultCellStyle = dataGridViewCellStyle6;
            this.gv_PalmCust_Present.HeaderText = "Azione";
            this.gv_PalmCust_Present.Name = "gv_PalmCust_Present";
            this.gv_PalmCust_Present.ReadOnly = true;
            this.gv_PalmCust_Present.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_PalmCust_Present.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.gv_PalmCust_Present.Width = 70;
            // 
            // fWClientiBouquetPalmCustBindingSource
            // 
            this.fWClientiBouquetPalmCustBindingSource.DataMember = "FW_Clienti_Bouquet_PalmCust";
            this.fWClientiBouquetPalmCustBindingSource.DataSource = this.sFClientiSerialNumbersFWClientiBindingSource;
            this.fWClientiBouquetPalmCustBindingSource.Sort = "SW_SortCode asc";
            // 
            // gv_RicStand
            // 
            this.gv_RicStand.AllowUserToAddRows = false;
            this.gv_RicStand.AllowUserToDeleteRows = false;
            this.gv_RicStand.AllowUserToResizeRows = false;
            this.gv_RicStand.AutoGenerateColumns = false;
            this.gv_RicStand.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_RicStand.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_RicStand.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_RicStand.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_RicStand.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.gv_RicStand.ColumnHeadersHeight = 40;
            this.gv_RicStand.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gv_RicStand_Code,
            this.gv_RicStand_DesIt,
            this.gv_RicStand_DesEn,
            this.gv_RicStand_Present});
            this.tableLayoutPanel1.SetColumnSpan(this.gv_RicStand, 3);
            this.gv_RicStand.DataSource = this.fWClientiBouquetRicStandBindingSource;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_RicStand.DefaultCellStyle = dataGridViewCellStyle11;
            this.gv_RicStand.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_RicStand.EnableHeadersVisualStyles = false;
            this.gv_RicStand.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_RicStand.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_RicStand.Location = new System.Drawing.Point(471, 205);
            this.gv_RicStand.MultiSelect = false;
            this.gv_RicStand.Name = "gv_RicStand";
            this.gv_RicStand.ReadOnly = true;
            this.gv_RicStand.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_RicStand.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.gv_RicStand.RowHeadersVisible = false;
            this.gv_RicStand.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.tableLayoutPanel1.SetRowSpan(this.gv_RicStand, 4);
            this.gv_RicStand.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Wheat;
            this.gv_RicStand.RowTemplate.Height = 30;
            this.gv_RicStand.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_RicStand.Size = new System.Drawing.Size(345, 163);
            this.gv_RicStand.Style = MetroFramework.MetroColorStyle.Blue;
            this.gv_RicStand.TabIndex = 127;
            this.gv_RicStand.UseStyleColors = true;
            this.gv_RicStand.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gv_RicStand_CellContentClick);
            this.gv_RicStand.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.gv_RicStand_CellFormatting);
            // 
            // gv_RicStand_Code
            // 
            this.gv_RicStand_Code.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_RicStand_Code.DataPropertyName = "SW_Code";
            this.gv_RicStand_Code.HeaderText = "Firmware";
            this.gv_RicStand_Code.Name = "gv_RicStand_Code";
            this.gv_RicStand_Code.ReadOnly = true;
            this.gv_RicStand_Code.Width = 77;
            // 
            // gv_RicStand_DesIt
            // 
            this.gv_RicStand_DesIt.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_RicStand_DesIt.DataPropertyName = "SW_Descrizione";
            this.gv_RicStand_DesIt.HeaderText = "Descrizione IT";
            this.gv_RicStand_DesIt.Name = "gv_RicStand_DesIt";
            this.gv_RicStand_DesIt.ReadOnly = true;
            // 
            // gv_RicStand_DesEn
            // 
            this.gv_RicStand_DesEn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_RicStand_DesEn.DataPropertyName = "SW_Descrizione_EN";
            this.gv_RicStand_DesEn.HeaderText = "Descrizione EN";
            this.gv_RicStand_DesEn.Name = "gv_RicStand_DesEn";
            this.gv_RicStand_DesEn.ReadOnly = true;
            // 
            // gv_RicStand_Present
            // 
            this.gv_RicStand_Present.DataPropertyName = "SW_Present";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.Padding = new System.Windows.Forms.Padding(3);
            this.gv_RicStand_Present.DefaultCellStyle = dataGridViewCellStyle10;
            this.gv_RicStand_Present.HeaderText = "Azione";
            this.gv_RicStand_Present.Name = "gv_RicStand_Present";
            this.gv_RicStand_Present.ReadOnly = true;
            this.gv_RicStand_Present.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_RicStand_Present.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.gv_RicStand_Present.Width = 70;
            // 
            // fWClientiBouquetRicStandBindingSource
            // 
            this.fWClientiBouquetRicStandBindingSource.DataMember = "FW_Clienti_Bouquet_RicStand";
            this.fWClientiBouquetRicStandBindingSource.DataSource = this.sFClientiSerialNumbersFWClientiBindingSource;
            this.fWClientiBouquetRicStandBindingSource.Sort = "SW_SortCode asc";
            // 
            // gv_RicCust
            // 
            this.gv_RicCust.AllowUserToAddRows = false;
            this.gv_RicCust.AllowUserToDeleteRows = false;
            this.gv_RicCust.AllowUserToResizeRows = false;
            this.gv_RicCust.AutoGenerateColumns = false;
            this.gv_RicCust.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_RicCust.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_RicCust.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_RicCust.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_RicCust.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.gv_RicCust.ColumnHeadersHeight = 40;
            this.gv_RicCust.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gv_RicCust_Code,
            this.gv_RicCust_DesIT,
            this.gv_RicCust_DesEn,
            this.gv_RicCust_Present});
            this.tableLayoutPanel1.SetColumnSpan(this.gv_RicCust, 3);
            this.gv_RicCust.DataSource = this.fWClientiBouquetRicCustBindingSource;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_RicCust.DefaultCellStyle = dataGridViewCellStyle15;
            this.gv_RicCust.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_RicCust.EnableHeadersVisualStyles = false;
            this.gv_RicCust.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_RicCust.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_RicCust.Location = new System.Drawing.Point(822, 205);
            this.gv_RicCust.MultiSelect = false;
            this.gv_RicCust.Name = "gv_RicCust";
            this.gv_RicCust.ReadOnly = true;
            this.gv_RicCust.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_RicCust.RowHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.gv_RicCust.RowHeadersVisible = false;
            this.gv_RicCust.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.tableLayoutPanel1.SetRowSpan(this.gv_RicCust, 4);
            this.gv_RicCust.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Wheat;
            this.gv_RicCust.RowTemplate.Height = 30;
            this.gv_RicCust.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_RicCust.Size = new System.Drawing.Size(350, 163);
            this.gv_RicCust.Style = MetroFramework.MetroColorStyle.Blue;
            this.gv_RicCust.TabIndex = 128;
            this.gv_RicCust.UseStyleColors = true;
            this.gv_RicCust.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gv_RicCust_CellContentClick);
            this.gv_RicCust.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.gv_RicCust_CellFormatting);
            // 
            // gv_RicCust_Code
            // 
            this.gv_RicCust_Code.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_RicCust_Code.DataPropertyName = "SW_Code";
            this.gv_RicCust_Code.HeaderText = "Firmware";
            this.gv_RicCust_Code.Name = "gv_RicCust_Code";
            this.gv_RicCust_Code.ReadOnly = true;
            this.gv_RicCust_Code.Width = 77;
            // 
            // gv_RicCust_DesIT
            // 
            this.gv_RicCust_DesIT.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_RicCust_DesIT.DataPropertyName = "SW_Descrizione";
            this.gv_RicCust_DesIT.HeaderText = "Descrizione IT";
            this.gv_RicCust_DesIT.Name = "gv_RicCust_DesIT";
            this.gv_RicCust_DesIT.ReadOnly = true;
            // 
            // gv_RicCust_DesEn
            // 
            this.gv_RicCust_DesEn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_RicCust_DesEn.DataPropertyName = "SW_Descrizione_EN";
            this.gv_RicCust_DesEn.HeaderText = "Descrizione EN";
            this.gv_RicCust_DesEn.Name = "gv_RicCust_DesEn";
            this.gv_RicCust_DesEn.ReadOnly = true;
            // 
            // gv_RicCust_Present
            // 
            this.gv_RicCust_Present.DataPropertyName = "SW_Present";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.Padding = new System.Windows.Forms.Padding(3);
            this.gv_RicCust_Present.DefaultCellStyle = dataGridViewCellStyle14;
            this.gv_RicCust_Present.HeaderText = "Azione";
            this.gv_RicCust_Present.Name = "gv_RicCust_Present";
            this.gv_RicCust_Present.ReadOnly = true;
            this.gv_RicCust_Present.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_RicCust_Present.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.gv_RicCust_Present.Width = 70;
            // 
            // fWClientiBouquetRicCustBindingSource
            // 
            this.fWClientiBouquetRicCustBindingSource.DataMember = "FW_Clienti_Bouquet_RicCust";
            this.fWClientiBouquetRicCustBindingSource.DataSource = this.sFClientiSerialNumbersFWClientiBindingSource;
            this.fWClientiBouquetRicCustBindingSource.Sort = "SW_SortCode asc";
            // 
            // gv_FWCliente
            // 
            this.gv_FWCliente.AllowUserToAddRows = false;
            this.gv_FWCliente.AllowUserToDeleteRows = false;
            this.gv_FWCliente.AllowUserToResizeRows = false;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_FWCliente.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle17;
            this.gv_FWCliente.AutoGenerateColumns = false;
            this.gv_FWCliente.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_FWCliente.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_FWCliente.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_FWCliente.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_FWCliente.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.gv_FWCliente.ColumnHeadersHeight = 40;
            this.gv_FWCliente.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gv_FWCliente_CodNominativo,
            this.gv_FWCliente_SWCode,
            this.gv_FWCliente_DesIT,
            this.gv_FWCliente_DesEN});
            this.tableLayoutPanel1.SetColumnSpan(this.gv_FWCliente, 3);
            this.gv_FWCliente.DataSource = this.sFClientiSerialNumbersFWClientiBindingSource;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_FWCliente.DefaultCellStyle = dataGridViewCellStyle19;
            this.gv_FWCliente.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_FWCliente.EnableHeadersVisualStyles = false;
            this.gv_FWCliente.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_FWCliente.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_FWCliente.Location = new System.Drawing.Point(3, 63);
            this.gv_FWCliente.MultiSelect = false;
            this.gv_FWCliente.Name = "gv_FWCliente";
            this.gv_FWCliente.ReadOnly = true;
            this.gv_FWCliente.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_FWCliente.RowHeadersDefaultCellStyle = dataGridViewCellStyle20;
            this.gv_FWCliente.RowHeadersVisible = false;
            this.gv_FWCliente.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.tableLayoutPanel1.SetRowSpan(this.gv_FWCliente, 8);
            this.gv_FWCliente.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Wheat;
            this.gv_FWCliente.RowTemplate.Height = 30;
            this.gv_FWCliente.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_FWCliente.Size = new System.Drawing.Size(345, 305);
            this.gv_FWCliente.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_FWCliente.TabIndex = 124;
            this.gv_FWCliente.UseStyleColors = true;
            this.gv_FWCliente.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.gv_FWCliente_CellFormatting);
            // 
            // gv_FWCliente_CodNominativo
            // 
            this.gv_FWCliente_CodNominativo.DataPropertyName = "Cod_Nominativo";
            this.gv_FWCliente_CodNominativo.HeaderText = "Cod_Nominativo";
            this.gv_FWCliente_CodNominativo.Name = "gv_FWCliente_CodNominativo";
            this.gv_FWCliente_CodNominativo.ReadOnly = true;
            this.gv_FWCliente_CodNominativo.Visible = false;
            // 
            // gv_FWCliente_SWCode
            // 
            this.gv_FWCliente_SWCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_FWCliente_SWCode.DataPropertyName = "SW_Code";
            this.gv_FWCliente_SWCode.HeaderText = "Firmware";
            this.gv_FWCliente_SWCode.Name = "gv_FWCliente_SWCode";
            this.gv_FWCliente_SWCode.ReadOnly = true;
            this.gv_FWCliente_SWCode.Width = 77;
            // 
            // gv_FWCliente_DesIT
            // 
            this.gv_FWCliente_DesIT.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_FWCliente_DesIT.DataPropertyName = "SW_Des1";
            this.gv_FWCliente_DesIT.HeaderText = "Descrizione IT";
            this.gv_FWCliente_DesIT.Name = "gv_FWCliente_DesIT";
            this.gv_FWCliente_DesIT.ReadOnly = true;
            // 
            // gv_FWCliente_DesEN
            // 
            this.gv_FWCliente_DesEN.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_FWCliente_DesEN.DataPropertyName = "SW_Des2";
            this.gv_FWCliente_DesEN.HeaderText = "Descrizione EN";
            this.gv_FWCliente_DesEN.Name = "gv_FWCliente_DesEN";
            this.gv_FWCliente_DesEN.ReadOnly = true;
            // 
            // cb_clienti
            // 
            this.cb_clienti.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.SetColumnSpan(this.cb_clienti, 3);
            this.cb_clienti.DataSource = this.sFClientiSerialNumbersBindingSource;
            this.cb_clienti.DisplayMember = "RagSocCognome";
            this.cb_clienti.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_clienti.FormattingEnabled = true;
            this.cb_clienti.Location = new System.Drawing.Point(3, 9);
            this.cb_clienti.Name = "cb_clienti";
            this.cb_clienti.Size = new System.Drawing.Size(345, 23);
            this.cb_clienti.TabIndex = 123;
            // 
            // metroLabel1
            // 
            this.metroLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel1.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.metroLabel1, 3);
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.Location = new System.Drawing.Point(471, 41);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(345, 19);
            this.metroLabel1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel1.TabIndex = 129;
            this.metroLabel1.Text = "Firmware Palmari - Standard:";
            this.metroLabel1.UseStyleColors = true;
            // 
            // sF_Clienti_SerialNumbersTableAdapter
            // 
            this.sF_Clienti_SerialNumbersTableAdapter.ClearBeforeFill = true;
            // 
            // fW_ClientiTableAdapter
            // 
            this.fW_ClientiTableAdapter.ClearBeforeFill = true;
            // 
            // bouquet_PalmStandTableAdapter
            // 
            this.bouquet_PalmStandTableAdapter.ClearBeforeFill = true;
            // 
            // bouquet_PalmCustTableAdapter
            // 
            this.bouquet_PalmCustTableAdapter.ClearBeforeFill = true;
            // 
            // bouquet_RicStandTableAdapter
            // 
            this.bouquet_RicStandTableAdapter.ClearBeforeFill = true;
            // 
            // bouquet_RicCustTableAdapter
            // 
            this.bouquet_RicCustTableAdapter.ClearBeforeFill = true;
            // 
            // fWClientiDBBindingSource
            // 
            this.fWClientiDBBindingSource.DataSource = this.ds_FwClienti;
            this.fWClientiDBBindingSource.Position = 0;
            this.fWClientiDBBindingSource.Sort = "";
            // 
            // fW_Clienti_DBTableAdapter
            // 
            this.fW_Clienti_DBTableAdapter.ClearBeforeFill = true;
            // 
            // sFClientiSNBindingSource
            // 
            this.sFClientiSNBindingSource.DataSource = this.ds_FwClienti;
            this.sFClientiSNBindingSource.Position = 0;
            this.sFClientiSNBindingSource.Sort = "";
            // 
            // sF_Clienti_SNTableAdapter
            // 
            this.sF_Clienti_SNTableAdapter.ClearBeforeFill = true;
            // 
            // firmwareDBBindingSource
            // 
            this.firmwareDBBindingSource.DataMember = "Firmware_DB";
            this.firmwareDBBindingSource.DataSource = this.ds_FwClienti;
            // 
            // firmware_DBTableAdapter
            // 
            this.firmware_DBTableAdapter.ClearBeforeFill = true;
            // 
            // UC_SL_FirmwareClienti
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1215, 446);
            this.ControlBox = false;
            this.Controls.Add(this.panel_SN);
            this.Controls.Add(this.layout_orizz_menu);
            this.DisplayHeader = false;
            this.Name = "UC_SL_FirmwareClienti";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UC_SL_FirmwareClientiLabel_Load);
            this.layout_orizz_menu.ResumeLayout(false);
            this.layout_orizz_menu.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            this.panel_SN.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_PalmStand)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fWClientiBouquetPalmStandBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFClientiSerialNumbersFWClientiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFClientiSerialNumbersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_FwClienti)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_PalmCust)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fWClientiBouquetPalmCustBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_RicStand)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fWClientiBouquetRicStandBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_RicCust)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fWClientiBouquetRicCustBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_FWCliente)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fWClientiDBBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFClientiSNBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.firmwareDBBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel layout_orizz_menu;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
        private MetroFramework.Controls.MetroPanel panel_SN;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ComboBox cb_clienti;
        private MetroFramework.Controls.MetroGrid gv_FWCliente;
        private ds_FwClienti ds_FwClienti;
        private System.Windows.Forms.BindingSource sFClientiSerialNumbersBindingSource;
        private ds_FwClientiTableAdapters.SF_Clienti_SerialNumbersTableAdapter sF_Clienti_SerialNumbersTableAdapter;
        private System.Windows.Forms.BindingSource sFClientiSerialNumbersFWClientiBindingSource;
        private ds_FwClientiTableAdapters.FW_ClientiTableAdapter fW_ClientiTableAdapter;
        private MetroFramework.Controls.MetroGrid gv_PalmStand;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_FWCliente_CodNominativo;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_FWCliente_SWCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_FWCliente_DesIT;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_FWCliente_DesEN;
        private MetroFramework.Controls.MetroGrid gv_PalmCust;
        private MetroFramework.Controls.MetroGrid gv_RicStand;
        private MetroFramework.Controls.MetroGrid gv_RicCust;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private System.Windows.Forms.BindingSource fWClientiBouquetPalmStandBindingSource;
        private ds_FwClientiTableAdapters.Bouquet_PalmStandTableAdapter bouquet_PalmStandTableAdapter;
        private System.Windows.Forms.BindingSource fWClientiBouquetPalmCustBindingSource;
        private ds_FwClientiTableAdapters.Bouquet_PalmCustTableAdapter bouquet_PalmCustTableAdapter;
        private System.Windows.Forms.BindingSource fWClientiBouquetRicStandBindingSource;
        private ds_FwClientiTableAdapters.Bouquet_RicStandTableAdapter bouquet_RicStandTableAdapter;
        private System.Windows.Forms.BindingSource fWClientiBouquetRicCustBindingSource;
        private ds_FwClientiTableAdapters.Bouquet_RicCustTableAdapter bouquet_RicCustTableAdapter;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_PalmStand_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_PalmStand_DesIt;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_PalmStand_DesEn;
        private System.Windows.Forms.DataGridViewButtonColumn gv_PalmStand_Present;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_PalmCust_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_PalmCust_DesIt;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_PalmCust_DesEn;
        private System.Windows.Forms.DataGridViewButtonColumn gv_PalmCust_Present;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_RicStand_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_RicStand_DesIt;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_RicStand_DesEn;
        private System.Windows.Forms.DataGridViewButtonColumn gv_RicStand_Present;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_RicCust_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_RicCust_DesIT;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_RicCust_DesEn;
        private System.Windows.Forms.DataGridViewButtonColumn gv_RicCust_Present;
        private System.Windows.Forms.BindingSource fWClientiDBBindingSource;
        private ds_FwClientiTableAdapters.FW_Clienti_DBTableAdapter fW_Clienti_DBTableAdapter;
        private System.Windows.Forms.BindingSource sFClientiSNBindingSource;
        private ds_FwClientiTableAdapters.SF_Clienti_SNTableAdapter sF_Clienti_SNTableAdapter;
        private System.Windows.Forms.BindingSource firmwareDBBindingSource;
        private ds_FwClientiTableAdapters.Firmware_DBTableAdapter firmware_DBTableAdapter;
    }
}
