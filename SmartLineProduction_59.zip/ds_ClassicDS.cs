﻿namespace SmartLineProduction
{


    partial class ds_ClassicDS
    {
    }
}
