﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using SmartLineProduction.Properties;
using System.Data.SqlTypes;
using MetroFramework;

namespace SmartLineProduction
{
    public partial class UC_FW_R : MetroFramework.Forms.MetroForm
    {
        private char displayform = 'E'; //Edit-View-Insert
        public UC_FW_R()
        {
            InitializeComponent();
        }

        private void uscitaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UC_FW_R_Load(object sender, EventArgs e)
        {
            GVar.formclosing = false;

            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.Firmware'. È possibile spostarla o rimuoverla se necessario.
            this.firmwareTableAdapter.Fill(this.ds_SL.Firmware);

            string filtroincorso = "SW_TipoDevice = 'R' and not SW_Obsolete_ver";
            DataView dv_R_incorso = new DataView(ds_SL.Firmware);
            dv_R_incorso.RowFilter = filtroincorso;
            gv_FW_R.DataSource = dv_R_incorso;
            dv_R_incorso.Sort = "SW_Code Asc";

            displayform = 'E';

            AbilitaForm();
        }

        private void gv_FW_R_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (GVar.formclosing) { return; }

            foreach (DataGridViewRow x in gv_FW_R.Rows)
            {
                x.MinimumHeight = 40;
            }
        }

        private void UC_FW_R_FormClosing(object sender, FormClosingEventArgs e)
        {
            GVar.formclosing = true;
        }

        private void gv_FW_R_SelectionChanged(object sender, EventArgs e)
        {

            DataGridViewSelectedRowCollection rows = gv_FW_R.SelectedRows;
            foreach (DataGridViewRow row in rows)
            {
                DataRow myRow = (row.DataBoundItem as DataRowView).Row;

                tb_gv_Code.Text = myRow["SW_Code"].ToString();
                tb_gv_Versione.Text = myRow["SW_Versione"].ToString();
                tb_gv_Revisione.Text = myRow["SW_Revisione"].ToString();

                tb_gv_Des1.Text = myRow["SW_Descrizione"].ToString();
                tb_gv_Des2.Text = myRow["SW_Descrizione_EN"].ToString();
                bool standard = (bool)myRow["SW_Standard"];
                if (standard) { cbox_SoftwareStandard.Checked = true; } else { cbox_SoftwareStandard.Checked = false; }

                cb_868.Checked = false;
                cb_433.Checked = false;
                cb_915.Checked = false;
                cb_filo.Checked = false;
                cb_24.Checked = false;

                switch (myRow["SW_R_Opt_RF"].ToString())
                {
                    case "868": cb_868.Checked = true; break;
                    case "915": cb_915.Checked = true; break;
                    case "433": cb_433.Checked = true; break;
                    case "2.4": cb_24.Checked = true; break;
                    case "filo": cb_filo.Checked = true; break;
                    default: break;
                }
                tog_Exp.Checked = (bool)myRow["SW_R_Opt_Plug_Exp"];
                tog_Ple.Checked = (bool)myRow["SW_R_Opt_Plug_Ple"];
                tog_TstEm.Checked = (bool)myRow["SW_R_Opt_Em_Keyb"];
                tog_optCan.Checked = (bool)myRow["SW_R_Opt_Can"];
                tog_Prop.Checked = (bool)myRow["SW_R_Opt_Prop_Out"];

                //Crea grid History
                string filtrohistory = "SW_TipoDevice = 'R' and SW_Obsolete_ver and SW_Code = '" + myRow["SW_Code"].ToString() + "'";
                DataView dv_R_history = new DataView(ds_SL.Firmware);
                dv_R_history.RowFilter = filtrohistory;
                gv_history.DataSource = dv_R_history;
                dv_R_history.Sort = "SW_Obsolete_ver_from_date Asc";
                //gv_history.Columns.Clear();
                //gv_history.Columns.Add("SW_Revisione", "Revisione");
                //gv_history.Columns.Add("SW_Obsolete_ver_from_date", "Data fine validità");
                //gv_history.Columns["SW_Revisione"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                //gv_history.Columns["SW_Obsolete_ver_from_date"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                //gv_history.AutoResizeColumns();
                gv_history.Refresh();
                ///////////////////////////////////
            }
        }

        private void AbilitaForm()
        {
            if (displayform == 'E')
            {
                panel_dati.Enabled = false;
            }

            gv_history.DataSource = null;
            gv_history.Refresh();
        }

        private void gv_history_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (GVar.formclosing) { return; }

            foreach (DataGridViewRow x in gv_history.Rows)
            {
                x.MinimumHeight = 40;
            }
        }
    }
}
