﻿namespace SmartLineProduction
{
    partial class UC_FW_R
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            this.uscitaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MainMenu = new System.Windows.Forms.MenuStrip();
            this.panel_FW_R = new MetroFramework.Controls.MetroPanel();
            this.gv_FW_R = new MetroFramework.Controls.MetroGrid();
            this.gv_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_TipoDevice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Des1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Des2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Versione = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Revisione = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_IsStandard = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.firmwareBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.firmwareTableAdapter = new SmartLineProduction.ds_SLTableAdapters.FirmwareTableAdapter();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.tb_gv_Code = new MetroFramework.Controls.MetroTextBox();
            this.panel_dati = new MetroFramework.Controls.MetroPanel();
            this.tog_Prop = new MetroFramework.Controls.MetroToggle();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.tog_optCan = new MetroFramework.Controls.MetroToggle();
            this.tog_TstEm = new MetroFramework.Controls.MetroToggle();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.tog_Ple = new MetroFramework.Controls.MetroToggle();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.tog_Exp = new MetroFramework.Controls.MetroToggle();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.cb_24 = new MetroFramework.Controls.MetroCheckBox();
            this.cb_filo = new MetroFramework.Controls.MetroCheckBox();
            this.cb_433 = new MetroFramework.Controls.MetroCheckBox();
            this.cb_915 = new MetroFramework.Controls.MetroCheckBox();
            this.cb_868 = new MetroFramework.Controls.MetroCheckBox();
            this.cbox_SoftwareStandard = new MetroFramework.Controls.MetroCheckBox();
            this.tb_gv_Revisione = new MetroFramework.Controls.MetroTextBox();
            this.tb_gv_Versione = new MetroFramework.Controls.MetroTextBox();
            this.tb_gv_Des2 = new MetroFramework.Controls.MetroTextBox();
            this.tb_gv_Des1 = new MetroFramework.Controls.MetroTextBox();
            this.layout_dati = new System.Windows.Forms.TableLayoutPanel();
            this.panel_history = new MetroFramework.Controls.MetroPanel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.gv_history = new MetroFramework.Controls.MetroGrid();
            this.history_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.history_Revision = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.history_FromDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MainMenu.SuspendLayout();
            this.panel_FW_R.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_FW_R)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.firmwareBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            this.panel_dati.SuspendLayout();
            this.metroPanel1.SuspendLayout();
            this.layout_dati.SuspendLayout();
            this.panel_history.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_history)).BeginInit();
            this.SuspendLayout();
            // 
            // uscitaToolStripMenuItem
            // 
            this.uscitaToolStripMenuItem.Name = "uscitaToolStripMenuItem";
            this.uscitaToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.uscitaToolStripMenuItem.Text = "Uscita";
            this.uscitaToolStripMenuItem.Click += new System.EventHandler(this.uscitaToolStripMenuItem_Click);
            // 
            // MainMenu
            // 
            this.MainMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.MainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uscitaToolStripMenuItem});
            this.MainMenu.Location = new System.Drawing.Point(20, 30);
            this.MainMenu.Name = "MainMenu";
            this.MainMenu.Size = new System.Drawing.Size(1003, 24);
            this.MainMenu.TabIndex = 71;
            this.MainMenu.Text = "menuStrip1";
            // 
            // panel_FW_R
            // 
            this.panel_FW_R.Controls.Add(this.gv_FW_R);
            this.panel_FW_R.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_FW_R.HorizontalScrollbarBarColor = true;
            this.panel_FW_R.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_FW_R.HorizontalScrollbarSize = 10;
            this.panel_FW_R.Location = new System.Drawing.Point(20, 54);
            this.panel_FW_R.Name = "panel_FW_R";
            this.panel_FW_R.Size = new System.Drawing.Size(150, 505);
            this.panel_FW_R.TabIndex = 72;
            this.panel_FW_R.VerticalScrollbarBarColor = true;
            this.panel_FW_R.VerticalScrollbarHighlightOnWheel = false;
            this.panel_FW_R.VerticalScrollbarSize = 10;
            // 
            // gv_FW_R
            // 
            this.gv_FW_R.AllowUserToAddRows = false;
            this.gv_FW_R.AllowUserToDeleteRows = false;
            this.gv_FW_R.AllowUserToOrderColumns = true;
            this.gv_FW_R.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.gv_FW_R.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.gv_FW_R.AutoGenerateColumns = false;
            this.gv_FW_R.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.gv_FW_R.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_FW_R.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_FW_R.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_FW_R.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_FW_R.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gv_FW_R.ColumnHeadersHeight = 40;
            this.gv_FW_R.ColumnHeadersVisible = false;
            this.gv_FW_R.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gv_Code,
            this.gv_TipoDevice,
            this.gv_Des1,
            this.gv_Des2,
            this.gv_Versione,
            this.gv_Revisione,
            this.gv_IsStandard});
            this.gv_FW_R.DataSource = this.firmwareBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_FW_R.DefaultCellStyle = dataGridViewCellStyle3;
            this.gv_FW_R.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_FW_R.EnableHeadersVisualStyles = false;
            this.gv_FW_R.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_FW_R.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_FW_R.Location = new System.Drawing.Point(0, 0);
            this.gv_FW_R.MultiSelect = false;
            this.gv_FW_R.Name = "gv_FW_R";
            this.gv_FW_R.ReadOnly = true;
            this.gv_FW_R.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_FW_R.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.gv_FW_R.RowHeadersVisible = false;
            this.gv_FW_R.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_FW_R.RowTemplate.DividerHeight = 1;
            this.gv_FW_R.RowTemplate.Height = 60;
            this.gv_FW_R.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_FW_R.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_FW_R.Size = new System.Drawing.Size(150, 505);
            this.gv_FW_R.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_FW_R.TabIndex = 2;
            this.gv_FW_R.UseCustomBackColor = true;
            this.gv_FW_R.UseCustomForeColor = true;
            this.gv_FW_R.UseStyleColors = true;
            this.gv_FW_R.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.gv_FW_R_CellPainting);
            this.gv_FW_R.SelectionChanged += new System.EventHandler(this.gv_FW_R_SelectionChanged);
            // 
            // gv_Code
            // 
            this.gv_Code.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_Code.DataPropertyName = "SW_Code";
            this.gv_Code.HeaderText = "SW_Code";
            this.gv_Code.Name = "gv_Code";
            this.gv_Code.ReadOnly = true;
            // 
            // gv_TipoDevice
            // 
            this.gv_TipoDevice.DataPropertyName = "SW_TipoDevice";
            this.gv_TipoDevice.HeaderText = "SW_TipoDevice";
            this.gv_TipoDevice.Name = "gv_TipoDevice";
            this.gv_TipoDevice.ReadOnly = true;
            this.gv_TipoDevice.Visible = false;
            // 
            // gv_Des1
            // 
            this.gv_Des1.DataPropertyName = "SW_Descrizione";
            this.gv_Des1.HeaderText = "SW_Descrizione";
            this.gv_Des1.Name = "gv_Des1";
            this.gv_Des1.ReadOnly = true;
            this.gv_Des1.Visible = false;
            // 
            // gv_Des2
            // 
            this.gv_Des2.DataPropertyName = "SW_Descrizione_EN";
            this.gv_Des2.HeaderText = "SW_Descrizione_EN";
            this.gv_Des2.Name = "gv_Des2";
            this.gv_Des2.ReadOnly = true;
            this.gv_Des2.Visible = false;
            // 
            // gv_Versione
            // 
            this.gv_Versione.DataPropertyName = "SW_Versione";
            this.gv_Versione.HeaderText = "SW_Versione";
            this.gv_Versione.Name = "gv_Versione";
            this.gv_Versione.ReadOnly = true;
            this.gv_Versione.Visible = false;
            // 
            // gv_Revisione
            // 
            this.gv_Revisione.DataPropertyName = "SW_Revisione";
            this.gv_Revisione.HeaderText = "SW_Revisione";
            this.gv_Revisione.Name = "gv_Revisione";
            this.gv_Revisione.ReadOnly = true;
            this.gv_Revisione.Visible = false;
            // 
            // gv_IsStandard
            // 
            this.gv_IsStandard.DataPropertyName = "SW_Standard";
            this.gv_IsStandard.HeaderText = "SW_Standard";
            this.gv_IsStandard.Name = "gv_IsStandard";
            this.gv_IsStandard.ReadOnly = true;
            this.gv_IsStandard.Visible = false;
            // 
            // firmwareBindingSource
            // 
            this.firmwareBindingSource.DataMember = "Firmware";
            this.firmwareBindingSource.DataSource = this.ds_SL;
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // firmwareTableAdapter
            // 
            this.firmwareTableAdapter.ClearBeforeFill = true;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(6, 9);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(109, 19);
            this.metroLabel1.TabIndex = 73;
            this.metroLabel1.Text = "Codice Firmware";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(6, 39);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(75, 19);
            this.metroLabel3.TabIndex = 75;
            this.metroLabel3.Text = "Descrizione";
            // 
            // tb_gv_Code
            // 
            // 
            // 
            // 
            this.tb_gv_Code.CustomButton.Image = null;
            this.tb_gv_Code.CustomButton.Location = new System.Drawing.Point(116, 1);
            this.tb_gv_Code.CustomButton.Name = "";
            this.tb_gv_Code.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_gv_Code.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_gv_Code.CustomButton.TabIndex = 1;
            this.tb_gv_Code.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_gv_Code.CustomButton.UseSelectable = true;
            this.tb_gv_Code.CustomButton.Visible = false;
            this.tb_gv_Code.Lines = new string[] {
        "tb_gv_Code"};
            this.tb_gv_Code.Location = new System.Drawing.Point(152, 9);
            this.tb_gv_Code.MaxLength = 32767;
            this.tb_gv_Code.Name = "tb_gv_Code";
            this.tb_gv_Code.PasswordChar = '\0';
            this.tb_gv_Code.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_gv_Code.SelectedText = "";
            this.tb_gv_Code.SelectionLength = 0;
            this.tb_gv_Code.SelectionStart = 0;
            this.tb_gv_Code.ShortcutsEnabled = true;
            this.tb_gv_Code.Size = new System.Drawing.Size(138, 23);
            this.tb_gv_Code.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_gv_Code.TabIndex = 76;
            this.tb_gv_Code.Text = "tb_gv_Code";
            this.tb_gv_Code.UseSelectable = true;
            this.tb_gv_Code.UseStyleColors = true;
            this.tb_gv_Code.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_gv_Code.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // panel_dati
            // 
            this.panel_dati.Controls.Add(this.tog_Prop);
            this.panel_dati.Controls.Add(this.metroLabel8);
            this.panel_dati.Controls.Add(this.metroLabel7);
            this.panel_dati.Controls.Add(this.tog_optCan);
            this.panel_dati.Controls.Add(this.tog_TstEm);
            this.panel_dati.Controls.Add(this.metroLabel6);
            this.panel_dati.Controls.Add(this.tog_Ple);
            this.panel_dati.Controls.Add(this.metroLabel5);
            this.panel_dati.Controls.Add(this.metroLabel4);
            this.panel_dati.Controls.Add(this.tog_Exp);
            this.panel_dati.Controls.Add(this.metroLabel2);
            this.panel_dati.Controls.Add(this.metroPanel1);
            this.panel_dati.Controls.Add(this.cbox_SoftwareStandard);
            this.panel_dati.Controls.Add(this.tb_gv_Revisione);
            this.panel_dati.Controls.Add(this.tb_gv_Versione);
            this.panel_dati.Controls.Add(this.tb_gv_Des2);
            this.panel_dati.Controls.Add(this.tb_gv_Des1);
            this.panel_dati.Controls.Add(this.tb_gv_Code);
            this.panel_dati.Controls.Add(this.metroLabel3);
            this.panel_dati.Controls.Add(this.metroLabel1);
            this.panel_dati.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_dati.HorizontalScrollbarBarColor = true;
            this.panel_dati.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_dati.HorizontalScrollbarSize = 10;
            this.panel_dati.Location = new System.Drawing.Point(3, 3);
            this.panel_dati.Name = "panel_dati";
            this.panel_dati.Size = new System.Drawing.Size(700, 326);
            this.panel_dati.TabIndex = 77;
            this.panel_dati.VerticalScrollbarBarColor = true;
            this.panel_dati.VerticalScrollbarHighlightOnWheel = false;
            this.panel_dati.VerticalScrollbarSize = 10;
            // 
            // tog_Prop
            // 
            this.tog_Prop.AutoSize = true;
            this.tog_Prop.Location = new System.Drawing.Point(152, 221);
            this.tog_Prop.Name = "tog_Prop";
            this.tog_Prop.Size = new System.Drawing.Size(80, 17);
            this.tog_Prop.Style = MetroFramework.MetroColorStyle.Red;
            this.tog_Prop.TabIndex = 99;
            this.tog_Prop.Text = "Off";
            this.tog_Prop.UseSelectable = true;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(6, 221);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(92, 19);
            this.metroLabel8.TabIndex = 98;
            this.metroLabel8.Text = "Proporzionale";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(6, 196);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(91, 19);
            this.metroLabel7.TabIndex = 97;
            this.metroLabel7.Text = "Opzione CAN";
            // 
            // tog_optCan
            // 
            this.tog_optCan.AutoSize = true;
            this.tog_optCan.Location = new System.Drawing.Point(152, 196);
            this.tog_optCan.Name = "tog_optCan";
            this.tog_optCan.Size = new System.Drawing.Size(80, 17);
            this.tog_optCan.Style = MetroFramework.MetroColorStyle.Red;
            this.tog_optCan.TabIndex = 96;
            this.tog_optCan.Text = "Off";
            this.tog_optCan.UseSelectable = true;
            // 
            // tog_TstEm
            // 
            this.tog_TstEm.AutoSize = true;
            this.tog_TstEm.Location = new System.Drawing.Point(152, 171);
            this.tog_TstEm.Name = "tog_TstEm";
            this.tog_TstEm.Size = new System.Drawing.Size(80, 17);
            this.tog_TstEm.Style = MetroFramework.MetroColorStyle.Red;
            this.tog_TstEm.TabIndex = 95;
            this.tog_TstEm.Text = "Off";
            this.tog_TstEm.UseSelectable = true;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(6, 171);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(137, 19);
            this.metroLabel6.TabIndex = 94;
            this.metroLabel6.Text = "Tastiera di emergenza";
            // 
            // tog_Ple
            // 
            this.tog_Ple.AutoSize = true;
            this.tog_Ple.Location = new System.Drawing.Point(152, 146);
            this.tog_Ple.Name = "tog_Ple";
            this.tog_Ple.Size = new System.Drawing.Size(80, 17);
            this.tog_Ple.Style = MetroFramework.MetroColorStyle.Red;
            this.tog_Ple.TabIndex = 93;
            this.tog_Ple.Text = "Off";
            this.tog_Ple.UseSelectable = true;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(6, 146);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(60, 19);
            this.metroLabel5.TabIndex = 92;
            this.metroLabel5.Text = "Plug PLE";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(6, 121);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(118, 19);
            this.metroLabel4.TabIndex = 91;
            this.metroLabel4.Text = "Plug di espansione";
            // 
            // tog_Exp
            // 
            this.tog_Exp.AutoSize = true;
            this.tog_Exp.Location = new System.Drawing.Point(152, 121);
            this.tog_Exp.Name = "tog_Exp";
            this.tog_Exp.Size = new System.Drawing.Size(80, 17);
            this.tog_Exp.Style = MetroFramework.MetroColorStyle.Red;
            this.tog_Exp.TabIndex = 90;
            this.tog_Exp.Text = "Off";
            this.tog_Exp.UseSelectable = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(6, 95);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(70, 19);
            this.metroLabel2.TabIndex = 89;
            this.metroLabel2.Text = "Frequenza";
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.cb_24);
            this.metroPanel1.Controls.Add(this.cb_filo);
            this.metroPanel1.Controls.Add(this.cb_433);
            this.metroPanel1.Controls.Add(this.cb_915);
            this.metroPanel1.Controls.Add(this.cb_868);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(152, 97);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(532, 18);
            this.metroPanel1.TabIndex = 88;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // cb_24
            // 
            this.cb_24.AutoSize = true;
            this.cb_24.Location = new System.Drawing.Point(247, 1);
            this.cb_24.Name = "cb_24";
            this.cb_24.Size = new System.Drawing.Size(64, 15);
            this.cb_24.Style = MetroFramework.MetroColorStyle.Red;
            this.cb_24.TabIndex = 92;
            this.cb_24.Text = "Solo 2,4";
            this.cb_24.UseSelectable = true;
            this.cb_24.UseStyleColors = true;
            // 
            // cb_filo
            // 
            this.cb_filo.AutoSize = true;
            this.cb_filo.Location = new System.Drawing.Point(191, 1);
            this.cb_filo.Name = "cb_filo";
            this.cb_filo.Size = new System.Drawing.Size(42, 15);
            this.cb_filo.Style = MetroFramework.MetroColorStyle.Red;
            this.cb_filo.TabIndex = 91;
            this.cb_filo.Text = "Filo";
            this.cb_filo.UseSelectable = true;
            this.cb_filo.UseStyleColors = true;
            // 
            // cb_433
            // 
            this.cb_433.AutoSize = true;
            this.cb_433.Location = new System.Drawing.Point(136, 1);
            this.cb_433.Name = "cb_433";
            this.cb_433.Size = new System.Drawing.Size(41, 15);
            this.cb_433.Style = MetroFramework.MetroColorStyle.Red;
            this.cb_433.TabIndex = 90;
            this.cb_433.Text = "433";
            this.cb_433.UseSelectable = true;
            this.cb_433.UseStyleColors = true;
            // 
            // cb_915
            // 
            this.cb_915.AutoSize = true;
            this.cb_915.Location = new System.Drawing.Point(81, 1);
            this.cb_915.Name = "cb_915";
            this.cb_915.Size = new System.Drawing.Size(41, 15);
            this.cb_915.Style = MetroFramework.MetroColorStyle.Red;
            this.cb_915.TabIndex = 89;
            this.cb_915.Text = "915";
            this.cb_915.UseSelectable = true;
            this.cb_915.UseStyleColors = true;
            // 
            // cb_868
            // 
            this.cb_868.AutoSize = true;
            this.cb_868.Location = new System.Drawing.Point(0, 1);
            this.cb_868.Name = "cb_868";
            this.cb_868.Size = new System.Drawing.Size(67, 15);
            this.cb_868.Style = MetroFramework.MetroColorStyle.Red;
            this.cb_868.TabIndex = 88;
            this.cb_868.Text = "868 / 2,4";
            this.cb_868.UseSelectable = true;
            this.cb_868.UseStyleColors = true;
            // 
            // cbox_SoftwareStandard
            // 
            this.cbox_SoftwareStandard.AutoSize = true;
            this.cbox_SoftwareStandard.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbox_SoftwareStandard.Location = new System.Drawing.Point(565, 13);
            this.cbox_SoftwareStandard.Name = "cbox_SoftwareStandard";
            this.cbox_SoftwareStandard.Size = new System.Drawing.Size(119, 15);
            this.cbox_SoftwareStandard.Style = MetroFramework.MetroColorStyle.Red;
            this.cbox_SoftwareStandard.TabIndex = 82;
            this.cbox_SoftwareStandard.Text = "Software Standard";
            this.cbox_SoftwareStandard.UseSelectable = true;
            this.cbox_SoftwareStandard.UseStyleColors = true;
            // 
            // tb_gv_Revisione
            // 
            // 
            // 
            // 
            this.tb_gv_Revisione.CustomButton.Image = null;
            this.tb_gv_Revisione.CustomButton.Location = new System.Drawing.Point(14, 1);
            this.tb_gv_Revisione.CustomButton.Name = "";
            this.tb_gv_Revisione.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_gv_Revisione.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_gv_Revisione.CustomButton.TabIndex = 1;
            this.tb_gv_Revisione.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_gv_Revisione.CustomButton.UseSelectable = true;
            this.tb_gv_Revisione.CustomButton.Visible = false;
            this.tb_gv_Revisione.Lines = new string[] {
        "metroTextBox1"};
            this.tb_gv_Revisione.Location = new System.Drawing.Point(497, 9);
            this.tb_gv_Revisione.MaxLength = 32767;
            this.tb_gv_Revisione.Name = "tb_gv_Revisione";
            this.tb_gv_Revisione.PasswordChar = '\0';
            this.tb_gv_Revisione.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_gv_Revisione.SelectedText = "";
            this.tb_gv_Revisione.SelectionLength = 0;
            this.tb_gv_Revisione.SelectionStart = 0;
            this.tb_gv_Revisione.ShortcutsEnabled = true;
            this.tb_gv_Revisione.Size = new System.Drawing.Size(36, 23);
            this.tb_gv_Revisione.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_gv_Revisione.TabIndex = 81;
            this.tb_gv_Revisione.Text = "metroTextBox1";
            this.tb_gv_Revisione.UseSelectable = true;
            this.tb_gv_Revisione.UseStyleColors = true;
            this.tb_gv_Revisione.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_gv_Revisione.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // tb_gv_Versione
            // 
            // 
            // 
            // 
            this.tb_gv_Versione.CustomButton.Image = null;
            this.tb_gv_Versione.CustomButton.Location = new System.Drawing.Point(48, 1);
            this.tb_gv_Versione.CustomButton.Name = "";
            this.tb_gv_Versione.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_gv_Versione.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_gv_Versione.CustomButton.TabIndex = 1;
            this.tb_gv_Versione.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_gv_Versione.CustomButton.UseSelectable = true;
            this.tb_gv_Versione.CustomButton.Visible = false;
            this.tb_gv_Versione.Lines = new string[] {
        "metroTextBox1"};
            this.tb_gv_Versione.Location = new System.Drawing.Point(421, 9);
            this.tb_gv_Versione.MaxLength = 32767;
            this.tb_gv_Versione.Name = "tb_gv_Versione";
            this.tb_gv_Versione.PasswordChar = '\0';
            this.tb_gv_Versione.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_gv_Versione.SelectedText = "";
            this.tb_gv_Versione.SelectionLength = 0;
            this.tb_gv_Versione.SelectionStart = 0;
            this.tb_gv_Versione.ShortcutsEnabled = true;
            this.tb_gv_Versione.Size = new System.Drawing.Size(70, 23);
            this.tb_gv_Versione.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_gv_Versione.TabIndex = 80;
            this.tb_gv_Versione.Text = "metroTextBox1";
            this.tb_gv_Versione.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tb_gv_Versione.UseSelectable = true;
            this.tb_gv_Versione.UseStyleColors = true;
            this.tb_gv_Versione.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_gv_Versione.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // tb_gv_Des2
            // 
            // 
            // 
            // 
            this.tb_gv_Des2.CustomButton.Image = null;
            this.tb_gv_Des2.CustomButton.Location = new System.Drawing.Point(510, 1);
            this.tb_gv_Des2.CustomButton.Name = "";
            this.tb_gv_Des2.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_gv_Des2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_gv_Des2.CustomButton.TabIndex = 1;
            this.tb_gv_Des2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_gv_Des2.CustomButton.UseSelectable = true;
            this.tb_gv_Des2.CustomButton.Visible = false;
            this.tb_gv_Des2.Lines = new string[] {
        "tb_gv_Des2"};
            this.tb_gv_Des2.Location = new System.Drawing.Point(152, 68);
            this.tb_gv_Des2.MaxLength = 32767;
            this.tb_gv_Des2.Name = "tb_gv_Des2";
            this.tb_gv_Des2.PasswordChar = '\0';
            this.tb_gv_Des2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_gv_Des2.SelectedText = "";
            this.tb_gv_Des2.SelectionLength = 0;
            this.tb_gv_Des2.SelectionStart = 0;
            this.tb_gv_Des2.ShortcutsEnabled = true;
            this.tb_gv_Des2.Size = new System.Drawing.Size(532, 23);
            this.tb_gv_Des2.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_gv_Des2.TabIndex = 78;
            this.tb_gv_Des2.Text = "tb_gv_Des2";
            this.tb_gv_Des2.UseSelectable = true;
            this.tb_gv_Des2.UseStyleColors = true;
            this.tb_gv_Des2.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_gv_Des2.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // tb_gv_Des1
            // 
            // 
            // 
            // 
            this.tb_gv_Des1.CustomButton.Image = null;
            this.tb_gv_Des1.CustomButton.Location = new System.Drawing.Point(510, 1);
            this.tb_gv_Des1.CustomButton.Name = "";
            this.tb_gv_Des1.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_gv_Des1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_gv_Des1.CustomButton.TabIndex = 1;
            this.tb_gv_Des1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_gv_Des1.CustomButton.UseSelectable = true;
            this.tb_gv_Des1.CustomButton.Visible = false;
            this.tb_gv_Des1.Lines = new string[] {
        "metroTextBox1"};
            this.tb_gv_Des1.Location = new System.Drawing.Point(152, 39);
            this.tb_gv_Des1.MaxLength = 32767;
            this.tb_gv_Des1.Name = "tb_gv_Des1";
            this.tb_gv_Des1.PasswordChar = '\0';
            this.tb_gv_Des1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_gv_Des1.SelectedText = "";
            this.tb_gv_Des1.SelectionLength = 0;
            this.tb_gv_Des1.SelectionStart = 0;
            this.tb_gv_Des1.ShortcutsEnabled = true;
            this.tb_gv_Des1.Size = new System.Drawing.Size(532, 23);
            this.tb_gv_Des1.Style = MetroFramework.MetroColorStyle.Red;
            this.tb_gv_Des1.TabIndex = 77;
            this.tb_gv_Des1.Text = "metroTextBox1";
            this.tb_gv_Des1.UseSelectable = true;
            this.tb_gv_Des1.UseStyleColors = true;
            this.tb_gv_Des1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_gv_Des1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // layout_dati
            // 
            this.layout_dati.ColumnCount = 2;
            this.layout_dati.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.layout_dati.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.layout_dati.Controls.Add(this.panel_dati, 0, 0);
            this.layout_dati.Controls.Add(this.panel_history, 1, 0);
            this.layout_dati.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_dati.Location = new System.Drawing.Point(170, 54);
            this.layout_dati.Name = "layout_dati";
            this.layout_dati.RowCount = 2;
            this.layout_dati.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_dati.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_dati.Size = new System.Drawing.Size(853, 505);
            this.layout_dati.TabIndex = 78;
            // 
            // panel_history
            // 
            this.panel_history.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_history.Controls.Add(this.gv_history);
            this.panel_history.Controls.Add(this.metroLabel9);
            this.panel_history.HorizontalScrollbarBarColor = true;
            this.panel_history.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_history.HorizontalScrollbarSize = 10;
            this.panel_history.Location = new System.Drawing.Point(709, 3);
            this.panel_history.Name = "panel_history";
            this.panel_history.Size = new System.Drawing.Size(250, 326);
            this.panel_history.TabIndex = 78;
            this.panel_history.VerticalScrollbarBarColor = true;
            this.panel_history.VerticalScrollbarHighlightOnWheel = false;
            this.panel_history.VerticalScrollbarSize = 10;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroLabel9.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel9.Location = new System.Drawing.Point(0, 0);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(125, 19);
            this.metroLabel9.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel9.TabIndex = 3;
            this.metroLabel9.Text = "Versioni precedenti";
            this.metroLabel9.UseStyleColors = true;
            // 
            // gv_history
            // 
            this.gv_history.AllowUserToAddRows = false;
            this.gv_history.AllowUserToDeleteRows = false;
            this.gv_history.AllowUserToResizeRows = false;
            this.gv_history.AutoGenerateColumns = false;
            this.gv_history.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_history.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_history.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_history.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_history.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.gv_history.ColumnHeadersHeight = 40;
            this.gv_history.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.history_Code,
            this.history_Revision,
            this.history_FromDate});
            this.gv_history.DataSource = this.firmwareBindingSource;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_history.DefaultCellStyle = dataGridViewCellStyle6;
            this.gv_history.Dock = System.Windows.Forms.DockStyle.Top;
            this.gv_history.EnableHeadersVisualStyles = false;
            this.gv_history.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_history.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_history.Location = new System.Drawing.Point(0, 19);
            this.gv_history.Name = "gv_history";
            this.gv_history.ReadOnly = true;
            this.gv_history.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_history.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.gv_history.RowHeadersVisible = false;
            this.gv_history.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_history.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_history.Size = new System.Drawing.Size(250, 307);
            this.gv_history.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_history.TabIndex = 4;
            this.gv_history.UseStyleColors = true;
            // 
            // history_Code
            // 
            this.history_Code.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.history_Code.DataPropertyName = "SW_Code";
            this.history_Code.HeaderText = "SW_Code";
            this.history_Code.Name = "history_Code";
            this.history_Code.ReadOnly = true;
            this.history_Code.Visible = false;
            this.history_Code.Width = 60;
            // 
            // history_Revision
            // 
            this.history_Revision.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.history_Revision.DataPropertyName = "SW_Revisione";
            this.history_Revision.HeaderText = "Revisione";
            this.history_Revision.Name = "history_Revision";
            this.history_Revision.ReadOnly = true;
            this.history_Revision.Width = 79;
            // 
            // history_FromDate
            // 
            this.history_FromDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.history_FromDate.DataPropertyName = "SW_Obsolete_ver_from_date";
            this.history_FromDate.HeaderText = "Fino al";
            this.history_FromDate.Name = "history_FromDate";
            this.history_FromDate.ReadOnly = true;
            // 
            // UC_FW_R
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1043, 579);
            this.ControlBox = false;
            this.Controls.Add(this.layout_dati);
            this.Controls.Add(this.panel_FW_R);
            this.Controls.Add(this.MainMenu);
            this.DisplayHeader = false;
            this.Name = "UC_FW_R";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Resizable = false;
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.UC_FW_R_FormClosing);
            this.Load += new System.EventHandler(this.UC_FW_R_Load);
            this.MainMenu.ResumeLayout(false);
            this.MainMenu.PerformLayout();
            this.panel_FW_R.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_FW_R)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.firmwareBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            this.panel_dati.ResumeLayout(false);
            this.panel_dati.PerformLayout();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            this.layout_dati.ResumeLayout(false);
            this.panel_history.ResumeLayout(false);
            this.panel_history.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_history)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStripMenuItem uscitaToolStripMenuItem;
        private System.Windows.Forms.MenuStrip MainMenu;
        private MetroFramework.Controls.MetroPanel panel_FW_R;
        private MetroFramework.Controls.MetroGrid gv_FW_R;
        private ds_SL ds_SL;
        private System.Windows.Forms.BindingSource firmwareBindingSource;
        private ds_SLTableAdapters.FirmwareTableAdapter firmwareTableAdapter;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTextBox tb_gv_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_TipoDevice;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Des1;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Des2;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Versione;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Revisione;
        private System.Windows.Forms.DataGridViewCheckBoxColumn gv_IsStandard;
        private MetroFramework.Controls.MetroPanel panel_dati;
        private MetroFramework.Controls.MetroTextBox tb_gv_Des2;
        private MetroFramework.Controls.MetroTextBox tb_gv_Des1;
        private MetroFramework.Controls.MetroTextBox tb_gv_Versione;
        private MetroFramework.Controls.MetroTextBox tb_gv_Revisione;
        private MetroFramework.Controls.MetroCheckBox cbox_SoftwareStandard;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroCheckBox cb_24;
        private MetroFramework.Controls.MetroCheckBox cb_filo;
        private MetroFramework.Controls.MetroCheckBox cb_433;
        private MetroFramework.Controls.MetroCheckBox cb_915;
        private MetroFramework.Controls.MetroCheckBox cb_868;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroToggle tog_optCan;
        private MetroFramework.Controls.MetroToggle tog_TstEm;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroToggle tog_Ple;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroToggle tog_Exp;
        private MetroFramework.Controls.MetroToggle tog_Prop;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private System.Windows.Forms.TableLayoutPanel layout_dati;
        private MetroFramework.Controls.MetroPanel panel_history;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroGrid gv_history;
        private System.Windows.Forms.DataGridViewTextBoxColumn history_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn history_Revision;
        private System.Windows.Forms.DataGridViewTextBoxColumn history_FromDate;
    }
}