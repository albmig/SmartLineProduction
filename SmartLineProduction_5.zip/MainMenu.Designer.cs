﻿namespace SmartLineProduction
{
    partial class MainMenu
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenu));
            this.tile_Programmazione = new MetroFramework.Controls.MetroTile();
            this.layout_Menu = new System.Windows.Forms.TableLayoutPanel();
            this.tile_FW_P = new MetroFramework.Controls.MetroTile();
            this.tile_FW_R = new MetroFramework.Controls.MetroTile();
            this.tile_Exit = new MetroFramework.Controls.MetroTile();
            this.tile_Avanzamento = new MetroFramework.Controls.MetroTile();
            this.tile_Spedizione = new MetroFramework.Controls.MetroTile();
            this.panel_Logo = new MetroFramework.Controls.MetroPanel();
            this.layout_Menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // tile_Programmazione
            // 
            this.tile_Programmazione.ActiveControl = null;
            this.layout_Menu.SetColumnSpan(this.tile_Programmazione, 2);
            this.tile_Programmazione.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tile_Programmazione.Location = new System.Drawing.Point(3, 151);
            this.tile_Programmazione.Name = "tile_Programmazione";
            this.tile_Programmazione.Size = new System.Drawing.Size(88, 31);
            this.tile_Programmazione.Style = MetroFramework.MetroColorStyle.Red;
            this.tile_Programmazione.TabIndex = 0;
            this.tile_Programmazione.Text = "Programmazione";
            this.tile_Programmazione.TileImage = ((System.Drawing.Image)(resources.GetObject("tile_Programmazione.TileImage")));
            this.tile_Programmazione.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.tile_Programmazione.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile_Programmazione.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tile_Programmazione.UseSelectable = true;
            this.tile_Programmazione.UseTileImage = true;
            this.tile_Programmazione.Click += new System.EventHandler(this.tile_Programmazione_Click);
            // 
            // layout_Menu
            // 
            this.layout_Menu.ColumnCount = 16;
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.Controls.Add(this.tile_FW_P, 6, 4);
            this.layout_Menu.Controls.Add(this.tile_FW_R, 6, 5);
            this.layout_Menu.Controls.Add(this.tile_Exit, 0, 0);
            this.layout_Menu.Controls.Add(this.tile_Avanzamento, 3, 4);
            this.layout_Menu.Controls.Add(this.tile_Spedizione, 0, 6);
            this.layout_Menu.Controls.Add(this.tile_Programmazione, 0, 4);
            this.layout_Menu.Controls.Add(this.panel_Logo, 14, 0);
            this.layout_Menu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Menu.Location = new System.Drawing.Point(20, 60);
            this.layout_Menu.Name = "layout_Menu";
            this.layout_Menu.RowCount = 10;
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Menu.Size = new System.Drawing.Size(760, 370);
            this.layout_Menu.TabIndex = 1;
            // 
            // tile_FW_P
            // 
            this.tile_FW_P.ActiveControl = null;
            this.layout_Menu.SetColumnSpan(this.tile_FW_P, 2);
            this.tile_FW_P.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tile_FW_P.Location = new System.Drawing.Point(285, 151);
            this.tile_FW_P.Name = "tile_FW_P";
            this.tile_FW_P.Size = new System.Drawing.Size(88, 31);
            this.tile_FW_P.Style = MetroFramework.MetroColorStyle.Lime;
            this.tile_FW_P.TabIndex = 6;
            this.tile_FW_P.Text = "Firmware Palmari";
            this.tile_FW_P.TileImage = ((System.Drawing.Image)(resources.GetObject("tile_FW_P.TileImage")));
            this.tile_FW_P.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.tile_FW_P.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile_FW_P.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tile_FW_P.UseSelectable = true;
            this.tile_FW_P.UseStyleColors = true;
            this.tile_FW_P.UseTileImage = true;
            this.tile_FW_P.Click += new System.EventHandler(this.tile_FW_P_Click);
            // 
            // tile_FW_R
            // 
            this.tile_FW_R.ActiveControl = null;
            this.layout_Menu.SetColumnSpan(this.tile_FW_R, 2);
            this.tile_FW_R.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tile_FW_R.Location = new System.Drawing.Point(285, 188);
            this.tile_FW_R.Name = "tile_FW_R";
            this.tile_FW_R.Size = new System.Drawing.Size(88, 31);
            this.tile_FW_R.Style = MetroFramework.MetroColorStyle.Green;
            this.tile_FW_R.TabIndex = 5;
            this.tile_FW_R.Text = "Firmware Ricevitori";
            this.tile_FW_R.TileImage = ((System.Drawing.Image)(resources.GetObject("tile_FW_R.TileImage")));
            this.tile_FW_R.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.tile_FW_R.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile_FW_R.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tile_FW_R.UseSelectable = true;
            this.tile_FW_R.UseStyleColors = true;
            this.tile_FW_R.UseTileImage = true;
            this.tile_FW_R.Click += new System.EventHandler(this.tile_FW_R_Click);
            // 
            // tile_Exit
            // 
            this.tile_Exit.ActiveControl = null;
            this.layout_Menu.SetColumnSpan(this.tile_Exit, 2);
            this.tile_Exit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tile_Exit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tile_Exit.Location = new System.Drawing.Point(3, 3);
            this.tile_Exit.Name = "tile_Exit";
            this.tile_Exit.Size = new System.Drawing.Size(88, 31);
            this.tile_Exit.Style = MetroFramework.MetroColorStyle.White;
            this.tile_Exit.TabIndex = 4;
            this.tile_Exit.Text = "Uscita";
            this.tile_Exit.TileImage = ((System.Drawing.Image)(resources.GetObject("tile_Exit.TileImage")));
            this.tile_Exit.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.tile_Exit.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile_Exit.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tile_Exit.UseCustomForeColor = true;
            this.tile_Exit.UseSelectable = true;
            this.tile_Exit.UseStyleColors = true;
            this.tile_Exit.UseTileImage = true;
            this.tile_Exit.Click += new System.EventHandler(this.tile_Exit_Click);
            // 
            // tile_Avanzamento
            // 
            this.tile_Avanzamento.ActiveControl = null;
            this.layout_Menu.SetColumnSpan(this.tile_Avanzamento, 2);
            this.tile_Avanzamento.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tile_Avanzamento.Location = new System.Drawing.Point(144, 151);
            this.tile_Avanzamento.Name = "tile_Avanzamento";
            this.tile_Avanzamento.Size = new System.Drawing.Size(88, 31);
            this.tile_Avanzamento.Style = MetroFramework.MetroColorStyle.Blue;
            this.tile_Avanzamento.TabIndex = 3;
            this.tile_Avanzamento.Text = "Avanz. Commesse";
            this.tile_Avanzamento.TileImage = ((System.Drawing.Image)(resources.GetObject("tile_Avanzamento.TileImage")));
            this.tile_Avanzamento.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.tile_Avanzamento.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile_Avanzamento.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tile_Avanzamento.UseSelectable = true;
            this.tile_Avanzamento.UseStyleColors = true;
            this.tile_Avanzamento.UseTileImage = true;
            this.tile_Avanzamento.Click += new System.EventHandler(this.tile_Avanzamento_Click);
            // 
            // tile_Spedizione
            // 
            this.tile_Spedizione.ActiveControl = null;
            this.layout_Menu.SetColumnSpan(this.tile_Spedizione, 2);
            this.tile_Spedizione.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tile_Spedizione.Location = new System.Drawing.Point(3, 225);
            this.tile_Spedizione.Name = "tile_Spedizione";
            this.tile_Spedizione.Size = new System.Drawing.Size(88, 31);
            this.tile_Spedizione.Style = MetroFramework.MetroColorStyle.Red;
            this.tile_Spedizione.TabIndex = 1;
            this.tile_Spedizione.Text = "Spedizione";
            this.tile_Spedizione.TileImage = ((System.Drawing.Image)(resources.GetObject("tile_Spedizione.TileImage")));
            this.tile_Spedizione.TileImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.tile_Spedizione.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.tile_Spedizione.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Regular;
            this.tile_Spedizione.UseSelectable = true;
            this.tile_Spedizione.UseTileImage = true;
            this.tile_Spedizione.Click += new System.EventHandler(this.tile_Spedizione_Click);
            // 
            // panel_Logo
            // 
            this.panel_Logo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_Logo.BackgroundImage")));
            this.panel_Logo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.layout_Menu.SetColumnSpan(this.panel_Logo, 2);
            this.panel_Logo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Logo.HorizontalScrollbarBarColor = true;
            this.panel_Logo.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_Logo.HorizontalScrollbarSize = 10;
            this.panel_Logo.Location = new System.Drawing.Point(661, 3);
            this.panel_Logo.Name = "panel_Logo";
            this.layout_Menu.SetRowSpan(this.panel_Logo, 3);
            this.panel_Logo.Size = new System.Drawing.Size(96, 105);
            this.panel_Logo.TabIndex = 2;
            this.panel_Logo.VerticalScrollbarBarColor = true;
            this.panel_Logo.VerticalScrollbarHighlightOnWheel = false;
            this.panel_Logo.VerticalScrollbarSize = 10;
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.layout_Menu);
            this.IsMdiContainer = true;
            this.Name = "MainMenu";
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "Sistematica - SmartLine";
            this.TransparencyKey = System.Drawing.Color.Empty;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.MdiChildActivate += new System.EventHandler(this.MainMenu_MdiChildActivate);
            this.layout_Menu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTile tile_Programmazione;
        private System.Windows.Forms.TableLayoutPanel layout_Menu;
        private MetroFramework.Controls.MetroTile tile_Spedizione;
        private MetroFramework.Controls.MetroPanel panel_Logo;
        private MetroFramework.Controls.MetroTile tile_Avanzamento;
        private MetroFramework.Controls.MetroTile tile_FW_R;
        private MetroFramework.Controls.MetroTile tile_FW_P;
        public MetroFramework.Controls.MetroTile tile_Exit;
    }
}

