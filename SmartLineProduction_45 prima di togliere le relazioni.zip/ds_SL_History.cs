﻿namespace SmartLineProduction
{
}

namespace SmartLineProduction
{
}

namespace SmartLineProduction
{
}
namespace SmartLineProduction
{


    partial class ds_SL_History
    {
    }
}

