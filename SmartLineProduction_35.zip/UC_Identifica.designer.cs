﻿namespace SmartLineProduction
{
    partial class UC_Identifica
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Identifica));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            this.layout_orizz_menu = new System.Windows.Forms.TableLayoutPanel();
            this.pan_Menu_comandi = new System.Windows.Forms.MenuStrip();
            this.verificaSaltiNumerazioneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.panel_fattibilita = new MetroFramework.Controls.MetroPanel();
            this.layout_Schede = new System.Windows.Forms.TableLayoutPanel();
            this.metroLabel26 = new MetroFramework.Controls.MetroLabel();
            this.sFSNarsnSFSNCicloAttivoKitBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sFSNarsnBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_QuerySN = new SmartLineProduction.ds_QuerySN();
            this.metroLabel25 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel24 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel23 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.sFSNarsnSFSNartaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.panel_grid = new MetroFramework.Controls.MetroPanel();
            this.gv_SN = new MetroFramework.Controls.MetroGrid();
            this.serialNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.articoloDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.entitaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serieDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.partitaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataInizioGarForDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.flObsoletoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataTrasfObsoletoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nume01DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataRegMovInizDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.progRegMovInizDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.progContrMovInizDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serialNumberEstDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.flTrasfWebDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDUtenteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDTerminaleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataUltModificaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel_search = new MetroFramework.Controls.MetroPanel();
            this.tb_search = new MetroFramework.Controls.MetroTextBox();
            this.panel_Smartline = new MetroFramework.Controls.MetroPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel_smartline_data = new MetroFramework.Controls.MetroPanel();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.sFSNarsnSFSNQueryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel19 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel20 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel21 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel22 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel16 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel17 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel18 = new MetroFramework.Controls.MetroLabel();
            this.metroCheckBox1 = new MetroFramework.Controls.MetroCheckBox();
            this.metroCheckBox2 = new MetroFramework.Controls.MetroCheckBox();
            this.metroLabel29 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel30 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel31 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel32 = new MetroFramework.Controls.MetroLabel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.Schede_pdf_it = new DevExpress.XtraPdfViewer.PdfViewer();
            this.barManager1 = new DevExpress.XtraBars.BarManager(this.components);
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.panel_ordini = new MetroFramework.Controls.MetroPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.metroGrid1 = new MetroFramework.Controls.MetroGrid();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sFSNCicloAttivoKitSFOrdiniDDTSerialNumbersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gv_Lotti = new MetroFramework.Controls.MetroGrid();
            this.gv_DDT_Descrizione = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_DDT_ArticoloTrimmed = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ltCreationTimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ltLottoFornitoreDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ltSerialNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ltCommessaLongDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ltArticoloDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sFSNarsnLottiSpedizioneBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroLabel27 = new MetroFramework.Controls.MetroLabel();
            this.lab_movimenti_sn = new MetroFramework.Controls.MetroLabel();
            this.gv_CicloAttivo = new MetroFramework.Controls.MetroGrid();
            this.gv_CicloAttivo_Commessa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_CicloAttivo_Articolo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_CicloAttivo_DataDocumento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_CicloAttivo_Descrizione = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_CicloAttivo_DataOrdine = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_CicloAttivo_NumOrdine = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_CicloAttivo_ArticoloOrdine = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_CicloAttivo_SerialNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_CicloAttivo_DesMovimento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_CicloAttivo_RSCognome = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_CicloAttivo_RSNome = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_CicloAttivo_RSCompleta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_CicloAttivo_RSNazione = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lab_movimenti_moma = new MetroFramework.Controls.MetroLabel();
            this.gv_moma = new MetroFramework.Controls.MetroGrid();
            this.gv_Moma_Commessa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Moma_Articolo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Moma_DataDoc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Moma_DesMov = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Moma_DataOrd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Moma_NumOrd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sFsnmomaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.metroLabel28 = new MetroFramework.Controls.MetroLabel();
            this.sF_SN_arsnTableAdapter = new SmartLineProduction.ds_QuerySNTableAdapters.SF_SN_arsnTableAdapter();
            this.sF_SN_artaTableAdapter = new SmartLineProduction.ds_QuerySNTableAdapters.SF_SN_artaTableAdapter();
            this.sF_SN_CicloAttivo_KitTableAdapter = new SmartLineProduction.ds_QuerySNTableAdapters.SF_SN_CicloAttivo_KitTableAdapter();
            this.sF_SN_QueryTableAdapter = new SmartLineProduction.ds_QuerySNTableAdapters.SF_SN_QueryTableAdapter();
            this.sF_sn_momaTableAdapter = new SmartLineProduction.ds_QuerySNTableAdapters.SF_sn_momaTableAdapter();
            this.sF_OrdiniDDT_SerialNumbersTableAdapter = new SmartLineProduction.ds_QuerySNTableAdapters.SF_OrdiniDDT_SerialNumbersTableAdapter();
            this.lottiSpedizioneTableAdapter = new SmartLineProduction.ds_QuerySNTableAdapters.LottiSpedizioneTableAdapter();
            this.layout_orizz_menu.SuspendLayout();
            this.pan_Menu_comandi.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            this.panel_fattibilita.SuspendLayout();
            this.layout_Schede.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFSNCicloAttivoKitBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_QuerySN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFSNartaBindingSource)).BeginInit();
            this.panel_grid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_SN)).BeginInit();
            this.panel_search.SuspendLayout();
            this.panel_Smartline.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel_smartline_data.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFSNQueryBindingSource)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            this.panel_ordini.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNCicloAttivoKitSFOrdiniDDTSerialNumbersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Lotti)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnLottiSpedizioneBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_CicloAttivo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_moma)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFsnmomaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // layout_orizz_menu
            // 
            this.layout_orizz_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.ColumnCount = 10;
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_comandi, 0, 0);
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_exit, 10, 0);
            this.layout_orizz_menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_orizz_menu.Location = new System.Drawing.Point(20, 30);
            this.layout_orizz_menu.Name = "layout_orizz_menu";
            this.layout_orizz_menu.RowCount = 1;
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_orizz_menu.Size = new System.Drawing.Size(978, 25);
            this.layout_orizz_menu.TabIndex = 125;
            // 
            // pan_Menu_comandi
            // 
            this.pan_Menu_comandi.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.SetColumnSpan(this.pan_Menu_comandi, 5);
            this.pan_Menu_comandi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pan_Menu_comandi.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.verificaSaltiNumerazioneToolStripMenuItem});
            this.pan_Menu_comandi.Location = new System.Drawing.Point(0, 0);
            this.pan_Menu_comandi.Name = "pan_Menu_comandi";
            this.pan_Menu_comandi.Size = new System.Drawing.Size(485, 25);
            this.pan_Menu_comandi.TabIndex = 86;
            this.pan_Menu_comandi.Text = "menuStrip1";
            // 
            // verificaSaltiNumerazioneToolStripMenuItem
            // 
            this.verificaSaltiNumerazioneToolStripMenuItem.Image = global::SmartLineProduction.Properties.Resources.FindInFile_16x;
            this.verificaSaltiNumerazioneToolStripMenuItem.Name = "verificaSaltiNumerazioneToolStripMenuItem";
            this.verificaSaltiNumerazioneToolStripMenuItem.Size = new System.Drawing.Size(169, 21);
            this.verificaSaltiNumerazioneToolStripMenuItem.Text = "Verifica salti numerazione";
            this.verificaSaltiNumerazioneToolStripMenuItem.Click += new System.EventHandler(this.verificaSaltiNumerazioneToolStripMenuItem_Click);
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Gainsboro;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(903, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(75, 24);
            this.pan_Menu_exit.TabIndex = 82;
            this.pan_Menu_exit.Text = "menuStrip1";
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            this.menu_sw_exit.Click += new System.EventHandler(this.menu_sw_exit_Click);
            // 
            // panel_fattibilita
            // 
            this.panel_fattibilita.Controls.Add(this.layout_Schede);
            this.panel_fattibilita.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_fattibilita.HorizontalScrollbarBarColor = true;
            this.panel_fattibilita.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_fattibilita.HorizontalScrollbarSize = 10;
            this.panel_fattibilita.Location = new System.Drawing.Point(20, 55);
            this.panel_fattibilita.Name = "panel_fattibilita";
            this.panel_fattibilita.Size = new System.Drawing.Size(978, 832);
            this.panel_fattibilita.TabIndex = 126;
            this.panel_fattibilita.VerticalScrollbarBarColor = true;
            this.panel_fattibilita.VerticalScrollbarHighlightOnWheel = false;
            this.panel_fattibilita.VerticalScrollbarSize = 10;
            // 
            // layout_Schede
            // 
            this.layout_Schede.ColumnCount = 8;
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.layout_Schede.Controls.Add(this.metroLabel26, 3, 4);
            this.layout_Schede.Controls.Add(this.metroLabel25, 3, 3);
            this.layout_Schede.Controls.Add(this.metroLabel11, 3, 5);
            this.layout_Schede.Controls.Add(this.metroLabel24, 3, 2);
            this.layout_Schede.Controls.Add(this.metroLabel23, 2, 2);
            this.layout_Schede.Controls.Add(this.metroLabel3, 3, 1);
            this.layout_Schede.Controls.Add(this.metroLabel2, 3, 0);
            this.layout_Schede.Controls.Add(this.metroLabel1, 2, 0);
            this.layout_Schede.Controls.Add(this.panel_grid, 0, 0);
            this.layout_Schede.Controls.Add(this.panel_Smartline, 2, 6);
            this.layout_Schede.Controls.Add(this.panel_ordini, 2, 7);
            this.layout_Schede.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Schede.Location = new System.Drawing.Point(0, 0);
            this.layout_Schede.Name = "layout_Schede";
            this.layout_Schede.RowCount = 8;
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 240F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_Schede.Size = new System.Drawing.Size(978, 832);
            this.layout_Schede.TabIndex = 123;
            // 
            // metroLabel26
            // 
            this.metroLabel26.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel26.AutoSize = true;
            this.layout_Schede.SetColumnSpan(this.metroLabel26, 5);
            this.metroLabel26.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNCicloAttivoKitBindingSource, "RagSocNome", true));
            this.metroLabel26.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel26.Location = new System.Drawing.Point(369, 80);
            this.metroLabel26.Name = "metroLabel26";
            this.metroLabel26.Size = new System.Drawing.Size(138, 19);
            this.metroLabel26.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel26.TabIndex = 32;
            this.metroLabel26.Text = "Cliente_RagSocNome";
            this.metroLabel26.UseCustomBackColor = true;
            this.metroLabel26.UseStyleColors = true;
            // 
            // sFSNarsnSFSNCicloAttivoKitBindingSource
            // 
            this.sFSNarsnSFSNCicloAttivoKitBindingSource.DataMember = "SF_SN_arsn_SF_SN_CicloAttivo_Kit";
            this.sFSNarsnSFSNCicloAttivoKitBindingSource.DataSource = this.sFSNarsnBindingSource;
            this.sFSNarsnSFSNCicloAttivoKitBindingSource.ListChanged += new System.ComponentModel.ListChangedEventHandler(this.sFSNarsnSFSNCicloAttivoKitBindingSource_ListChanged);
            // 
            // sFSNarsnBindingSource
            // 
            this.sFSNarsnBindingSource.DataMember = "SF_SN_arsn";
            this.sFSNarsnBindingSource.DataSource = this.ds_QuerySN;
            this.sFSNarsnBindingSource.Filter = "";
            this.sFSNarsnBindingSource.Sort = "SerialNumber asc";
            // 
            // ds_QuerySN
            // 
            this.ds_QuerySN.DataSetName = "ds_QuerySN";
            this.ds_QuerySN.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // metroLabel25
            // 
            this.metroLabel25.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel25.AutoSize = true;
            this.layout_Schede.SetColumnSpan(this.metroLabel25, 5);
            this.metroLabel25.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNCicloAttivoKitBindingSource, "RagSocCognome", true));
            this.metroLabel25.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel25.Location = new System.Drawing.Point(369, 60);
            this.metroLabel25.Name = "metroLabel25";
            this.metroLabel25.Size = new System.Drawing.Size(161, 19);
            this.metroLabel25.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel25.TabIndex = 31;
            this.metroLabel25.Text = "Cliente_RagSocCognome";
            this.metroLabel25.UseCustomBackColor = true;
            this.metroLabel25.UseStyleColors = true;
            // 
            // metroLabel11
            // 
            this.metroLabel11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNCicloAttivoKitBindingSource, "NazioneFiscale", true));
            this.metroLabel11.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel11.Location = new System.Drawing.Point(369, 100);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(116, 19);
            this.metroLabel11.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel11.TabIndex = 30;
            this.metroLabel11.Text = "Cliente_NazioneFiscale";
            this.metroLabel11.UseCustomBackColor = true;
            this.metroLabel11.UseStyleColors = true;
            // 
            // metroLabel24
            // 
            this.metroLabel24.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel24.AutoSize = true;
            this.layout_Schede.SetColumnSpan(this.metroLabel24, 5);
            this.metroLabel24.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNCicloAttivoKitBindingSource, "RagSocCompleta", true));
            this.metroLabel24.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel24.Location = new System.Drawing.Point(369, 40);
            this.metroLabel24.Name = "metroLabel24";
            this.metroLabel24.Size = new System.Drawing.Size(160, 19);
            this.metroLabel24.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel24.TabIndex = 29;
            this.metroLabel24.Text = "Cliente_RagSocCompleta";
            this.metroLabel24.UseCustomBackColor = true;
            this.metroLabel24.UseStyleColors = true;
            // 
            // metroLabel23
            // 
            this.metroLabel23.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel23.AutoSize = true;
            this.metroLabel23.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel23.Location = new System.Drawing.Point(247, 40);
            this.metroLabel23.Name = "metroLabel23";
            this.metroLabel23.Size = new System.Drawing.Size(54, 19);
            this.metroLabel23.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel23.TabIndex = 28;
            this.metroLabel23.Text = "Cliente:";
            this.metroLabel23.UseCustomBackColor = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel3.AutoSize = true;
            this.layout_Schede.SetColumnSpan(this.metroLabel3, 5);
            this.metroLabel3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNartaBindingSource, "DescrizioneEstesa", true));
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Location = new System.Drawing.Point(369, 20);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(69, 19);
            this.metroLabel3.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel3.TabIndex = 23;
            this.metroLabel3.Text = "DesEstArt";
            this.metroLabel3.UseStyleColors = true;
            // 
            // sFSNarsnSFSNartaBindingSource
            // 
            this.sFSNarsnSFSNartaBindingSource.DataMember = "SF_SN_arsn_SF_SN_arta";
            this.sFSNarsnSFSNartaBindingSource.DataSource = this.sFSNarsnBindingSource;
            // 
            // metroLabel2
            // 
            this.metroLabel2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel2.AutoSize = true;
            this.layout_Schede.SetColumnSpan(this.metroLabel2, 5);
            this.metroLabel2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNartaBindingSource, "Descrizione", true));
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Location = new System.Drawing.Point(369, 0);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(51, 19);
            this.metroLabel2.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel2.TabIndex = 22;
            this.metroLabel2.Text = "DesArt";
            this.metroLabel2.UseStyleColors = true;
            // 
            // metroLabel1
            // 
            this.metroLabel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(247, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(81, 19);
            this.metroLabel1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel1.TabIndex = 21;
            this.metroLabel1.Text = "Descrizione:";
            // 
            // panel_grid
            // 
            this.layout_Schede.SetColumnSpan(this.panel_grid, 2);
            this.panel_grid.Controls.Add(this.gv_SN);
            this.panel_grid.Controls.Add(this.panel_search);
            this.panel_grid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_grid.HorizontalScrollbarBarColor = true;
            this.panel_grid.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_grid.HorizontalScrollbarSize = 10;
            this.panel_grid.Location = new System.Drawing.Point(3, 3);
            this.panel_grid.Name = "panel_grid";
            this.layout_Schede.SetRowSpan(this.panel_grid, 8);
            this.panel_grid.Size = new System.Drawing.Size(238, 826);
            this.panel_grid.TabIndex = 17;
            this.panel_grid.VerticalScrollbarBarColor = true;
            this.panel_grid.VerticalScrollbarHighlightOnWheel = false;
            this.panel_grid.VerticalScrollbarSize = 10;
            // 
            // gv_SN
            // 
            this.gv_SN.AllowUserToAddRows = false;
            this.gv_SN.AllowUserToDeleteRows = false;
            this.gv_SN.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_SN.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.gv_SN.AutoGenerateColumns = false;
            this.gv_SN.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_SN.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_SN.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_SN.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_SN.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gv_SN.ColumnHeadersHeight = 40;
            this.gv_SN.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serialNumberDataGridViewTextBoxColumn,
            this.articoloDataGridViewTextBoxColumn,
            this.entitaDataGridViewTextBoxColumn,
            this.serieDataGridViewTextBoxColumn,
            this.partitaDataGridViewTextBoxColumn,
            this.dataInizioGarForDataGridViewTextBoxColumn,
            this.flObsoletoDataGridViewTextBoxColumn,
            this.dataTrasfObsoletoDataGridViewTextBoxColumn,
            this.nume01DataGridViewTextBoxColumn,
            this.dataRegMovInizDataGridViewTextBoxColumn,
            this.progRegMovInizDataGridViewTextBoxColumn,
            this.progContrMovInizDataGridViewTextBoxColumn,
            this.serialNumberEstDataGridViewTextBoxColumn,
            this.flTrasfWebDataGridViewTextBoxColumn,
            this.iDUtenteDataGridViewTextBoxColumn,
            this.iDTerminaleDataGridViewTextBoxColumn,
            this.dataUltModificaDataGridViewTextBoxColumn});
            this.gv_SN.DataSource = this.sFSNarsnBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_SN.DefaultCellStyle = dataGridViewCellStyle3;
            this.gv_SN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_SN.EnableHeadersVisualStyles = false;
            this.gv_SN.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_SN.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_SN.Location = new System.Drawing.Point(0, 30);
            this.gv_SN.MultiSelect = false;
            this.gv_SN.Name = "gv_SN";
            this.gv_SN.ReadOnly = true;
            this.gv_SN.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_SN.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.gv_SN.RowHeadersVisible = false;
            this.gv_SN.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_SN.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Wheat;
            this.gv_SN.RowTemplate.Height = 30;
            this.gv_SN.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_SN.Size = new System.Drawing.Size(238, 796);
            this.gv_SN.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_SN.TabIndex = 2;
            this.gv_SN.UseStyleColors = true;
            // 
            // serialNumberDataGridViewTextBoxColumn
            // 
            this.serialNumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.serialNumberDataGridViewTextBoxColumn.DataPropertyName = "SerialNumber";
            this.serialNumberDataGridViewTextBoxColumn.HeaderText = "S/N";
            this.serialNumberDataGridViewTextBoxColumn.Name = "serialNumberDataGridViewTextBoxColumn";
            this.serialNumberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // articoloDataGridViewTextBoxColumn
            // 
            this.articoloDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.articoloDataGridViewTextBoxColumn.DataPropertyName = "Articolo";
            this.articoloDataGridViewTextBoxColumn.HeaderText = "Articolo";
            this.articoloDataGridViewTextBoxColumn.Name = "articoloDataGridViewTextBoxColumn";
            this.articoloDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // entitaDataGridViewTextBoxColumn
            // 
            this.entitaDataGridViewTextBoxColumn.DataPropertyName = "Entita";
            this.entitaDataGridViewTextBoxColumn.HeaderText = "Entita";
            this.entitaDataGridViewTextBoxColumn.Name = "entitaDataGridViewTextBoxColumn";
            this.entitaDataGridViewTextBoxColumn.ReadOnly = true;
            this.entitaDataGridViewTextBoxColumn.Visible = false;
            // 
            // serieDataGridViewTextBoxColumn
            // 
            this.serieDataGridViewTextBoxColumn.DataPropertyName = "Serie";
            this.serieDataGridViewTextBoxColumn.HeaderText = "Serie";
            this.serieDataGridViewTextBoxColumn.Name = "serieDataGridViewTextBoxColumn";
            this.serieDataGridViewTextBoxColumn.ReadOnly = true;
            this.serieDataGridViewTextBoxColumn.Visible = false;
            // 
            // partitaDataGridViewTextBoxColumn
            // 
            this.partitaDataGridViewTextBoxColumn.DataPropertyName = "Partita";
            this.partitaDataGridViewTextBoxColumn.HeaderText = "Partita";
            this.partitaDataGridViewTextBoxColumn.Name = "partitaDataGridViewTextBoxColumn";
            this.partitaDataGridViewTextBoxColumn.ReadOnly = true;
            this.partitaDataGridViewTextBoxColumn.Visible = false;
            // 
            // dataInizioGarForDataGridViewTextBoxColumn
            // 
            this.dataInizioGarForDataGridViewTextBoxColumn.DataPropertyName = "DataInizioGarFor";
            this.dataInizioGarForDataGridViewTextBoxColumn.HeaderText = "DataInizioGarFor";
            this.dataInizioGarForDataGridViewTextBoxColumn.Name = "dataInizioGarForDataGridViewTextBoxColumn";
            this.dataInizioGarForDataGridViewTextBoxColumn.ReadOnly = true;
            this.dataInizioGarForDataGridViewTextBoxColumn.Visible = false;
            // 
            // flObsoletoDataGridViewTextBoxColumn
            // 
            this.flObsoletoDataGridViewTextBoxColumn.DataPropertyName = "FlObsoleto";
            this.flObsoletoDataGridViewTextBoxColumn.HeaderText = "FlObsoleto";
            this.flObsoletoDataGridViewTextBoxColumn.Name = "flObsoletoDataGridViewTextBoxColumn";
            this.flObsoletoDataGridViewTextBoxColumn.ReadOnly = true;
            this.flObsoletoDataGridViewTextBoxColumn.Visible = false;
            // 
            // dataTrasfObsoletoDataGridViewTextBoxColumn
            // 
            this.dataTrasfObsoletoDataGridViewTextBoxColumn.DataPropertyName = "DataTrasfObsoleto";
            this.dataTrasfObsoletoDataGridViewTextBoxColumn.HeaderText = "DataTrasfObsoleto";
            this.dataTrasfObsoletoDataGridViewTextBoxColumn.Name = "dataTrasfObsoletoDataGridViewTextBoxColumn";
            this.dataTrasfObsoletoDataGridViewTextBoxColumn.ReadOnly = true;
            this.dataTrasfObsoletoDataGridViewTextBoxColumn.Visible = false;
            // 
            // nume01DataGridViewTextBoxColumn
            // 
            this.nume01DataGridViewTextBoxColumn.DataPropertyName = "Nume01";
            this.nume01DataGridViewTextBoxColumn.HeaderText = "Nume01";
            this.nume01DataGridViewTextBoxColumn.Name = "nume01DataGridViewTextBoxColumn";
            this.nume01DataGridViewTextBoxColumn.ReadOnly = true;
            this.nume01DataGridViewTextBoxColumn.Visible = false;
            // 
            // dataRegMovInizDataGridViewTextBoxColumn
            // 
            this.dataRegMovInizDataGridViewTextBoxColumn.DataPropertyName = "DataRegMovIniz";
            this.dataRegMovInizDataGridViewTextBoxColumn.HeaderText = "DataRegMovIniz";
            this.dataRegMovInizDataGridViewTextBoxColumn.Name = "dataRegMovInizDataGridViewTextBoxColumn";
            this.dataRegMovInizDataGridViewTextBoxColumn.ReadOnly = true;
            this.dataRegMovInizDataGridViewTextBoxColumn.Visible = false;
            // 
            // progRegMovInizDataGridViewTextBoxColumn
            // 
            this.progRegMovInizDataGridViewTextBoxColumn.DataPropertyName = "ProgRegMovIniz";
            this.progRegMovInizDataGridViewTextBoxColumn.HeaderText = "ProgRegMovIniz";
            this.progRegMovInizDataGridViewTextBoxColumn.Name = "progRegMovInizDataGridViewTextBoxColumn";
            this.progRegMovInizDataGridViewTextBoxColumn.ReadOnly = true;
            this.progRegMovInizDataGridViewTextBoxColumn.Visible = false;
            // 
            // progContrMovInizDataGridViewTextBoxColumn
            // 
            this.progContrMovInizDataGridViewTextBoxColumn.DataPropertyName = "ProgContrMovIniz";
            this.progContrMovInizDataGridViewTextBoxColumn.HeaderText = "ProgContrMovIniz";
            this.progContrMovInizDataGridViewTextBoxColumn.Name = "progContrMovInizDataGridViewTextBoxColumn";
            this.progContrMovInizDataGridViewTextBoxColumn.ReadOnly = true;
            this.progContrMovInizDataGridViewTextBoxColumn.Visible = false;
            // 
            // serialNumberEstDataGridViewTextBoxColumn
            // 
            this.serialNumberEstDataGridViewTextBoxColumn.DataPropertyName = "SerialNumberEst";
            this.serialNumberEstDataGridViewTextBoxColumn.HeaderText = "SerialNumberEst";
            this.serialNumberEstDataGridViewTextBoxColumn.Name = "serialNumberEstDataGridViewTextBoxColumn";
            this.serialNumberEstDataGridViewTextBoxColumn.ReadOnly = true;
            this.serialNumberEstDataGridViewTextBoxColumn.Visible = false;
            // 
            // flTrasfWebDataGridViewTextBoxColumn
            // 
            this.flTrasfWebDataGridViewTextBoxColumn.DataPropertyName = "FlTrasfWeb";
            this.flTrasfWebDataGridViewTextBoxColumn.HeaderText = "FlTrasfWeb";
            this.flTrasfWebDataGridViewTextBoxColumn.Name = "flTrasfWebDataGridViewTextBoxColumn";
            this.flTrasfWebDataGridViewTextBoxColumn.ReadOnly = true;
            this.flTrasfWebDataGridViewTextBoxColumn.Visible = false;
            // 
            // iDUtenteDataGridViewTextBoxColumn
            // 
            this.iDUtenteDataGridViewTextBoxColumn.DataPropertyName = "IDUtente";
            this.iDUtenteDataGridViewTextBoxColumn.HeaderText = "IDUtente";
            this.iDUtenteDataGridViewTextBoxColumn.Name = "iDUtenteDataGridViewTextBoxColumn";
            this.iDUtenteDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDUtenteDataGridViewTextBoxColumn.Visible = false;
            // 
            // iDTerminaleDataGridViewTextBoxColumn
            // 
            this.iDTerminaleDataGridViewTextBoxColumn.DataPropertyName = "IDTerminale";
            this.iDTerminaleDataGridViewTextBoxColumn.HeaderText = "IDTerminale";
            this.iDTerminaleDataGridViewTextBoxColumn.Name = "iDTerminaleDataGridViewTextBoxColumn";
            this.iDTerminaleDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDTerminaleDataGridViewTextBoxColumn.Visible = false;
            // 
            // dataUltModificaDataGridViewTextBoxColumn
            // 
            this.dataUltModificaDataGridViewTextBoxColumn.DataPropertyName = "DataUltModifica";
            this.dataUltModificaDataGridViewTextBoxColumn.HeaderText = "DataUltModifica";
            this.dataUltModificaDataGridViewTextBoxColumn.Name = "dataUltModificaDataGridViewTextBoxColumn";
            this.dataUltModificaDataGridViewTextBoxColumn.ReadOnly = true;
            this.dataUltModificaDataGridViewTextBoxColumn.Visible = false;
            // 
            // panel_search
            // 
            this.panel_search.BackColor = System.Drawing.Color.Transparent;
            this.panel_search.Controls.Add(this.tb_search);
            this.panel_search.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_search.HorizontalScrollbarBarColor = true;
            this.panel_search.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_search.HorizontalScrollbarSize = 10;
            this.panel_search.Location = new System.Drawing.Point(0, 0);
            this.panel_search.Name = "panel_search";
            this.panel_search.Size = new System.Drawing.Size(238, 30);
            this.panel_search.TabIndex = 4;
            this.panel_search.UseCustomBackColor = true;
            this.panel_search.VerticalScrollbarBarColor = true;
            this.panel_search.VerticalScrollbarHighlightOnWheel = false;
            this.panel_search.VerticalScrollbarSize = 10;
            // 
            // tb_search
            // 
            this.tb_search.BackColor = System.Drawing.Color.LightYellow;
            // 
            // 
            // 
            this.tb_search.CustomButton.Image = null;
            this.tb_search.CustomButton.Location = new System.Drawing.Point(216, 1);
            this.tb_search.CustomButton.Name = "";
            this.tb_search.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_search.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_search.CustomButton.TabIndex = 1;
            this.tb_search.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_search.CustomButton.UseSelectable = true;
            this.tb_search.CustomButton.Visible = false;
            this.tb_search.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_search.Icon = global::SmartLineProduction.Properties.Resources.Lente;
            this.tb_search.IconRight = true;
            this.tb_search.Lines = new string[] {
        "metroTextBox1"};
            this.tb_search.Location = new System.Drawing.Point(0, 0);
            this.tb_search.MaxLength = 32767;
            this.tb_search.Name = "tb_search";
            this.tb_search.PasswordChar = '\0';
            this.tb_search.PromptText = "ricerca";
            this.tb_search.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_search.SelectedText = "";
            this.tb_search.SelectionLength = 0;
            this.tb_search.SelectionStart = 0;
            this.tb_search.ShortcutsEnabled = true;
            this.tb_search.Size = new System.Drawing.Size(238, 23);
            this.tb_search.TabIndex = 2;
            this.tb_search.Text = "metroTextBox1";
            this.tb_search.UseCustomBackColor = true;
            this.tb_search.UseSelectable = true;
            this.tb_search.WaterMark = "ricerca";
            this.tb_search.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_search.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tb_search.TextChanged += new System.EventHandler(this.tb_search_TextChanged);
            // 
            // panel_Smartline
            // 
            this.panel_Smartline.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel_Smartline.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.layout_Schede.SetColumnSpan(this.panel_Smartline, 6);
            this.panel_Smartline.Controls.Add(this.tableLayoutPanel2);
            this.panel_Smartline.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Smartline.HorizontalScrollbarBarColor = true;
            this.panel_Smartline.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_Smartline.HorizontalScrollbarSize = 10;
            this.panel_Smartline.Location = new System.Drawing.Point(247, 123);
            this.panel_Smartline.Name = "panel_Smartline";
            this.panel_Smartline.Size = new System.Drawing.Size(728, 234);
            this.panel_Smartline.TabIndex = 26;
            this.panel_Smartline.UseCustomBackColor = true;
            this.panel_Smartline.VerticalScrollbarBarColor = true;
            this.panel_Smartline.VerticalScrollbarHighlightOnWheel = false;
            this.panel_Smartline.VerticalScrollbarSize = 10;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel2.Controls.Add(this.panel_smartline_data, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 232F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(726, 232);
            this.tableLayoutPanel2.TabIndex = 49;
            this.tableLayoutPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel2_Paint);
            // 
            // panel_smartline_data
            // 
            this.panel_smartline_data.Controls.Add(this.metroButton1);
            this.panel_smartline_data.Controls.Add(this.metroLabel4);
            this.panel_smartline_data.Controls.Add(this.metroLabel9);
            this.panel_smartline_data.Controls.Add(this.metroLabel10);
            this.panel_smartline_data.Controls.Add(this.metroLabel5);
            this.panel_smartline_data.Controls.Add(this.metroLabel6);
            this.panel_smartline_data.Controls.Add(this.metroLabel19);
            this.panel_smartline_data.Controls.Add(this.metroLabel20);
            this.panel_smartline_data.Controls.Add(this.metroLabel7);
            this.panel_smartline_data.Controls.Add(this.metroLabel8);
            this.panel_smartline_data.Controls.Add(this.metroLabel21);
            this.panel_smartline_data.Controls.Add(this.metroLabel22);
            this.panel_smartline_data.Controls.Add(this.metroLabel12);
            this.panel_smartline_data.Controls.Add(this.metroLabel14);
            this.panel_smartline_data.Controls.Add(this.metroLabel13);
            this.panel_smartline_data.Controls.Add(this.metroLabel15);
            this.panel_smartline_data.Controls.Add(this.metroLabel16);
            this.panel_smartline_data.Controls.Add(this.metroLabel17);
            this.panel_smartline_data.Controls.Add(this.metroLabel18);
            this.panel_smartline_data.Controls.Add(this.metroCheckBox1);
            this.panel_smartline_data.Controls.Add(this.metroCheckBox2);
            this.panel_smartline_data.Controls.Add(this.metroLabel29);
            this.panel_smartline_data.Controls.Add(this.metroLabel30);
            this.panel_smartline_data.Controls.Add(this.metroLabel31);
            this.panel_smartline_data.Controls.Add(this.metroLabel32);
            this.panel_smartline_data.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_smartline_data.HorizontalScrollbarBarColor = true;
            this.panel_smartline_data.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_smartline_data.HorizontalScrollbarSize = 10;
            this.panel_smartline_data.Location = new System.Drawing.Point(3, 3);
            this.panel_smartline_data.Name = "panel_smartline_data";
            this.panel_smartline_data.Size = new System.Drawing.Size(502, 226);
            this.panel_smartline_data.TabIndex = 0;
            this.panel_smartline_data.UseCustomBackColor = true;
            this.panel_smartline_data.VerticalScrollbarBarColor = true;
            this.panel_smartline_data.VerticalScrollbarHighlightOnWheel = false;
            this.panel_smartline_data.VerticalScrollbarSize = 10;
            // 
            // metroButton1
            // 
            this.metroButton1.BackgroundImage = global::SmartLineProduction.Properties.Resources.PDF_Flags_IT;
            this.metroButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.metroButton1.Location = new System.Drawing.Point(375, 1);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(70, 30);
            this.metroButton1.TabIndex = 49;
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(0, 0);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(90, 25);
            this.metroLabel4.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel4.TabIndex = 22;
            this.metroLabel4.Text = "SmartLine";
            this.metroLabel4.UseCustomBackColor = true;
            this.metroLabel4.UseStyleColors = true;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel9.Location = new System.Drawing.Point(0, 30);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(54, 19);
            this.metroLabel9.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel9.TabIndex = 27;
            this.metroLabel9.Text = "Cliente:";
            this.metroLabel9.UseCustomBackColor = true;
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "RAGIONESOCIALE", true));
            this.metroLabel10.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel10.Location = new System.Drawing.Point(120, 30);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(101, 19);
            this.metroLabel10.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel10.TabIndex = 28;
            this.metroLabel10.Text = "Cliente_RagSoc";
            this.metroLabel10.UseCustomBackColor = true;
            this.metroLabel10.UseStyleColors = true;
            // 
            // sFSNarsnSFSNQueryBindingSource
            // 
            this.sFSNarsnSFSNQueryBindingSource.DataMember = "SF_SN_arsn_SF_SN_Query";
            this.sFSNarsnSFSNQueryBindingSource.DataSource = this.sFSNarsnBindingSource;
            this.sFSNarsnSFSNQueryBindingSource.ListChanged += new System.ComponentModel.ListChangedEventHandler(this.sFSNarsnSFSNQueryBindingSource_ListChanged);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel5.Location = new System.Drawing.Point(0, 49);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(28, 19);
            this.metroLabel5.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel5.TabIndex = 23;
            this.metroLabel5.Text = "Kit:";
            this.metroLabel5.UseCustomBackColor = true;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "Ser_Kit", true));
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel6.Location = new System.Drawing.Point(120, 49);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(25, 19);
            this.metroLabel6.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel6.TabIndex = 24;
            this.metroLabel6.Text = "Kit";
            this.metroLabel6.UseCustomBackColor = true;
            this.metroLabel6.UseStyleColors = true;
            // 
            // metroLabel19
            // 
            this.metroLabel19.AutoSize = true;
            this.metroLabel19.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "Des_Kit", true));
            this.metroLabel19.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel19.Location = new System.Drawing.Point(300, 49);
            this.metroLabel19.Name = "metroLabel19";
            this.metroLabel19.Size = new System.Drawing.Size(54, 19);
            this.metroLabel19.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel19.TabIndex = 37;
            this.metroLabel19.Text = "Des_Kit";
            this.metroLabel19.UseCustomBackColor = true;
            this.metroLabel19.UseStyleColors = true;
            // 
            // metroLabel20
            // 
            this.metroLabel20.AutoSize = true;
            this.metroLabel20.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "DesEst_Kit", true));
            this.metroLabel20.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel20.Location = new System.Drawing.Point(300, 68);
            this.metroLabel20.Name = "metroLabel20";
            this.metroLabel20.Size = new System.Drawing.Size(72, 19);
            this.metroLabel20.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel20.TabIndex = 38;
            this.metroLabel20.Text = "DesEst_Kit";
            this.metroLabel20.UseCustomBackColor = true;
            this.metroLabel20.UseStyleColors = true;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel7.Location = new System.Drawing.Point(0, 87);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(52, 19);
            this.metroLabel7.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel7.TabIndex = 25;
            this.metroLabel7.Text = "Device:";
            this.metroLabel7.UseCustomBackColor = true;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "Ser_Device", true));
            this.metroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel8.Location = new System.Drawing.Point(120, 87);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(49, 19);
            this.metroLabel8.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel8.TabIndex = 26;
            this.metroLabel8.Text = "Device";
            this.metroLabel8.UseCustomBackColor = true;
            this.metroLabel8.UseStyleColors = true;
            // 
            // metroLabel21
            // 
            this.metroLabel21.AutoSize = true;
            this.metroLabel21.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "Des_Device", true));
            this.metroLabel21.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel21.Location = new System.Drawing.Point(300, 87);
            this.metroLabel21.Name = "metroLabel21";
            this.metroLabel21.Size = new System.Drawing.Size(78, 19);
            this.metroLabel21.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel21.TabIndex = 39;
            this.metroLabel21.Text = "Des_Device";
            this.metroLabel21.UseCustomBackColor = true;
            this.metroLabel21.UseStyleColors = true;
            // 
            // metroLabel22
            // 
            this.metroLabel22.AutoSize = true;
            this.metroLabel22.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "DesEst_Device", true));
            this.metroLabel22.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel22.Location = new System.Drawing.Point(300, 106);
            this.metroLabel22.Name = "metroLabel22";
            this.metroLabel22.Size = new System.Drawing.Size(96, 19);
            this.metroLabel22.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel22.TabIndex = 40;
            this.metroLabel22.Text = "DesEst_Device";
            this.metroLabel22.UseCustomBackColor = true;
            this.metroLabel22.UseStyleColors = true;
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel12.Location = new System.Drawing.Point(0, 125);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(62, 19);
            this.metroLabel12.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel12.TabIndex = 30;
            this.metroLabel12.Text = "ID Code:";
            this.metroLabel12.UseCustomBackColor = true;
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "Ser_Device_ID_Code", true));
            this.metroLabel14.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel14.Location = new System.Drawing.Point(120, 125);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(55, 19);
            this.metroLabel14.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel14.TabIndex = 32;
            this.metroLabel14.Text = "IDCode";
            this.metroLabel14.UseCustomBackColor = true;
            this.metroLabel14.UseStyleColors = true;
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel13.Location = new System.Drawing.Point(0, 144);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(108, 19);
            this.metroLabel13.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel13.TabIndex = 31;
            this.metroLabel13.Text = "Serial Microchip:";
            this.metroLabel13.UseCustomBackColor = true;
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "Ser_OfficialSerial", true));
            this.metroLabel15.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel15.Location = new System.Drawing.Point(120, 144);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(41, 19);
            this.metroLabel15.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel15.TabIndex = 33;
            this.metroLabel15.Text = "Serial";
            this.metroLabel15.UseCustomBackColor = true;
            this.metroLabel15.UseStyleColors = true;
            // 
            // metroLabel16
            // 
            this.metroLabel16.AutoSize = true;
            this.metroLabel16.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel16.Location = new System.Drawing.Point(0, 163);
            this.metroLabel16.Name = "metroLabel16";
            this.metroLabel16.Size = new System.Drawing.Size(112, 19);
            this.metroLabel16.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel16.TabIndex = 34;
            this.metroLabel16.Text = "Firmware iniziale:";
            this.metroLabel16.UseCustomBackColor = true;
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "Ser_SW_Code", true));
            this.metroLabel17.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel17.Location = new System.Drawing.Point(120, 163);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(65, 19);
            this.metroLabel17.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel17.TabIndex = 35;
            this.metroLabel17.Text = "Firmware";
            this.metroLabel17.UseCustomBackColor = true;
            this.metroLabel17.UseStyleColors = true;
            // 
            // metroLabel18
            // 
            this.metroLabel18.AutoSize = true;
            this.metroLabel18.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "Ser_SW_Code_Rev", true));
            this.metroLabel18.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel18.Location = new System.Drawing.Point(300, 163);
            this.metroLabel18.Name = "metroLabel18";
            this.metroLabel18.Size = new System.Drawing.Size(54, 19);
            this.metroLabel18.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel18.TabIndex = 36;
            this.metroLabel18.Text = "FW_rev";
            this.metroLabel18.UseCustomBackColor = true;
            this.metroLabel18.UseStyleColors = true;
            // 
            // metroCheckBox1
            // 
            this.metroCheckBox1.AutoSize = true;
            this.metroCheckBox1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.metroCheckBox1.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.sFSNarsnSFSNQueryBindingSource, "Ser_SW_Std_Type", true));
            this.metroCheckBox1.Location = new System.Drawing.Point(429, 166);
            this.metroCheckBox1.Name = "metroCheckBox1";
            this.metroCheckBox1.Size = new System.Drawing.Size(122, 15);
            this.metroCheckBox1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroCheckBox1.TabIndex = 41;
            this.metroCheckBox1.Text = "Firmware Standard";
            this.metroCheckBox1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.metroCheckBox1.UseCustomBackColor = true;
            this.metroCheckBox1.UseSelectable = true;
            this.metroCheckBox1.UseStyleColors = true;
            // 
            // metroCheckBox2
            // 
            this.metroCheckBox2.AutoSize = true;
            this.metroCheckBox2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.metroCheckBox2.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.sFSNarsnSFSNQueryBindingSource, "SW_Obsolete_ver", true));
            this.metroCheckBox2.Location = new System.Drawing.Point(589, 166);
            this.metroCheckBox2.Name = "metroCheckBox2";
            this.metroCheckBox2.Size = new System.Drawing.Size(121, 15);
            this.metroCheckBox2.Style = MetroFramework.MetroColorStyle.Red;
            this.metroCheckBox2.TabIndex = 42;
            this.metroCheckBox2.Text = "Revisione obsoleta";
            this.metroCheckBox2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.metroCheckBox2.UseCustomBackColor = true;
            this.metroCheckBox2.UseSelectable = true;
            this.metroCheckBox2.UseStyleColors = true;
            // 
            // metroLabel29
            // 
            this.metroLabel29.AutoSize = true;
            this.metroLabel29.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel29.Location = new System.Drawing.Point(0, 182);
            this.metroLabel29.Name = "metroLabel29";
            this.metroLabel29.Size = new System.Drawing.Size(114, 19);
            this.metroLabel29.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel29.TabIndex = 45;
            this.metroLabel29.Text = "Data produzione:";
            this.metroLabel29.UseCustomBackColor = true;
            // 
            // metroLabel30
            // 
            this.metroLabel30.AutoSize = true;
            this.metroLabel30.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "Ser_DateProduction", true));
            this.metroLabel30.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel30.Location = new System.Drawing.Point(120, 182);
            this.metroLabel30.Name = "metroLabel30";
            this.metroLabel30.Size = new System.Drawing.Size(105, 19);
            this.metroLabel30.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel30.TabIndex = 46;
            this.metroLabel30.Text = "DateProduction";
            this.metroLabel30.UseCustomBackColor = true;
            this.metroLabel30.UseStyleColors = true;
            // 
            // metroLabel31
            // 
            this.metroLabel31.AutoSize = true;
            this.metroLabel31.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel31.Location = new System.Drawing.Point(0, 201);
            this.metroLabel31.Name = "metroLabel31";
            this.metroLabel31.Size = new System.Drawing.Size(109, 19);
            this.metroLabel31.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel31.TabIndex = 47;
            this.metroLabel31.Text = "Data spedizione:";
            this.metroLabel31.UseCustomBackColor = true;
            // 
            // metroLabel32
            // 
            this.metroLabel32.AutoSize = true;
            this.metroLabel32.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.sFSNarsnSFSNQueryBindingSource, "Ser_Data_Spedito", true));
            this.metroLabel32.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel32.Location = new System.Drawing.Point(120, 201);
            this.metroLabel32.Name = "metroLabel32";
            this.metroLabel32.Size = new System.Drawing.Size(91, 19);
            this.metroLabel32.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel32.TabIndex = 48;
            this.metroLabel32.Text = "DateShipping";
            this.metroLabel32.UseCustomBackColor = true;
            this.metroLabel32.UseStyleColors = true;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.Schede_pdf_it, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(511, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(212, 226);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // Schede_pdf_it
            // 
            this.Schede_pdf_it.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Schede_pdf_it.Location = new System.Drawing.Point(3, 3);
            this.Schede_pdf_it.MenuManager = this.barManager1;
            this.Schede_pdf_it.Name = "Schede_pdf_it";
            this.Schede_pdf_it.Size = new System.Drawing.Size(206, 220);
            this.Schede_pdf_it.TabIndex = 0;
            // 
            // barManager1
            // 
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this;
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(20, 30);
            this.barDockControlTop.Manager = this.barManager1;
            this.barDockControlTop.Size = new System.Drawing.Size(978, 0);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(20, 887);
            this.barDockControlBottom.Manager = this.barManager1;
            this.barDockControlBottom.Size = new System.Drawing.Size(978, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(20, 30);
            this.barDockControlLeft.Manager = this.barManager1;
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 857);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(998, 30);
            this.barDockControlRight.Manager = this.barManager1;
            this.barDockControlRight.Size = new System.Drawing.Size(0, 857);
            // 
            // panel_ordini
            // 
            this.panel_ordini.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.layout_Schede.SetColumnSpan(this.panel_ordini, 6);
            this.panel_ordini.Controls.Add(this.tableLayoutPanel1);
            this.panel_ordini.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_ordini.HorizontalScrollbarBarColor = true;
            this.panel_ordini.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_ordini.HorizontalScrollbarSize = 10;
            this.panel_ordini.Location = new System.Drawing.Point(247, 363);
            this.panel_ordini.Name = "panel_ordini";
            this.panel_ordini.Size = new System.Drawing.Size(728, 466);
            this.panel_ordini.TabIndex = 35;
            this.panel_ordini.VerticalScrollbarBarColor = true;
            this.panel_ordini.VerticalScrollbarHighlightOnWheel = false;
            this.panel_ordini.VerticalScrollbarSize = 10;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Controls.Add(this.metroGrid1, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.gv_Lotti, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.metroLabel27, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.lab_movimenti_sn, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.gv_CicloAttivo, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lab_movimenti_moma, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.gv_moma, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.metroLabel28, 1, 4);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(726, 464);
            this.tableLayoutPanel1.TabIndex = 4;
            // 
            // metroGrid1
            // 
            this.metroGrid1.AllowUserToAddRows = false;
            this.metroGrid1.AllowUserToDeleteRows = false;
            this.metroGrid1.AllowUserToResizeRows = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Gainsboro;
            this.metroGrid1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.metroGrid1.AutoGenerateColumns = false;
            this.metroGrid1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.metroGrid1.ColumnHeadersHeight = 40;
            this.metroGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17});
            this.metroGrid1.DataSource = this.sFSNCicloAttivoKitSFOrdiniDDTSerialNumbersBindingSource;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid1.DefaultCellStyle = dataGridViewCellStyle7;
            this.metroGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroGrid1.EnableHeadersVisualStyles = false;
            this.metroGrid1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.Location = new System.Drawing.Point(3, 304);
            this.metroGrid1.MultiSelect = false;
            this.metroGrid1.Name = "metroGrid1";
            this.metroGrid1.ReadOnly = true;
            this.metroGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.metroGrid1.RowHeadersVisible = false;
            this.metroGrid1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid1.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Wheat;
            this.metroGrid1.RowTemplate.Height = 30;
            this.metroGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid1.Size = new System.Drawing.Size(538, 157);
            this.metroGrid1.Style = MetroFramework.MetroColorStyle.Orange;
            this.metroGrid1.TabIndex = 55;
            this.metroGrid1.UseCustomBackColor = true;
            this.metroGrid1.UseCustomForeColor = true;
            this.metroGrid1.UseStyleColors = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Descrizione";
            this.dataGridViewTextBoxColumn2.HeaderText = "Descrizione";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn3.DataPropertyName = "COMMESSA_SHORT";
            this.dataGridViewTextBoxColumn3.HeaderText = "Commessa";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 84;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn4.DataPropertyName = "ArticoloTrim";
            this.dataGridViewTextBoxColumn4.HeaderText = "Articolo";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn5.DataPropertyName = "ARTICOLO";
            this.dataGridViewTextBoxColumn5.HeaderText = "Articolo";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Visible = false;
            this.dataGridViewTextBoxColumn5.Width = 70;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn6.DataPropertyName = "DATA_DDT";
            this.dataGridViewTextBoxColumn6.HeaderText = "Data DDt";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 71;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn7.DataPropertyName = "NUM_DDT";
            this.dataGridViewTextBoxColumn7.HeaderText = "Numero DDt";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 86;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn8.DataPropertyName = "QTA_DDT";
            this.dataGridViewTextBoxColumn8.HeaderText = "Q.tà DDt";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 68;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn9.DataPropertyName = "NUM_ORDINE";
            this.dataGridViewTextBoxColumn9.HeaderText = "N. Ordine";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 74;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn10.DataPropertyName = "QTA_ORDINE";
            this.dataGridViewTextBoxColumn10.HeaderText = "Q.tà Ordine";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Width = 83;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn11.DataPropertyName = "TIPO_ORDINE";
            this.dataGridViewTextBoxColumn11.HeaderText = "TIPO_ORDINE";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Visible = false;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "RIGA_ORDINE";
            this.dataGridViewTextBoxColumn12.HeaderText = "RIGA_ORDINE";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Visible = false;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "COMMESSA_LONG";
            this.dataGridViewTextBoxColumn13.HeaderText = "COMMESSA_LONG";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Visible = false;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "U_M";
            this.dataGridViewTextBoxColumn14.HeaderText = "U_M";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Visible = false;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "PREZZO";
            this.dataGridViewTextBoxColumn15.HeaderText = "PREZZO";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Visible = false;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "TIPO_DDT";
            this.dataGridViewTextBoxColumn16.HeaderText = "TIPO_DDT";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Visible = false;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "RIGA_DDT";
            this.dataGridViewTextBoxColumn17.HeaderText = "RIGA_DDT";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.Visible = false;
            // 
            // sFSNCicloAttivoKitSFOrdiniDDTSerialNumbersBindingSource
            // 
            this.sFSNCicloAttivoKitSFOrdiniDDTSerialNumbersBindingSource.DataMember = "SF_SN_CicloAttivo_Kit_SF_OrdiniDDT_SerialNumbers";
            this.sFSNCicloAttivoKitSFOrdiniDDTSerialNumbersBindingSource.DataSource = this.sFSNarsnSFSNCicloAttivoKitBindingSource;
            // 
            // gv_Lotti
            // 
            this.gv_Lotti.AllowUserToAddRows = false;
            this.gv_Lotti.AllowUserToDeleteRows = false;
            this.gv_Lotti.AllowUserToResizeRows = false;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_Lotti.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.gv_Lotti.AutoGenerateColumns = false;
            this.gv_Lotti.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Lotti.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Lotti.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_Lotti.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Lotti.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.gv_Lotti.ColumnHeadersHeight = 40;
            this.gv_Lotti.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gv_DDT_Descrizione,
            this.gv_DDT_ArticoloTrimmed,
            this.idDataGridViewTextBoxColumn,
            this.ltCreationTimeDataGridViewTextBoxColumn,
            this.ltLottoFornitoreDataGridViewTextBoxColumn,
            this.ltSerialNumberDataGridViewTextBoxColumn,
            this.ltCommessaLongDataGridViewTextBoxColumn,
            this.ltArticoloDataGridViewTextBoxColumn});
            this.gv_Lotti.DataSource = this.sFSNarsnLottiSpedizioneBindingSource;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Lotti.DefaultCellStyle = dataGridViewCellStyle11;
            this.gv_Lotti.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Lotti.EnableHeadersVisualStyles = false;
            this.gv_Lotti.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Lotti.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Lotti.Location = new System.Drawing.Point(547, 304);
            this.gv_Lotti.MultiSelect = false;
            this.gv_Lotti.Name = "gv_Lotti";
            this.gv_Lotti.ReadOnly = true;
            this.gv_Lotti.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Lotti.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.gv_Lotti.RowHeadersVisible = false;
            this.gv_Lotti.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Lotti.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Wheat;
            this.gv_Lotti.RowTemplate.Height = 30;
            this.gv_Lotti.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Lotti.Size = new System.Drawing.Size(176, 157);
            this.gv_Lotti.Style = MetroFramework.MetroColorStyle.Blue;
            this.gv_Lotti.TabIndex = 53;
            this.gv_Lotti.UseCustomBackColor = true;
            this.gv_Lotti.UseCustomForeColor = true;
            this.gv_Lotti.UseStyleColors = true;
            this.gv_Lotti.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.gv_DDT_CellFormatting);
            // 
            // gv_DDT_Descrizione
            // 
            this.gv_DDT_Descrizione.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_DDT_Descrizione.DataPropertyName = "Descrizione";
            this.gv_DDT_Descrizione.HeaderText = "Descrizione";
            this.gv_DDT_Descrizione.Name = "gv_DDT_Descrizione";
            this.gv_DDT_Descrizione.ReadOnly = true;
            this.gv_DDT_Descrizione.Visible = false;
            // 
            // gv_DDT_ArticoloTrimmed
            // 
            this.gv_DDT_ArticoloTrimmed.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_DDT_ArticoloTrimmed.DataPropertyName = "ArticoloTrim";
            this.gv_DDT_ArticoloTrimmed.HeaderText = "Articolo";
            this.gv_DDT_ArticoloTrimmed.Name = "gv_DDT_ArticoloTrimmed";
            this.gv_DDT_ArticoloTrimmed.ReadOnly = true;
            this.gv_DDT_ArticoloTrimmed.Visible = false;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Visible = false;
            // 
            // ltCreationTimeDataGridViewTextBoxColumn
            // 
            this.ltCreationTimeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.ltCreationTimeDataGridViewTextBoxColumn.DataPropertyName = "Lt_CreationTime";
            this.ltCreationTimeDataGridViewTextBoxColumn.HeaderText = "Data di utilizzo";
            this.ltCreationTimeDataGridViewTextBoxColumn.Name = "ltCreationTimeDataGridViewTextBoxColumn";
            this.ltCreationTimeDataGridViewTextBoxColumn.ReadOnly = true;
            this.ltCreationTimeDataGridViewTextBoxColumn.Width = 98;
            // 
            // ltLottoFornitoreDataGridViewTextBoxColumn
            // 
            this.ltLottoFornitoreDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ltLottoFornitoreDataGridViewTextBoxColumn.DataPropertyName = "Lt_LottoFornitore";
            this.ltLottoFornitoreDataGridViewTextBoxColumn.HeaderText = "Lotto";
            this.ltLottoFornitoreDataGridViewTextBoxColumn.Name = "ltLottoFornitoreDataGridViewTextBoxColumn";
            this.ltLottoFornitoreDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // ltSerialNumberDataGridViewTextBoxColumn
            // 
            this.ltSerialNumberDataGridViewTextBoxColumn.DataPropertyName = "Lt_SerialNumber";
            this.ltSerialNumberDataGridViewTextBoxColumn.HeaderText = "Lt_SerialNumber";
            this.ltSerialNumberDataGridViewTextBoxColumn.Name = "ltSerialNumberDataGridViewTextBoxColumn";
            this.ltSerialNumberDataGridViewTextBoxColumn.ReadOnly = true;
            this.ltSerialNumberDataGridViewTextBoxColumn.Visible = false;
            // 
            // ltCommessaLongDataGridViewTextBoxColumn
            // 
            this.ltCommessaLongDataGridViewTextBoxColumn.DataPropertyName = "Lt_CommessaLong";
            this.ltCommessaLongDataGridViewTextBoxColumn.HeaderText = "Lt_CommessaLong";
            this.ltCommessaLongDataGridViewTextBoxColumn.Name = "ltCommessaLongDataGridViewTextBoxColumn";
            this.ltCommessaLongDataGridViewTextBoxColumn.ReadOnly = true;
            this.ltCommessaLongDataGridViewTextBoxColumn.Visible = false;
            // 
            // ltArticoloDataGridViewTextBoxColumn
            // 
            this.ltArticoloDataGridViewTextBoxColumn.DataPropertyName = "Lt_Articolo";
            this.ltArticoloDataGridViewTextBoxColumn.HeaderText = "Lt_Articolo";
            this.ltArticoloDataGridViewTextBoxColumn.Name = "ltArticoloDataGridViewTextBoxColumn";
            this.ltArticoloDataGridViewTextBoxColumn.ReadOnly = true;
            this.ltArticoloDataGridViewTextBoxColumn.Visible = false;
            // 
            // sFSNarsnLottiSpedizioneBindingSource
            // 
            this.sFSNarsnLottiSpedizioneBindingSource.DataMember = "SF_SN_arsn_LottiSpedizione";
            this.sFSNarsnLottiSpedizioneBindingSource.DataSource = this.sFSNarsnBindingSource;
            // 
            // metroLabel27
            // 
            this.metroLabel27.AutoSize = true;
            this.metroLabel27.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel27.Location = new System.Drawing.Point(3, 281);
            this.metroLabel27.Name = "metroLabel27";
            this.metroLabel27.Size = new System.Drawing.Size(310, 19);
            this.metroLabel27.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel27.TabIndex = 52;
            this.metroLabel27.Text = "Elenco dei DDT relativi alla Commessa selezionata";
            this.metroLabel27.UseStyleColors = true;
            // 
            // lab_movimenti_sn
            // 
            this.lab_movimenti_sn.AutoSize = true;
            this.lab_movimenti_sn.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_movimenti_sn.Location = new System.Drawing.Point(3, 0);
            this.lab_movimenti_sn.Name = "lab_movimenti_sn";
            this.lab_movimenti_sn.Size = new System.Drawing.Size(451, 19);
            this.lab_movimenti_sn.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_movimenti_sn.TabIndex = 49;
            this.lab_movimenti_sn.Text = "Elenco dei movimenti di magazzino relativi al numero di serie selezionata";
            this.lab_movimenti_sn.UseStyleColors = true;
            // 
            // gv_CicloAttivo
            // 
            this.gv_CicloAttivo.AllowUserToAddRows = false;
            this.gv_CicloAttivo.AllowUserToDeleteRows = false;
            this.gv_CicloAttivo.AllowUserToResizeRows = false;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_CicloAttivo.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            this.gv_CicloAttivo.AutoGenerateColumns = false;
            this.gv_CicloAttivo.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_CicloAttivo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_CicloAttivo.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_CicloAttivo.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_CicloAttivo.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.gv_CicloAttivo.ColumnHeadersHeight = 40;
            this.gv_CicloAttivo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gv_CicloAttivo_Commessa,
            this.gv_CicloAttivo_Articolo,
            this.gv_CicloAttivo_DataDocumento,
            this.gv_CicloAttivo_Descrizione,
            this.gv_CicloAttivo_DataOrdine,
            this.gv_CicloAttivo_NumOrdine,
            this.gv_CicloAttivo_ArticoloOrdine,
            this.gv_CicloAttivo_SerialNumber,
            this.gv_CicloAttivo_DesMovimento,
            this.gv_CicloAttivo_RSCognome,
            this.gv_CicloAttivo_RSNome,
            this.gv_CicloAttivo_RSCompleta,
            this.gv_CicloAttivo_RSNazione});
            this.tableLayoutPanel1.SetColumnSpan(this.gv_CicloAttivo, 2);
            this.gv_CicloAttivo.DataSource = this.sFSNarsnSFSNCicloAttivoKitBindingSource;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_CicloAttivo.DefaultCellStyle = dataGridViewCellStyle15;
            this.gv_CicloAttivo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_CicloAttivo.EnableHeadersVisualStyles = false;
            this.gv_CicloAttivo.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_CicloAttivo.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_CicloAttivo.Location = new System.Drawing.Point(3, 23);
            this.gv_CicloAttivo.MultiSelect = false;
            this.gv_CicloAttivo.Name = "gv_CicloAttivo";
            this.gv_CicloAttivo.ReadOnly = true;
            this.gv_CicloAttivo.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_CicloAttivo.RowHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.gv_CicloAttivo.RowHeadersVisible = false;
            this.gv_CicloAttivo.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_CicloAttivo.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Wheat;
            this.gv_CicloAttivo.RowTemplate.Height = 30;
            this.gv_CicloAttivo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_CicloAttivo.Size = new System.Drawing.Size(720, 74);
            this.gv_CicloAttivo.Style = MetroFramework.MetroColorStyle.Orange;
            this.gv_CicloAttivo.TabIndex = 3;
            this.gv_CicloAttivo.UseCustomBackColor = true;
            this.gv_CicloAttivo.UseCustomForeColor = true;
            this.gv_CicloAttivo.UseStyleColors = true;
            this.gv_CicloAttivo.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.gv_CicloAttivo_CellFormatting);
            // 
            // gv_CicloAttivo_Commessa
            // 
            this.gv_CicloAttivo_Commessa.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_CicloAttivo_Commessa.DataPropertyName = "Commessa";
            this.gv_CicloAttivo_Commessa.HeaderText = "Commessa";
            this.gv_CicloAttivo_Commessa.Name = "gv_CicloAttivo_Commessa";
            this.gv_CicloAttivo_Commessa.ReadOnly = true;
            this.gv_CicloAttivo_Commessa.Width = 84;
            // 
            // gv_CicloAttivo_Articolo
            // 
            this.gv_CicloAttivo_Articolo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_CicloAttivo_Articolo.DataPropertyName = "Articolo";
            this.gv_CicloAttivo_Articolo.HeaderText = "Articolo";
            this.gv_CicloAttivo_Articolo.Name = "gv_CicloAttivo_Articolo";
            this.gv_CicloAttivo_Articolo.ReadOnly = true;
            this.gv_CicloAttivo_Articolo.Width = 70;
            // 
            // gv_CicloAttivo_DataDocumento
            // 
            this.gv_CicloAttivo_DataDocumento.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_CicloAttivo_DataDocumento.DataPropertyName = "DataDocumento";
            this.gv_CicloAttivo_DataDocumento.HeaderText = "DataDocumento";
            this.gv_CicloAttivo_DataDocumento.Name = "gv_CicloAttivo_DataDocumento";
            this.gv_CicloAttivo_DataDocumento.ReadOnly = true;
            this.gv_CicloAttivo_DataDocumento.Width = 114;
            // 
            // gv_CicloAttivo_Descrizione
            // 
            this.gv_CicloAttivo_Descrizione.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_CicloAttivo_Descrizione.DataPropertyName = "Descrizione";
            this.gv_CicloAttivo_Descrizione.HeaderText = "Descrizione";
            this.gv_CicloAttivo_Descrizione.Name = "gv_CicloAttivo_Descrizione";
            this.gv_CicloAttivo_Descrizione.ReadOnly = true;
            // 
            // gv_CicloAttivo_DataOrdine
            // 
            this.gv_CicloAttivo_DataOrdine.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_CicloAttivo_DataOrdine.DataPropertyName = "DataOrdine";
            this.gv_CicloAttivo_DataOrdine.HeaderText = "DataOrdine";
            this.gv_CicloAttivo_DataOrdine.Name = "gv_CicloAttivo_DataOrdine";
            this.gv_CicloAttivo_DataOrdine.ReadOnly = true;
            this.gv_CicloAttivo_DataOrdine.Width = 90;
            // 
            // gv_CicloAttivo_NumOrdine
            // 
            this.gv_CicloAttivo_NumOrdine.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_CicloAttivo_NumOrdine.DataPropertyName = "NumeroOrdine";
            this.gv_CicloAttivo_NumOrdine.HeaderText = "NumeroOrdine";
            this.gv_CicloAttivo_NumOrdine.Name = "gv_CicloAttivo_NumOrdine";
            this.gv_CicloAttivo_NumOrdine.ReadOnly = true;
            this.gv_CicloAttivo_NumOrdine.Width = 107;
            // 
            // gv_CicloAttivo_ArticoloOrdine
            // 
            this.gv_CicloAttivo_ArticoloOrdine.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_CicloAttivo_ArticoloOrdine.DataPropertyName = "Articolo_Ordine";
            this.gv_CicloAttivo_ArticoloOrdine.HeaderText = "Articolo in Ordine";
            this.gv_CicloAttivo_ArticoloOrdine.Name = "gv_CicloAttivo_ArticoloOrdine";
            this.gv_CicloAttivo_ArticoloOrdine.ReadOnly = true;
            // 
            // gv_CicloAttivo_SerialNumber
            // 
            this.gv_CicloAttivo_SerialNumber.DataPropertyName = "SerialNumber";
            this.gv_CicloAttivo_SerialNumber.HeaderText = "SerialNumber";
            this.gv_CicloAttivo_SerialNumber.Name = "gv_CicloAttivo_SerialNumber";
            this.gv_CicloAttivo_SerialNumber.ReadOnly = true;
            this.gv_CicloAttivo_SerialNumber.Visible = false;
            // 
            // gv_CicloAttivo_DesMovimento
            // 
            this.gv_CicloAttivo_DesMovimento.DataPropertyName = "DescrizioneMovimento";
            this.gv_CicloAttivo_DesMovimento.HeaderText = "DescrizioneMovimento";
            this.gv_CicloAttivo_DesMovimento.Name = "gv_CicloAttivo_DesMovimento";
            this.gv_CicloAttivo_DesMovimento.ReadOnly = true;
            this.gv_CicloAttivo_DesMovimento.Visible = false;
            // 
            // gv_CicloAttivo_RSCognome
            // 
            this.gv_CicloAttivo_RSCognome.DataPropertyName = "RagSocCognome";
            this.gv_CicloAttivo_RSCognome.HeaderText = "RagSocCognome";
            this.gv_CicloAttivo_RSCognome.Name = "gv_CicloAttivo_RSCognome";
            this.gv_CicloAttivo_RSCognome.ReadOnly = true;
            this.gv_CicloAttivo_RSCognome.Visible = false;
            // 
            // gv_CicloAttivo_RSNome
            // 
            this.gv_CicloAttivo_RSNome.DataPropertyName = "RagSocNome";
            this.gv_CicloAttivo_RSNome.HeaderText = "RagSocNome";
            this.gv_CicloAttivo_RSNome.Name = "gv_CicloAttivo_RSNome";
            this.gv_CicloAttivo_RSNome.ReadOnly = true;
            this.gv_CicloAttivo_RSNome.Visible = false;
            // 
            // gv_CicloAttivo_RSCompleta
            // 
            this.gv_CicloAttivo_RSCompleta.DataPropertyName = "RagSocCompleta";
            this.gv_CicloAttivo_RSCompleta.HeaderText = "RagSocCompleta";
            this.gv_CicloAttivo_RSCompleta.Name = "gv_CicloAttivo_RSCompleta";
            this.gv_CicloAttivo_RSCompleta.ReadOnly = true;
            this.gv_CicloAttivo_RSCompleta.Visible = false;
            // 
            // gv_CicloAttivo_RSNazione
            // 
            this.gv_CicloAttivo_RSNazione.DataPropertyName = "NazioneFiscale";
            this.gv_CicloAttivo_RSNazione.HeaderText = "NazioneFiscale";
            this.gv_CicloAttivo_RSNazione.Name = "gv_CicloAttivo_RSNazione";
            this.gv_CicloAttivo_RSNazione.ReadOnly = true;
            this.gv_CicloAttivo_RSNazione.Visible = false;
            // 
            // lab_movimenti_moma
            // 
            this.lab_movimenti_moma.AutoSize = true;
            this.lab_movimenti_moma.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lab_movimenti_moma.Location = new System.Drawing.Point(3, 100);
            this.lab_movimenti_moma.Name = "lab_movimenti_moma";
            this.lab_movimenti_moma.Size = new System.Drawing.Size(433, 19);
            this.lab_movimenti_moma.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_movimenti_moma.TabIndex = 50;
            this.lab_movimenti_moma.Text = "Elenco dei movimenti di magazzino relativi alla Commessa selezionata";
            this.lab_movimenti_moma.UseStyleColors = true;
            // 
            // gv_moma
            // 
            this.gv_moma.AllowUserToAddRows = false;
            this.gv_moma.AllowUserToDeleteRows = false;
            this.gv_moma.AllowUserToResizeRows = false;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_moma.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle17;
            this.gv_moma.AutoGenerateColumns = false;
            this.gv_moma.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_moma.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_moma.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_moma.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_moma.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.gv_moma.ColumnHeadersHeight = 40;
            this.gv_moma.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gv_Moma_Commessa,
            this.gv_Moma_Articolo,
            this.gv_Moma_DataDoc,
            this.gv_Moma_DesMov,
            this.gv_Moma_DataOrd,
            this.gv_Moma_NumOrd});
            this.tableLayoutPanel1.SetColumnSpan(this.gv_moma, 2);
            this.gv_moma.DataSource = this.sFsnmomaBindingSource;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_moma.DefaultCellStyle = dataGridViewCellStyle19;
            this.gv_moma.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_moma.EnableHeadersVisualStyles = false;
            this.gv_moma.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_moma.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_moma.Location = new System.Drawing.Point(3, 123);
            this.gv_moma.MultiSelect = false;
            this.gv_moma.Name = "gv_moma";
            this.gv_moma.ReadOnly = true;
            this.gv_moma.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(119)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(133)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_moma.RowHeadersDefaultCellStyle = dataGridViewCellStyle20;
            this.gv_moma.RowHeadersVisible = false;
            this.gv_moma.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_moma.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Wheat;
            this.gv_moma.RowTemplate.Height = 30;
            this.gv_moma.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_moma.Size = new System.Drawing.Size(720, 155);
            this.gv_moma.Style = MetroFramework.MetroColorStyle.Orange;
            this.gv_moma.TabIndex = 51;
            this.gv_moma.UseCustomBackColor = true;
            this.gv_moma.UseCustomForeColor = true;
            this.gv_moma.UseStyleColors = true;
            this.gv_moma.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.gv_moma_CellFormatting);
            // 
            // gv_Moma_Commessa
            // 
            this.gv_Moma_Commessa.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Moma_Commessa.DataPropertyName = "Commessa";
            this.gv_Moma_Commessa.HeaderText = "Commessa";
            this.gv_Moma_Commessa.Name = "gv_Moma_Commessa";
            this.gv_Moma_Commessa.ReadOnly = true;
            this.gv_Moma_Commessa.Width = 84;
            // 
            // gv_Moma_Articolo
            // 
            this.gv_Moma_Articolo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Moma_Articolo.DataPropertyName = "Articolo";
            this.gv_Moma_Articolo.HeaderText = "Articolo";
            this.gv_Moma_Articolo.Name = "gv_Moma_Articolo";
            this.gv_Moma_Articolo.ReadOnly = true;
            this.gv_Moma_Articolo.Width = 70;
            // 
            // gv_Moma_DataDoc
            // 
            this.gv_Moma_DataDoc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Moma_DataDoc.DataPropertyName = "DataDocumento";
            this.gv_Moma_DataDoc.HeaderText = "DataDocumento";
            this.gv_Moma_DataDoc.Name = "gv_Moma_DataDoc";
            this.gv_Moma_DataDoc.ReadOnly = true;
            this.gv_Moma_DataDoc.Width = 114;
            // 
            // gv_Moma_DesMov
            // 
            this.gv_Moma_DesMov.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_Moma_DesMov.DataPropertyName = "Descrizione";
            this.gv_Moma_DesMov.HeaderText = "Descrizione";
            this.gv_Moma_DesMov.Name = "gv_Moma_DesMov";
            this.gv_Moma_DesMov.ReadOnly = true;
            // 
            // gv_Moma_DataOrd
            // 
            this.gv_Moma_DataOrd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.gv_Moma_DataOrd.DataPropertyName = "DataOrdine";
            this.gv_Moma_DataOrd.HeaderText = "DataOrdine";
            this.gv_Moma_DataOrd.Name = "gv_Moma_DataOrd";
            this.gv_Moma_DataOrd.ReadOnly = true;
            this.gv_Moma_DataOrd.Width = 90;
            // 
            // gv_Moma_NumOrd
            // 
            this.gv_Moma_NumOrd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.gv_Moma_NumOrd.DataPropertyName = "NumeroOrdine";
            this.gv_Moma_NumOrd.HeaderText = "NumeroOrdine";
            this.gv_Moma_NumOrd.Name = "gv_Moma_NumOrd";
            this.gv_Moma_NumOrd.ReadOnly = true;
            // 
            // sFsnmomaBindingSource
            // 
            this.sFsnmomaBindingSource.DataMember = "SF_sn_moma";
            this.sFsnmomaBindingSource.DataSource = this.ds_QuerySN;
            // 
            // metroLabel28
            // 
            this.metroLabel28.AutoSize = true;
            this.metroLabel28.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel28.Location = new System.Drawing.Point(547, 281);
            this.metroLabel28.Name = "metroLabel28";
            this.metroLabel28.Size = new System.Drawing.Size(102, 19);
            this.metroLabel28.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel28.TabIndex = 54;
            this.metroLabel28.Text = "Lotti impegnati";
            this.metroLabel28.UseStyleColors = true;
            // 
            // sF_SN_arsnTableAdapter
            // 
            this.sF_SN_arsnTableAdapter.ClearBeforeFill = true;
            // 
            // sF_SN_artaTableAdapter
            // 
            this.sF_SN_artaTableAdapter.ClearBeforeFill = true;
            // 
            // sF_SN_CicloAttivo_KitTableAdapter
            // 
            this.sF_SN_CicloAttivo_KitTableAdapter.ClearBeforeFill = true;
            // 
            // sF_SN_QueryTableAdapter
            // 
            this.sF_SN_QueryTableAdapter.ClearBeforeFill = true;
            // 
            // sF_sn_momaTableAdapter
            // 
            this.sF_sn_momaTableAdapter.ClearBeforeFill = true;
            // 
            // sF_OrdiniDDT_SerialNumbersTableAdapter
            // 
            this.sF_OrdiniDDT_SerialNumbersTableAdapter.ClearBeforeFill = true;
            // 
            // lottiSpedizioneTableAdapter
            // 
            this.lottiSpedizioneTableAdapter.ClearBeforeFill = true;
            // 
            // UC_Identifica
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1018, 907);
            this.ControlBox = false;
            this.Controls.Add(this.panel_fattibilita);
            this.Controls.Add(this.layout_orizz_menu);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.DisplayHeader = false;
            this.Name = "UC_Identifica";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UC_Identifica_Load);
            this.layout_orizz_menu.ResumeLayout(false);
            this.layout_orizz_menu.PerformLayout();
            this.pan_Menu_comandi.ResumeLayout(false);
            this.pan_Menu_comandi.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            this.panel_fattibilita.ResumeLayout(false);
            this.layout_Schede.ResumeLayout(false);
            this.layout_Schede.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFSNCicloAttivoKitBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_QuerySN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFSNartaBindingSource)).EndInit();
            this.panel_grid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_SN)).EndInit();
            this.panel_search.ResumeLayout(false);
            this.panel_Smartline.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel_smartline_data.ResumeLayout(false);
            this.panel_smartline_data.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnSFSNQueryBindingSource)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            this.panel_ordini.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNCicloAttivoKitSFOrdiniDDTSerialNumbersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Lotti)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFSNarsnLottiSpedizioneBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_CicloAttivo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_moma)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sFsnmomaBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel layout_orizz_menu;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
        private MetroFramework.Controls.MetroPanel panel_fattibilita;
        private System.Windows.Forms.TableLayoutPanel layout_Schede;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloCompostoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloComponenteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Explode_Mag;
        private MetroFramework.Controls.MetroPanel panel_grid;
        private System.Windows.Forms.DataGridViewTextBoxColumn qualProg1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private MetroFramework.Controls.MetroGrid gv_SN;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.MenuStrip pan_Menu_comandi;
        private System.Windows.Forms.ToolStripMenuItem verificaSaltiNumerazioneToolStripMenuItem;
        private ds_QuerySN ds_QuerySN;
        private System.Windows.Forms.BindingSource sFSNarsnBindingSource;
        private ds_QuerySNTableAdapters.SF_SN_arsnTableAdapter sF_SN_arsnTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn serialNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn entitaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serieDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn partitaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataInizioGarForDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn flObsoletoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataTrasfObsoletoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nume01DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataRegMovInizDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn progRegMovInizDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn progContrMovInizDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serialNumberEstDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn flTrasfWebDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDUtenteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDTerminaleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataUltModificaDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel24;
        private MetroFramework.Controls.MetroLabel metroLabel23;
        private System.Windows.Forms.DataGridViewTextBoxColumn entitaDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serieDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn partitaDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataRegistrazioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn progRegistrazioneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn progContropDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn flStatoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoMovimentoDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroLabel metroLabel26;
        private MetroFramework.Controls.MetroLabel metroLabel25;
        private System.Windows.Forms.BindingSource sFSNarsnSFSNartaBindingSource;
        private ds_QuerySNTableAdapters.SF_SN_artaTableAdapter sF_SN_artaTableAdapter;
        private System.Windows.Forms.BindingSource sFSNarsnSFSNCicloAttivoKitBindingSource;
        private ds_QuerySNTableAdapters.SF_SN_CicloAttivo_KitTableAdapter sF_SN_CicloAttivo_KitTableAdapter;
        private MetroFramework.Controls.MetroPanel panel_ordini;
        private MetroFramework.Controls.MetroGrid gv_CicloAttivo;
        private System.Windows.Forms.BindingSource sFSNarsnSFSNQueryBindingSource;
        private ds_QuerySNTableAdapters.SF_SN_QueryTableAdapter sF_SN_QueryTableAdapter;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private MetroFramework.Controls.MetroLabel lab_movimenti_sn;
        private MetroFramework.Controls.MetroLabel lab_movimenti_moma;
        private MetroFramework.Controls.MetroGrid gv_moma;
        private System.Windows.Forms.BindingSource sFsnmomaBindingSource;
        private ds_QuerySNTableAdapters.SF_sn_momaTableAdapter sF_sn_momaTableAdapter;
        private MetroFramework.Controls.MetroPanel panel_Smartline;
        private MetroFramework.Controls.MetroLabel metroLabel32;
        private MetroFramework.Controls.MetroLabel metroLabel31;
        private MetroFramework.Controls.MetroLabel metroLabel30;
        private MetroFramework.Controls.MetroLabel metroLabel29;
        private MetroFramework.Controls.MetroCheckBox metroCheckBox2;
        private MetroFramework.Controls.MetroCheckBox metroCheckBox1;
        private MetroFramework.Controls.MetroLabel metroLabel22;
        private MetroFramework.Controls.MetroLabel metroLabel21;
        private MetroFramework.Controls.MetroLabel metroLabel20;
        private MetroFramework.Controls.MetroLabel metroLabel19;
        private MetroFramework.Controls.MetroLabel metroLabel18;
        private MetroFramework.Controls.MetroLabel metroLabel17;
        private MetroFramework.Controls.MetroLabel metroLabel16;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private MetroFramework.Controls.MetroPanel panel_smartline_data;
        private MetroFramework.Controls.MetroPanel panel_search;
        private MetroFramework.Controls.MetroTextBox tb_search;
        private MetroFramework.Controls.MetroGrid gv_Lotti;
        private MetroFramework.Controls.MetroLabel metroLabel27;
        private System.Windows.Forms.DataGridViewTextBoxColumn cOMMESSADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloDataGridViewTextBoxColumn1;
        private System.Windows.Forms.BindingSource sFSNCicloAttivoKitSFOrdiniDDTSerialNumbersBindingSource;
        private ds_QuerySNTableAdapters.SF_OrdiniDDT_SerialNumbersTableAdapter sF_OrdiniDDT_SerialNumbersTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_CicloAttivo_Commessa;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_CicloAttivo_Articolo;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_CicloAttivo_DataDocumento;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_CicloAttivo_Descrizione;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_CicloAttivo_DataOrdine;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_CicloAttivo_NumOrdine;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_CicloAttivo_ArticoloOrdine;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_CicloAttivo_SerialNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_CicloAttivo_DesMovimento;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_CicloAttivo_RSCognome;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_CicloAttivo_RSNome;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_CicloAttivo_RSCompleta;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_CicloAttivo_RSNazione;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Moma_Commessa;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Moma_Articolo;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Moma_DataDoc;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Moma_DesMov;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Moma_DataOrd;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_Moma_NumOrd;
        private MetroFramework.Controls.MetroGrid metroGrid1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private MetroFramework.Controls.MetroLabel metroLabel28;
        private System.Windows.Forms.BindingSource sFSNarsnLottiSpedizioneBindingSource;
        private ds_QuerySNTableAdapters.LottiSpedizioneTableAdapter lottiSpedizioneTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_DDT_Descrizione;
        private System.Windows.Forms.DataGridViewTextBoxColumn gv_DDT_ArticoloTrimmed;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ltCreationTimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ltLottoFornitoreDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ltSerialNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ltCommessaLongDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ltArticoloDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ltFirmwareDataGridViewTextBoxColumn;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private DevExpress.XtraPdfViewer.PdfViewer Schede_pdf_it;
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private MetroFramework.Controls.MetroButton metroButton1;
    }
}