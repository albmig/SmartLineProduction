﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using DYMO.Label.Framework;

namespace SmartLineProduction
{
    public partial class MainMenu : MetroFramework.Forms.MetroForm
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void tile_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void MainMenu_MdiChildActivate(object sender, EventArgs e)
        {
            Form f = this.ActiveMdiChild;

            if (f == null)
            {
                //the last child form was just closed
                layout_Menu.Visible = true;
            }
            else
            {
                layout_Menu.Visible = false;
            }
        }

        private void MainMenu_Load(object sender, EventArgs e)
        {
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
            this.Icon = global::SmartLineProduction.Properties.Resources.logo_new_32;

            lab_resources_path.Text = Properties.Settings.Default.Doc_folder;
        }

        private void pan_Menu_exit_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            Application.Exit();
        }

        private bool SetupLabelWriterSelection()
        {
            int contadymoprinters = 0;
            foreach (IPrinter printer in Framework.GetPrinters())
                contadymoprinters++;

            if (contadymoprinters > 0) { return true; } else { return false; }
        }

        private void spedizioneToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_AssegnaSNProduzione uC_AssegnaSNProduzione = new UC_AssegnaSNProduzione();
            SplashDB.Close();
            uC_AssegnaSNProduzione.MdiParent = this;
            uC_AssegnaSNProduzione.Dock = DockStyle.Fill;
            Cursor.Current = Cursors.Default;
            uC_AssegnaSNProduzione.Show();
        }

        private void fasiDiAvanzamentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_Avanzamento uC_Avanzamento = new UC_Avanzamento();
            SplashDB.Close();
            uC_Avanzamento.MdiParent = this;
            uC_Avanzamento.Dock = DockStyle.Fill;
            uC_Avanzamento.Show();
        }

        private void prodottiAttivatiToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void schedeProdottiToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void codificaKitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_CodificaKit uC_CodificaKit = new UC_CodificaKit();
            SplashDB.Close();
            uC_CodificaKit.MdiParent = this;
            uC_CodificaKit.Dock = DockStyle.Fill;
            uC_CodificaKit.Show();

        }

        private void fWPalmariToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_FW_P uC_FW_P = new UC_FW_P();
            SplashDB.Close();
            uC_FW_P.MdiParent = this;
            uC_FW_P.Dock = DockStyle.Fill;
            uC_FW_P.Show();
        }

        private void fWRicevitoriToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_FW_R uC_FW_R = new UC_FW_R();
            SplashDB.Close();
            uC_FW_R.MdiParent = this;
            uC_FW_R.Dock = DockStyle.Fill;
            uC_FW_R.Show();
        }

        private void verificaFattibilitàToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void raccoltaDatasheetPerCommessaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            //UC_Pack_Kit uC_Pack_Kit = new UC_Pack_Kit();
            //SplashDB.Close();
            //uC_Pack_Kit.MdiParent = this;
            //uC_Pack_Kit.Dock = DockStyle.Fill;
            //uC_Pack_Kit.Show();
            UC_Pack_Commessa uC_Pack_Commessa = new UC_Pack_Commessa();
            SplashDB.Close();
            uC_Pack_Commessa.MdiParent = this;
            uC_Pack_Commessa.Dock = DockStyle.Fill;
            uC_Pack_Commessa.Show();
        }

        private void aaaaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_Pack_Kit uC_Pack_Kit = new UC_Pack_Kit();
            SplashDB.Close();
            uC_Pack_Kit.MdiParent = this;
            uC_Pack_Kit.Dock = DockStyle.Fill;
            uC_Pack_Kit.Show();
        }

        private void programmazioneSchedeSmartLineToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (glob_use_printer) { SetupLabelWriterSelection(true); }
            bool printerexist = false;
            printerexist = SetupLabelWriterSelection();
            if (!printerexist)
            {
                MetroFramework.MetroMessageBox.Show(this, "Warning", "Non esiste una stampante disponibile per l'applicazione su questa postazione!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            else
            {
                GVar.CloseSplash = false;
                Splash SplashDB = new Splash();
                SplashDB.Show();

                UC_Programmazione_Commessa uC_Programmazione_Commessa = new UC_Programmazione_Commessa();
                SplashDB.Close();
                uC_Programmazione_Commessa.MdiParent = this;
                uC_Programmazione_Commessa.Dock = DockStyle.Fill;
                uC_Programmazione_Commessa.Show();
            }
        }

        private void menu_sw_exit_Click(object sender, EventArgs e)
        {

        }

        private void classificazioneDocumentiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_Quality uC_Quality = new UC_Quality();
            SplashDB.Close();
            uC_Quality.MdiParent = this;
            uC_Quality.Dock = DockStyle.Fill;
            uC_Quality.Show();
        }

        private void interrogazioneDeviceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_Identifica uC_Identifica = new UC_Identifica();
            SplashDB.Close();
            uC_Identifica.MdiParent = this;
            uC_Identifica.Dock = DockStyle.Fill;
            uC_Identifica.Show();

        }

        private void ssswsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            Form1 form1 = new Form1();
            SplashDB.Close();
            form1.MdiParent = this;
            form1.Dock = DockStyle.Fill;
            form1.Show();
        }

        private void storiaNumeriDiSerieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_Identifica uC_Identifica = new UC_Identifica();
            SplashDB.Close();
            uC_Identifica.MdiParent = this;
            uC_Identifica.Dock = DockStyle.Fill;
            uC_Identifica.Show();
        }

        private void prodottiAttivatiToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_ReportProdotti uC_ReportProdotti = new UC_ReportProdotti();
            SplashDB.Close();
            uC_ReportProdotti.MdiParent = this;
            uC_ReportProdotti.Dock = DockStyle.Fill;
            uC_ReportProdotti.Show();
        }

        private void schedeProdottiToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_Schede uC_Schede = new UC_Schede();
            SplashDB.Close();
            uC_Schede.MdiParent = this;
            uC_Schede.Dock = DockStyle.Fill;
            uC_Schede.Show();
        }

        private void analisiDisponibilitàDiMagazzinoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_Fattibilita uC_Fattibilita = new UC_Fattibilita();
            SplashDB.Close();
            uC_Fattibilita.MdiParent = this;
            uC_Fattibilita.Dock = DockStyle.Fill;
            uC_Fattibilita.Show();
        }

        private void configuratoreUsciteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_ConfigurazioneOutput uC_ConfigurazioneOutput = new UC_ConfigurazioneOutput();
            SplashDB.Close();
            uC_ConfigurazioneOutput.MdiParent = this;
            uC_ConfigurazioneOutput.Dock = DockStyle.Fill;
            uC_ConfigurazioneOutput.Show();
        }

        private void analisiCostiDelVendutoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;

#if (DEBUG)
            {
                Splash SplashDB = new Splash();
                SplashDB.Show();

                UC_Amm_AnalisiCosti uC_Amm_AnalisiCosti = new UC_Amm_AnalisiCosti();
                SplashDB.Close();
                uC_Amm_AnalisiCosti.MdiParent = this;
                uC_Amm_AnalisiCosti.Dock = DockStyle.Fill;
                uC_Amm_AnalisiCosti.Show();
            }
#else
            UC_Password uC_Password = new UC_Password();
            if (uC_Password.ShowDialog() == DialogResult.Cancel)
                return;
            //if (pf.password == Properties.Settings.Default.pass)
            if (uC_Password.password == "Mattia12")
            {
                Splash SplashDB = new Splash();
                SplashDB.Show();

                UC_Amm_AnalisiCosti uC_Amm_AnalisiCosti = new UC_Amm_AnalisiCosti();
                SplashDB.Close();
                uC_Amm_AnalisiCosti.MdiParent = this;
                uC_Amm_AnalisiCosti.Dock = DockStyle.Fill;
                uC_Amm_AnalisiCosti.Show();
            }
#endif
        }

        private void lavorazioneProgettiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_Projects uC_Projects = new UC_Projects();
            SplashDB.Close();
            uC_Projects.MdiParent = this;
            uC_Projects.Dock = DockStyle.Fill;
            uC_Projects.Show();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_FW_K uC_FW_K = new UC_FW_K();
            SplashDB.Close();
            uC_FW_K.MdiParent = this;
            uC_FW_K.Dock = DockStyle.Fill;
            uC_FW_K.Show();
        }

        private void individuazioneEtichetteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_IndividuaLabel uC_IndividuaLabel = new UC_IndividuaLabel();
            SplashDB.Close();
            uC_IndividuaLabel.MdiParent = this;
            uC_IndividuaLabel.Dock = DockStyle.Fill;
            uC_IndividuaLabel.Show();
            this.ActiveControl = uC_IndividuaLabel;
        }

        private void oldVersionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_Spedizione uC_Spedizione = new UC_Spedizione();
            SplashDB.Close();
            uC_Spedizione.MdiParent = this;
            uC_Spedizione.Dock = DockStyle.Fill;
            Cursor.Current = Cursors.Default;
            uC_Spedizione.Show();
        }

        private void nuovaVersioneToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void programmaDaCommessaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (glob_use_printer) { SetupLabelWriterSelection(true); }
            bool printerexist = false;
            printerexist = SetupLabelWriterSelection();
            if (!printerexist)
            {
                MetroFramework.MetroMessageBox.Show(this, "Warning", "Non esiste una stampante disponibile per l'applicazione su questa postazione!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            else
            {
                GVar.CloseSplash = false;
                Splash SplashDB = new Splash();
                SplashDB.Show();

                UC_Programmazione_Commessa uC_Programmazione_Commessa = new UC_Programmazione_Commessa();
                SplashDB.Close();
                uC_Programmazione_Commessa.MdiParent = this;
                uC_Programmazione_Commessa.Dock = DockStyle.Fill;
                uC_Programmazione_Commessa.Show();
            }
        }

        private void riprogrammazionePlugClonazioneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (glob_use_printer) { SetupLabelWriterSelection(true); }
            bool printerexist = false;
            printerexist = SetupLabelWriterSelection();
            if (!printerexist)
            {
                MetroFramework.MetroMessageBox.Show(this, "Warning", "Non esiste una stampante disponibile per l'applicazione su questa postazione!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            else
            {
                GVar.CloseSplash = false;
                Splash SplashDB = new Splash();
                SplashDB.Show();

                UC_Programmazione_Clona uC_Programmazione_Clona = new UC_Programmazione_Clona();
                SplashDB.Close();
                uC_Programmazione_Clona.MdiParent = this;
                uC_Programmazione_Clona.Dock = DockStyle.Fill;
                uC_Programmazione_Clona.Show();
            }
        }

        private void tracciaiblitàDeiNumeriDiSerieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_Identifica uC_Identifica = new UC_Identifica();
            SplashDB.Close();
            uC_Identifica.MdiParent = this;
            uC_Identifica.Dock = DockStyle.Fill;
            uC_Identifica.Show();
        }

        private void tracciaturaProdottiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_SL_History uC_SL_History = new UC_SL_History();
            SplashDB.Close();
            uC_SL_History.MdiParent = this;
            uC_SL_History.Dock = DockStyle.Fill;
            uC_SL_History.Show();
        }

        private void bouquetFirmwarePerClienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;

#if (DEBUG)
            {
                Splash SplashDB = new Splash();
                SplashDB.Show();

                UC_SL_FirmwareClienti uC_SL_FirmwareClienti = new UC_SL_FirmwareClienti();
                SplashDB.Close();
                uC_SL_FirmwareClienti.MdiParent = this;
                uC_SL_FirmwareClienti.Dock = DockStyle.Fill;
                uC_SL_FirmwareClienti.Show();
            }
#else
            UC_Password uC_Password = new UC_Password();
            if (uC_Password.ShowDialog() == DialogResult.Cancel)
                return;
            //if (pf.password == Properties.Settings.Default.pass)
            if (uC_Password.password == "MatriX")
            {
                Splash SplashDB = new Splash();
                SplashDB.Show();

                UC_SL_FirmwareClienti uC_SL_FirmwareClienti = new UC_SL_FirmwareClienti();
                SplashDB.Close();
                uC_SL_FirmwareClienti.MdiParent = this;
                uC_SL_FirmwareClienti.Dock = DockStyle.Fill;
                uC_SL_FirmwareClienti.Show();
            }
#endif
        }

        private void visioneSchedeDiLavorazioneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_SchedeLavorazione uC_SchedeLavorazione = new UC_SchedeLavorazione();
            SplashDB.Close();
            uC_SchedeLavorazione.MdiParent = this;
            uC_SchedeLavorazione.Dock = DockStyle.Fill;
            uC_SchedeLavorazione.Show();
        }

        private void compilazioneNCRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_Ncr uC_Ncr = new UC_Ncr();
            SplashDB.Close();
            uC_Ncr.MdiParent = this;
            uC_Ncr.Dock = DockStyle.Fill;
            uC_Ncr.Show();
        }

        private void stampaEtichetteZebraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GVar.CloseSplash = false;
            Splash SplashDB = new Splash();
            SplashDB.Show();

            UC_PrintLabel_Zebra uC_PrintLabel_Zebra = new UC_PrintLabel_Zebra();
            SplashDB.Close();
            uC_PrintLabel_Zebra.MdiParent = this;
            uC_PrintLabel_Zebra.Dock = DockStyle.Fill;
            uC_PrintLabel_Zebra.Show();
        }

        private void programmazionePerProgettazioneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (glob_use_printer) { SetupLabelWriterSelection(true); }
            bool printerexist = false;
            printerexist = SetupLabelWriterSelection();
            if (!printerexist)
            {
                MetroFramework.MetroMessageBox.Show(this, "Warning", "Non esiste una stampante disponibile per l'applicazione su questa postazione!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            else
            {
                GVar.CloseSplash = false;
                Splash SplashDB = new Splash();
                SplashDB.Show();

                UC_Programmazione_Progettazione uC_Programmazione_Progettazione = new UC_Programmazione_Progettazione();
                SplashDB.Close();
                uC_Programmazione_Progettazione.MdiParent = this;
                uC_Programmazione_Progettazione.Dock = DockStyle.Fill;
                uC_Programmazione_Progettazione.Show();
            }

        }
    }
}
