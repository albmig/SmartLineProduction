﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;


namespace SmartLineProduction
{
    public partial class UC_Amm_AnalisiCosti : MetroFramework.Forms.MetroForm
    {
        string filtroclienti = "";
        string filtroarticoli = "";
        string filtrocosti = "";
        decimal tot_costi = 0;
        decimal tot_ricavi = 0;
        decimal tot_diff = 0;

        public UC_Amm_AnalisiCosti()
        {
            InitializeComponent();
        }

        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UC_Amm_AnalisiCosti_Load(object sender, EventArgs e)
        {
            //// TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_Expl_Sale'. È possibile spostarla o rimuoverla se necessario.
            //this.sF_Expl_SaleTableAdapter.Fill(this.ds_SL.SF_Expl_Sale);
            //// TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_Expl_Arta'. È possibile spostarla o rimuoverla se necessario.
            //this.sF_Expl_ArtaTableAdapter.Fill(this.ds_SL.SF_Expl_Arta);
            //// TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_Expl_Dbar'. È possibile spostarla o rimuoverla se necessario.
            //this.sF_Expl_DbarTableAdapter.Fill(this.ds_SL.SF_Expl_Dbar);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.ACV_ClienteArticolo'. È possibile spostarla o rimuoverla se necessario.
            this.aCV_ClienteArticolo.FillBy_ClienteArticolo(this.ds_SL.ACV_ClienteArticolo);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.ACV_Cliente'. È possibile spostarla o rimuoverla se necessario.
            this.aCV_Cliente.FillBy_Cliente(this.ds_SL.ACV_Cliente);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.Analisi_Costi_Venduto'. È possibile spostarla o rimuoverla se necessario.
            this.analisi_Costi_VendutoTableAdapter.Fill(this.ds_SL.Analisi_Costi_Venduto);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.Analisi_Costi_Distinte'. È possibile spostarla o rimuoverla se necessario.
            this.analisi_Costi_DistinteTableAdapter.Fill(this.ds_SL.Analisi_Costi_Distinte);

            AzzeraCosti();

            SettingForm();
        }

        private void btn_AzzeraFiltroClienti_Click(object sender, EventArgs e)
        {
            cb_elencoClienti.SelectedIndex = -1;
            cb_elencoarticoli.SelectedIndex = -1;
            filtroclienti = "";
            filtroarticoli = "";
            FiltraCommesse();
        }

        private void btn_AzzeraFiltroArticoli_Click(object sender, EventArgs e)
        {
            cb_elencoarticoli.SelectedIndex = -1;
            filtroarticoli = "";
            FiltraCommesse();
        }

        private void cb_elencoClienti_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_elencoClienti.SelectedIndex >= 0)
            {
                filtroclienti = "Cliente = " + "'" + cb_elencoClienti.Text.ToString() + "'";
                FiltraCommesse();
                cb_elencoarticoli.SelectedIndex = -1;
            }
        }

        private void cb_elencoarticoli_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_elencoarticoli.SelectedIndex >= 0)
            {
                filtroarticoli = "ARTICOLO = " + "'" + cb_elencoarticoli.Text.ToString() + "'";
                FiltraCommesse();
            }
        }

        private void gv_Venduto_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.Value == null) { return; }
            if ((gv_Venduto.Columns[e.ColumnIndex].Name == "gv_Venduto_Margine") && (e.Value != null))
            {
                DataGridViewCell cell = this.gv_Venduto.Rows[e.RowIndex].Cells[e.ColumnIndex];
                DataGridViewRow gridRow = gv_Venduto.Rows[e.RowIndex];
                decimal margin = Convert.ToDecimal(gridRow.Cells["gv_Venduto_Margine"].Value);
                if (margin > 0)
                {
                    e.CellStyle.BackColor = Color.LightGreen;
                }
                if (margin < 0)
                {
                    e.CellStyle.BackColor = Color.Red;
                }
            }
        }

        // Funzioni
        private void FiltraCommesse()
        {
            Cursor.Current = Cursors.WaitCursor;

            string filtrocosti = "";
            if (filtroclienti != "")
            {
                filtrocosti = filtroclienti;
            }
            if (filtroarticoli != "")
            {
                if (filtroclienti != "") { filtrocosti = filtrocosti + " AND " + filtroarticoli; } else { filtrocosti = filtroarticoli; }
            }

            if ((filtroclienti == "") && (filtroarticoli == "")) { filtrocosti = ""; }

            analisiCostiVendutoBindingSource.Filter = filtrocosti;
            if (filtroclienti != "")
            {
                aCVClienteArticoloBindingSource.Filter = filtroclienti;
            }

            //Eseguo le somme
            tot_ricavi = Convert.ToDecimal(ds_SL.Analisi_Costi_Venduto.Compute("SUM(Tot_Ricavi)", filtrocosti));
            tot_costi = Convert.ToDecimal(ds_SL.Analisi_Costi_Venduto.Compute("SUM(Tot_Costi)", filtrocosti));
            tot_diff = tot_ricavi - tot_costi;
            lab_tot_costi.Text = tot_costi.ToString("C2");
            lab_tot_ricavi.Text = tot_ricavi.ToString("C2");
            lab_tot_diff.Text = tot_diff.ToString("C2");
            if (tot_diff >= 0)
            {
                lab_tot_diff.Style = MetroFramework.MetroColorStyle.Green;
            }
            else
            {
                lab_tot_diff.Style = MetroFramework.MetroColorStyle.Red;
            }
            Cursor.Current = Cursors.Default;
        }

        private void SettingForm()
        {
            cb_elencoClienti.SelectedIndex = -1;
            cb_elencoarticoli.SelectedIndex = -1;
            FiltraCommesse();

            gv_Venduto.Columns["gv_Venduto_QtaTot"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            gv_Venduto.Columns["gv_Venduto_Prezzo"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            gv_Venduto.Columns["gv_Venduto_TotRicavi"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            gv_Venduto.Columns["gv_Venduto_TotCosti"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            gv_Venduto.Columns["gv_Venduto_CostoMat"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            gv_Venduto.Columns["gv_Venduto_CostoProd"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            gv_Venduto.Columns["gv_Venduto_CostoMan"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            gv_Venduto.Columns["gv_Venduto_CostoLav"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            gv_Venduto.Columns["gv_Venduto_Margine"].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
        }

        private void AzzeraCosti()
        {
            return;
            DataView appoggio_distinte_view = new DataView(this.ds_SL.Analisi_Costi_Distinte);
            DataView real_distinte_view = this.ds_SL.Analisi_Costi_Distinte.DefaultView;

            foreach (DataRowView real_dv in real_distinte_view)
            {
                //decimal costomatprima = 0;
                //decimal costouomo = 0;
                //decimal costolavest = 0;

                DataRow row = real_dv.Row;
                //try
                //{
                //    costomatprima = Convert.ToDecimal(row["Costo_Materia_Prima"]);
                //    costouomo = Convert.ToDecimal(row["Costo_Uomo"]);
                //}
                //catch (Exception e)
                //{
                //    costomatprima = 0;
                //    costouomo = 0;
                //}

                long idpadre = Convert.ToUInt32(row["id_padre"]);
                long idfiglio = Convert.ToUInt32(row["id_figlio"]);

                //Filtra dataview di appoggio
                string filtro = "id_figlio = " + idpadre;
                appoggio_distinte_view.RowFilter = filtro;

                foreach (DataRowView appoggio_dv in appoggio_distinte_view)
                {
                    appoggio_dv["Costo_Materia_Prima"] = 0;
                    appoggio_dv["Costo_Uomo"] = 0;
                    appoggio_dv["Costo_Lav_Est"] = 0;
                    appoggio_dv["Costo_Unit"] = 0;
                    appoggio_dv["Costo_Tot"] = 0;
                }
            }
        }

        private void tree_Distinta_CustomDrawNodeCell(object sender, DevExpress.XtraTreeList.CustomDrawNodeCellEventArgs e)
        {
            return;
            if (e.Node.HasChildren)
            {
                if ((e.Column.FieldName == "Costo_Unit") ||
                    (e.Column.FieldName == "Costo_Tot") ||
                    (e.Column.FieldName == "Costo_Materia_Prima") ||
                    (e.Column.FieldName == "Costo_Uomo") ||
                    (e.Column.FieldName == "Costo_Lav_Est"))
                {
                    e.CellText = "";
                }
            }
        }

        private void analisiCostiVendutoBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            tree_Distinta.ExpandAll();
        }

        private void gv_Venduto_SelectionChanged(object sender, EventArgs e)
        {
            tree_Distinta.ExpandAll();
        }
    }
}