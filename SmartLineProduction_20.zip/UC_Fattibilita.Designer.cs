﻿namespace SmartLineProduction
{
    partial class UC_Fattibilita
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Fattibilita));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.layout_orizz_menu = new System.Windows.Forms.TableLayoutPanel();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.panel_fattibilita = new MetroFramework.Controls.MetroPanel();
            this.layout_Schede = new System.Windows.Forms.TableLayoutPanel();
            this.panel_grid_Articoli = new MetroFramework.Controls.MetroPanel();
            this.gv_Articoli = new MetroFramework.Controls.MetroGrid();
            this.panel_search = new MetroFramework.Controls.MetroPanel();
            this.tb_search = new MetroFramework.Controls.MetroTextBox();
            this.panel_des_art_Kit = new MetroFramework.Controls.MetroPanel();
            this.Des_2 = new MetroFramework.Controls.MetroLabel();
            this.lab_des1_articolo = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.panel_qta = new MetroFramework.Controls.MetroPanel();
            this.btn_Calcola = new MetroFramework.Controls.MetroButton();
            this.tb_qta = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.gv_Explode = new System.Windows.Forms.DataGridView();
            this.Magazzino = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel_Depositi = new MetroFramework.Controls.MetroPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.gv_Depositi = new System.Windows.Forms.DataGridView();
            this.InclusoCalcoli = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.TipoMagazzino = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.layout_view = new System.Windows.Forms.TableLayoutPanel();
            this.ds_SL = new SmartLineProduction.ds_SL();
            this.layout_orizz_menu.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            this.panel_fattibilita.SuspendLayout();
            this.layout_Schede.SuspendLayout();
            this.panel_grid_Articoli.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Articoli)).BeginInit();
            this.panel_search.SuspendLayout();
            this.panel_des_art_Kit.SuspendLayout();
            this.panel_qta.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Explode)).BeginInit();
            this.panel_Depositi.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Depositi)).BeginInit();
            this.layout_view.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).BeginInit();
            this.SuspendLayout();
            // 
            // layout_orizz_menu
            // 
            this.layout_orizz_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.ColumnCount = 10;
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_exit, 10, 0);
            this.layout_orizz_menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_orizz_menu.Location = new System.Drawing.Point(20, 30);
            this.layout_orizz_menu.Name = "layout_orizz_menu";
            this.layout_orizz_menu.RowCount = 1;
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.layout_orizz_menu.Size = new System.Drawing.Size(960, 25);
            this.layout_orizz_menu.TabIndex = 125;
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Gainsboro;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(885, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(75, 24);
            this.pan_Menu_exit.TabIndex = 82;
            this.pan_Menu_exit.Text = "menuStrip1";
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            this.menu_sw_exit.Click += new System.EventHandler(this.menu_sw_exit_Click);
            // 
            // panel_fattibilita
            // 
            this.panel_fattibilita.Controls.Add(this.layout_Schede);
            this.panel_fattibilita.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_fattibilita.HorizontalScrollbarBarColor = true;
            this.panel_fattibilita.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_fattibilita.HorizontalScrollbarSize = 10;
            this.panel_fattibilita.Location = new System.Drawing.Point(20, 55);
            this.panel_fattibilita.Name = "panel_fattibilita";
            this.panel_fattibilita.Size = new System.Drawing.Size(960, 425);
            this.panel_fattibilita.TabIndex = 126;
            this.panel_fattibilita.VerticalScrollbarBarColor = true;
            this.panel_fattibilita.VerticalScrollbarHighlightOnWheel = false;
            this.panel_fattibilita.VerticalScrollbarSize = 10;
            // 
            // layout_Schede
            // 
            this.layout_Schede.ColumnCount = 3;
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.layout_Schede.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.layout_Schede.Controls.Add(this.panel_grid_Articoli, 0, 0);
            this.layout_Schede.Controls.Add(this.panel_des_art_Kit, 1, 0);
            this.layout_Schede.Controls.Add(this.panel_qta, 1, 1);
            this.layout_Schede.Controls.Add(this.panel_Depositi, 1, 1);
            this.layout_Schede.Controls.Add(this.layout_view, 1, 2);
            this.layout_Schede.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Schede.Location = new System.Drawing.Point(0, 0);
            this.layout_Schede.Name = "layout_Schede";
            this.layout_Schede.RowCount = 3;
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_Schede.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_Schede.Size = new System.Drawing.Size(960, 425);
            this.layout_Schede.TabIndex = 123;
            // 
            // panel_grid_Articoli
            // 
            this.panel_grid_Articoli.Controls.Add(this.gv_Articoli);
            this.panel_grid_Articoli.Controls.Add(this.panel_search);
            this.panel_grid_Articoli.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_grid_Articoli.HorizontalScrollbarBarColor = true;
            this.panel_grid_Articoli.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_grid_Articoli.HorizontalScrollbarSize = 10;
            this.panel_grid_Articoli.Location = new System.Drawing.Point(3, 3);
            this.panel_grid_Articoli.Name = "panel_grid_Articoli";
            this.layout_Schede.SetRowSpan(this.panel_grid_Articoli, 3);
            this.panel_grid_Articoli.Size = new System.Drawing.Size(144, 544);
            this.panel_grid_Articoli.TabIndex = 83;
            this.panel_grid_Articoli.VerticalScrollbarBarColor = true;
            this.panel_grid_Articoli.VerticalScrollbarHighlightOnWheel = false;
            this.panel_grid_Articoli.VerticalScrollbarSize = 10;
            // 
            // gv_Articoli
            // 
            this.gv_Articoli.AllowUserToAddRows = false;
            this.gv_Articoli.AllowUserToDeleteRows = false;
            this.gv_Articoli.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Gainsboro;
            this.gv_Articoli.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.gv_Articoli.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Articoli.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Articoli.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.gv_Articoli.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Articoli.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gv_Articoli.ColumnHeadersHeight = 40;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Articoli.DefaultCellStyle = dataGridViewCellStyle3;
            this.gv_Articoli.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Articoli.EnableHeadersVisualStyles = false;
            this.gv_Articoli.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.gv_Articoli.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gv_Articoli.Location = new System.Drawing.Point(0, 30);
            this.gv_Articoli.MultiSelect = false;
            this.gv_Articoli.Name = "gv_Articoli";
            this.gv_Articoli.ReadOnly = true;
            this.gv_Articoli.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Articoli.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.gv_Articoli.RowHeadersVisible = false;
            this.gv_Articoli.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Articoli.RowTemplate.Height = 30;
            this.gv_Articoli.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Articoli.Size = new System.Drawing.Size(144, 514);
            this.gv_Articoli.Style = MetroFramework.MetroColorStyle.Red;
            this.gv_Articoli.TabIndex = 0;
            this.gv_Articoli.UseStyleColors = true;
            // 
            // panel_search
            // 
            this.panel_search.BackColor = System.Drawing.Color.Transparent;
            this.panel_search.Controls.Add(this.tb_search);
            this.panel_search.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_search.HorizontalScrollbarBarColor = true;
            this.panel_search.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_search.HorizontalScrollbarSize = 10;
            this.panel_search.Location = new System.Drawing.Point(0, 0);
            this.panel_search.Name = "panel_search";
            this.panel_search.Size = new System.Drawing.Size(144, 30);
            this.panel_search.TabIndex = 3;
            this.panel_search.UseCustomBackColor = true;
            this.panel_search.VerticalScrollbarBarColor = true;
            this.panel_search.VerticalScrollbarHighlightOnWheel = false;
            this.panel_search.VerticalScrollbarSize = 10;
            // 
            // tb_search
            // 
            this.tb_search.BackColor = System.Drawing.Color.LightYellow;
            // 
            // 
            // 
            this.tb_search.CustomButton.Image = null;
            this.tb_search.CustomButton.Location = new System.Drawing.Point(122, 1);
            this.tb_search.CustomButton.Name = "";
            this.tb_search.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_search.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_search.CustomButton.TabIndex = 1;
            this.tb_search.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_search.CustomButton.UseSelectable = true;
            this.tb_search.CustomButton.Visible = false;
            this.tb_search.Dock = System.Windows.Forms.DockStyle.Top;
            this.tb_search.Icon = global::SmartLineProduction.Properties.Resources.Lente;
            this.tb_search.IconRight = true;
            this.tb_search.Lines = new string[] {
        "metroTextBox1"};
            this.tb_search.Location = new System.Drawing.Point(0, 0);
            this.tb_search.MaxLength = 32767;
            this.tb_search.Name = "tb_search";
            this.tb_search.PasswordChar = '\0';
            this.tb_search.PromptText = "ricerca";
            this.tb_search.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_search.SelectedText = "";
            this.tb_search.SelectionLength = 0;
            this.tb_search.SelectionStart = 0;
            this.tb_search.ShortcutsEnabled = true;
            this.tb_search.Size = new System.Drawing.Size(144, 23);
            this.tb_search.TabIndex = 2;
            this.tb_search.Text = "metroTextBox1";
            this.tb_search.UseCustomBackColor = true;
            this.tb_search.UseSelectable = true;
            this.tb_search.WaterMark = "ricerca";
            this.tb_search.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_search.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.tb_search.TextChanged += new System.EventHandler(this.tb_search_TextChanged);
            // 
            // panel_des_art_Kit
            // 
            this.layout_Schede.SetColumnSpan(this.panel_des_art_Kit, 2);
            this.panel_des_art_Kit.Controls.Add(this.Des_2);
            this.panel_des_art_Kit.Controls.Add(this.lab_des1_articolo);
            this.panel_des_art_Kit.Controls.Add(this.metroLabel1);
            this.panel_des_art_Kit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_des_art_Kit.HorizontalScrollbarBarColor = true;
            this.panel_des_art_Kit.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Kit.HorizontalScrollbarSize = 10;
            this.panel_des_art_Kit.Location = new System.Drawing.Point(153, 3);
            this.panel_des_art_Kit.Name = "panel_des_art_Kit";
            this.panel_des_art_Kit.Size = new System.Drawing.Size(804, 44);
            this.panel_des_art_Kit.TabIndex = 1;
            this.panel_des_art_Kit.VerticalScrollbarBarColor = true;
            this.panel_des_art_Kit.VerticalScrollbarHighlightOnWheel = false;
            this.panel_des_art_Kit.VerticalScrollbarSize = 10;
            // 
            // Des_2
            // 
            this.Des_2.AutoSize = true;
            this.Des_2.Location = new System.Drawing.Point(124, 19);
            this.Des_2.Name = "Des_2";
            this.Des_2.Size = new System.Drawing.Size(41, 19);
            this.Des_2.Style = MetroFramework.MetroColorStyle.Red;
            this.Des_2.TabIndex = 4;
            this.Des_2.Text = "Des_1";
            this.Des_2.UseStyleColors = true;
            // 
            // lab_des1_articolo
            // 
            this.lab_des1_articolo.AutoSize = true;
            this.lab_des1_articolo.Location = new System.Drawing.Point(124, 0);
            this.lab_des1_articolo.Name = "lab_des1_articolo";
            this.lab_des1_articolo.Size = new System.Drawing.Size(41, 19);
            this.lab_des1_articolo.Style = MetroFramework.MetroColorStyle.Red;
            this.lab_des1_articolo.TabIndex = 3;
            this.lab_des1_articolo.Text = "Des_1";
            this.lab_des1_articolo.UseStyleColors = true;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(3, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(75, 19);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "Descrizione";
            // 
            // panel_qta
            // 
            this.panel_qta.Controls.Add(this.btn_Calcola);
            this.panel_qta.Controls.Add(this.tb_qta);
            this.panel_qta.Controls.Add(this.metroLabel2);
            this.panel_qta.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_qta.HorizontalScrollbarBarColor = true;
            this.panel_qta.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_qta.HorizontalScrollbarSize = 10;
            this.panel_qta.Location = new System.Drawing.Point(558, 53);
            this.panel_qta.Name = "panel_qta";
            this.panel_qta.Size = new System.Drawing.Size(399, 150);
            this.panel_qta.TabIndex = 84;
            this.panel_qta.VerticalScrollbarBarColor = true;
            this.panel_qta.VerticalScrollbarHighlightOnWheel = false;
            this.panel_qta.VerticalScrollbarSize = 10;
            // 
            // btn_Calcola
            // 
            this.btn_Calcola.Location = new System.Drawing.Point(205, 69);
            this.btn_Calcola.Name = "btn_Calcola";
            this.btn_Calcola.Size = new System.Drawing.Size(75, 23);
            this.btn_Calcola.TabIndex = 5;
            this.btn_Calcola.Text = "Calcola";
            this.btn_Calcola.UseSelectable = true;
            this.btn_Calcola.Click += new System.EventHandler(this.btn_Calcola_Click);
            // 
            // tb_qta
            // 
            this.tb_qta.BackColor = System.Drawing.Color.LightYellow;
            // 
            // 
            // 
            this.tb_qta.CustomButton.Image = null;
            this.tb_qta.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.tb_qta.CustomButton.Name = "";
            this.tb_qta.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.tb_qta.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.tb_qta.CustomButton.TabIndex = 1;
            this.tb_qta.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tb_qta.CustomButton.UseSelectable = true;
            this.tb_qta.CustomButton.Visible = false;
            this.tb_qta.Lines = new string[] {
        "tb_qta"};
            this.tb_qta.Location = new System.Drawing.Point(124, 69);
            this.tb_qta.MaxLength = 32767;
            this.tb_qta.Name = "tb_qta";
            this.tb_qta.PasswordChar = '\0';
            this.tb_qta.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tb_qta.SelectedText = "";
            this.tb_qta.SelectionLength = 0;
            this.tb_qta.SelectionStart = 0;
            this.tb_qta.ShortcutsEnabled = true;
            this.tb_qta.Size = new System.Drawing.Size(75, 23);
            this.tb_qta.TabIndex = 4;
            this.tb_qta.Text = "tb_qta";
            this.tb_qta.UseCustomBackColor = true;
            this.tb_qta.UseSelectable = true;
            this.tb_qta.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.tb_qta.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(3, 69);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(112, 19);
            this.metroLabel2.TabIndex = 3;
            this.metroLabel2.Text = "Q.tà da realizzare";
            // 
            // gv_Explode
            // 
            this.gv_Explode.AllowUserToAddRows = false;
            this.gv_Explode.AllowUserToDeleteRows = false;
            this.gv_Explode.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gv_Explode.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Magazzino});
            this.gv_Explode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Explode.Location = new System.Drawing.Point(3, 3);
            this.gv_Explode.Name = "gv_Explode";
            this.gv_Explode.ReadOnly = true;
            this.gv_Explode.RowHeadersVisible = false;
            this.gv_Explode.Size = new System.Drawing.Size(798, 191);
            this.gv_Explode.TabIndex = 85;
            this.gv_Explode.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gv_Explode_CellContentClick);
            // 
            // Magazzino
            // 
            this.Magazzino.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Magazzino.DataPropertyName = "Magazzino";
            this.Magazzino.HeaderText = "Magazzino";
            this.Magazzino.Name = "Magazzino";
            this.Magazzino.ReadOnly = true;
            // 
            // panel_Depositi
            // 
            this.panel_Depositi.Controls.Add(this.tableLayoutPanel1);
            this.panel_Depositi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Depositi.HorizontalScrollbarBarColor = true;
            this.panel_Depositi.HorizontalScrollbarHighlightOnWheel = false;
            this.panel_Depositi.HorizontalScrollbarSize = 10;
            this.panel_Depositi.Location = new System.Drawing.Point(153, 53);
            this.panel_Depositi.Name = "panel_Depositi";
            this.panel_Depositi.Size = new System.Drawing.Size(399, 150);
            this.panel_Depositi.TabIndex = 86;
            this.panel_Depositi.VerticalScrollbarBarColor = true;
            this.panel_Depositi.VerticalScrollbarHighlightOnWheel = false;
            this.panel_Depositi.VerticalScrollbarSize = 10;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.metroLabel3, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.gv_Depositi, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(399, 150);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(3, 0);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(189, 19);
            this.metroLabel3.TabIndex = 4;
            this.metroLabel3.Text = "Depositi da prendere in esame";
            // 
            // gv_Depositi
            // 
            this.gv_Depositi.AllowUserToAddRows = false;
            this.gv_Depositi.AllowUserToDeleteRows = false;
            this.gv_Depositi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gv_Depositi.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.InclusoCalcoli,
            this.TipoMagazzino});
            this.gv_Depositi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gv_Depositi.Location = new System.Drawing.Point(3, 23);
            this.gv_Depositi.MultiSelect = false;
            this.gv_Depositi.Name = "gv_Depositi";
            this.gv_Depositi.RowHeadersVisible = false;
            this.gv_Depositi.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Depositi.Size = new System.Drawing.Size(393, 124);
            this.gv_Depositi.TabIndex = 5;
            // 
            // InclusoCalcoli
            // 
            this.InclusoCalcoli.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.InclusoCalcoli.DataPropertyName = "Incluso";
            this.InclusoCalcoli.FalseValue = "0";
            this.InclusoCalcoli.HeaderText = "Incluso";
            this.InclusoCalcoli.Name = "InclusoCalcoli";
            this.InclusoCalcoli.ReadOnly = true;
            this.InclusoCalcoli.TrueValue = "1";
            this.InclusoCalcoli.Width = 47;
            // 
            // TipoMagazzino
            // 
            this.TipoMagazzino.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.TipoMagazzino.DataPropertyName = "TipoMagazzino";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.TipoMagazzino.DefaultCellStyle = dataGridViewCellStyle5;
            this.TipoMagazzino.HeaderText = "Tipo di Magazzino";
            this.TipoMagazzino.Name = "TipoMagazzino";
            this.TipoMagazzino.Width = 108;
            // 
            // layout_view
            // 
            this.layout_view.ColumnCount = 1;
            this.layout_Schede.SetColumnSpan(this.layout_view, 2);
            this.layout_view.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.layout_view.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.layout_view.Controls.Add(this.gv_Explode, 0, 0);
            this.layout_view.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_view.Location = new System.Drawing.Point(153, 209);
            this.layout_view.Name = "layout_view";
            this.layout_view.RowCount = 2;
            this.layout_view.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 58.33333F));
            this.layout_view.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 41.66667F));
            this.layout_view.Size = new System.Drawing.Size(804, 338);
            this.layout_view.TabIndex = 87;
            // 
            // ds_SL
            // 
            this.ds_SL.DataSetName = "ds_SL";
            this.ds_SL.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // UC_Fattibilita
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 500);
            this.ControlBox = false;
            this.Controls.Add(this.panel_fattibilita);
            this.Controls.Add(this.layout_orizz_menu);
            this.DisplayHeader = false;
            this.Name = "UC_Fattibilita";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.UC_Fattibilita_Load);
            this.layout_orizz_menu.ResumeLayout(false);
            this.layout_orizz_menu.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            this.panel_fattibilita.ResumeLayout(false);
            this.layout_Schede.ResumeLayout(false);
            this.panel_grid_Articoli.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gv_Articoli)).EndInit();
            this.panel_search.ResumeLayout(false);
            this.panel_des_art_Kit.ResumeLayout(false);
            this.panel_des_art_Kit.PerformLayout();
            this.panel_qta.ResumeLayout(false);
            this.panel_qta.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Explode)).EndInit();
            this.panel_Depositi.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Depositi)).EndInit();
            this.layout_view.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ds_SL)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel layout_orizz_menu;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
        private MetroFramework.Controls.MetroPanel panel_fattibilita;
        private System.Windows.Forms.TableLayoutPanel layout_Schede;
        private MetroFramework.Controls.MetroPanel panel_grid_Articoli;
        private MetroFramework.Controls.MetroGrid gv_Articoli;
        private MetroFramework.Controls.MetroPanel panel_search;
        private MetroFramework.Controls.MetroTextBox tb_search;
        private MetroFramework.Controls.MetroPanel panel_des_art_Kit;
        private MetroFramework.Controls.MetroLabel lab_des1_articolo;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private ds_SL ds_SL;
        private MetroFramework.Controls.MetroLabel Des_2;
        private MetroFramework.Controls.MetroPanel panel_qta;
        private MetroFramework.Controls.MetroTextBox tb_qta;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroButton btn_Calcola;
        private System.Windows.Forms.DataGridView gv_Explode;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloCompostoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn articoloComponenteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Magazzino;
        private MetroFramework.Controls.MetroPanel panel_Depositi;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private System.Windows.Forms.DataGridView gv_Depositi;
        private System.Windows.Forms.DataGridViewCheckBoxColumn InclusoCalcoli;
        private System.Windows.Forms.DataGridViewTextBoxColumn TipoMagazzino;
        private System.Windows.Forms.TableLayoutPanel layout_view;
    }
}