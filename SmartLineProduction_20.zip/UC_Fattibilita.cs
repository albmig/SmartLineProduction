﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using Syncfusion.Windows.Forms.Grid.Grouping;

namespace SmartLineProduction
{
    public partial class UC_Fattibilita : MetroFramework.Forms.MetroForm
    {
        public UC_Fattibilita()
        {
            InitializeComponent();
        }

        private void menu_sw_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UC_Fattibilita_Load(object sender, EventArgs e)
        {
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_Depositi'. È possibile spostarla o rimuoverla se necessario.
            this.sF_DepositiTableAdapter.Fill(this.ds_SL.SF_Depositi);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL1.SF_Fattibile_DB_level_1'. È possibile spostarla o rimuoverla se necessario.
            this.sF_Fattibile_DB_level_1TableAdapter.Fill(this.ds_SL.SF_Fattibile_DB_level_1);
            // TODO: questa riga di codice carica i dati nella tabella 'ds_SL.SF_Fatttibile_Articolo'. È possibile spostarla o rimuoverla se necessario.
            this.sF_Fattibile_ArticoloTableAdapter.Fill(this.ds_SL.SF_Fattibile_Articolo);

            PulisciForm();
        }

        private void tb_search_TextChanged(object sender, EventArgs e)
        {
            FiltraArticoli();
            tb_search.Focus();
        }

        private void FiltraArticoli()
        {
            string filtro = "";

            //Aggiungo filtro su tb_search
            if (tb_search.Text != "")
            {
                filtro = string.Format("Articolo LIKE '%{0}%'", tb_search.Text);
            }
            this.sFFattibileArticoloBindingSource.Filter = filtro;
        }

        private void PulisciForm()
        {
            tb_search.Text = "";
            tb_qta.Text = "0";
        }

        private void btn_Calcola_Click(object sender, EventArgs e)
        {
            ds_SL.dt_Tmp_Fattibile_Explode.Clear();

            DataRowView drview = (DataRowView)sFFattibileArticoloBindingSource.Current;
            if (drview == null) { return; }

            string filtro = "ArticoloComposto = " + "'" + drview["Articolo"].ToString().Trim() + "'";
            DataView dvDBread = new DataView(ds_SL.SF_Fattibile_DB_level_1);
            dvDBread.RowFilter = filtro;

//            foreach (DataRow rw in ds_SL.SF_Fattibile_DB_level_1.Rows)
              foreach (DataRowView rw in dvDBread)
                {
                    var newrow = ds_SL.dt_Tmp_Fattibile_Explode.NewRow();

                newrow["ArticoloLista"] = rw["ArticoloComponente"].ToString(); // serve x raggruppamento

                newrow["ArticoloComposto"] = rw["ArticoloComposto"].ToString();
                newrow["ArticoloComponente"] = rw["ArticoloComponente"].ToString();
                newrow["Descrizione"] = rw["Descrizione"].ToString();
                newrow["DescrizioneEstesa"] = rw["DescrizioneEstesa"].ToString();
                newrow["DaEsplodere"] = rw["DaEsplodere"].ToString();
                newrow["GiacenzaAttuale"] = Convert.ToInt16(rw["GiacenzaAttuale"]);
                newrow["DisponibilitaFutura"] = Convert.ToInt16(rw["DisponibilitaFutura"]);
                newrow["ImpegnatoClienti"] = Convert.ToInt16(rw["ImpegnatoClienti"]);
                newrow["OrdinatoFornitori"] = Convert.ToInt16(rw["OrdinatoFornitori"]);
                newrow["QtaInProduzione"] = Convert.ToInt16(rw["QtaInProduzione"]);
                newrow["Magazzino"] = rw["Magazzino"].ToString();

                ds_SL.dt_Tmp_Fattibile_Explode.Rows.Add(newrow);
            }

            gv_Explode.DataSource = ds_SL.dt_Tmp_Fattibile_Explode;


        }

        private void gv_Explode_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
