﻿namespace SmartLineProduction
{
    partial class MainMenu
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenu));
            this.layout_Menu = new System.Windows.Forms.TableLayoutPanel();
            this.layout_orizz_menu = new System.Windows.Forms.TableLayoutPanel();
            this.MainMenuStrip = new System.Windows.Forms.MenuStrip();
            this.programmazioneSchedeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spedizioneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fasiDiAvanzamentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spedizioneToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.gestioneDelFirmwareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classicLineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.smartLineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fWPalmariToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fWRicevitoriToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prodottiAttivatiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.schedeProdottiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.raccoltaDocumentiKitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.codificaKitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.verificaFattibilitàToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pan_Menu_exit = new System.Windows.Forms.MenuStrip();
            this.menu_sw_exit = new System.Windows.Forms.ToolStripMenuItem();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.lab_resources_path = new MetroFramework.Controls.MetroLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.miniToolStrip = new System.Windows.Forms.MenuStrip();
            this.layout_Menu.SuspendLayout();
            this.layout_orizz_menu.SuspendLayout();
            this.MainMenuStrip.SuspendLayout();
            this.pan_Menu_exit.SuspendLayout();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // layout_Menu
            // 
            this.layout_Menu.AutoScroll = true;
            this.layout_Menu.AutoSize = true;
            this.layout_Menu.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.layout_Menu.ColumnCount = 16;
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.25F));
            this.layout_Menu.Controls.Add(this.layout_orizz_menu, 0, 0);
            this.layout_Menu.Controls.Add(this.metroPanel1, 0, 1);
            this.layout_Menu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout_Menu.Location = new System.Drawing.Point(20, 60);
            this.layout_Menu.Name = "layout_Menu";
            this.layout_Menu.RowCount = 2;
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_Menu.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.layout_Menu.Size = new System.Drawing.Size(760, 370);
            this.layout_Menu.TabIndex = 1;
            // 
            // layout_orizz_menu
            // 
            this.layout_orizz_menu.BackColor = System.Drawing.Color.Gainsboro;
            this.layout_orizz_menu.ColumnCount = 10;
            this.layout_Menu.SetColumnSpan(this.layout_orizz_menu, 20);
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.layout_orizz_menu.Controls.Add(this.MainMenuStrip, 0, 0);
            this.layout_orizz_menu.Controls.Add(this.pan_Menu_exit, 10, 0);
            this.layout_orizz_menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.layout_orizz_menu.Location = new System.Drawing.Point(3, 3);
            this.layout_orizz_menu.Name = "layout_orizz_menu";
            this.layout_orizz_menu.RowCount = 1;
            this.layout_orizz_menu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.layout_orizz_menu.Size = new System.Drawing.Size(754, 25);
            this.layout_orizz_menu.TabIndex = 119;
            // 
            // MainMenuStrip
            // 
            this.MainMenuStrip.BackColor = System.Drawing.Color.Transparent;
            this.layout_orizz_menu.SetColumnSpan(this.MainMenuStrip, 9);
            this.MainMenuStrip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.programmazioneSchedeToolStripMenuItem,
            this.spedizioneToolStripMenuItem,
            this.gestioneDelFirmwareToolStripMenuItem,
            this.reportToolStripMenuItem});
            this.MainMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.MainMenuStrip.Name = "MainMenuStrip";
            this.MainMenuStrip.Size = new System.Drawing.Size(675, 25);
            this.MainMenuStrip.TabIndex = 83;
            this.MainMenuStrip.Text = "menuStrip1";
            // 
            // programmazioneSchedeToolStripMenuItem
            // 
            this.programmazioneSchedeToolStripMenuItem.Name = "programmazioneSchedeToolStripMenuItem";
            this.programmazioneSchedeToolStripMenuItem.Size = new System.Drawing.Size(151, 21);
            this.programmazioneSchedeToolStripMenuItem.Text = "Programmazione Schede";
            this.programmazioneSchedeToolStripMenuItem.Click += new System.EventHandler(this.programmazioneSchedeToolStripMenuItem_Click);
            // 
            // spedizioneToolStripMenuItem
            // 
            this.spedizioneToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fasiDiAvanzamentoToolStripMenuItem,
            this.spedizioneToolStripMenuItem1});
            this.spedizioneToolStripMenuItem.Name = "spedizioneToolStripMenuItem";
            this.spedizioneToolStripMenuItem.Size = new System.Drawing.Size(115, 21);
            this.spedizioneToolStripMenuItem.Text = "Fasi di lavorazione";
            // 
            // fasiDiAvanzamentoToolStripMenuItem
            // 
            this.fasiDiAvanzamentoToolStripMenuItem.Name = "fasiDiAvanzamentoToolStripMenuItem";
            this.fasiDiAvanzamentoToolStripMenuItem.Size = new System.Drawing.Size(281, 22);
            this.fasiDiAvanzamentoToolStripMenuItem.Text = "Fasi di avanzamento";
            this.fasiDiAvanzamentoToolStripMenuItem.Click += new System.EventHandler(this.fasiDiAvanzamentoToolStripMenuItem_Click);
            // 
            // spedizioneToolStripMenuItem1
            // 
            this.spedizioneToolStripMenuItem1.Name = "spedizioneToolStripMenuItem1";
            this.spedizioneToolStripMenuItem1.Size = new System.Drawing.Size(281, 22);
            this.spedizioneToolStripMenuItem1.Text = "Check-out Collaudo/Confezionamento";
            this.spedizioneToolStripMenuItem1.Click += new System.EventHandler(this.spedizioneToolStripMenuItem1_Click);
            // 
            // gestioneDelFirmwareToolStripMenuItem
            // 
            this.gestioneDelFirmwareToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.classicLineToolStripMenuItem,
            this.smartLineToolStripMenuItem});
            this.gestioneDelFirmwareToolStripMenuItem.Name = "gestioneDelFirmwareToolStripMenuItem";
            this.gestioneDelFirmwareToolStripMenuItem.Size = new System.Drawing.Size(136, 21);
            this.gestioneDelFirmwareToolStripMenuItem.Text = "Gestione del Firmware";
            // 
            // classicLineToolStripMenuItem
            // 
            this.classicLineToolStripMenuItem.Name = "classicLineToolStripMenuItem";
            this.classicLineToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.classicLineToolStripMenuItem.Text = "- Classic Line -";
            // 
            // smartLineToolStripMenuItem
            // 
            this.smartLineToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fWPalmariToolStripMenuItem1,
            this.fWRicevitoriToolStripMenuItem1});
            this.smartLineToolStripMenuItem.Name = "smartLineToolStripMenuItem";
            this.smartLineToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.smartLineToolStripMenuItem.Text = "- Smart Line -";
            // 
            // fWPalmariToolStripMenuItem1
            // 
            this.fWPalmariToolStripMenuItem1.Name = "fWPalmariToolStripMenuItem1";
            this.fWPalmariToolStripMenuItem1.Size = new System.Drawing.Size(143, 22);
            this.fWPalmariToolStripMenuItem1.Text = "FW Palmari";
            this.fWPalmariToolStripMenuItem1.Click += new System.EventHandler(this.fWPalmariToolStripMenuItem1_Click);
            // 
            // fWRicevitoriToolStripMenuItem1
            // 
            this.fWRicevitoriToolStripMenuItem1.Name = "fWRicevitoriToolStripMenuItem1";
            this.fWRicevitoriToolStripMenuItem1.Size = new System.Drawing.Size(143, 22);
            this.fWRicevitoriToolStripMenuItem1.Text = "FW Ricevitori";
            this.fWRicevitoriToolStripMenuItem1.Click += new System.EventHandler(this.fWRicevitoriToolStripMenuItem1_Click);
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.prodottiAttivatiToolStripMenuItem,
            this.schedeProdottiToolStripMenuItem,
            this.raccoltaDocumentiKitToolStripMenuItem,
            this.toolStripSeparator1,
            this.codificaKitToolStripMenuItem,
            this.toolStripSeparator2,
            this.verificaFattibilitàToolStripMenuItem});
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(100, 21);
            this.reportToolStripMenuItem.Text = "Report - Analisi";
            // 
            // prodottiAttivatiToolStripMenuItem
            // 
            this.prodottiAttivatiToolStripMenuItem.Name = "prodottiAttivatiToolStripMenuItem";
            this.prodottiAttivatiToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.prodottiAttivatiToolStripMenuItem.Text = "Prodotti attivati";
            this.prodottiAttivatiToolStripMenuItem.Click += new System.EventHandler(this.prodottiAttivatiToolStripMenuItem_Click);
            // 
            // schedeProdottiToolStripMenuItem
            // 
            this.schedeProdottiToolStripMenuItem.Name = "schedeProdottiToolStripMenuItem";
            this.schedeProdottiToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.schedeProdottiToolStripMenuItem.Text = "Schede Prodotti";
            this.schedeProdottiToolStripMenuItem.Click += new System.EventHandler(this.schedeProdottiToolStripMenuItem_Click);
            // 
            // raccoltaDocumentiKitToolStripMenuItem
            // 
            this.raccoltaDocumentiKitToolStripMenuItem.Name = "raccoltaDocumentiKitToolStripMenuItem";
            this.raccoltaDocumentiKitToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.raccoltaDocumentiKitToolStripMenuItem.Text = "Raccolta Documenti - Kit";
            this.raccoltaDocumentiKitToolStripMenuItem.Visible = false;
            this.raccoltaDocumentiKitToolStripMenuItem.Click += new System.EventHandler(this.raccoltaDocumentiKitToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(242, 6);
            // 
            // codificaKitToolStripMenuItem
            // 
            this.codificaKitToolStripMenuItem.Name = "codificaKitToolStripMenuItem";
            this.codificaKitToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.codificaKitToolStripMenuItem.Text = "Ricerca / Richiesta di codifica Kit";
            this.codificaKitToolStripMenuItem.Click += new System.EventHandler(this.codificaKitToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(242, 6);
            // 
            // verificaFattibilitàToolStripMenuItem
            // 
            this.verificaFattibilitàToolStripMenuItem.Name = "verificaFattibilitàToolStripMenuItem";
            this.verificaFattibilitàToolStripMenuItem.Size = new System.Drawing.Size(245, 22);
            this.verificaFattibilitàToolStripMenuItem.Text = "Verifica Fattibilità";
            this.verificaFattibilitàToolStripMenuItem.Click += new System.EventHandler(this.verificaFattibilitàToolStripMenuItem_Click);
            // 
            // pan_Menu_exit
            // 
            this.pan_Menu_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pan_Menu_exit.BackColor = System.Drawing.Color.Transparent;
            this.pan_Menu_exit.Dock = System.Windows.Forms.DockStyle.None;
            this.pan_Menu_exit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_sw_exit});
            this.pan_Menu_exit.Location = new System.Drawing.Point(679, 0);
            this.pan_Menu_exit.Name = "pan_Menu_exit";
            this.pan_Menu_exit.Size = new System.Drawing.Size(75, 24);
            this.pan_Menu_exit.TabIndex = 82;
            this.pan_Menu_exit.Text = "menuStrip1";
            this.pan_Menu_exit.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.pan_Menu_exit_ItemClicked);
            // 
            // menu_sw_exit
            // 
            this.menu_sw_exit.Image = ((System.Drawing.Image)(resources.GetObject("menu_sw_exit.Image")));
            this.menu_sw_exit.Name = "menu_sw_exit";
            this.menu_sw_exit.Size = new System.Drawing.Size(67, 20);
            this.menu_sw_exit.Text = "Uscita";
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroPanel1.BackgroundImage")));
            this.metroPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.layout_Menu.SetColumnSpan(this.metroPanel1, 16);
            this.metroPanel1.Controls.Add(this.lab_resources_path);
            this.metroPanel1.Controls.Add(this.pictureBox1);
            this.metroPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(3, 34);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(754, 333);
            this.metroPanel1.TabIndex = 120;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // lab_resources_path
            // 
            this.lab_resources_path.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lab_resources_path.AutoSize = true;
            this.lab_resources_path.BackColor = System.Drawing.Color.Transparent;
            this.lab_resources_path.ForeColor = System.Drawing.Color.White;
            this.lab_resources_path.Location = new System.Drawing.Point(3, 314);
            this.lab_resources_path.Name = "lab_resources_path";
            this.lab_resources_path.Size = new System.Drawing.Size(81, 19);
            this.lab_resources_path.TabIndex = 3;
            this.lab_resources_path.Text = "metroLabel1";
            this.lab_resources_path.UseCustomBackColor = true;
            this.lab_resources_path.UseCustomForeColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(300, 99);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(150, 150);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // miniToolStrip
            // 
            this.miniToolStrip.AccessibleName = "Selezione nuovo elemento";
            this.miniToolStrip.AccessibleRole = System.Windows.Forms.AccessibleRole.ComboBox;
            this.miniToolStrip.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.miniToolStrip.AutoSize = false;
            this.miniToolStrip.BackColor = System.Drawing.Color.Gainsboro;
            this.miniToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.miniToolStrip.Location = new System.Drawing.Point(0, 0);
            this.miniToolStrip.Name = "miniToolStrip";
            this.miniToolStrip.Size = new System.Drawing.Size(75, 24);
            this.miniToolStrip.TabIndex = 82;
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.layout_Menu);
            this.IsMdiContainer = true;
            this.Name = "MainMenu";
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "Sistematica - Factory";
            this.TransparencyKey = System.Drawing.Color.Empty;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainMenu_Load);
            this.MdiChildActivate += new System.EventHandler(this.MainMenu_MdiChildActivate);
            this.layout_Menu.ResumeLayout(false);
            this.layout_orizz_menu.ResumeLayout(false);
            this.layout_orizz_menu.PerformLayout();
            this.MainMenuStrip.ResumeLayout(false);
            this.MainMenuStrip.PerformLayout();
            this.pan_Menu_exit.ResumeLayout(false);
            this.pan_Menu_exit.PerformLayout();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel layout_Menu;
        private System.Windows.Forms.TableLayoutPanel layout_orizz_menu;
        private System.Windows.Forms.MenuStrip MainMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem programmazioneSchedeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spedizioneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fasiDiAvanzamentoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spedizioneToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem gestioneDelFirmwareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prodottiAttivatiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem schedeProdottiToolStripMenuItem;
        private System.Windows.Forms.MenuStrip pan_Menu_exit;
        private System.Windows.Forms.ToolStripMenuItem menu_sw_exit;
        private System.Windows.Forms.MenuStrip miniToolStrip;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.ToolStripMenuItem raccoltaDocumentiKitToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem codificaKitToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private MetroFramework.Controls.MetroLabel lab_resources_path;
        private System.Windows.Forms.ToolStripMenuItem classicLineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem smartLineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fWPalmariToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem fWRicevitoriToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem verificaFattibilitàToolStripMenuItem;
    }
}

