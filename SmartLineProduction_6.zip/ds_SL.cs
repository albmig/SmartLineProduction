﻿namespace SmartLineProduction
{


    public partial class ds_SL
    {
    }
}
