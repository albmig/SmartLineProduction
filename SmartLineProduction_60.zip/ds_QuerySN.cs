﻿namespace SmartLineProduction
{


    partial class ds_QuerySN
    {
    }
}
